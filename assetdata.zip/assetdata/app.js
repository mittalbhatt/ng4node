const http = require('http');
fs = require('fs');
//var mysqlApostrophe = require("mysql-apostrophe");
var express = require('express');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
var cookieParser = require('cookie-parser');
var csrf = require('csurf');
global.app = express();
var passport = require('./server/config/passport');
var server = http.createServer(app);
global.dateFormat = require('dateformat');
global.io = require('socket.io')(server);
var port = process.env.PORT || 3005;
global._ = require('underscore');
var session = require('express-session'); // Added for o365

require('dotenv').config();

app.use(cookieParser());

// Added for o365
app.use(session(
  { secret: 'BD7I4um/JuiAxgLkirV6KRT4FVaMq1cLxulaFB5hbC8=',
    resave: false,
    saveUninitialized: false 
}));

// Global function is here
//global = require('./config/global');
// Configuration Variables
//var config    = require('./config/config');\\

global.multipart = require('connect-multiparty');
global.multipartMiddleware = multipart();


app.use(function(req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.set('appPath', __dirname +'/dist');
app.use(express.static(__dirname +'/dist'));

app.use(passport.initialize());
app.use(passport.session());

//var csrfProtection = csrf({ cookie: true });
//var parseForm = bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit:50000 });

app.use(bodyParser.json({limit: "50mb"}));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit:50000 }));
app.use(expressValidator());
//app.use(cookieParser());
app.use(csrf({ cookie: true }));
//app.use(mysqlApostrophe); //must be after bodyparser

app.use('/images/', express.static(__dirname +'/images'));

// ====================START: App ROUTE ================================================

var appRoute = require('./server/routes');
appRoute(app, io);


/* CUSTOMIZATION START - ASHWIN FOR WEBSERVICE */
global.WS = require(process.cwd() + '/api/common/WebService.js');
require(process.cwd() + '/api/v1/route_v1.js');
/* CUSTOMIZATION END - ASHWIN FOR WEBSERVICE */


// ============== Create CSRF Token ========================//
app.get('/token/form-token', function(req, res, next) {
	var token = req.csrfToken();
	res.send({"success":true,"token":token});
});

app.use(function (err, req, res, next) {
  if (err.code !== 'EBADCSRFTOKEN') return next(err)
  // handle CSRF token errors here
  res.send({"success":false,"message":"Invalid session token.!","token":""})
});

// ============== Create CSRF Token ========================//

// ====================END: App ROUTE ==================================================

app.use('/*', function(req, res, next) {
	res.sendFile(app.get('appPath') + '/index.html');
});
app.use(app.oauth.errorHandler())

server.listen(port, function () {
  console.log('Express server listening on port '+ port);
});

exports = module.exports = app;
