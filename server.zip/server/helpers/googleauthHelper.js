var http = require('http');
var express = require('express');
var Session = require('express-session');
//var google = require('googleapis');
const {google} = require('googleapis');
var plus = google.plus('v1');
var OAuth2 = google.auth.OAuth2;
const ClientId = "57025079773-qj7a0ru0qikhv9raqe9h9vgn0a8see8f.apps.googleusercontent.com";
const ClientSecret = "XExuheUbcRaT4fBlqJ_8LdLe";






//const RedirectionUrl = "http://localhost:1234/oauthCallback";
const RedirectionUrl = "http://texas.smartoffice.com:3005/settings";
var settingsController = require('../controllers/settingsController');

var app = express();
app.use(Session({
    secret: 'raysources-secret-19890913007',
    resave: true,
    saveUninitialized: true
}));

// function getOAuthClient () {
//     return new OAuth2(ClientId ,  ClientSecret, RedirectionUrl);
// }
module.exports = {
  getOAuthClient: function() {
    return new OAuth2(ClientId ,  ClientSecret, RedirectionUrl);
  },
 getAuthUrl: function() {
    var oauth2Client = this.getOAuthClient();
    // generate a url that asks permissions for Google+ and Google Calendar scopes
    var scopes = [
      //'https://www.googleapis.com/auth/plus.me'
    'https://www.googleapis.com/auth/plus.login', 'https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/calendar'
    ];
   

    var url = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });

    return url;
},
 getTokenFromCode: function(auth_code, callback, request, response) {
  
  var oauth2Client = this.getOAuthClient();
    var session = request.session;
    var code = auth_code;
//   oauth2Client.on('tokens', (tokens) => {
//   if (tokens.refresh_token) {
//     console.log('refreshtokens===========================');
//     // store the refresh_token in my database!
//     console.log(tokens.refresh_token);
//   }
//   console.log(tokens.access_token);
// });
    oauth2Client.getToken(code, function(err, tokens) {
      // Now tokens contains an access_token and an optional refresh_token. Save them.
      if(!err) {
        var setcread=oauth2Client.setCredentials(tokens);
 if (tokens.refresh_token) {
    console.log('refreshtokens===========================');
    // store the refresh_token in my database!
    console.log(tokens.refresh_token);
  }
        var tokan=tokens;
        session["tokens"]=tokens;
         console.log('tokens===========================');
        console.log(tokan);
       // console.log( session["tokens"]);
         settingsController.upsertConfigurationUserforgoogle(request, response, tokan);  
         callback(request, response, null, tokan);
       // res.send('<h3>Login successful!!</h3><a href="/details">Go to details page</a>;');
      }
      else{
        console.log('Access token error: ', error.message);
          console.log(error);
          callback(request ,response, error, null);
      }
    });
   
   },

   createEvent: function( results, attendiesForgoogle, newEvent) {
 var oauth2Client = this.getOAuthClient();
     console.log('oauth2Client==========');
  console.log(newEvent.start.dateTime);
  console.log(newEvent.start.dateTime.toISOString().replace('Z', ''));
  var startdate=newEvent.start.dateTime.toISOString().replace('Z', '');

  var enddate=newEvent.end.dateTime.toISOString().replace('Z', '');
    oauth2Client.setCredentials({ access_token: results[0].google_access_token,
  token_type: 'Bearer',
  refresh_token:results[0].google_refresh_token,
  id_token: results[0].google_id_token,
  expiry_date: results[0].google_token_expire_at });

     var resource = {
        summary: newEvent.summary,
        location: newEvent.location,
        description: newEvent.description,
        start: {
            'dateTime': startdate,
            'timeZone': newEvent.start.timeZone
          },
        end: {
            'dateTime': enddate,
            'timeZone': newEvent.end.timeZone,
        },

       
        
    }; 
    console.log(resource);

    var calendar = google.calendar('v3');
    calendar.events.insert({
    auth: oauth2Client,
    calendarId: 'primary',
    sendNotifications: true,
    resource: resource

    },function(err,resp) {
      console.log('eventcreated=========')
        if (err) {
           // resp.send('There was an error : ' + err);
           // return;
        }
           // resp.send(resp,'Event created:', resp.htmlLink);
        }
    )

  },
  getTokenFromRefreshToken: function(refresh_token, callback, request, response, resolve) {
    var token = oauth2.accessToken.create({ refresh_token: refresh_token, expires_in: 0});
    token.refresh(function(error, result) {
      if (error) {
        console.log('Refresh token error: ', error.message);
        callback(request, response, error, null);
      }
      else {
        console.log('New token: ', result.token);
        settingsController.upsertConfigurationUserforgoogle(request, response, result);
        resolve(true);
        //callback(request, response, null, result);
      }
    });
  },

  //   getTokenFromCode: function(auth_code, callback, request, response) {
  //   oauth2.authCode.getToken({
  //     code: auth_code,
  //     redirect_uri: redirectUri,
  //     scope: scopes
  //     }, function (error, result) {
  //       if (error) {
  //         console.log('Access token error: ', error.message);
  //         console.log(error);
  //         callback(request ,response, error, null);
  //       }
  //       else {
  //         var token = oauth2.accessToken.create(result);

  //         settingsController.upsertConfigurationUser(request, response, token);  
          
  //         callback(request, response, null, token);
  //       }
  //     });
  // }
};

// app.use("/settings", function (req, res) {
//  console.log('testcode=====================================');
//     var oauth2Client = getOAuthClient();
//     var session = req.session;
//     var code = req.query.code;
//     oauth2Client.getToken(code, function(err, tokens) {
//       // Now tokens contains an access_token and an optional refresh_token. Save them.
//       if(!err) {
//         oauth2Client.setCredentials(tokens);
//         session["tokens"]=tokens;
//         console.log(tokens);
//         res.send('<h3>Login successful!!</h3><a href="/details">Go to details page</a>;');
//       }
//       else{
//         res.send('Login failed!!');
//       }
//     });
// });

app.use("/details", function (req, res) {
    var oauth2Client = getOAuthClient();
    oauth2Client.setCredentials(req.session["tokens"]);
    var test = listEvents(oauth2Client);

    
    var p = new Promise(function (resolve, reject) {
        plus.people.get({ userId: 'me', auth: oauth2Client }, function(err, response) {
            resolve(response || err);
        });
    }).then(function (data) {
        res.send('<img src='+data.image.url+'><h3>Hello '+data.displayName+'</h3><br/><br/><a href="/create">Create Meeting</a>');

    })
});

function listEvents(auth) {
  // const calendar = google.calendar({version: 'v3', auth});
  // calendar.events.list({
  //   calendarId: 'primary',
  //   timeMin: (new Date()).toISOString(),
  //   maxResults: 10,
  //   singleEvents: true,
  //   orderBy: 'startTime',
  // }, (err, res) => {

    
  //   if (err) return console.log('The API returned an error: ' + err);
  //   const events = res.items;
  //   if (events.length) {
  //     console.log('Upcoming 10 events:');
  //     events.map((event, i) => {
  //       const start = event.start.dateTime || event.start.date;
  //       console.log(`${start} - ${event.summary}`);
  //     });
  //   } else {
  //     console.log('No upcoming events found.');
  //   }
  // });
  app.use("/create", function (req, res) {
    var oauth2Client = getOAuthClient();
     console.log('oauth2Client==========');
    console.log(oauth2Client);
    oauth2Client.setCredentials(req.session["tokens"]);

    var resource = {
        summary: "Google Meeting testing",
        location: "Coffee Room",
        description: 'A chance to hear more about Google\'s developer products.',
        start: {
            'dateTime': '2018-07-27T09:00:00-07:00',
            'timeZone': 'America/Los_Angeles',
          },
        end: {
            'dateTime': '2018-07-27T13:00:00-07:00',
            'timeZone': 'America/Los_Angeles',
        },

        attendees: [
            {'email': 'mittal.bhatt@softwebsolutions.com'}
            //{'email': 'jignesh.vagh@softwebsolutions.com'},
        ]
        
    }; 

    var calendar = google.calendar('v3');
    calendar.events.insert({
    auth: oauth2Client,
    calendarId: 'primary',
    sendNotifications: true,
    resource: resource

    },function(err,resp) {
        if (err) {
            res.send('There was an error : ' + err);
            return;
        }
            res.send(resp,'Event created:', resp.htmlLink);
        }
    )
});
}



app.use("/create", function (req, res) {
    var oauth2Client = getOAuthClient();
    console.log(oauth2Client);
    oauth2Client.setCredentials(req.session["tokens"]);

    var resource = {
        summary: "Google Meeting testing",
        location: "Coffee Room",
        description: 'A chance to hear more about Google\'s developer products.',
        start: {
            'dateTime': '2018-07-13T09:00:00-07:00',
            'timeZone': 'America/Los_Angeles',
          },
        end: {
            'dateTime': '2018-07-13T13:00:00-07:00',
            'timeZone': 'America/Los_Angeles',
        },

        attendees: [
            {'email': 'rohan@softwebsolutions.com'},
            {'email': 'jignesh.vagh@softwebsolutions.com'},
        ]
        
    }; 

    var calendar = google.calendar('v3');
    calendar.events.insert({
    auth: oauth2Client,
    calendarId: 'primary',
    sendNotifications: true,
    resource: resource

    },function(err,resp) {
        if (err) {
            res.send('There was an error : ' + err);
            return;
        }
            res.send(resp,'Event created:', resp.htmlLink);
        }
    )
});

app.use("/", function (req, res) {
    var url = getAuthUrl();
    res.send('<h1>Authentication using google oAuth</h1><a href='+url+'>Login</a>')
});


var port = 1234;
var server = http.createServer(app);
server.listen(port);
server.on('listening', function () {
    console.log('listening to '+port);
});
