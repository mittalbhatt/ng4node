'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg
var conn = require('../config/mysql-connection');
var connection = conn.connection;

/**
 * @uses get floor listing data
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.floorsList = function (req, res, next) {

	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;

	var domain = generalConfig.getDomain(req);
	var imagePathObj = generalConfig.getFilePath(domain, "floor", "main", "sub");

	generalConfig.getDataBase(req, res, function(company_databasename){
		if(company_databasename != null){ 
			var query = "SELECT `Floors`.`floor_id`, `Floors`.`floor_name`, `Floors`.`floor_no`, `Floors`.`building_id`, `Floors`.`floor_plan_image`, `Floors`.`status`, `Building`.`building_id` AS `buildingId`, `Building`.`building_name` AS `building_name` FROM "+company_databasename+".`so_floors` AS `Floors` LEFT OUTER JOIN "+company_databasename+".`so_buildings` AS `Building` ON `Floors`.`building_id` = `Building`.`building_id` WHERE `Floors`.`deleted_at` IS NULL AND (`Floors`.`floor_name` LIKE '%"+search+"%' OR `Floors`.`floor_no` LIKE '%"+search+"%' OR `Building`.`building_name` LIKE '%"+search+"%') ORDER BY `Floors`.`"+sort+"` "+orderBy;
			var countQuery = query;
			    query += " LIMIT "+perPage+" OFFSET "+offset+"";
			connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                    //accessObj.then(function(resp){
                        results.forEach(function(val){
                            if(val.floor_plan_image != ""){
                                var path = imagePathObj.mainLink+'/80x80/'+val.floor_plan_image;
                                if(!generalConfig.checkFilePath(path)){
                                   val.image_path = generalConfig.no_image_80;
                                }else{
                                   val.image_path = generalConfig.imageUrl(path);
                                }
                            } else {
                                val.image_path = generalConfig.no_image_80;
                            }
                        });
                        generalConfig.getFloorTotalCount(req, res, countQuery,  function(count){
                            count = (count != null)?count:0;
                            return res.json({
                                'success' : true,
                                'data' : results,
                                'draw' : draw,
                                //'accessObj' :resp,
                                'recordsTotal' : count,
                                'recordsFiltered' : count,
                                'message': message.SUCCESS
                            });
                        });
                    //});
                }
            });

		} else {
			return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
		}
	});
};


/**
 * @uses Get Building data for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.buildingList = function (req, res, next) {
	generalConfig.getDataBase(req, res, function(company_databasename){ 
		if(company_databasename != null){
			var query = "SELECT `building_id`, `building_name` FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`deleted_at` IS NULL AND `status` = 1";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        return res.json({
							'success': true,
							'data': results,
							'message': message.SUCCESS
						});
                    }
                });

		} else {
			res.json({
                'success': false,
                'message': message.ERROR,
            });
		}
	});

	// db.models.Building.findAll({
	// 	where: {
	// 		deleted_at: { $eq: null },
	// 		status: { $eq: 1 }			
	// 	},
	// 	attributes: [
	// 		'building_id',
	// 		'building_name'
	// 	]		
	// }).then(function (data) {
	// 	res.json({
	// 		'success': true,
	// 		'data': data,
	// 		'message': message.SUCCESS
	// 	});
	// }).catch(function (err) {
	// 	res.json({
	// 		'success': false,
	// 		'message': message.ERROR,
	// 		'error': err
	// 	});
	// });
}


/**
 * @uses create new floor
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.insertFloor = function (req, res, next) {

	var base64Image = req.body.floor_plan_image;
    var filename = req.body.plan_image_name;
	var timestamp = Math.floor(new Date() / 1000);
	var newFile = null;
	var statusValue = (req.body.status==1 || req.body.status==true) ? 1 : 0; 	

	var building_id = req.body.building_id;
	var floor_no = (req.body.floor_no)?req.body.floor_no:'';
	var floor_name = (req.body.floor_name)?req.body.floor_name:'';

	req.checkBody("building_id", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("floor_no", message.NO_FLOOR_REQUIRE).notEmpty();
	if (req.body.floor_no) {
        req.checkBody("floor_no", message.NO_FLOOR_NUMERIC).isInt();
    }
	req.checkBody("floor_name", message.FLOOR_NAME_REQUIRE).notEmpty();

	var errMsg = {};
	var errors = req.validationErrors();
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });
    } else {

    	generalConfig.getDataBase(req, res, function(company_databasename){ 
    		
    		if(company_databasename != null){
    			var query = "SELECT `floor_id`, `floor_name`, `floor_no`, `building_id`, `floor_plan_image`, `status`, `created_at` AS `createdAt`, `updated_at` AS `updatedAt`, `deleted_at` FROM "+company_databasename+".`so_floors` AS `Floors` WHERE `Floors`.`building_id` = '"+building_id+"' AND (`Floors`.`floor_no` = '"+floor_no+"' OR `Floors`.`floor_name` = '"+floor_name+"') AND `Floors`.`deleted_at` IS NULL";
                connection.query(query, function (error, results, fields) { 
                	if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });

                    } 
                    else if(results){
                    	if(results.length >0){
                    		res.json({
								success: false,
								message: message.FLOOR_IN_USED
							});
                    	} else {

                    		var new_file_name = "";
					        var doamin = generalConfig.getDomain(req);
					        var resObj = upload.uploadImage(doamin, "floor", base64Image, filename, "", "", "");
					        var GUID = generalConfig.generateGUID();
					        var createDate = generalConfig.getDateTimeUTC();

					        if(resObj.success == true){
					            new_file_name = resObj.file_name;
					        } else {
					            return res.json({
					                'success': resObj.success,
					                'message': resObj.message
					            });
					            
					        }

					        var insertQuery = "INSERT INTO "+company_databasename+".`so_floors` (`floor_id`,`floor_name`,`floor_no`,`building_id`,`floor_plan_image`,`status`, `created_at`, `updated_at`) VALUES ('"+GUID+"','"+floor_name+"','"+floor_no+"','"+building_id+"','"+new_file_name+"',"+statusValue+",'"+createDate+"','"+createDate+"')";
					        connection.query(insertQuery, function (error, results, fields) { 
					        	if(error){
			                        return res.json({
			                            'success': false,
			                            'message': message.ERROR,
			                            'error': error
			                        });
			                    } else if(results){ 
			                    	res.json({
										success: true,
										data: null,
										message: message.FLOOR_ADD_SUCCESS
									});
			                    }
					        });
                    	}
                    }
                });
    		} else {
    			res.json({
                    'success': false,
                    'message': message.ERROR,
                });
    		}
    	});
	}
};


/**
 * @uses Get floor data by id for update page
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.getFloorById = function (req, res, next) {
	var floor_id = req.params.id;
	if(floor_id){
		generalConfig.getDataBase(req, res, function(company_databasename){ 
			if(company_databasename != ""){
				var query = "SELECT `floor_id`, `floor_name`, `floor_no`, `building_id`, `floor_plan_image`, `status`, `created_at` AS `createdAt`, `updated_at` AS `updatedAt`, `deleted_at` FROM "+company_databasename+".`so_floors` AS `Floors` WHERE `Floors`.`floor_id` = '"+floor_id+"'";
				connection.query(query, function (error, results, fields) { 
					if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    }
                    if(results.length > 0){

                    	var building_id = results[0].building_id;
                    	if(building_id){
                    		var query = "SELECT `no_of_floor` FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`building_id` = '"+building_id+"'";

                    		connection.query(query, function (error, building_result, fields) { 
                    			if(error){
			                        return res.json({
			                            'success': false,
			                            'message': message.ERROR,
			                            'error': error
			                        });
			                    }

			                    if(building_result){
			                    	var domain = generalConfig.getDomain(req);
    								var imagePathObj = generalConfig.getFilePath(domain, "floor", "main", "sub");
			                    	
			                    	if(results[0].floor_plan_image != ""){
			                            var path = imagePathObj.mainLink+'/'+results[0].floor_plan_image;
			                            if(!generalConfig.checkFilePath(path)){
			                               results[0].image = generalConfig.no_image_200;
			                            }else{
			                               results[0].image = generalConfig.imageUrl(path);
			                            }
			                        } else {
			                            results[0].image = generalConfig.no_image_200;
			                        }


			                        var no_floor = building_result[0].no_of_floor;
				                    var floorArr = [];

				                    if(no_floor > 0){
				                        for (var i = 1; i <= no_floor; i++) {
				                           floorArr.push({"key":i, "value":i});
				                        }
				                    }

				                    results[0].floorArr = floorArr;
				                    results = results[0];
				                    res.json({
					                    'success' : true,
					                    'data' : results,
					                    'message': message.SUCCESS
					                });
			                    }
                    		});
                    	}
                    }
				});

			} else {
				return res.json({
	                'success': false,
	                'message': message.ERROR
	            }); 
			}
		});
	} else {
		return res.json({
            'success': false,
            'message': message.ERROR
        });
	}
};


/**
 * @uses update specific floor value
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.updateFloor = function (req, res, next) {


	
	
	var base64Image = req.body.floor_plan_image;
    var filename = req.body.new_floor_plan_image;
    var old_filename = req.body.old_floor_plan_image;
    var removeImage = req.body.removeImage;
	var statusValue = (req.body.status==1 || req.body.status==true) ? 1 : 0; 	


    req.checkBody("building_id", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("floor_name", message.FLOOR_NAME_REQUIRE).notEmpty();
    req.checkBody("floor_no", message.NO_FLOOR_REQUIRE).notEmpty();
	if (req.body.floor_no) {
        req.checkBody("floor_no", message.NO_FLOOR_NUMERIC).isInt();
    }

	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {

    	 generalConfig.getDataBase(req, res, function(company_databasename){  
            if(company_databasename != null){ 
            	var floor_name = req.body.floor_name;
				var floor_no = req.body.floor_no;
				var building_id = req.body.building_id;
				var floor_id = req.body.floor_id;

            	var query = "SELECT `floor_id`, `floor_name`, `floor_no`, `building_id`, `floor_plan_image`, `status`, `created_at` AS `createdAt`, `updated_at` AS `updatedAt`, `deleted_at` FROM "+company_databasename+".`so_floors` AS `Floors` WHERE `Floors`.`building_id` = '"+building_id+"' AND (`Floors`.`floor_no` = '"+floor_no+"' OR `Floors`.`floor_name` = '"+floor_name+"') AND `Floors`.`floor_id` != '"+floor_id+"' AND `Floors`.`deleted_at` IS NULL";
            	
            	console.log('-----------------');
            	console.log(query);
            	console.log('-----------------');
            	connection.query(query, function (error, results, fields) { 
                	if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });

                    }
                    else if(results) {

                    if(results.length >0){
                    		res.json({
								success: false,
								message: message.FLOOR_IN_USED
							});
                    	} else {

		                var new_file_name = "";
				    	var doamin = generalConfig.getDomain(req);
				        var resObj = upload.uploadImage(doamin, "floor", base64Image, filename, old_filename, removeImage, "");
				        var updateDate = generalConfig.getDateTimeUTC();
				        var floor_id = req.body.floor_id;

				        if(resObj.success == true){
				            new_file_name = resObj.file_name;
				        } else {
							return res.json({
				                'success': resObj.success,
				                'message': resObj.message
				            });
				        }

				        
						var floor_name = req.body.floor_name;
						var floor_no = req.body.floor_no;
						var building_id = req.body.building_id;

		            	var query = "UPDATE "+company_databasename+".`so_floors` SET `floor_name`='"+floor_name+"',`floor_no`="+floor_no+",`building_id`='"+building_id+"',`floor_plan_image`='"+new_file_name+"',`status`="+statusValue+",`updated_at`='"+updateDate+"' WHERE `floor_id` = '"+req.body.floor_id+"'";
		                connection.query(query, function (error, results, fields) {
		                    if(error){
		                        return res.json({
		                            'success': false,
		                            'message': message.ERROR,
		                            'error': error
		                        });
		                    } else if(results){
		                        return res.json({
		                            'success' : true,
		                            'message': message.FLOOR_UPDATE_SUCCESS
		                        });
		                    }
		                });
                    }
                }
                })
            }


    	else {
            	return res.json({
                    'success': false,
                    'message': message.ERROR
                });
            }
        });
    }
};

/**
 * @uses update specific space status value
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.updateFloorStatus = function (req, res, next) {

	var statusValue = (req.body.status==1) ? 0 : 1; 	
	var updateDate = generalConfig.getDateTimeUTC();
	var floor_id = req.body.id;

	if(floor_id){
		generalConfig.getDataBase(req, res, function(company_databasename){  
			if(company_databasename != null){ 
				var query = "UPDATE "+company_databasename+".`so_floors` AS `Floors` SET `Floors`.`status`='"+statusValue+"', `Floors`.`updated_at`='"+updateDate+"' WHERE `Floors`.`floor_id` = '"+floor_id+"'";
	                connection.query(query, function (error, results, fields) {
	                    if(error){
	                        return res.json({
	                            'success': false,
	                            'message': message.ERROR,
	                            'error': error
	                        });
	                    } else if(results){
	                        return res.json({
	                            'success' : true,
	                            'message': message.STATUS_UPDATE
	                        });
	                    }
	                });

			} else {
				res.json({
	                'success': false,
	                'message': message.ERROR,
	            });
			}
		});
	}else {
		res.json({
		    'success': false,
		    'message': message.ERROR,
		});
	}
};

/**
 * @uses soft delete floor data by id 
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
 
exports.removeFloor = function (req, res) {
	// var floor_id = req.body.id;
	// if(floor_id){
	// 	generalConfig.getDataBase(req, res, function(company_databasename){ 

	// 		if(company_databasename != null){ 
	// 			var findSpace = "SELECT `space_name`, `floor_id` FROM `so_spaces` AS `Space` WHERE smartoffice_softweb.`Space`.`floor_id` = '"+floor_id+"'";

	// 			connection.query(findSpace, function (error, results, fields) { 
	// 				console.log(error);
	// 			});

 //                connection.query(query, function (error, results, fields) {

 //                    if(error){
 //                        return res.json({
 //                            'success': false,
 //                            'message': message.ERROR,
 //                            'error': error
 //                        });

 //                    } else if(results){
 //                    	if(results.length > 0){
 //                    		res.json({
	// 							success: false,
	// 							data: null,
	// 							message: message.FLOOR_ASS_SPACE
	// 						});
 //                    	} else {
 //                    		var updateDate = generalConfig.getDateTimeUTC();

 //                    		var query = "UPDATE smartoffice_softweb.`so_floors` AS `Floors` SET `Floors`.`updated_at`='"+updateDate+"' WHERE `Floors`.`floor_id` = '"+floor_id+"'";
	// 		                connection.query(query, function (error, results, fields) {
	// 		                    if(error){
	// 		                        return res.json({
	// 		                            'success': false,
	// 		                            'message': message.ERROR,
	// 		                            'error': error
	// 		                        });
	// 		                    } else if(results){
	// 		                        return res.json({
	// 		                            'success' : true,
	// 		                            'message': message.FLOOR_DELETE
	// 		                        });
	// 		                    }
	// 		                });
 //                    	}
 //                    }
 //                });

	// 		} else {
	// 			return res.json({
 //                    'success': false,
 //                    'message': message.ERROR
 //                });
	// 		}
	// 	});

		// db.models.Space.findOne({
		// 	where: { floor_id: floor_id }
		// }).then(function (floor) {

		// 	if(floor == null){

		// 		db.models.Floors.update(obj, {
		// 			where: { floor_id: floor_id }
		// 		}).then(function () {
		// 	        res.json({
		// 				success: true,
		// 				data: null,
		// 				message: message.FLOOR_DELETE
		// 			});
		// 	    }).catch(function (err) {
		// 	        res.json({
		// 				success: false,
		// 				data: null,
		// 				message: message.ERROR
		// 			});
		// 	    });
		// 	} else {

		//         res.json({
		// 			success: false,
		// 			data: null,
		// 			message: message.FLOOR_ASS_SPACE
		// 		});
		// 		return;
		// 	}


	 //    }).catch(function (err) {
	        
	 //        res.json({
		// 		success: false,
		// 		data: null,
		// 		message: message.ERROR
		// 	});
	 //    });
//	}

	
};


exports.removeFloorById = function (req, res) {
	var floor_id = req.body.id; 

	generalConfig.getDataBase(req, res, function(company_databasename){ 
		var findQuery = " SELECT space_name, floor_id FROM  "+company_databasename+".so_spaces  WHERE  floor_id = '"+floor_id+"' AND deleted_at IS NULL";

		if(company_databasename != null){ 
			connection.query(findQuery, function (error, results, fields) { 
				if(error){
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                } else {

                	if(results.length > 0){
                		res.json({
							success: false,
							data: null,
							message: message.FLOOR_ASS_SPACE
						});
                	} else {
	                	var updateDate = generalConfig.getDateTimeUTC();
                		var query = "UPDATE "+company_databasename+".`so_floors` AS `Floors` SET `Floors`.`deleted_at`='"+updateDate+"' WHERE `Floors`.`floor_id` = '"+floor_id+"'";
		                	
		                connection.query(query, function (error, results, fields) {
		                    if(error){
		                        return res.json({
		                            'success': false,
		                            'message': message.ERROR,
		                            'error': error
		                        });
		                    } else if(results){
		                        return res.json({
		                            'success' : true,
		                            'message': message.FLOOR_DELETE
		                        });
		                    }
			            });
			        }
                }
			});
		} else {
				return res.json({
                    'success': false,
                    'message': message.ERROR
                });
			}
		
	});
}


