'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var database = require('../config/database');
var master_database = database.master_database.name;
var async = require('async');
var dateFormat = require('dateformat');
var difference = require('array-difference');
var smtpTransport = generalConfig.smtpTransport;
var handlebars = require('handlebars');
var database = require('../config/database');
var master_database = database.master_database.name;



/**
 * @uses Get user inforamation
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
// exports.userInfo = function (req, res, next) {
// 	var userInfo = generalConfig.getUserInfo(req);
// 	console.log(userInfo);
// }


/**
 * @uses Get event data by id for update page
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.getEventById = function (req, res, next) {
 	var data = {};
    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

    var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"' ";


    connection.query(userQuery, function (error, userResult, fields) {
    
        if(userResult.length > 0){
            var email_id = userResult[0].email_id;
            var email = userResult[0].email;
            var time_difference = userResult[0].time_difference;

            generalConfig.getDataBase(req, res, function(company_databasename){
                
                if(company_databasename != null){ 

                    var query = "SELECT *, ";
                    query += " DATE_FORMAT(a.start_time,'%m/%d/%Y') as booking_date,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(a.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_date_time, ";  
                    query += " DATE_FORMAT(CONVERT_TZ(a.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_date_time  ";
                    query += " FROM "+company_databasename+".so_space_booking AS a ";
                    query += " INNER JOIN "+company_databasename+".so_space_attendies AS s ON a.booking_id = s.booking_id ";
                    query += " INNER JOIN "+company_databasename+".so_email_master AS d ON s.email_id   = d.email_id ";
                    query += " where a.booking_id  = '"+req.params.id+"' ";
                    query += "AND s.deleted_at is NULL";

                        connection.query(query, function (error, results, fields) {
                   		            
                            if(error){
                            return res.json({
                                'success': false,
                                'message': message.ERROR,
                                'error': error
                            });
                            }
                            if(results){
                            
                            	data.events = results;
            					res.json({
            						'success': true,
            						'data': data,
            						'message': message.SUCCESS
            					});
                       
                            }
                        });

                } else {
                	return res.json({
                    	'success' : false,
                    	'data' : null,
                    	'recordsTotal' : 0,
                    	'recordsFiltered' : 0,
                    	'message': message.ERROR
                	});
                }
            });
        }
    });
};



/**
 * @uses Get all listing data for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.allListingData = function (req, res, next) {
	var data = {};

    generalConfig.getDataBase(req, res, function(company_databasename){
    if(company_databasename != null){ 
        var query = "SELECT *  FROM "+company_databasename+".so_spaces where deleted_at IS NULL ";

        connection.query(query, function (error, results, fields) {
       
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                	data.space = results;
					res.json({
						'success': true,
						'data': data,
						'message': message.SUCCESS
					});

           
                }
            });
        } else {
        	return res.json({
            	'success' : false,
            	'data' : null,
            	'recordsTotal' : 0,
            	'recordsFiltered' : 0,
            	'message': message.ERROR
        	});
        }
    });
}


/**
 * @uses create new event
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.bookEvent = function (req, res, next) {


	// Validation messages
    req.checkBody("booking_title", message.TITLE_REQUIRED).notEmpty();
	req.checkBody("start_datetime", message.START_TIME_REQUIRE).notEmpty();
	req.checkBody("end_datetime", message.END_TIME_REQUIRE).notEmpty();
	req.checkBody("space_id", message.SPACE_NAME_REUIRED).notEmpty();
	
	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {
		
    	generalConfig.getDataBase(req, res, function(company_databasename){
    	var createdDate = generalConfig.getDateTimeUTC();

		var date1 = new Date(req.body.start_datetime);
        var startDateTime = dateFormat(date1, "UTC:yyyy-mm-dd HH:MM:ss");

        var date2 = new Date(req.body.end_datetime);
        var endDateTime = dateFormat(date2, "UTC:yyyy-mm-dd HH:MM:ss");


    
    		var query  = "";
		    query += "SELECT ";
		    query += " sb.booking_id, sb.space_id, sb.user_id, ";
		    query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
		    query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
		    query += " sb.booking_duration, ";
		    query += "IF( ";
		    query += " (SELECT booking_id FROM "+company_databasename+".so_space_booking as sb WHERE sb.space_id = '"+req.body.space_id+"' ";
		    query += " AND ((sb.start_time < '"+startDateTime+"' AND sb.end_time > '"+startDateTime+"') ";
		    query += " OR (sb.start_time < '"+endDateTime+"' AND sb.end_time > '"+endDateTime+"') ";
		    query += " OR (sb.start_time >= '"+startDateTime+"' AND sb.end_time <= '"+endDateTime+"')) ";
		    query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
		    query += "  IS NULL, ";

	        query += "IF( ";
	        query += " (SELECT maintainance_id FROM "+company_databasename+".so_space_maintainance as sm WHERE sm.space_id = '"+req.body.space_id+"' ";
	        query += " AND ((sm.start_time < '"+startDateTime+"' AND sm.end_time > '"+startDateTime+"') ";
	        query += " OR (sm.start_time < '"+endDateTime+"' AND sm.end_time > '"+endDateTime+"') ";
	        query += " OR (sm.start_time >= '"+startDateTime+"' AND sm.end_time <= '"+endDateTime+"')) ";
	        query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
	        query += "  IS NULL, ";
	        query += "  '0', "; //query += "  'Room Available', ";
	        query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
	        query += "  ), ";

		    query += "  '1' "; //query += "  'Room not available' ";
		    query += "  ) AS is_available ";
		    query += " FROM "+company_databasename+".so_space_booking AS sb ";
		    query += " WHERE sb.deleted_at IS NULL ";
		    query += " AND sb.space_id = '"+req.body.space_id+"' GROUP BY sb.space_id " ;

			var result = connection.query(query);

			
		connection.query(query, function (error, findresult, fields) {
		if(findresult.length == 0 || findresult[0].is_available == 0) {

		var startTimeUtc = generalConfig.getDateTimeUTC(req.body.start_datetime);
		var endTimeUtc = generalConfig.getDateTimeUTC(req.body.end_datetime);


        if(!req.body.booking_details) {
            var booking_details = '';
        }
        else{
            var booking_details = req.body.booking_details; 
        }
		

        var obj = {
			space_id: req.body.space_id,
			user_id: req.body.user_id,
			booking_title: req.body.booking_title,
			booking_details: booking_details,
			amenities_notes: req.body.amenities_notes,
			catering_notes: req.body.catering_notes,
			start_time:startTimeUtc,
			end_time: endTimeUtc,
			booking_duration: req.body.booking_duration,
			// device_id:req.body.device_id,
			status: req.body.status,
			createdAt: createdDate,
			updatedAt: createdDate
        };


        var GUID = generalConfig.generateGUID();
		var InsertId = GUID;

		var insertQuery = "INSERT INTO "+company_databasename+".`so_space_booking` (`booking_id`,`space_id`,`user_id`,`booking_title`,`booking_details`,`amenities_notes`,`catering_notes`,`start_time`,`end_time`,`booking_duration`, `status`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+obj.space_id+"','"+obj.user_id+"','"+obj.booking_title+"','"+obj.booking_details+"','"+obj.amenities_notes+"','"+obj.catering_notes+"','"+obj.start_time+"','"+obj.end_time+"','"+obj.booking_duration+"', '"+obj.status+"','"+obj.createdAt+"','"+obj.updatedAt+"')";
	
		connection.query(insertQuery, function (error, results, fields) { 

        	if(error){
                return res.json({
					success: false,
					data: null,
					message: message.ERROR
			});
            } 
            else if(results){
		 		addEmailTags(req,res,req.body.emailTags, InsertId);
				
			 	// var mail_body = generalConfig.createEventTemplate();
	              res.json({
							'success' : true,
							'data' : results,
							'message': 'Event Created Successfully'
						});
				
            }
        });
			     }
			     else {

            	res.json({
					success: false,
					data: null,
					message: 'Meeting already booked at this space on this time duration.'
				});

			    }
			});

    	})

    }
};



/**
 * @uses update event booking
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.updateEvent = function(req, res, next) {	
    var statusValue = (req.body.status == 1 || req.body.status == true) ? 1 : 0;
    var errors = req.validationErrors();
    var errMsg = {};
    if (errors) {
        errors.forEach(function(err) {
            errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {

        // utc Converted datetime 
        var startDateTime = generalConfig.getDateTimeUTC(req.body.start_datetime);
        var endDateTime = generalConfig.getDateTimeUTC(req.body.end_datetime);
        var updatedAt = generalConfig.getDateTimeUTC();

        var data = {};
        generalConfig.getDataBase(req, res, function(company_databasename) {
		var date1 = new Date(req.body.start_datetime);
        var startDateTime = dateFormat(date1, "UTC:yyyy-mm-dd HH:MM:ss");

        var date2 = new Date(req.body.end_datetime);
        var endDateTime = dateFormat(date2, "UTC:yyyy-mm-dd HH:MM:ss");

        var emailArrayNew = [];

        req.body.emailTags.forEach(function(emailArrays) {
        	emailArrayNew.push(emailArrays.value);
    	})

    	var recipients = emailArrayNew.join(", ");

        var checkTimeQuery = "";
        checkTimeQuery += " SELECT sb.booking_title,DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
        checkTimeQuery += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time";
        checkTimeQuery += " FROM " + company_databasename + ".so_space_booking AS sb ";
        checkTimeQuery += " WHERE sb.deleted_at IS NULL ";
        checkTimeQuery += " AND sb.booking_id =  '" + req.body.booking_id + "'";

        connection.query(checkTimeQuery, function(error, findresult, fields) {        	
        	if(findresult[0].utc_start_time != startDateTime || findresult[0].utc_end_time != endDateTime) {

        		var meetingTitle = findresult[0].booking_title;
				var meetingData = findresult[0].booking_date;
				var startTime = findresult[0].utc_start_time;
				var endTime = findresult[0].utc_end_time;
				var updatedStartTime = startDateTime;
				var updatedEndTime = endDateTime;
				var domain = generalConfig.getDomain(req);

				generalConfig.getCompanyFromDomain(domain, function(companyInfo){
				var companyLogo = companyInfo.company_logo;
				var replacements = {
			        companyLogo: companyLogo,
			        meetingTitle: meetingTitle,
			        startTime: startTime,
			        endTime: endTime,
			        updatedStartTime:updatedStartTime,
			        updatedEndTime:updatedEndTime

			    };

				var to = recipients;
				var subject = "This meeting is rescheduled."

				// generalConfig.sendMail('eventRescheduleTemplate.html',replacements,to,subject);
													
		}	)
			}
		})


            var query = "";
            query += "SELECT ";
            query += " sb.booking_id, sb.space_id, sb.user_id, ";
            query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
            query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
            query += " sb.booking_duration, ";
            query += "IF( ";
            query += " (SELECT booking_id FROM " + company_databasename + ".so_space_booking as sb WHERE sb.space_id = '" + req.body.space_id + "' ";
            query += " AND ((sb.start_time < '" + startDateTime + "' AND sb.end_time > '" + startDateTime + "') ";
            query += " OR (sb.start_time < '" + endDateTime + "' AND sb.end_time > '" + endDateTime + "') ";
            query += " OR (sb.start_time >= '" + startDateTime + "' AND sb.end_time <= '" + endDateTime + "')) ";
            query += " AND sb.status=1 and sb.deleted_at IS NULL and not sb.booking_id = '" +req.body.booking_id + "' GROUP BY sb.space_id) ";
            query += "  IS NULL, ";

            query += "IF( ";
            query += " (SELECT maintainance_id FROM " + company_databasename + ".so_space_maintainance as sm WHERE sm.space_id = '" + req.body.space_id + "' ";
            query += " AND ((sm.start_time < '" + startDateTime + "' AND sm.end_time > '" + startDateTime + "') ";
            query += " OR (sm.start_time < '" + endDateTime + "' AND sm.end_time > '" + endDateTime + "') ";
            query += " OR (sm.start_time >= '" + startDateTime + "' AND sm.end_time <= '" + endDateTime + "')) ";
            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
            query += "  IS NULL, ";
            query += "  '0', "; //query += "  'Room Available', ";
            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
            query += "  ), ";

            query += "  '1' "; //query += "  'Room not available' ";
            query += "  ) AS is_available ";
            query += " FROM " + company_databasename + ".so_space_booking AS sb ";
            query += " WHERE sb.deleted_at IS NULL ";

            query += " AND sb.space_id = '" + req.body.space_id + "' GROUP BY sb.space_id ";

            connection.query(query, function(error, findresult, fields) {

            	if(findresult) {

            		if (findresult.length == 0 || findresult[0].is_available == 0) {
                    var update_meeting_query = "UPDATE " + company_databasename + ".so_space_booking ";
                    update_meeting_query += " SET ";
                    update_meeting_query += " space_id = '" + req.body.space_id + "', ";
                    update_meeting_query += " booking_title = '" + req.body.booking_title + "', ";
                    update_meeting_query += " booking_details = '" + req.body.booking_details + "', ";
                    update_meeting_query += " amenities_notes = '" + req.body.amenities_notes + "', ";
                    update_meeting_query += " catering_notes = '" + req.body.catering_notes + "', ";
                    update_meeting_query += " user_id = '" + req.body.user_id + "', ";
                    update_meeting_query += " booking_duration = '" + req.body.booking_duration + "', ";
                    update_meeting_query += " start_time = '" + startDateTime + "', ";
                    update_meeting_query += " end_time = '" + endDateTime + "', ";
                    update_meeting_query += " updated_at = '" + updatedAt + "'";
                    update_meeting_query += " WHERE booking_id = '" + req.body.booking_id + "'";


                    if (company_databasename != null) {
                        var query = update_meeting_query;

                        connection.query(query, function(error, results, fields) {
                            if (error) {
                                return res.json({
                                    'success': false,
                                    'message': message.ERROR,
                                    'error': error
                                });
                            }
                            if (results) {
                                updateEmailTags(req, res, req.body.emailTags, req.body.booking_id);
                                data.space = results;
                                res.json({
                                    'success': true,
                                    'data': data,
                                    'message': message.SUCCESS
                                });


                            }
                        });
                    } else {
                        return res.json({
                            'success': false,
                            'data': null,
                            'recordsTotal': 0,
                            'recordsFiltered': 0,
                            'message': message.ERROR
                        });
                    } 





                }


                  else {


                        res.json({
                            success: false,
                            data: null,
                            message: 'Meeting already booked at this space on this time duration.'
                        });

                    }


            	}

             

                  else {

  								res.json({
                                    'success': true,
                                    'data': data,
                                    'message': message.SUCCESS
                                });

                    }



            });




        });

    }
};


function updateEmailTags(req, res, emailArr, bookingId) {
    var data = {};
    var emailArrayNew = [];
    var emailArrayExisting = [];
    var emailArrayExistingIds = [];

    emailArr.forEach(function(emailArrays) {
        emailArrayNew.push(emailArrays.value);
    })
    generalConfig.getDataBase(req, res, function(company_databasename) {
        if (company_databasename != null) {
            var query = "SELECT *  FROM " + company_databasename + ".so_space_attendies where deleted_at IS NULL AND booking_id = '" + bookingId + "' ";
            connection.query(query, function(error, results, fields) {
                if (error) {
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                }
                if (results) {
                    data.space = results;
                    results.forEach(function(email) {
                        emailArrayExistingIds.push(email.email_id);
                    })
                    var a = "'" + emailArrayExistingIds.join("', '") + "'";
                    var b = '(' + a + ')';
                    var selectQuery = "SELECT  `EmailMaster`.*  FROM " + company_databasename + ".`so_email_master` as `EmailMaster` where `EmailMaster`.email_id  IN  " + b + "";
                    connection.query(selectQuery, function(error, results, fields) {
                        if (error) {

                        }
                        if (results) {
                            results.forEach(function(emailArrayss) {
                                emailArrayExisting.push(emailArrayss.email_address);
                            })
                            var diffArray = difference(emailArrayNew, emailArrayExisting); // yeilds [1, 4]
                            if (diffArray.length > 0) {
                                diffArray.forEach(function(arr) {
                                    var arrs = [];
                                    if (emailArrayNew.indexOf(arr) > -1) {
                                        arrs.push({
                                            display: arr,
                                            value: arr
                                        });

                                        addEmailTags(req, res, arrs, bookingId);

                                    } else if (emailArrayNew.indexOf(arr) < 0) {

                                        var selectQuery = "SELECT  `EmailMaster`.*  FROM " + company_databasename + ".`so_email_master` as `EmailMaster` where `EmailMaster`.email_address  = '" + arr + "'";
                                        connection.query(selectQuery, function(error, results, fields) {

                                            if (error) {
                                                return res.json({
                                                    'success': false,
                                                    'message': message.ERROR,
                                                    'error': error
                                                });
                                            }
                                            if (results) {
												var deleted_at = generalConfig.getDateTimeUTC();
                                                var updateQuery = "UPDATE  " + company_databasename + ".`so_space_attendies` SET  `deleted_at` = '" + deleted_at + "' WHERE  `so_space_attendies`.`email_id` = '" + results[0].email_id + "'";
                                                updateQuery +=  " AND booking_id ='"+bookingId+"'";
                                                connection.query(updateQuery, function(error, results, fields) {
                                                    if (error) {
                                                        return res.json({
                                                            'success': false,
                                                            'message': message.ERROR,
                                                            'error': error
                                                        });
                                                    }
                                                    if (results) {


										            var meetingTitle = req.body.booking_title;
													var meetingData = req.body.booking_date;
													var startTime = req.body.start_time;
													var endTime = req.body.end_time;
													var spaceName = req.body.space_name;                             	
													var domain = generalConfig.getDomain(req);

													generalConfig.getCompanyFromDomain(domain, function(companyInfo){
													var companyLogo = companyInfo.company_logo;
													var replacements = {
												        companyLogo: companyLogo,
												        meetingTitle: meetingTitle,
												        startTime: startTime,
												        endTime: endTime,

												    };

													var to = arr;
													var subject = "This meeting is cancelled."

													// generalConfig.sendMail('removeAttendyEventTemplate.html',replacements,to,subject);
													
									

											})

                                        }
                                    })
                                }
                            })

                        }
                    })

                }

            }

       });

    }
});
        } else {
            return res.json({
                'success': false,
                'data': null,
                'recordsTotal': 0,
                'recordsFiltered': 0,
                'message': message.ERROR
            });
        }
    });

}


function addEmailTags(req, res, emailArr, bookingId) {
	var meetingTitle = req.body.booking_title;
	var meetingData = req.body.booking_date;
	var startTime = req.body.start_time;
	var endTime = req.body.end_time;
	var spaceName = req.body.space_name;


    var attentiesType = '';
    emailArr.forEach(function(email) {
        if (email != null) {
            var GUID = generalConfig.generateGUID();
            var InsertId = GUID;
            generalConfig.getDataBase(req, res, function(company_databasename) {
                var selectQuery = "SELECT  `EmailMaster`.*  FROM " + company_databasename + ".`so_email_master` as `EmailMaster` where `EmailMaster`.email_address =  '" + email.value + "'";
                connection.query(selectQuery, function(error, results, fields) {
                        if(error){
				            return res.json({
								success: false,
								data: null,
								message: message.ERROR
							});
				        }

                    if (results.length == 0) {
                        var insertQuery = "INSERT INTO " + company_databasename + ".`so_email_master` (`email_id`,`email_address`,`created_at`, `updated_at`) VALUES ('" + InsertId + "','" + email.value + "','" + generalConfig.getDateTimeUTC() + "','" + generalConfig.getDateTimeUTC() + "')";
                        connection.query(insertQuery, function(error, resultsa, fields) {

                        	if(error){
					            return res.json({
									success: false,
									data: null,
									message: message.ERROR
								});
					        }
                            
                        	var selectQuery2 = "SELECT  `EmailMaster`.*  FROM " + company_databasename + ".`so_email_master` as `EmailMaster` where `EmailMaster`.email_id =  '" +  InsertId+ "'";
                        	
                        connection.query(selectQuery2, function(error, resultsab, fields) {
    						master_db.models.User.find({where : { email : email.value }}).then(function(users){
	    						if(users) {

	    							var attendies_type = 'USER';
	    						}
	    						else {
	    							attendies_type = 'GUEST';
	    						}

	    						if(error){
						            return res.json({
										success: false,
										data: null,
										message: message.ERROR
									});
						        }
	                        
	                        	if(resultsab[0].email_id) {

	                        		 var insertAttentiesQuery = "INSERT INTO " + company_databasename + ".`so_space_attendies` (`attendies_id`,`booking_id`,`email_id`,`attendies_type`,`created_at`, `updated_at`) VALUES ('" + InsertId + "','" + bookingId + "','" + resultsab[0].email_id + "','" + attendies_type + "','" + generalConfig.getDateTimeUTC() + "','" + generalConfig.getDateTimeUTC() + "')";
	                            		connection.query(insertAttentiesQuery, function(error, results, fields) {

	                            			if(error){
									            return res.json({
													success: false,
													data: null,
													message: message.ERROR
												});
									        }
	                            	});
	                        	}
                        	});
                        });
                    });


                    } 
        			else if (results.length > 0) {
                    	var insertAttentiesQuery = "SELECT  `EmailMaster`.*  FROM " + company_databasename + ".`so_email_master` as `EmailMaster` where `EmailMaster`.email_id =  '" +  InsertId+ "'";
                		connection.query(insertAttentiesQuery, function(error, results, fields) {

                			if(error){
					            return res.json({
									success: false,
									data: null,
									message: message.ERROR
								});
					        }
                		});

                        var new_email_address = email.value;
                        var email_id = results[0].email_id;
                        var old_created_at = results[0].created_at;
                           master_db.models.User.find({where : { email : email.value }}).then(function(users){
    						if(users) {

    							var attendies_type = 'USER';
    						}
    						else {
    							attendies_type = 'GUEST';
    						}


                        if (email_id) {
                            var insertAttentiesQuery = "INSERT INTO " + company_databasename + ".`so_space_attendies` (`attendies_id`,`booking_id`,`email_id`,`attendies_type`,`created_at`, `updated_at`) VALUES ('" + InsertId + "','" + bookingId + "','" + email_id + "','" + attendies_type + "','" + generalConfig.getDateTimeUTC() + "','" + generalConfig.getDateTimeUTC() + "')";
                            connection.query(insertAttentiesQuery, function(error, results, fields) {
                            	if(error){
						            return res.json({
										success: false,
										data: null,
										message: message.ERROR
									});
						        }

						        if(results) {


						        }

                            });

                        }
                    });
                    }
                })
            })



			var domain = generalConfig.getDomain(req);

			generalConfig.getCompanyFromDomain(domain, function(companyInfo){

			var companyLogo = companyInfo.company_logo;

			var replacements = {
			         companyLogo: companyLogo,
			         meetingTitle: meetingTitle,
			         startTime: startTime,
			         endTime: endTime,
			         spaceName:spaceName,

			    };

			var to = email.value;
			var subject = "You are invited to join this meeting."

			// generalConfig.sendMail('createEventTemplate.html',replacements,to,subject);
			
			})


		









        }

    });
}

exports.getScheduleList = function (req, res, next) {
    var flag = req.query.flag;
    //flag 1 is search from custom param, flag 0 is search from datatable param

    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;
    var dateTime = req.query.dt;
    
    if(dateTime != undefined){
        var TimeUTC = generalConfig.getDateTimeUTC(dateTime);
    }

    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

    if(flag ==1){

        var title = req.query.title;
        var organizer = req.query.organizer;
        var start_date = req.query.start_date;
        var end_date = req.query.end_date;
        var building_name = req.query.building_name;
        var floor_name = req.query.floor_name;
        var space_name = req.query.space_name;
        
    }

    var now = new Date();
    var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
    

    if(user && user.user_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){

                var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"' ";
                    

                connection.query(userQuery, function (error, userResult, fields) {
                
                    if(userResult.length > 0){
                        var email_id = userResult[0].email_id;
                        var email = userResult[0].email;
                        var time_difference = userResult[0].time_difference;
                    }

                    var query  = "";
                    query += "SELECT sb.space_id, s.space_name,  s.floor_id, s.space_capacity, ";
                    query += " s.space_size,  s.floor_id, f.floor_name, f.building_id, b.building_name, ";
                    query += " s.space_type_id, st.space_type_name,  sb.booking_id, sb.user_id,  sb.booking_title, ";
                    query += " sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
                    query += " IF(sb.start_time >= '"+currentDate+"', true, false) as is_delete_valid, ";
                    query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
                    query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,   sb.booking_duration, ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, ";  
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_time,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_end_date,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_time,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%W, %M %d, %Y') as display_date, ";
                    query += " (  SELECT  GROUP_CONCAT(email_address) as email_address  FROM "+company_databasename+".so_email_master AS emailmaster  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id  ";
                    query += " WHERE spaceattendies.booking_id = sb.booking_id GROUP BY sb.booking_id ) AS attendies, ";
                    query += " sa.email_id, sa.attendies_type,e.email_address,CONCAT(u.first_name,' ',u.last_name) as organizer_full_name,  ";
                    query += " LCASE(u.email) as organizer_email, u.phone_number as organizer_phone_number ";
                    query += " FROM "+company_databasename+".so_space_attendies AS sa  ";
                    query += " LEFT JOIN "+company_databasename+".so_email_master AS e ON e.email_id = sa.email_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_booking AS sb ON sb.booking_id = sa.booking_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_spaces AS s ON s.space_id = sb.space_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_type AS st ON st.space_type_id = s.space_type_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_floors AS f ON f.floor_id = s.floor_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_buildings AS b ON b.building_id = f.building_id  ";
                    query += " LEFT JOIN "+master_database+".so_users AS u ON u.user_id = sb.user_id  ";
                    query += " WHERE (LCASE(e.email_address) = LCASE('"+email+"') OR sb.user_id = '"+user.user_id+"')  ";
                    query += " AND (b.building_name LIKE '%"+search+"%' OR s.space_name LIKE '%"+search+"%' OR u.first_name LIKE '%"+search+"%' OR u.last_name LIKE '%"+search+"%' OR sb.booking_title LIKE '%"+search+"%' OR f.floor_name LIKE '%"+search+"%' ) ";


                    if(flag == 0){
                        
                            query += " AND  sb.deleted_at IS NULL ";
                            query += " GROUP BY sb.booking_id ORDER BY "+sort+" ";
                            var count = query;
                            query += orderBy+" LIMIT "+perPage+" OFFSET "+offset+"";

                        
                    } else {

                            if(organizer != "" && organizer != undefined){
                                query += " AND ( u.first_name LIKE '%"+organizer+"%' OR u.last_name LIKE '%"+organizer+"%' ) "
                            }

                            if(title != "" && title != undefined){
                                query += " AND sb.booking_title LIKE '%"+title+"%' ";
                            }

                            if(building_name != "" && building_name != undefined){
                                query += " AND b.building_name LIKE '%"+building_name+"%' ";
                            }

                            if(floor_name != "" && floor_name != undefined){
                                query += " AND f.floor_name LIKE '%"+floor_name+"%' ";
                            }

                            if(space_name != "" && space_name != undefined){
                                query += " AND s.space_name LIKE '%"+space_name+"%' ";
                            }

                            if(start_date != ""  && end_date != ""){
                                query += " AND ( DATE_FORMAT(sb.start_time,'%Y-%m-%d')  >= '"+start_date+"' AND DATE_FORMAT(sb.end_time,'%Y-%m-%d')  <= '"+end_date+"' ) ";
                            }

                            if(start_date != "" && end_date == ""){
                                query += " AND DATE_FORMAT(sb.start_time,'%Y-%m-%d')  >= '"+start_date+"' ";    
                            }

                            if(end_date != "" &&  start_date == ""){
                                query += " AND DATE_FORMAT(sb.end_time,'%Y-%m-%d')  <= '"+end_date+"' ";
                            }

                            query += " AND  sb.deleted_at IS NULL ";
                            query += " GROUP BY sb.booking_id ORDER BY "+sort+" ";
                            var count = query;
                            query += orderBy+" LIMIT "+perPage+" OFFSET "+offset+"";

                    }

                    connection.query(query, function (error, results, fields) {
                      if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                      }
                        if(results){
                                connection.query(count, function (error, count, fields) {
                                    async.forEach(results, function (val, callback){ 
                                        val.timezone = userResult[0].timezone;
                                        val.time_difference = userResult[0].time_difference;

                                        callback()
                                    }, function(err) {

                                        count = (count != null)?count:0;
                                        return res.json({
                                            'success' : true,
                                            'data' : results,
                                            'draw' : draw,
                                            'recordsTotal' : count.length,
                                            'recordsFiltered' : count.length,
                                            'message': message.SUCCESS
                                        });
                                    });

                                });
                        }
                    });
                });

            } else {
                return res.json({
                    'success' : false,
                    'data' : null,
                    'draw' : draw,                
                    'recordsTotal' : 0,
                    'recordsFiltered' : 0,
                    'message': message.ERROR
                });
            }
        });
    } else {
        return res.json({
            'success' : false,
            'data' : null,
            'draw' : draw,                
            'recordsTotal' : 0,
            'recordsFiltered' : 0,
            'message': message.ERROR
        });
    }
}

exports.removeMeeting = function(req, res, next){
	var booking_id = req.body.booking_id;
	var deleted_at = generalConfig.getDateTimeUTC();
	if(booking_id){ 

	    generalConfig.getDataBase(req, res, function(company_databasename){
		    if(company_databasename != null){ 
		    	var Selectquery =   "SELECT  * FROM  `"+company_databasename+"`.`so_space_attendies` AS s";
		    	Selectquery += " INNER JOIN "+company_databasename+".so_email_master AS d ON s.email_id   = d.email_id ";
		    	Selectquery += " INNER JOIN "+company_databasename+".so_space_booking AS SB ON SB.booking_id   = s.booking_id";
		    	
		    	Selectquery += " WHERE  s.booking_id =  '"+booking_id+"'";
		    	Selectquery += " AND s.deleted_at is NULL";

		    	console.log(Selectquery);
		    	connection.query(Selectquery, function (error, results, fields) { 
		    		if(error){
		                return res.json({
		                    'success': false,
		                    'message': message.ERROR,
		                    'error': error
		                });
		            }

		            if(results){

		            	// results.forEach(function(info) {


		      //       			var startdate = new Date(info.start_time+ ' UTC');
								// var startTime = 	startdate.toString();

								// var enddate = new Date(info.end_time+ ' UTC');
								// var endTime = 	enddate.toString();

				    // 			var domain = generalConfig.getDomain(req);

				    //         	generalConfig.getCompanyFromDomain(domain, function(companyInfo){
								// var companyLogo = companyInfo.company_logo;
								// var replacements = {
							 //        companyLogo: companyLogo,
							 //        meetingTitle: info.booking_title,
							 //        startTime: info.startTime,
							 //        endTime: info.endTime,

							 //    };

								// var to = info.email_address;
								// var subject = "This meeting is cancelled."

								// // generalConfig.sendMail('removeAttendyEventTemplate.html',replacements,to,subject);
								
									
                                
        //                  })

		            	var query = "UPDATE  "+company_databasename+".`so_space_booking` SET  `deleted_at` = '"+deleted_at+"' WHERE  `so_space_booking`.`booking_id` = '"+booking_id+"'";
		    	connection.query(query, function (error, results, fields) { 
		    		if(error){

                        console.log('+++++++++++++=====');
                        console.log(error);
                        console.log('+++++++++++++=====');
                        console.log('inside erorrrr---------')

		                return res.json({
		                    'success': false,
		                    'message': message.ERROR,
		                    'error': error
		                });
		            }

		            if(results){


                        return res.json({
                            'success' : true,
                            'message': message.SCHEDULE_DELETE
                        });

		            
		            }
		         })
		    	




		    	// });


                        

		            	
		            }

		    	});

		    
 
		    	
		    } else {
		    	res.json({
					'success': false,
					'message': message.ERROR
				});
		    }
		});

	} else {
		res.json({
			'success': false,
			'message': message.ERROR
		});
	}
	
}


exports.getMeetingDetailsById = function(req, res, next){
	var booking_id = req.body.booking_id;
    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

	if(booking_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){

                var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"' ";

                connection.query(userQuery, function (error, userResult, fields) {
                
                    if(userResult.length > 0){
                        var email_id = userResult[0].email_id;
                        var email = userResult[0].email;
                        var time_difference = userResult[0].time_difference;
                    }

    	        	 	var query = "SELECT *, ";
                        query += " DATE_FORMAT(`SB`.start_time, '%c/%d/%Y %k:%i %p') AS start_time,";
    	        		query += " DATE_FORMAT(`SB`.end_time, '%c/%d/%Y %k:%i %p') AS end_time,";
                        query += " DATE_FORMAT(`SB`.start_time,'%m/%d/%Y') as booking_date,  ";
                        query += " DATE_FORMAT(CONVERT_TZ(`SB`.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_date_time, ";  
                        query += " DATE_FORMAT(CONVERT_TZ(`SB`.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_date_time,  ";
                        query += " `SB`.booking_duration as booking_duration,";
    	        		query += " `SB`.device_id as device_id, `SB`.status as status, `SB`.created_at as created_at, `SB`.deleted_at as deleted_at,";
    	        		query += " CONCAT(`U`.first_name,' ',`U`.last_name) AS organizer, `S`.space_name as space_name, `BD`.building_name as building_name";
    	        		query += " FROM "+company_databasename+".`so_space_booking` AS `SB`",
    	        		query += " INNER JOIN "+company_databasename+".so_space_attendies AS s ON SB.booking_id = s.booking_id ";
	                    query += " INNER JOIN "+company_databasename+".so_email_master AS d ON s.email_id   = d.email_id ";
    	        		query += " LEFT JOIN "+master_database+".so_users AS `U` ON `U`.user_id = `SB`.user_id ";
    	        		query += " LEFT JOIN "+company_databasename+".so_spaces AS `S` ON `S`.space_id = `SB`.space_id ";
    	        		query += " LEFT JOIN "+company_databasename+".so_floors AS `FL` ON `S`.floor_id = `FL`.floor_id ";
    	        		query += " LEFT JOIN "+company_databasename+".so_buildings AS `BD` ON `BD`.building_id = `FL`.building_id ";
    	        		query += " WHERE `SB`.booking_id = '"+booking_id+"'";
    	        		


    	        	connection.query(query, function (error, results, fields) {
    	              if(error){
    	                return res.json({
    	                    'success': false,
    	                    'message': message.ERROR,
    	                    'error': error
    	                });
    	              }
    	                if(results){

    	                
                            generalConfig.getScheduleMeetingTotalCount(req, res, company_databasename,  function(count){
                                return res.json({
                                    'success' : true,
                                    'data' : results,
                                    'message': message.SUCCESS
                                });
                            });
    	                }
    	            });

                });

	        } else {
	        	res.json({
					'success': false,
					'message': message.ERROR
				});
	        }
	    });
	}
}



exports.getUpcomingMeetings = function(req, res, next){
    var now = new Date();
    var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
    var endCurrentDate  = dateFormat(now, "UTC:yyyy-mm-dd 24:01:00");
    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;
    var domain = generalConfig.getDomain(req);

    console.log(domain);
    console.log('--------------');

    var base_image_url = 'images/uploads/'+domain+'/';
    console.log(base_image_url);


    if(user && user.user_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){
                
                var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"' ";

                connection.query(userQuery, function (error, userResult, fields) {
                
                    if(userResult.length > 0){
                        var email_id = userResult[0].email_id;
                        var email = userResult[0].email;
                        var time_difference = userResult[0].time_difference;
                    }

                    var query  = "";
                    query += "SELECT sb.space_id, s.space_name,  s.floor_id, s.space_capacity, ";
                    query += " s.space_size,  s.floor_id, f.floor_name, f.building_id, b.building_name, ";
                    query += " s.space_type_id, st.space_type_name,  sb.booking_id, sb.user_id, u.profile_picture, sb.booking_title, ";
                    query += " sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
                    query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
                    query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,   sb.booking_duration, ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, ";  
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_time,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_end_date,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_time,  ";
                    query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%W, %M %d, %Y') as display_date, ";
                    query += " IF(sb.start_time >= '"+currentDate+"', true, false) as is_delete_valid, ";
                    


                    query += " (  SELECT  GROUP_CONCAT(email_address) as email_address  FROM "+company_databasename+".so_email_master AS emailmaster  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id  ";
                    query += " WHERE spaceattendies.booking_id = sb.booking_id GROUP BY sb.booking_id ) AS attendies, ";
                    


                    query += " (  SELECT  GROUP_CONCAT(CONCAT('"+base_image_url+"user_image/', profile_picture)) as email_address  FROM "+company_databasename+".so_email_master AS emailmaster  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id  ";
                    query += " LEFT JOIN "+master_database+".so_users AS Users ON Users.email = emailmaster.email_address  ";
                    query += " WHERE spaceattendies.booking_id = sb.booking_id GROUP BY sb.booking_id ) AS attendiesProfilePicture, ";
                    // query += " CONCAT('"+base_image_url+"space_image/',s.space_image) as full_space_image, ";


                    query += " sa.email_id, sa.attendies_type,e.email_address,CONCAT(u.first_name,' ',u.last_name) as organizer_full_name,  ";
                    query += " LCASE(u.email) as organizer_email, u.phone_number as organizer_phone_number";
                    query += " FROM "+company_databasename+".so_space_attendies AS sa  ";
                    query += " LEFT JOIN "+company_databasename+".so_email_master AS e ON e.email_id = sa.email_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_booking AS sb ON sb.booking_id = sa.booking_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_spaces AS s ON s.space_id = sb.space_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_space_type AS st ON st.space_type_id = s.space_type_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_floors AS f ON f.floor_id = s.floor_id  ";
                    query += " LEFT JOIN "+company_databasename+".so_buildings AS b ON b.building_id = f.building_id  ";
                    query += " LEFT JOIN "+master_database+".so_users AS u ON u.user_id = sb.user_id  ";
                    query += " WHERE (LCASE(e.email_address) = LCASE('"+email+"') OR sb.user_id = '"+user.user_id+"')  ";
                    query += " AND sb.space_id = '"+req.params.spaceId+"'";
                    query += " AND  sb.deleted_at IS NULL AND sb.start_time >= '"+currentDate+"'  ";
                    query += " AND sb.end_time <= '"+endCurrentDate+"'  ";
                    query += " GROUP BY sb.booking_id LIMIT 5";

                    if(userResult){
                        connection.query(query, function (error, total_count, fields) {
                          console.log(query);
                          if(error){
                            return res.json({
                                'success': false,
                                'message': message.ERROR,
                                'error': error
                            });
                          }
                            if(total_count){
                                return res.json({
                                    'success' : true,
                                    'data' : total_count,
                                    'message': message.SUCCESS
                                });
                            }
                        });
                    }
                });

            } else {
                return res.json({
                    'success' : false,
                    'data' : null,
                    'draw' : draw,                
                    'recordsTotal' : 0,
                    'recordsFiltered' : 0,
                    'message': message.ERROR
                });
            }
        });
    } else {
        return res.json({
            'success' : false,
            'data' : null,
            'draw' : draw,                
            'recordsTotal' : 0,
            'recordsFiltered' : 0,
            'message': message.ERROR
        });
    }
}
