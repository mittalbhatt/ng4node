'use strict';

var Sequelize = require('sequelize');
var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;

var mysql = require('mysql');
var config    = require('../config/database');
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var AuthController = require('./authController');

/**
 * @uses (getAmenities) fetch Amenities list
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/
exports.getAmenity = function(req, res, next){
    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;

    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");
    var accessObj = generalConfig.userAccessCheck(req);
    
    generalConfig.getDataBase(req, res, function(company_databasename){

        if(company_databasename != null){
            var query = "SELECT `amenity_id`, `amenity_name`, `amenity_image`, `status`, `created_at` AS `createdAt`, ";
            query += " `updated_at` AS `updatedAt`, `deleted_at` FROM "+company_databasename+".`so_amenities` AS `Amenities` ";
            query += " WHERE `Amenities`.`deleted_at` IS NULL AND (`Amenities`.`amenity_name` LIKE '%"+search+"%') ";
            query += " ORDER BY `Amenities`.`"+sort+"` "+orderBy;
            var countQuery = query;
            query += " LIMIT "+perPage+" OFFSET "+offset+"";
            
            connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                    accessObj.then(function(resp){
                        results.forEach(function(val){
                            if(val.amenity_image != ""){
                                var path = imagePathObj.mainLink+'/'+val.amenity_image;
                                
                                if(!generalConfig.checkFilePath(path)){
                                   val.image_path = generalConfig.no_image_80;
                                }else{
                                   val.image_path = generalConfig.imageUrl(path);
                                }
                                
                            } else {
                                val.image_path = generalConfig.no_image_80;
                            }
                        });

                        generalConfig.getAminityTotalCount(req, res, countQuery,  function(count){
                            count = (count != null)?count:0;
                            return res.json({
                                'success' : true,
                                'data' : results,
                                'draw' : draw,
                                'accessObj' :resp,
                                'recordsTotal' : count,
                                'recordsFiltered' : count,
                                'message': message.SUCCESS
                            });
                        });
                    });
                }
            });
        } else {
            return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
        }
    });

}

/**
 * @uses (addAmenities) insert new amenities data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/

exports.addAmenity = function(req, res, next) {

    var amenity_name = (req.body.amenity_name)?req.body.amenity_name:'';
    var status = 1; //parseInt(req.body.status);
    var base64Image = req.body.amenity_image;
    var filename = req.body.image_name;
    var newFile = '';
    var errMsg = [];

    req.checkBody("amenity_name", message.AMENITY_REQUIRE).notEmpty();
    var errors = req.validationErrors();
	var errMsg = {};

    if (errors) {
        errors.forEach(function (err) {			
			errMsg[err.param] = [err.msg];
        });	
        return res.json({
                'success': false,
                'message': errMsg
            });
    } else {
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){
                var findQuery = "SELECT `amenity_id` FROM "+company_databasename+".`so_amenities` AS `Amenities` WHERE `Amenities`.`amenity_name` = '"+amenity_name+"'";
                connection.query(findQuery, function (error, findresult, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(findresult.length > 0 && findresult[0].amenity_id != ""){
                        res.json({
                            'success': false,
                            'message': message.AMENITY_EXIST
                        });
                    } else {
                        var new_file_name = "";
                        var createDate = generalConfig.getDateTimeUTC();
                        var GUID = generalConfig.generateGUID();
                        
                        var doamin = generalConfig.getDomain(req);
                        var resObj = upload.uploadImage(doamin, "amenity", base64Image, filename, "", "", "");

                        if(resObj.success == true){
                            new_file_name = resObj.file_name;
                        } else {
                            return res.json({
                                'success': resObj.success,
                                'message': resObj.message
                            });
                        }
                        var query = "INSERT INTO "+company_databasename+".`so_amenities` (`amenity_id`, `amenity_name`, `amenity_image`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES ('"+GUID+"', '"+amenity_name+"', '"+new_file_name+"', '"+status+"', '"+createDate+"', '"+createDate+"', NULL)";
                        connection.query(query, function (error, results, fields) {
                            if(error){
                                return res.json({
                                    'success': false,
                                    'message': message.ERROR,
                                    'error': error
                                });
                            } else if(results){
                                return res.json({
                                    'success' : true,
                                    'message': message.AMENITY_ADD_SUCCESS
                                });
                            }
                        });
                    }
                });
            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                });   
            }
        });
    }
};

/**
 * @uses (getEditAmenity) fetch selected amenities info
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.getEditAmenity = function(req, res, next){
    var amenity_id = req.body.amenity_id;
    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");

    if(amenity_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){
                var query = "SELECT `amenity_id`, `amenity_name`, `amenity_image`, `status`, `created_at` AS `createdAt`, `updated_at` AS `updatedAt`, `deleted_at`, CONCAT('"+imagePathObj.mainLink+"','/','amenity_image') as image FROM "+company_databasename+".`so_amenities` AS `Amenities` WHERE `Amenities`.`amenity_id` = '"+amenity_id+"'";
                connection.query(query, function (error, results, fields) { 
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    }
                    if(results.length > 0){
                        if(results[0].amenity_image != ""){
                            var path = imagePathObj.mainLink+'/'+results[0].amenity_image;
                            if(!generalConfig.checkFilePath(path)){
                               results[0].image = generalConfig.no_image_200;
                            }else{
                               results[0].image = generalConfig.imageUrl(path);
                            }
                        } else {
                            results[0].image = generalConfig.no_image_200;
                        }

                        return res.json({
                            'success' : true,
                            'data' : results[0],
                            'message': message.SUCCESS
                        });
                    } else {
                        return res.json({
                            'success' : false,
                            'data' : null,
                            'message': message.NOT_FOUND
                        });
                    }
                });
            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}

/**
 * @uses (updateAmenities) updated new building data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateAmenity = function(req, res, next) {

    var amenity_id = req.body.amenity_id;
    var amenity_name = req.body.amenity_name;
    var status = req.body.status; //(req.body.status) ? parseInt(req.body.status) : 1;
    var base64Image = req.body.amenity_image;
    var filename = req.body.new_image_name;
    var old_filename = req.body.old_amenity_image;
    var removeImage = req.body.removeImage;
    var errMsg = [];

    req.checkBody("amenity_name", message.AMENITY_REQUIRE).notEmpty();
    var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {			
			errMsg[err.param] = [err.msg];
        });	
        res.json({
            'success': false,
            'message': errMsg
        });
    } else {
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){

                var findQuery = "SELECT `amenity_id` FROM "+company_databasename+".`so_amenities` AS `Amenities` WHERE `Amenities`.`amenity_name` = '"+amenity_name+"' AND `Amenities`.`amenity_id` != '"+amenity_id+"' AND `Amenities`.`deleted_at` IS NULL ";
                connection.query(findQuery, function (error, findresult, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(findresult.length > 0 && findresult[0].amenity_id != ""){
                        return res.json({
                            'success': false,
                            'message': message.AMENITY_EXIST
                        });
                    } else {
                        var new_file_name = "";
                        var updateDate = generalConfig.getDateTimeUTC();
                        var doamin = generalConfig.getDomain(req);
                        var resObj = upload.uploadImage(doamin, "amenity", base64Image, filename, old_filename, removeImage, "");

                        if(resObj.success == true){
                            new_file_name = resObj.file_name;
                        } else {
                            return res.json({
                                'success': resObj.success,
                                'message': resObj.message
                            });
                        }
                        var query = "UPDATE "+company_databasename+".`so_amenities` AS `Amenities` SET `Amenities`.`amenity_name`='"+amenity_name+"', `Amenities`.`amenity_image`='"+new_file_name+"', `Amenities`.`status`="+status+", `Amenities`.`updated_at`='"+updateDate+"' WHERE `Amenities`.`amenity_id` = '"+amenity_id+"'";
                        connection.query(query, function (error, results, fields) {
                            if(error){
                                return res.json({
                                    'success': false,
                                    'message': message.ERROR,
                                    'error': error
                                });
                            } else if(results){
                                return res.json({
                                    'success' : true,
                                    'message': message.AMENITY_UPDATE
                                });
                            }
                        });
                    }
                });
            } else {
                res.json({
                    'success': false,
                    'message': message.ERROR
                });   
            }
        });
    }

};

/**
 * @uses (removeBuilding) remove selected building from database (soft delete)
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.removeAmenity = function(req, res, next){
    var amenity_id = req.body.amenity_id;
    var deletedDate = generalConfig.getDateTimeUTC();
    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
           var query = "UPDATE "+company_databasename+".`so_amenities` AS `Amenities` SET `Amenities`.`deleted_at`='"+deletedDate+"' WHERE `Amenities`.`amenity_id` = '"+amenity_id+"'";
            connection.query(query, function (error, results, fields) {
                if(error){
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });

                } else if(results){
                    return res.json({
                        'success' : true,
                        'message': message.AMENITY_DELETE
                    });
                }
            });
        } else {
            return res.json({
                'success': false,
                'message': message.ERROR
            }); 
        }
    });
}

exports.updateAmenityStatus= function(req, res, next){
    
    var amenity_id = req.body.amenity_id;
    var status = (req.body.status == 1)?0:1;
    var updateDate = generalConfig.getDateTimeUTC();

    if(amenity_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){
               var query = "UPDATE "+company_databasename+".`so_amenities` AS `Amenities` SET `Amenities`.`status`='"+status+"', `Amenities`.`updated_at`='"+updateDate+"' WHERE `Amenities`.`amenity_id` = '"+amenity_id+"'";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        return res.json({
                            'success' : true,
                            'message': message.STATUS_UPDATE
                        });
                    }
                });
            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
    }
}
