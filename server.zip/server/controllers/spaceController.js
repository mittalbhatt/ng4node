'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var Sequelize = require('sequelize');

var conn = require('../config/mysql-connection');
var connection = conn.connection;
var async = require('async');
var database = require('../config/database');
var master_database = database.master_database.name;

/**
 * @uses get space listing data
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.spaceList = function (req, res, next) {

	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;

    var domain = generalConfig.getDomain(req);
    //(domain, type, mainLink, subLink, http path)
    var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");
    var imageSpacePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
    var accessObj = generalConfig.userAccessCheck(req);

    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
	        	//var query = "SELECT  `SPACE`.*, `Floor`.floor_name, `Building`.building_name,`SPACETYPE`.space_type_name FROM ( SELECT `Space`.`space_id`, `Space`.`space_name`, `Space`.`floor_id`, `Space`.`space_capacity`, `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, `Space`.`space_notes`, `Space`.`space_image`, `Space`.`status` FROM "+company_databasename+".`so_spaces` AS `Space` WHERE `Space`.`deleted_at` IS NULL AND (`Space`.`space_name` LIKE '%"+search+"%') ORDER BY `Space`.`"+sort+"` "+orderBy+" LIMIT "+perPage+" OFFSET "+offset+") AS  `SPACE` LEFT JOIN "+company_databasename+".`so_floors` AS `Floor` ON `SPACE`.floor_id = `Floor`.floor_id LEFT JOIN "+company_databasename+".`so_buildings` AS `Building` ON `Building`.building_id = `Floor`.building_id LEFT JOIN "+company_databasename+".`so_space_type` AS `SPACETYPE` ON `SPACETYPE`.space_type_id = `SPACE`.space_type_id";
	            //var query ="SELECT  `SPACE`.*,(SELECT group_concat(concat(`A`.amenity_name,':',`A`.amenity_image) separator ',') FROM "+company_databasename+".`so_space_amenities` AS `SA` LEFT JOIN "+company_databasename+".`so_amenities` AS `A` ON `SA`.amenity_id = `A`.amenity_id WHERE `SA`.space_id = `SPACE`.space_id group by `SA`.space_id) as space_amenities, `Floor`.floor_name, `Building`.building_name,`SPACETYPE`.space_type_name FROM ( SELECT `Space`.`space_id`, `Space`.`space_name`, `Space`.`floor_id`, `Space`.`space_capacity`, `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, `Space`.`space_notes`, `Space`.`space_image`, `Space`.`status` FROM "+company_databasename+".`so_spaces` AS `Space` WHERE `Space`.`deleted_at` IS NULL AND (`Space`.`space_name` LIKE '%"+search+"%') ORDER BY `Space`.`space_name` asc LIMIT 10 OFFSET 0) AS  `SPACE` LEFT JOIN "+company_databasename+".`so_floors` AS `Floor` ON `SPACE`.floor_id = `Floor`.floor_id LEFT JOIN "+company_databasename+".`so_buildings` AS `Building` ON `Building`.building_id = `Floor`.building_id LEFT JOIN "+company_databasename+".`so_space_type` AS `SPACETYPE` ON `SPACETYPE`.space_type_id = `SPACE`.space_type_id";
	            var query = "SELECT  `SPACE`.*, " 
					query += "(SELECT group_concat(concat(`A`.amenity_name,':',`A`.amenity_image) separator ',') FROM "+company_databasename+".`so_space_amenities` AS `SA` ";
					query += " LEFT JOIN "+company_databasename+".`so_amenities` AS `A` ON `SA`.amenity_id = `A`.amenity_id WHERE `A`.deleted_at IS NULL AND `A`.status=1 AND `SA`.space_id = `SPACE`.space_id AND `SA`.deleted_at IS NULL  group by `SA`.space_id) as space_amenities "; 
					query += " FROM ( SELECT `Space`.`space_id`, `Space`.`space_name`,  `Space`.`floor_id`, `Space`.`space_capacity`, `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, `Space`.`space_notes`, `Space`.`space_image`, `Space`.`status`,`Floor`.floor_name, `Building`.building_name,`SPACETYPE`.space_type_name FROM "+company_databasename+".`so_spaces` AS `Space` ";
					query += " LEFT JOIN "+company_databasename+".`so_floors` AS `Floor` ON `Space`.floor_id = `Floor`.floor_id LEFT JOIN "+company_databasename+".`so_buildings` AS `Building` ON `Building`.building_id = `Floor`.building_id LEFT JOIN "+company_databasename+".`so_space_type` AS `SPACETYPE` ON `SPACETYPE`.space_type_id = `Space`.space_type_id WHERE `Space`.`deleted_at` IS NULL AND ";
					query += " ( `Space`.`space_name` LIKE '%"+search+"%' OR `Building`.building_name LIKE '%"+search+"%' OR `Floor`.floor_name LIKE '%"+search+"%' OR `SPACETYPE`.space_type_name LIKE '%"+search+"%') ORDER BY `Space`.`"+sort+"` "+orderBy;

					var countQuery = query + ") AS  `SPACE`";

					query += " LIMIT "+perPage+" OFFSET "+offset;
					query += ") AS  `SPACE`";
	           
	            connection.query(query, function (error, results, fields) {
	              if(error){
	                return res.json({
	                    'success': false,
	                    'message': message.ERROR,
	                    'error': error
	                });
	              }
	                if(results){
	                	async.forEach(results, function (space, callback){ 
	                		if(space.space_image != '' && space.space_image != null){
	                			var path = imageSpacePathObj.mainLink+'/80x80/'+space.space_image;
	                			if(!generalConfig.checkFilePath(path)){
                                   space.image_path = generalConfig.no_image_80;
                                }else{
                                   space.image_path = generalConfig.imageUrl(path);
                                }
	                		} else {
	                			space.image_path = generalConfig.no_image_80;
	                		}

	                		callback();
	                	}, function(err) {

	                        generalConfig.getSpaceTotalCount(req, res, countQuery,  function(count){
	                            accessObj.then(function(resp){
		                            var amenityFinArr = [];
		                            var amenityObj = {};
		                            async.forEach(results, function (item, callback){

		                            	if(item.space_amenities != null){
		                            		var space_amenity_arr = item.space_amenities.split(",");

		                            		for(var i =0; i < space_amenity_arr.length; i++ ){
		                            			var amenityArr = space_amenity_arr[i].split(":");
		                            			var amenity_name = amenityArr[0];
		                            			var amenity_image = amenityArr[1];

	                            				if(amenity_image != ""){
							                        var path = imagePathObj.mainLink+'/'+amenity_image;
							                        if(!generalConfig.checkFilePath(path)){
							                        	amenityObj = {name : amenity_name, path : generalConfig.no_image_80};
							                            amenityFinArr.push(amenityObj);
							                            amenityObj = { name : "", path : ""}
							                        }else{
							                        	amenityObj = { name : amenity_name, path : generalConfig.imageUrl(path)};
							                        	amenityFinArr.push(amenityObj);
							                        	amenityObj = { name : "", path : generalConfig.no_image_80}
							                        }

							                    }
		                            		}
		                            		item.amenityArray = amenityFinArr;
		                            		amenityFinArr = [];
		                            	}else {
		                            		item.amenityArray = null;
		                            		amenityFinArr = [];
		                            	}

		                            	callback();
		                            }, function(err) {
		                            	count = (count != null)?count:0;
			                            return res.json({
			                                'success' : true,
			                                'data' : results,
			                                'draw' : draw,
			                                'accessObj' :resp,
			                                'recordsTotal' : count,
			                                'recordsFiltered' : count,
			                                'message': message.SUCCESS
			                            });
									});
	                	});

	                        });
                        });
	                }
	            });
	        } else {
	        	return res.json({
                	'success' : false,
                	'data' : null,
                	'draw' : draw,
                	'recordsTotal' : 0,
                	'recordsFiltered' : 0,
                	'message': message.ERROR
            	});
	        }
	    });
};


/**
 * @uses Get Fllors list for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.floorList = function (req, res, next) {
	var building_id = req.params.id;
	if(building_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){
				var query = "SELECT `floor_id`, `floor_name` FROM "+company_databasename+".`so_floors` AS `Floors` WHERE `Floors`.`deleted_at` IS NULL AND `Floors`.`status` = 1 AND `Floors`.`building_id` = '"+building_id+"'";
	        	connection.query(query, function (error, results, fields) {
	              if(error){
	                return res.json({
	                    'success': false,
	                    'message': message.ERROR,
	                    'error': error
	                });
	              } else if(results){
	              	res.json({
						'success': true,
						'data': results,
						'message': message.SUCCESS
					});
	              }
	            });
	        } else {
	        	res.json({
					'success': false,
					'message': message.ERROR
				});
	        }
	    });
	}
}


/**
 * @uses Get Fllors list for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.spaceListData = function (req, res, next) {
	var floor_id = req.params.id;
	if(floor_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){
				var query = "SELECT `space_id`, `space_name` FROM "+company_databasename+".`so_spaces` WHERE `deleted_at` IS NULL AND `floor_id` = '"+floor_id+"'";
	        	connection.query(query, function (error, results, fields) {
	              if(error){
	                return res.json({
	                    'success': false,
	                    'message': null,
	                    'error': error
	                });
	              } else if(results){
	              	res.json({
						'success': true,
						'data': results,
						'message': null
					});
	              }
	            });
	        } else {
	        	res.json({
					'success': false,
					'message': null
				});
	        }
	    });
	}
}


/**
 * @uses Get space list for display in dropdown
 *
 * @author RB < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
 */

exports.getSpaceList = function (req, res, next) {
    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
        	var query = "SELECT `space_id`,`space_name` FROM "+company_databasename+".`so_spaces` WHERE `deleted_at` IS NULL";
        	connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              } else if(results){
              	res.json({
					'success': true,
					'data': results,
					'message': message.SUCCESS
				});
              }
            });
        } else {
        	res.json({
				'success': false,
				'message': message.ERROR
			});
        }
    });
}

/**
 * @uses Get all listing data for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.AllListingData = function (req, res, next) {

	var allList = {};
	var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");

	generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
	    	var building = "SELECT `building_id`, `building_name` FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`deleted_at` IS NULL AND `Building`.`status` = 1";
	    	var amenity = "SELECT `amenity_id`, `amenity_name`, `amenity_image` FROM "+company_databasename+".`so_amenities` AS `Amenities` WHERE `Amenities`.`deleted_at` IS NULL AND `Amenities`.`status` = 1";
	    	var SpaceType = "SELECT `space_type_id`, `space_type_name` FROM "+company_databasename+".`so_space_type` AS `SpaceType` WHERE `SpaceType`.`deleted_at` IS NULL";

	    	connection.query(building, function (error, results, fields) {
	    		allList.buildings = (results)?results : {};
    			connection.query(amenity, function (error, amenity, fields) {

    				async.forEach(amenity, function (val, callback){
						if(val.amenity_image != "" && val.amenity_image != null){
							var path = imagePathObj.mainLink+'/'+val.amenity_image;
	    					if(!generalConfig.checkFilePath(path)){
                              	val.image_path = generalConfig.no_image_80;
                            }else{
                              	val.image_path = generalConfig.imageUrl(path);
                            }
						} else {
							val.image_path = generalConfig.no_image_80;
						}
						
						callback()
					}, function(err) {
    					allList.amenities = (amenity)?amenity : {};
    					
					});

					connection.query(SpaceType, function (error, results, fields) {
						allList.spacetypes = (results)?results : {};
						return res.json({
							'success': true,
							'data': allList,
							'message': message.SUCCESS
						});
					});
    			});
	    	});
        } else {
        	res.json({
				'success': false,
				'message': message.ERROR
			});
        }
    });
}


/**
 * @uses create new space
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.addSpace = function (req, res, next) {

	var base64Image = req.body.space_image;
    var filename = req.body.new_space_image;

	// Validation messages
    req.checkBody("space_name", message.SPACE_NAME_REQUIRED).notEmpty();
    req.checkBody("building_id", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("floor_id", message.FLOOR_NAME_REQUIRE).notEmpty();
    //req.checkBody("status", message.STATUS_REQUIRED).notEmpty();
    req.checkBody("space_capacity", message.CAPACITY_REUIRED).notEmpty();
	if (req.body.space_capacity) {
        req.checkBody("space_capacity", message.SPACE_CAPACITY_NUMERIC).isInt();
    }

	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {

		var space_name = (req.body.space_name)?req.body.space_name:'';
		var floor_id = (req.body.floor_id)?req.body.floor_id:'';
		var space_capacity = (req.body.space_capacity)?req.body.space_capacity:'';
		var space_type_id = (req.body.space_type_id)?req.body.space_type_id:'';
		var space_size = (req.body.space_size)?req.body.space_size:'';
		var space_bookable = (req.body.space_bookable)?req.body.space_bookable:0;
		var space_is_private = (req.body.space_is_private)?req.body.space_is_private:0;
		var space_notes = (req.body.space_notes)?req.body.space_notes:'';
		var status = 1; //req.body.status;
		var createdAt = generalConfig.getDateTimeUTC();

		generalConfig.getDataBase(req, res, function(company_databasename){
			if(company_databasename != null){

				var new_file_name = "";
		        var doamin = generalConfig.getDomain(req);
		        var resObj = upload.uploadImage(doamin, "space", base64Image, filename, "", "", "");

				if (resObj.success == true) {
		            new_file_name = resObj.file_name;
		        } else {
		            return res.json({
		                'success': resObj.success,
		                'message': resObj.message
		            });

		        }

				var space_image = (new_file_name)?new_file_name:'';
				var GUID = generalConfig.generateGUID();
				var InsertId = GUID;
				var insert = "INSERT INTO "+company_databasename+".`so_spaces` (`space_id`,`space_name`,`floor_id`,`space_capacity`,`space_type_id`,`space_size`,`space_bookable`,`space_is_private`,`space_notes`,`space_image`,`status`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+space_name+"','"+floor_id+"','"+space_capacity+"','"+space_type_id+"','"+space_size+"',"+space_bookable+",'"+space_is_private+"','"+space_notes+"','"+space_image+"',"+status+",'"+createdAt+"','"+createdAt+"')";

								
				connection.query(insert, function (error, results, fields) {
					if(error){
						res.json({
				            'success': false,
				            'message': message.ERROR,
				        });
					} else if(results){
						if (req.body.amenitiesListGroup) {
							var amenitiesListGroup = [];
							amenitiesListGroup = JSON.parse(JSON.stringify(req.body.amenitiesListGroup));
							for (var i = 0; i < Object.keys(amenitiesListGroup).length; i++) {
								var GUID = generalConfig.generateGUID();
								if (Object.keys(amenitiesListGroup[i]).length > 0) {
									if (amenitiesListGroup[i].space_is_private == true) {
										var query = "INSERT INTO "+company_databasename+".`so_space_amenities` (`space_amenities_id`,`space_id`,`amenity_id`,`created_at`, `updated_at`) VALUES ('"+GUID+"','"+InsertId+"','"+amenitiesListGroup[i].amenity_id+"','"+generalConfig.getDateTimeUTC()+"', '"+generalConfig.getDateTimeUTC()+"')";
										connection.query(query);
									}
								}
							}
						}

						if(Object.keys(amenitiesListGroup).length == i){
							res.json({
								success: true,
								message: message.SPACE_ADD_SUCCESS
							});
						}
					}
				});
			}
			else{
				res.json({
		            'success': false,
		            'message': message.ERROR,
		        });
			}
		});
    }
};


/**
 * @uses Get space data by id for update page
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.getSpaceById = function (req, res, next) {
    var space_id = req.params.id;
    generalConfig.getDataBase(req, res, function(company_databasename){
		if(company_databasename != null){

		    var query = "SELECT `Space`.`space_id`, `Space`.`space_name`, `Space`.`floor_id`, `Space`.`space_capacity`, `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, `Space`.`space_notes`, `Space`.`space_image`, `Space`.`is_maintenance`, `Space`.`status`, `Space`.`created_at` AS `createdAt`, `Space`.`updated_at` AS `updatedAt`, `Space`.`deleted_at`, `Floor`.`floor_id` AS `Floor.floor_id`, `Floor`.`floor_name` AS `Floor.floor_name`, `Floor.Building`.`building_id` AS `building_id` FROM "+company_databasename+".`so_spaces` AS `Space` LEFT OUTER JOIN "+company_databasename+".`so_floors` AS `Floor` ON `Space`.`floor_id` = `Floor`.`floor_id` LEFT OUTER JOIN "+company_databasename+".`so_buildings` AS `Floor.Building` ON `Floor`.`building_id` = `Floor.Building`.`building_id` WHERE `Space`.`space_id` = '"+space_id+"'";
		    var amenity = "SELECT `SpaceAmenities`.`space_amenities_id`, `SpaceAmenities`.`deleted_at`, `SpaceAmenities`.`amenity_id` FROM  "+company_databasename+".`so_space_amenities` AS `SpaceAmenities`  WHERE `SpaceAmenities`.`space_id` = '"+space_id+"' AND `SpaceAmenities`.`deleted_at` is NULL";

		    var domain = generalConfig.getDomain(req);
			var imagePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
			var imgObjSpace = generalConfig.getFilePath(domain, "space", "main", "sub");
			connection.query(amenity, function (error, amenity, fields) {

				connection.query(query, function (error, results, fields) {
					results[0].SpaceAmenities = amenity;						

						if(results[0]['image_path'] != "")
						{
	                        var spaceImagePath = imgObjSpace.mainLink+'/'+results[0]['image_path'];							
	                        if(!generalConfig.checkFilePath(spaceImagePath)){
	                           results[0]['image_path'] = generalConfig.no_image_200;
	                        }else{
	                           results[0]['image_path'] = generalConfig.imageUrl(spaceImagePath)
	                        }
	                    } else {
	                        results[0]['image_path'] = generalConfig.no_image_200;
	                    }

	                async.forEach(results, function (val, callback){
	                	if(val.space_image != ""){
	                        var path = imagePathObj.mainLink+'/'+val.space_image;							
	                        if(!generalConfig.checkFilePath(path)){
	                           val.image_path = generalConfig.no_image_200;
	                        }else{
	                           val.image_path = generalConfig.imageUrl(path)
	                        }
	                    } else {
	                        val.image_path = generalConfig.no_image_200;
	                    }

					callback()
					}, function(err) {
						res.json({
							"success": true,
							"data": results[0],
							"message": null
						});
					});

				});
			});
		} else {
			res.json({
	            'success': false,
	            'message': message.ERROR,
	        });
		}
	});
};


/**
 * @uses update specific space value
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.updateSpace = function (req, res, next) {

	var base64Image = req.body.space_image;
    var filename = req.body.new_space_image;
    var old_filename = req.body.old_space_image;
    var removeImage = req.body.removeImage;
    var space_id = req.body.space_id;

	// Validation messages
    req.checkBody("space_name", message.SPACE_NAME_REQUIRED).notEmpty();
    req.checkBody("building_id", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("floor_id", message.FLOOR_NAME_REQUIRE).notEmpty();
    //req.checkBody("status", message.STATUS_REQUIRED).notEmpty();
    req.checkBody("space_capacity", message.CAPACITY_REUIRED).notEmpty();
	if (req.body.space_capacity) {
        req.checkBody("space_capacity", message.SPACE_CAPACITY_NUMERIC).isInt();
    }

	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {
		var space_name = (req.body.space_name)?req.body.space_name:'';
		var floor_id = (req.body.floor_id)?req.body.floor_id:'';
		var space_capacity = (req.body.space_capacity)?req.body.space_capacity:'';
		var space_type_id = (req.body.space_type_id)?req.body.space_type_id:'';
		var space_size = (req.body.space_size)?req.body.space_size:'';
		var space_bookable = (req.body.space_bookable)?req.body.space_bookable:0;
		var space_is_private = (req.body.space_is_private)?req.body.space_is_private:0;
		var space_notes = (req.body.space_notes)?req.body.space_notes:'';
		var status = req.body.status;
		var updatedAt = generalConfig.getDateTimeUTC();

        generalConfig.getDataBase(req, res, function(company_databasename){
			if(company_databasename != null){
				var new_file_name = "";
		        var doamin = generalConfig.getDomain(req);
		        var resObj = upload.uploadImage(doamin, "space", base64Image, filename, old_filename, removeImage, "");
		        if (resObj.success == true) {
		            new_file_name = resObj.file_name;
		        } else {
					return res.json({
		                'success': resObj.success,
		                'message': resObj.message
		            });
		        }

				var update = "UPDATE "+company_databasename+".`so_spaces` SET `space_name`='"+space_name+"',`floor_id`='"+floor_id+"',`space_capacity`="+space_capacity+",`space_type_id`='"+space_type_id+"',`space_size`='"+space_size+"',`space_bookable`="+space_bookable+",`space_is_private`='"+space_is_private+"',`space_notes`='"+space_notes+"',`space_image`='"+new_file_name+"',`status`="+status+",`updated_at`='"+updatedAt+"' WHERE `space_id` = '"+space_id+"'";
				connection.query(update, function (error, results, fields) {
					if(error){
						res.json({
				            'success': false,
				            'message': message.ERROR,
				        });
					} else if(results){
						// var remvQuery = "DELETE FROM "+company_databasename+".`so_space_amenities` WHERE `space_id` = '"+space_id+"'";
				// var remvQuery  = "DELETE  FROM  "+company_databasename+".`so_space_amenities` AS `SpaceAmenities` ";
			 //    remvQuery += " LEFT JOIN   "+company_databasename+".`so_amenities` AS `Amenities` ON `Amenities`.`amenity_id` =  `SpaceAmenities`.`amenity_id` ";
			 //    remvQuery += " WHERE `SpaceAmenities`.`space_id` = '"+space_id+"'";

				var remvQuery =  "UPDATE "+company_databasename+".`so_space_amenities` ";
		remvQuery += " LEFT JOIN "+company_databasename+". `so_amenities` ON `so_amenities`.`amenity_id` = `so_space_amenities`.`amenity_id`";
		remvQuery +=  " SET `so_space_amenities`.`deleted_at`  = '"+updatedAt+"'";
		remvQuery += " where `so_space_amenities`.`space_id` = '"+space_id+"' and `so_amenities`.`status` = 1";


						connection.query(remvQuery, function (error, results, fields) {
							
							if(results){
								if (req.body.amenitiesListGroup) {
									var amenitiesListGroup = [];
									amenitiesListGroup = JSON.parse(JSON.stringify(req.body.amenitiesListGroup));

									for (var i = 0; i < Object.keys(amenitiesListGroup).length; i++) {
																			
										var GUID = generalConfig.generateGUID();
										if (Object.keys(amenitiesListGroup[i]).length > 0) {
											if (amenitiesListGroup[i].space_is_private == true) {
												var query = "INSERT INTO "+company_databasename+".`so_space_amenities` (`space_amenities_id`,`space_id`,`amenity_id`,`created_at`,`updated_at`) VALUES ('"+GUID+"','"+space_id+"','"+amenitiesListGroup[i].amenity_id+"','"+generalConfig.getDateTimeUTC()+"','"+generalConfig.getDateTimeUTC()+"')";
												connection.query(query, function (error, amntResults, fields) {
												});
											}
										}
									}

									if(Object.keys(amenitiesListGroup).length == i){
										res.json({
											success: true,
											message: message.SPACE_ADD_SUCCESS
										});
									}
								} else {
									res.json({
										success: true,
										message: message.SPACE_ADD_SUCCESS
									});
								}

							}
						});
					}
				});
			}else{
				res.json({
		            'success': false,
		            'message': message.ERROR,
		        });
			}
		});
    }
};


/**
 * @uses update specific space status value
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.updateSpaceStatus = function (req, res, next) {

	var statusValue = (req.body.status==1) ? 0 : 1;
	var space_id = req.body.id;
	var updated_at = generalConfig.getDateTimeUTC();

	if(space_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
			if(company_databasename != null){
				var query = "UPDATE "+company_databasename+".`so_spaces` SET `status`='"+statusValue+"', `updated_at`='"+updated_at+"' WHERE `space_id` = '"+space_id+"'";
				connection.query(query, function (error, results, fields) {
					if(error){
						res.json({
				            'success': false,
				            'message': message.ERROR,
				        });
					} else if(results){
						res.json({
							success: true,
							message: message.STATUS_UPDATE
						});
					}
				});
			} else {
				res.json({
		            'success': false,
		            'message': message.ERROR,
		        });
			}

		});
	} else {
		res.json({
            'success': false,
            'message': message.ERROR,
        });
	}
};


/**
 * @uses soft delete space data by id
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.removeSpace = function (req, res) {
	var space_id = req.body.id;
	var deleteData = generalConfig.getDateTimeUTC();
	if(space_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
			if(company_databasename != null){

				var query = "UPDATE "+company_databasename+".`so_spaces` SET `deleted_at`='"+deleteData+"' WHERE `space_id` = '"+space_id+"'";
				connection.query(query, function (error, results, fields) {
					if(!error){
						var deleteQuery = "DELETE FROM "+company_databasename+".`so_space_amenities` WHERE `space_id` = '"+space_id+"'";
						connection.query(deleteQuery, function (deleteAmenityError, results, fields) {
							if(!deleteAmenityError){

								var deleteSensorQuery = "DELETE FROM "+company_databasename+".`so_sensor_master` WHERE `space_id` = '"+space_id+"'";
								//var deleteSensorQuery = "UPDATE "+company_databasename+".`so_sensor_master` AS `Sensor` SET `Sensor`.`deleted_at`='"+deleteData+"' WHERE `Sensor`.`space_id` = '"+space_id+"'";
								connection.query(deleteSensorQuery, function (deleteSensorError, results, fields) {
									if(!deleteSensorError){
										res.json({
											success: true,
											data: null,
											message: message.DELETE
										});
									}
								});
								
							}
						});
					}
				});

			} else {
				res.json({
		            'success': false,
		            'message': message.ERROR,
		        });
			}
		});

	} else {
		res.json({
            'success': false,
            'message': message.ERROR,
        });
	}
};



/**
 * @uses for space calendar meeting detail
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.getMeetingSpaceById = function(req, res, next){
	
	let userObj = generalConfig.getUserInfo(req);
	let timezone = '';
	let timeDiffOffset = '';
	if (userObj) {
		timezone = userObj.data.timezone;
		timeDiffOffset = userObj.data.time_difference;
	}
	
	var space_id = req.body.space_id;
	//var date1 = new Date((req.body.start)*1000);
	//var datee = dateFormat(date1, "UTC:yyyy-mm-dd HH:MM:ss");
	//var date2 = new Date((req.body.end)*1000);
	//var datee2 = dateFormat(date2, "UTC:yyyy-mm-dd HH:MM:ss");

	let datee = generalConfig.getUTCDateTime((req.body.start)*1000, timeDiffOffset, timezone);
	let datee2 = generalConfig.getUTCDateTime((req.body.end)*1000, timeDiffOffset, timezone);
	
    generalConfig.getDataBase(req, res, function(company_databasename){
		if(company_databasename != null){
			var now = new Date();
    		var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
    		var userObj = generalConfig.getUserInfo(req);
    		var user = userObj.data;

			var query = "";
			var amenity = "";
			var booking = "";

			var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"'";

        	connection.query(userQuery, function (error, userResult, fields) {
        	
	        	if(userResult.length > 0){
	        		var email_id = userResult[0].email_id;
	        		var email = userResult[0].email;
	        		var time_difference = userResult[0].time_difference;
	        	}

			    query += " SELECT `Space`.`space_id`, `Space`.`space_name`, `Space`.`floor_id`, `Space`.`space_capacity`, sp.space_type_name, ";
			    query += " `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, ";
			    query += " `Space`.`space_notes`, `Space`.`space_image`, `Space`.`is_maintenance`, `Space`.`status`, ";
			    query += " `Space`.`created_at` AS `createdAt`, `Space`.`updated_at` AS `updatedAt`, `Space`.`deleted_at`, ";
			    query += " `Floor`.`floor_id` AS `floor_id`, `Floor`.`floor_name` AS `floor_name`, ";
			    query += " `Building`.`building_id` AS `building_id`, `Building`.`building_name` AS `building_name` ";
			    query += " FROM "+company_databasename+".`so_spaces` AS `Space` ";
			    query += " LEFT OUTER JOIN "+company_databasename+".`so_floors` AS `Floor` ON `Space`.`floor_id` = `Floor`.`floor_id` ";
			    query += " LEFT OUTER JOIN "+company_databasename+".`so_space_type` AS `sp` ON `sp`.`space_type_id` = `Space`.`space_type_id` ";
			    query += " LEFT OUTER JOIN "+company_databasename+".`so_buildings` AS `Building` ON `Floor`.`building_id` = `Building`.`building_id` ";
			    query += " WHERE `Space`.`space_id` = '"+space_id+"'";

			    amenity += " SELECT `Amenities`.`amenity_image`,`Amenities`.`amenity_name` ";
			    amenity += " FROM  "+company_databasename+".`so_space_amenities` AS `SpaceAmenities` ";
			    amenity += " LEFT JOIN   "+company_databasename+".`so_amenities` AS `Amenities` ON `Amenities`.`amenity_id` =  `SpaceAmenities`.`amenity_id` ";
			    amenity += " WHERE `SpaceAmenities`.`space_id` = '"+space_id+"' AND `SpaceAmenities`.`deleted_at` IS NULL";

			    booking += " SELECT booking_title as title, booking_details, booking_id, ";
				booking += " DATE_FORMAT(start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
                booking += " DATE_FORMAT(end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
                    
				// booking += " DATE_FORMAT(CONVERT_TZ(start_time,'+00:00','"+time_difference+"'),'%Y-%m-%dT%I:%i:%s') AS start, ";  
				// booking += " DATE_FORMAT(CONVERT_TZ(end_time,'+00:00','"+time_difference+"'),'%Y-%m-%dT%I:%i:%s') AS end,  ";
				// booking += " DATE_FORMAT(CONVERT_TZ(start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y %l:%i %p') as display_start_date, ";  
               	// booking += " IF(start_time >= '"+currentDate+"', true, false) as is_delete_valid, ";               
				// booking += " DATE_FORMAT(CONVERT_TZ(end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y %l:%i %p') as display_end_date  ";

				booking += " IF(start_time >= '"+currentDate+"', true, false) as is_delete_valid ";               
			    booking += " FROM  "+company_databasename+".`so_space_booking` ";
			    booking += " WHERE  `space_id` =  '"+space_id+"'";
		    	booking += " AND deleted_at is NULL";
		    	booking += " AND start_time >= '"+datee+"'";
               	booking += " AND end_time <= '"+datee2+"'";

			    var domain = generalConfig.getDomain(req);
				var imagePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
				var amenityimagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");

				connection.query(amenity, function (error, amenity, fields) {
					async.forEach(amenity, function (val, callback){
	                	if(val.amenity_image != ""){
	                        var path = amenityimagePathObj.mainLink+'/'+val.amenity_image;
	                        if(!generalConfig.checkFilePath(path)){
	                           val.amenity_image_path = generalConfig.no_image_200;
	                        }else{
	                           val.amenity_image_path = generalConfig.imageUrl(path)
	                        }
	                    } else {
	                        val.amenity_image_path = generalConfig.no_image_200;
	                    }

					callback()
					}, function(err) {
						connection.query(query, function (error, results, fields) {
							if(results[0]) {
							results[0].SpaceAmenities = amenity;
			                async.forEach(results, function (val, callback){
			                	if(val.space_image != ""){
			                        var path = imagePathObj.mainLink+'/'+val.space_image;
			                        if(!generalConfig.checkFilePath(path)){
			                           val.image_path = generalConfig.no_image_200;
			                        }else{
			                           val.image_path = generalConfig.imageUrl(path);
			                        }
			                    } else {
			                        val.image_path = generalConfig.no_image_200;
			                    }

							callback()
							}, function(err) {

								connection.query(booking, function (error, booking, fields) {
									if(booking){
										var bookingArray = [];
										async.forEach(booking, function (booking, callback){
											bookingArray.push(booking);
											callback()
										}, function(err) {
											res.json({
												"success": true,
												"data": results[0],
												"booking_data": bookingArray,
												"message": null
											});
										});
									}
								});
							});
							}
						});
					});
				});
			});
		} else {
			res.json({
	            'success': false,
	            'message': message.ERROR,
	        });
		}
	});
}

exports.allBuildingFloorListData = function(req, res, next){
	generalConfig.getDataBase(req, res, function(company_databasename){
		if(company_databasename != null){
			var floor = " SELECT floor_id, floor_name FROM "+company_databasename+".`so_floors` WHERE status = 1 AND deleted_at IS NULL ";
			var space = " SELECT space_id, space_name FROM "+company_databasename+".`so_spaces` WHERE deleted_at IS NULL ";
			var building = " SELECT building_id, building_name FROM "+company_databasename+".`so_buildings` WHERE status = 1 AND deleted_at IS NULL ";
			var resultsObj = {};
			connection.query(building, function (error, building, fields) {
				if(building){
					connection.query(floor, function (error, floor, fields) {
						if(floor){
							connection.query(space, function (error, space, fields) {
								if(space){
									resultsObj.building = building;
									resultsObj.floor = floor;
									resultsObj.space = space;

									res.json({
										"success": true,
										"data": resultsObj,
										"message": null
									});
								}
							});
						}

					});
				}
			});

		} else {
			res.json({
	            'success': false,
	            'message': message.ERROR,
	        });
		}
	});
}