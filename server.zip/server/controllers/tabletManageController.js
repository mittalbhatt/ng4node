'use strict';


var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;

/**
 * @uses (getTabletList) fetch Tablets list
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/
exports.getTabletList = function(req, res, next){
    
    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir; 
    
    db.models.TabletMaster.findAndCountAll({
        where : {
        	deleted_at: {
              $eq: null
            },
           $or: [
                {device_id: {$like: '%' + search + '%'}},
                {device_activation_key: {$like: '%' + search + '%'}},
                { '$Space.space_name$': { $like: '%' + search + '%'}},
                { '$DeviceMaster.device_name$': { $like: '%' + search + '%'}}
            ]
        },
        include: [
        { model: db.models.Space, attributes: ['space_name'] },
        { model: db.models.DeviceMaster, attributes: ['device_name'] }
        ],
            order: [[sort, orderBy]],
            offset:offset,
            limit:perPage
        })
        .then(function(data) {

            res.json({
                'success' : true,
                'data' : data.rows,
                'draw' : draw,
                'recordsTotal' : data.count,
                'recordsFiltered' : data.count,
                'message': message.SUCCESS
            });
        })
        .catch(function(err) {
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });        
        });
}

/**
 * @uses (addTablet) insert new tablet device data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.addTablet = function(req, res, next) {

    var device_id = req.body.device_id;
    var space_id = req.body.space_id;
    var status = parseInt(req.body.status);
    var errMsg = [];

    var device_activation_key = generalConfig.generateRandomNum();
    var createDate = generalConfig.getDateTimeUTC();

    req.checkBody({
        'device_id': {
            notEmpty: true,
            errorMessage: 'Device ID is required'
        },
        'space_id':{
            notEmpty: true,
            errorMessage: 'Space is required'
        }
    });

    var errors = req.validationErrors();

	var errMsg = {};

    if (errors) {
        
        errors.forEach(function (err) {			
			errMsg[err.param] = [err.msg];
        });

        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else { 

        db.models.TabletMaster.create({
            device_id               : (device_id)?device_id:'',
            device_activation_key   : (device_activation_key)?device_activation_key:'',
            space_id                : (space_id)?space_id:'',
            status                  : status,
            created_at              : createDate
        })
        .then(function(user) {
            res.json({
                'success' : true,
                'message': message.TABLET_ADD_SUCCESS
            });
        })
        .catch(function(err) {
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });
        });
    }
};

/**
 * @uses (getEditTablet) fetch selected tablet device info
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.getEditTablet = function(req, res, next){
    
    var tablet_id = req.body.tablet_id;

    if(tablet_id){

        db.models.TabletMaster.findOne({
            where: { tablet_id: tablet_id },
            include: [
                { model: db.models.DeviceMaster, attributes: ['device_name'] }
            ]
        }).then(function(data) {
                
                res.json({
                    'success' : true,
                    'data' : data,
                    'message': message.SUCCESS
                });
            })
            .catch(function(err) {
                res.json({
                    'success': false,
                    'message': message.NOT_FOUND,
                    'error': err
                });        
            });
        
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}


/**
 * @uses (updateTablet) Update tablet device data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateTablet = function(req, res, next) {

    var tablet_id = req.body.tablet_id;
    var device_id = req.body.device_id;
    var space_id = req.body.space_id;
    var status = parseInt(req.body.status);
    var updateDate = generalConfig.getDateTimeUTC();
    var errMsg = [];

    req.checkBody({
        'device_id': {
            notEmpty: true,
            errorMessage: 'Device ID is required'
        },
        'space_id':{
            notEmpty: true,
            errorMessage: 'Space is required'
        }
    });

    var errors = req.validationErrors();

    var errMsg = {};

    if (errors) {
        
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        });

        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else { 

        if(tablet_id){

            db.models.TabletMaster.update({
                device_id   : (device_id)?device_id:'',
                space_id    : (space_id)?space_id:'',
                status      : status,
                updated_at  : updateDate
            },{
                where: { tablet_id: tablet_id }
            })
            .then(function(user) {
                res.json({
                    'success' : true,
                    'message': message.TABLET_UPDATE
                });
            })
            .catch(function(err) {
                res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': err
                });
            });
            
        } else {
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });
        }
    }
};

/**
 * @uses (removeTablet) remove selected tablet from database (soft delete)
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.removeTablet = function(req, res, next){
    
    var tablet_id = req.body.tablet_id;
    var deleteDate = generalConfig.getDateTimeUTC();
    if(tablet_id){
        db.models.TabletMaster.update({ deleted_at:deleteDate },{
            where: { tablet_id: tablet_id }
        }).then(function(data) {

                if(data == 1){
                    res.json({
                        'success' : true,
                        'message': message.TABLET_DELETE
                    });
                } else {

                    res.json({
                        'success' : false,
                        'message': message.NOT_FOUND
                    });
                }

            })
            .catch(function(err) {
                res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': err
                });        
            });
        
    }else{
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}

/**
 * @uses (updateTabletStatus) update status of  selected tablet from database
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateTabletStatus= function(req, res, next){
    
    var tablet_id = req.body.tablet_id;
    var status = (req.body.status == 1)?0:1;
    var updateDate = generalConfig.getDateTimeUTC();

    if(tablet_id){
        db.models.TabletMaster.update({ status:status, updated_at:updateDate},{
            where: { tablet_id: tablet_id }
        }).then(function(data) {

                if(data == 1){
                    res.json({
                        'success' : true,
                        'message': message.STATUS_UPDATE
                    });
                } else {

                    res.json({
                        'success' : false,
                        'message': message.NOT_FOUND
                    });
                }

            })
            .catch(function(err) {
                res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': err
                });        
            });
        
    }else{
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}



/**
 * @uses (updateTabletStatus) update status of  selected tablet from database
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateTabletBookStatus= function(req, res, next){
    
    var tablet_id = req.body.tablet_id;
    var status = (req.body.status == 1)?0:1;
    var updateDate = generalConfig.getDateTimeUTC();

    if(tablet_id){
        db.models.TabletMaster.update({ is_booking:status, updated_at:updateDate },{
            where: { tablet_id: tablet_id }
        }).then(function(data) {

                if(data == 1){
                    res.json({
                        'success' : true,
                        'message': message.STATUS_UPDATE
                    });
                } else {

                    res.json({
                        'success' : false,
                        'message': message.NOT_FOUND
                    });
                }

            })
            .catch(function(err) {
                res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': err
                });        
            });
        
    }else{
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}
