'use strict';

// var generalConfig = require('../config/generalConfig');
var Sequelize = require('sequelize');
var passport = require('passport');
var DBMigrate = require('db-migrate');
var sequlizeConfig = require('../config/sequelize');
var generalConfig = require('../config/generalConfig');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var mysql = require('mysql');
var LANG = require('../common/language');
var message = LANG.msg;
var moment = require('moment');
var dotenv = require('dotenv').config();
var mysql      = require('mysql');
const fs = require('fs-extra');
var async = require('async');


exports.login = function(req, res, next) {
	passport.authenticate('local', function(err, user, info) {
		
		if(!user) {
			if(err) {
				console.log("----Out and failed to session ----"+err);
				res.json({status:err});
			} else {
				console.log("----Out and failed to session --- ----"+info);
				res.json({status:'fail'});
			}
		} else {

			console.log("============== In success and set session =================");
			var curUserID = user.user_id;
			console.log("============== In success and set session =================");

            // var curUserID = encrypt(curUserID.toString());
			// req.session.admin = user;
			 res.json({
                success:true,

                data:user,
                message:'Login successfully'
            });
		}
	})(req, res, next);
};

exports.getUserInfo = function (req, res, next){
    
    var userInfo = generalConfig.getUserInfo(req);

    if(userInfo){

        var user_id = userInfo.data.user_id;

        master_db.models.User
        .findOne({ where: { user_id: user_id } })
        .then(function(user) {
            
            if(user){
                res.json({
                    success:true,
                    data:user,
                    message:message.SUCCESS
                });
            }
            
        })
        .catch(function(err) {
            res.json({
                error: true,
                data: err,
                message: message.ERROR
            });    
        });
    }
};

exports.getRoleFromDomain = function(req, res, next) {

    var userInfo = generalConfig.getRoleFromDomain(req);
   
    if (userInfo) {

        res.json({
            success: true,
            data: userInfo,
            message: message.SUCCESS
        });

    } else {

        res.json({
            success: true,
            message: message.ERROR
        });

    }
};

exports.signout = function (req, res) {
	console.log("---------- Session Destroy admin -----------");
	delete req.session.admin;
	res.json({status:"success"});
	/*req.session.destroy(function(err) {
		console.log("---------- Session Destroy admin -----------");
		res.json({status:"success"});
	})*/
};

exports.getSession = function(req, res){
	/*console.log("---------- Get Session data-----------");
	if(req.session.admin) {
		//console.log(req.session.user);
		res.json(req.session.admin);
	} else {
		console.log("No User Found");
		res.json({status:'fail'});
	}*/
};

/**
    * Find user by id
*/
exports.getById = function(req, res, next) {

	/*console.log('Welcome here');
	console.log(req.body);

	var decryptedUserID = decrypt(req.body.user_id);
	var id = parseInt(decryptedUserID);

    db.User.find({
    	attributes : ['id','email','firstname','lastname','birthday','contact','gender','profilePicture','isAdmin','userStatus','questionId','answer'],
    	where : { id: id }
    }).then(function(user){
    	if (!user)
            return next(new Error('Failed to load User ' + id));
        req.profile = user;
        res.json(user);
        //next();
    }).catch(function(err){
    	res.json({status:err});
        //next(err);
    });*/
};

/*
	Module : Login Cookie Encryption
	Author : Mayank [SOFTWEB]
	Inputs : PLain format of Email, Password
	Output : Encrypt inputed Email and Password
	Date   : 2015-12-10
*/
exports.encryptCookies = function(req, res){
	/*var encryptedPassword = encrypt(req.body.rememberPass);
	var encryptedEmail = encrypt(req.body.rememberEmail);
	res.json({encEmail : encryptedEmail , encPass : encryptedPassword});*/
};

/*
	Module : Login Cookie Decryption
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted format of Email, Password
	Output : Decrypt posted Email and Password
	Date   : 2015-12-10
*/
exports.decryptCookies = function(req, res){

	/*console.log(req.body);

	var decryptedEmail = decrypt(req.body.cookieEmailAdmin);
	var decryptedPassword = decrypt(req.body.cookiePasswordAdmin);
	res.json({decEmail : decryptedEmail , decPass : decryptedPassword});*/
};


/*
	Module : Encryption function
	Author : Mayank [SOFTWEB]
	Inputs : text
	Output : Encrypt text
	Date   : 2015-12-03
*/
function encrypt(text){
  /*var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password)
;  var crypted = cipher.update(text,'utf8','hex');
  crypted += cipher.final('hex');
  return crypted;*/
}

/*
	Module : Decryption function
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted text
	Output : Simple text
	Date   : 2015-12-03
*/
function decrypt(text){
  /*var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  var dec = decipher.update(text,'hex','utf8');
  dec += decipher.final('utf8');
  return dec;*/
}


/**
 * @company registration
 *
 * @author RB < @softwebsolutions.com >
 *
 * @return json
 */

exports.register = function(req, res, next) {

    var database = 'DATABASE';
    var first_name = req.body.first_name;
    var last_name = req.body.last_name;
    var email = req.body.email;
    var phone_number = req.body.phone_number;
    req.body.password = generalConfig.encryptPassword(req.body.password);

    var errMsg = [];
    req.checkBody("first_name", "First Name is required").notEmpty();
    req.checkBody("last_name", "Last Name is required").notEmpty();
    req.checkBody("email", "Email is required").notEmpty();
    req.checkBody("phone_number", "Phone Number is required").notEmpty();

    var errors = req.validationErrors();


    if (errors) {

        errors.forEach(function(err) {
            errMsg.push(err.msg);
        });

        res.json({
            'success': false,
            'message': errMsg
        });

    } else {

        master_db.models.companyMaster.find({
            where: {
                company_domain_prefix: req.body.domain_name
            }
        }).then(function(companyMaster) {

            if (!companyMaster) {
                master_db.models.User.find({
                    where: {
                        email: req.body.email

                    },
                }).then(function(users) {

                    if (!users) {

                        req.body.company_domain_prefix = req.body.domain_name;
                        var featureArray = [{
                                "feature-id": 1,
                                "feature-slug": 'amenities'
                            },
                            {
                                "feature-id": 2,
                                "feature-slug": 'issue-reporting'
                            },
                            {
                                "feature-id": 3,
                                "feature-slug": 'admin-booking'
                            },
                            {
                                "feature-id": 4,
                                "feature-slug": 'indoor-wayfinding'
                            },
                            {
                                "feature-id": 5,
                                "feature-slug": 'saml-single-sign-on'
                            }, {
                                "feature-id": 6,
                                "feature-slug": 'meeting-services'
                            },


                        ]

                        req.body.user_type = 'CompanyAdmin';
                        req.body.created_at = generalConfig.getDateTimeUTC();
                        req.body.timezone = generalConfig.default_timezone;

                        var array = JSON.stringify(featureArray);
                        var users = master_db.models.User.build(req.body);
                        var company = master_db.models.companyMaster.build(req.body);
                        var map = master_db.models.companyUser.build(req.body);
                        company.company_db_name = "smartoffice_" + req.body.domain_name;
                        company.save().then(function(company) {
                            users.save().then(function(user) {
                                map.company_id = company.company_id;
                                map.user_id = user.user_id;
                                map.save().then(function(companyUser) {
                                    master_db.models.Plan.find({
                                        where: {
                                            plan_price: 0
                                        },
                                        include: [{
                                            model: master_db.models.PlanDetails,
                                            where: {
                                                deleted_at: {
                                                    $eq: null
                                                }
                                            }
                                        }],
                                    }).then(function(plan) {
                                        var companyUserDetail = master_db.models.CompanyDetails.build({
                                            company_id: company.company_id,
                                            plan_id: plan.plan_id,
                                            plan_name: plan.plan_name,
                                            plan_price: plan.plan_price,
                                            no_of_month: 1,
                                            no_of_user: plan.PlanDetail.no_of_employee,
                                            no_of_space: plan.PlanDetail.no_of_space,
                                            is_renew: 0,
                                            feature_detail: array,
                                            plan_start_date: new Date(),
                                            plan_end_date: new Date().setMonth(new Date().getMonth() + 1),
                                            status: 1,
                                            created_at: generalConfig.getDateTimeUTC(),

                                        });
                                        companyUserDetail.save().then(function(companyUser) {

                                            var databaseName = "smartoffice_" + (req.body.domain_name);
                                            var connection = mysql.createConnection({
                                                host: process.env.MASTER_DATABASE_HOST,
                                                user: process.env.MASTER_DATABASE_USERNAME,
                                                password: process.env.MASTER_DATABASE_PASSWORD,
                                            });

                                            connection.connect();

                                            connection.query("CREATE DATABASE " + databaseName + "", function(error, results, fields) {


                                                if (error) {

                                                    if (error.code == 'ER_DB_CREATE_EXISTS') {
                                                        res.json({
                                                            success: false,
                                                            message: 'Database Already Exists!'
                                                        });

                                                    }

                                                } else {

                                                    process.env.DATABASE = databaseName;
                                                    var dbm = DBMigrate.getInstance(true);
                                                    dbm.up(40).then(function() {


                                                        connection.query("INSERT INTO " + databaseName + ".`so_amenities` SELECT * FROM `smartoffice_master`.`so_company_master_amenities`"),
                                                            function(error, results, fields) {

                                                                if (error) {


                                                                } else {


                                                                }
                                                            }

                                                        const dir = 'images/uploads/' + req.body.domain_name;
                                                        // With Promises:
                                                        fs.ensureDir(dir)
                                                            .then(() => {
                                                                // Promise usage:
                                                                fs.copy('images/default/amenity_images', 'images/uploads/' + req.body.domain_name + '/amenity_images' )
                                                                    .then(() => {
                                                                        var data = {
                                                                            company: companyUser,
                                                                            user: user
                                                                        }
                                                                        res.json({
                                                                            success: true,
                                                                            data: data,
                                                                            domain: req.body.domain_name,
                                                                            message: "Records Inserted Successfully!"
                                                                        });
                                                                    })
                                                                    .catch(err => {})


                                                            })
                                                            .catch(err => {
                                                                console.error(err)
                                                            })

                                                    });

                                                }
                                            })


                                        }).catch(function(err) {


                                            res.json({
                                                success: false,
                                                message: err
                                            });

                                        })

                                    }).catch(function(err) {

                                        res.json({
                                            success: false,
                                            message: err
                                        });
                                    });

                                }).catch(function(err) {

                                    res.json({
                                        success: false,
                                        message: err
                                    });
                                });

                            })
                        }).catch(function(err) {
                            res.json({
                                success: false,
                                message: err
                            });
                        });
                    } else {
                        res.json({
                            success: false,
                            message: "This Email Address Already Exists!"
                        });

                    }
                })


            } else {

                res.json({
                    success: false,
                    message: "This Domain Already Exists!"
                });

            }

        })



    }
};
exports.saveUserOffice = function(req, res, next) {

    master_db.models.companyMaster.find({
        where: {
            company_id: req.body.company_id,
        }
    }).then(function(Company) {

        if (Company) {

            master_db.models.companyMaster.update(req.body, {
                where: {
                    company_id: req.body.company_id
                }
            }).then(function(company) {

                res.json({
                    success: true,
                    message: 'Company name updated'
                })


            }).catch(function(err) {
                res.json({
                    success: false,
                    message: err
                });
            });
        }
    }).catch(function(err) {
        res.json({
            success: false,
            message: err
        });
    });




};
exports.getAccessRight = function(req, res, next){
    
    var userObj = generalConfig.getUserInfo(req);
    var returnObj = {};
    var currentDate = generalConfig.getDateTimeUTC();
    
    var domain = generalConfig.getDomain(req);

    if(generalConfig.masterDoamin == domain){
        var imagePathObj = generalConfig.getFilePath(domain, "master", "main", "sub");
    } else {
        var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
    }

    if(userObj){
        var user_id = userObj.data.user_id;

         master_db.models.User
        .findOne({ 
            where: { user_id: user_id },
            attributes : ['user_id','email',[Sequelize.fn('CONCAT',Sequelize.col('first_name'),' ',Sequelize.col('last_name')), 'full_name'],'profile_picture','timezone','time_difference']
        })
        .then(function(loggedinUser) { 
            if(loggedinUser.dataValues.profile_picture != ""){
                var path = 'src/'+imagePathObj.mainLink+'/'+loggedinUser.dataValues.profile_picture;
                if(!fs.existsSync(path)){
                    loggedinUser.dataValues.profile_picture = "";
                } else {
                    loggedinUser.dataValues.profile_picture = imagePathObj.mainLink+'/'+loggedinUser.dataValues.profile_picture;
                }
            }else{
                loggedinUser.dataValues.profile_picture = "";
            }

            if(loggedinUser){

                master_db.models.companyUser
                .findOne({ 
                    where: { user_id: user_id }
                })
                .then(function(user) {
                    if(user.company_id == '') {
                        res.json({
                            success: true,
                            message: message.SUCCESS
                        });
                    } else {
                   if(user && user.company_id){
                    var company_id = user.company_id;
                        
                        master_db.models.CompanyDetails.findOne({ 
                            where: { 
                                company_id: company_id,
                                plan_start_date: { $lte: currentDate },
                                plan_end_date: { $gte: currentDate }
                            }
                        })
                        .then(function(company) {

                            // set profile image path
                            var imgProfileObj = '';
                            if(generalConfig.masterDoamin == domain)
                            {
                                imgProfileObj = generalConfig.getFilePath(domain, "master", "main", "sub");
                            }
                            else
                            {
                                imgProfileObj = generalConfig.getFilePath(domain, "user", "main", "sub");
                            }

                            var companyLogoPath = "";   
                            if(loggedinUser._previousDataValues['profile_picture'] != "" && loggedinUser._previousDataValues['profile_picture']!=null)
                            {
                                var path = imgProfileObj.mainLink+'/'+loggedinUser._previousDataValues['profile_picture'];
                                if(!generalConfig.checkFilePath(path))
                                {
                                   returnObj.profile_picture = generalConfig.no_image_80;
                                }
                                else
                                {
                                   returnObj.profile_picture = generalConfig.imageUrl(path);
                                }                
                            }
                            else
                            {               
                                returnObj.profile_picture = generalConfig.no_image_80;                
                            }

                            if(company){
                                returnObj.user_id = loggedinUser.user_id;
                                returnObj.email = loggedinUser.email;
                                returnObj.full_name = loggedinUser.dataValues.full_name;
                                // returnObj.profile_picture = loggedinUser._previousDataValues['profile_picture'];
                                returnObj.timezone = loggedinUser.timezone;
                                returnObj.time_difference = loggedinUser.time_difference;
                                returnObj.is_renew = company.is_renew;
                                returnObj.no_of_month = company.no_of_month;
                                returnObj.no_of_space = company.no_of_space;
                                returnObj.no_of_user = company.no_of_user;
                                returnObj.plan_end_date = company.plan_end_date;
                                returnObj.plan_start_date = company.plan_start_date;
                                returnObj.plan_name = company.plan_name;
                                returnObj.plan_price = company.plan_price;
                                returnObj.user_type = user.user_type;
                                returnObj.company_id = company.company_id;

                                master_db.models.companyMaster.findOne({
                                    where : { company_id : company.company_id },        
                                    })
                                    .then(function(objCompanyMaster)
                                    {
                                        var imagePathObjForCompany = generalConfig.getFilePath(domain, "company", "main", "sub");

                                        var companyLogoPath = "";   
                                        if(objCompanyMaster.company_logo != "" && objCompanyMaster.company_logo!=null)
                                        {
                                            var path = imagePathObjForCompany.mainLink+'/'+objCompanyMaster.company_logo;
                                            if(!generalConfig.checkFilePath(path))
                                            {
                                               returnObj.company_logo = generalConfig.no_image_80;
                                            }
                                            else
                                            {
                                               returnObj.company_logo = generalConfig.imageUrl(path);
                                            }                
                                        }
                                        else
                                        {               
                                            returnObj.company_logo = generalConfig.no_image_80;                
                                        }

                                        if(returnObj !== "")
                                        {
                                                res.json({
                                                success: true,
                                                data: returnObj,
                                                message: message.SUCCESS
                                            });
                                            return;
                                        }
                                    });
                                
                            } else if(company.user_type == 'MasterAdmin' || company.user_type == 'Admin') {
                                 res.json({
                                        success: true,
                                        message: message.SUCCESS
                                    });
                            } else {
                                res.json({
                                    success: false,
                                    message: message.SUBSCRIPTION_EXPIRE
                                });
                                return;
                            }
                        });
                    }

                    }
                })
                .catch(function(err) {
                    res.json({
                        success: false,
                        data: err,
                        message: message.ERROR
                    });    
                });
            }
        });
    } else {
        res.json({
            success: false,
            message: message.ERROR
        }); 
    }
}