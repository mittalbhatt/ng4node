'use strict';

var fs = require("fs");
var Sequelize = require('sequelize');
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;
var moment = require('moment');
var database = require('../config/database');
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var getObjectDiff = require('object-diff');

exports.getInitList = function(req, res, next){
    
    var master_database = database.master_database.name;
    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;
    
    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
            var find_company_id = "SELECT company_id, user_type, building_id, floor_id  FROM "+master_database+".`so_company_users_map` WHERE `user_id` = '"+user.user_id+"' AND status = 1";
            connection.query(find_company_id, function (error, company, fields) {
                if(company && company.length >0){
                    var company_id = company[0].company_id;
                    //var query = "SELECT user_id, concat(`first_name`,' ', `last_name`) as name FROM "+master_database+".`so_users` WHERE user_id != 1 AND user_id != '' AND deleted_at IS NULL";
                    var query = "SELECT `U`.user_id, concat(`U`.`first_name`,' ', `U`.`last_name`) as name  FROM "+master_database+".`so_company_users_map` AS `CUM` LEFT JOIN "+master_database+".`so_users` AS `U` ON `U`.user_id = `CUM`.user_id  WHERE `CUM`.`company_id` = '"+company_id+"' AND `U`.user_id != 1 AND `U`.user_id != '' AND `U`.status != 0 AND `U`.deleted_at IS NULL";
                    connection.query(query, function (error, results, fields) {
                      if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                      }
                        if(results){
                           var query = "SELECT `space_id`, `space_name` FROM "+company_databasename+".`so_spaces` AS `Space` WHERE `Space`.`deleted_at` IS NULL AND `Space`.`status` = 1";
                           connection.query(query, function (error, space, fields) { 
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });
                                }

                                if(space){
                                    res.json({
                                        'success' : true,
                                        'message': "",
                                        'data':{'users':results,'space':space}
                                    });
                                }
                           });
                        }
                    });
                }
            });

        } else {
            res.json({
                'success' : flase,
                'message': message.ERROR
            });
        }
    });
}


exports.addServiceRequest = function(req, res, next){
 
    var service_title = (req.body.service_title)?req.body.service_title:'';
    var service_due_date      = moment(req.body.service_due_date, "MM-DD-YYYY").format('YYYY-MM-DD');
    var assigned_user_id = (req.body.assigned_user_id)?req.body.assigned_user_id:'';
    var space_id = (req.body.space_id)?req.body.space_id:'';
    var space_name = (req.body.space_name)?req.body.space_name:'';
    var current_status = (req.body.current_status)?req.body.current_status:'';
    var severity = (req.body.severity)?req.body.severity:'';
    var category_name = (req.body.category_name)?req.body.category_name:'';
    var special_instruction = (req.body.special_instruction)?req.body.special_instruction:'';

  
    var status = (req.body.status)?req.body.status:1;    
    var errMsg = [];

    req.checkBody("service_title", message.SERVICE_TITLE_REQUIRED).notEmpty();
    req.checkBody("current_status", message.SERVICE_CURRENT_STATUS_REQUIRED).notEmpty();
    req.checkBody("severity", message.SERVERITY_REQUIRED).notEmpty();
    req.checkBody("category_name", message.SERVICE_CATEGORY_REQUIRED).notEmpty();

    var errors = req.validationErrors();

    var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        }); 
        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else {

        // specified category
        if(!['Administration','Housekeeping','Access Controls','Network & Communication','Others'].includes(category_name))
        {
            return res.json({
                'success': false,
                'message': "Invalid Category"                
            });
        }

        var userObj = generalConfig.getUserInfo(req);
        var user = userObj.data;

        var createDate = generalConfig.getDateTimeUTC();
        var tag = generalConfig.ticketTag;
        var service_ticket_number = generalConfig.getTicketNumber(tag);
        var GUID = generalConfig.generateGUID();

        generalConfig.getDataBase(req, res, function(company_databasename){

            if(company_databasename != null){
                var query = "SELECT `SR`.`service_ticket_number` FROM "+company_databasename+".`so_service_requests` AS `SR` ORDER BY `SR`.`created_at`  DESC LIMIT 1";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    }

                    if(results.length > 0){
                        var lastTicketNum = results[0].service_ticket_number;;
                        if(lastTicketNum){
                           var  split_number = lastTicketNum.replace(/[a-zA-Z]+/, '');
                           var newTicketNum = (parseInt(split_number) + 1);
                           newTicketNum = generalConfig.ticketTag+newTicketNum;
                        }
                    } else {
                        var newTicketNum = generalConfig.ticketTag+10000;
                    }

                    var service_ticket_number = (newTicketNum)?newTicketNum:'';                    
                    var created_by            = (user.user_id)?user.user_id:'';
                    var created_at            = createDate;                    

                        var insert = "INSERT INTO "+company_databasename+".`so_service_requests` (`service_request_id`, `service_title`, `special_instruction`, `service_ticket_number`, `service_due_date`, `space_id`, `space_name`, `created_by`, `assigned_user_id`, `category_name`, `severity`, `current_status`, `status`, `created_at`, `updated_at` ) VALUES ('"+GUID+"', '"+service_title+"', '"+special_instruction+"', '"+service_ticket_number+"', '"+service_due_date+"', '"+space_id+"', '"+space_name+"','"+created_by+"', '"+assigned_user_id+"', '"+category_name+"', '"+severity+"', "+current_status+", "+status+", '"+created_at+"', '"+created_at+"')";

                        connection.query(insert, function (error, results, fields) {
                            if(error){
                                return res.json({
                                    'success': false,
                                    'message': message.ERROR,
                                    'error': error
                                });
                            }
                        
                            if(results){
                                
                                var GUID2 = generalConfig.generateGUID();
                                var query = "INSERT INTO "+company_databasename+".`so_service_request_status` (`service_request_status_id`,`service_request_id`,`current_status`,`service_due_date`,`severity`,`special_instruction`,`created_by`,`assigned_user_id`,`created_at`, `updated_at` ) VALUES ('"+GUID2+"', '"+GUID+"', '"+current_status+"', '"+service_due_date+"', '"+severity+"', '"+special_instruction+"','"+created_by+"', '"+assigned_user_id+"', '"+created_at+"', '"+created_at+"')";
                                connection.query(query, function (error, results, fields) {
                                    if(error){
                                        return res.json({
                                            'success': false,
                                            'message': message.ERROR,
                                            'error': error
                                        });
                                    }
                                    else
                                    {
                                        res.json({
                                            'success' : true,
                                            'message': message.SERVICE_ADD_SUCCESS
                                        });
                                    }
                                });
                            }
                        });
                });
            } else {
                res.json({
                    'success' : flase,
                    'message': message.ERROR
                });
            }
        });
    }
}

exports.getServiceRequestList = function(req, res, next){
    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir; 

    var statusSearch = generalConfig.statusFilter(search);
    

    if(statusSearch === ""){
        statusSearch = search;
    }

    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){
            var query = "SELECT `SR`.`service_request_id`, `SR`.`service_title`, `SR`.`special_instruction`, `SR`.`service_ticket_number`, `SR`.`service_due_date`, `SR`.`space_id`, `SR`.`space_name`, `SR`.`created_by`, `SR`.`assigned_user_id`, `SR`.`category_name`, `SR`.`severity`, `SR`.`current_status`, `SR`.`status`, DATE_FORMAT(`SR`.`created_at`, '%d %b, %Y | %k:%i %p') AS createdAt, `SR`.`updated_at` AS `updatedAt`, DATE_FORMAT(`SR`.`updated_at`, '%d %b, %Y | %k:%i %p') AS dispUpdatedAt, DATE_FORMAT(`SR`.`created_at`, '%d %b, %Y | %k:%i %p') AS createdAt, `SR`.`deleted_at`,CONCAT(`U`.first_name,' ',`U`.last_name) AS assigned_user, CONCAT(`US`.first_name,' ',`US`.last_name) AS created_user FROM "+company_databasename+".`so_service_requests` AS `SR` LEFT JOIN "+database.master_database.name+".`so_users` AS `U` ON `SR`.assigned_user_id = `U`.user_id  LEFT JOIN "+database.master_database.name+".`so_users` AS `US` ON `SR`.created_by  = `US`.user_id WHERE `SR`.`deleted_at` IS NULL AND ( `SR`.`service_ticket_number` LIKE '%"+search+"%' OR `SR`.`category_name` LIKE '%"+search+"%' OR `SR`.`service_title` LIKE '%"+search+"%' OR `SR`.`current_status` LIKE '%"+statusSearch+"%' OR `SR`.`space_name` LIKE '%"+search+"%' OR `U`.first_name LIKE '%"+search+"%' OR  `U`.last_name LIKE '%"+search+"%') ORDER BY `SR`.`"+sort+"` "+orderBy+" LIMIT "+perPage+" OFFSET "+offset+"";
            
            connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                    generalConfig.getServiceRequestTotalCount(req, res, company_databasename,  function(count){
                        count = (count != null)?count:0;
                        return res.json({
                            'success' : true,
                            'data' : results,
                            'draw' : draw,
                            'recordsTotal' : count,
                            'recordsFiltered' : count,
                            'message': message.SUCCESS
                        });
                    });
                }
            });
        } else {
            return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
        }
    });
}

exports.getEditServiceRequest = function(req, res, next){

    var service_request_id = req.body.service_request_id;
    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
    var imgProfileImage = generalConfig.getFilePath(domain, "user", "main", "sub");
    var imgSRImage = generalConfig.getFilePath(domain, "serviceRequest", "main", "sub");
    var master_database = database.master_database.name;
    var userName = "";
    generalConfig.getDataBase(req, res, function(company_databasename){ 
        if(company_databasename != null){ 
            var query = "SELECT `S`.space_name, `S`.space_image, DATE_FORMAT(`SR`.`created_at`, '%d %b, %Y | %k:%i %p') AS createdAt, CONCAT(`SU`.first_name,' ',`SU`.last_name) as userName ,DATE_FORMAT(`SR`.`service_due_date`,  '%c/%d/%Y') AS service_due_date, DATE_FORMAT(`SR`.`service_due_date`, '%d %b, %Y') AS displayDueDate, `SR`.service_request_id,`SR`.service_title,`SR`.special_instruction,`SR`.service_ticket_number,`SR`.space_id,`SR`.space_name,`SR`.created_by,`SR`.assigned_user_id,`SR`.category_name,`SR`.severity,`SR`.current_status,`SR`.status,`SR`.created_at,`SR`.updated_at,`SR`.deleted_at  FROM "+company_databasename+".`so_service_requests` AS `SR` LEFT JOIN "+company_databasename+".`so_spaces` AS `S` ON `SR`.space_id = `S`.space_id LEFT JOIN `"+master_database+"`.`so_users` AS `SU` ON ``.`SR`.created_by = `SU`.user_id WHERE `SR`.service_request_id = '"+service_request_id+"'";
            connection.query(query, function (error, results, fields) {
                if(error){
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                } else if(results){
                    results.forEach(function(val){
                        if(val.space_image != ""){
                            var path = imagePathObj.mainLink+'/'+val.space_image;
                            if(!generalConfig.checkFilePath(path)){
                               val.space_image = generalConfig.no_image_200;
                            }else{
                               val.space_image = generalConfig.imageUrl(path);
                            }
                        } else {
                            val.space_image = generalConfig.no_image_200;
                        }
                    });

                    if(results[0].userName){
                        userName = results[0].userName;
                        results[0].userName = userName.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()});
                    }

                    var statusQuery = "SELECT DATE_FORMAT(`SRS`.`created_at`, '%d %b, %Y | %k:%i %p') AS createdAt, DATE_FORMAT(`SRS`.`service_due_date`, '%d %b, %Y') AS displayDueDate, UCASE(DAYNAME(`SRS`.`created_at`)) as upDayName, DATE_FORMAT(`SRS`.`created_at`, '%k:%i %p') AS upTime, DATE_FORMAT(`SRS`.`created_at`, '%d %b') AS upDateMonth, `U`.profile_picture as profilePicture, CONCAT(`U`.first_name,' ',`U`.last_name) as created_user,CONCAT(`US`.first_name,' ',`US`.last_name) as assign_user ,`SRS`.* FROM "+company_databasename+".`so_service_request_status` AS `SRS` LEFT JOIN "+master_database+".so_users AS `U` ON `SRS`.created_by = `U`.user_id  LEFT JOIN "+master_database+".so_users AS `US` ON `SRS`.assigned_user_id = `US`.user_id WHERE `service_request_id` = '"+service_request_id+"' ORDER BY `created_at` DESC";

                    connection.query(statusQuery, function (error, statusQuery, fields) {
                        if(error){
                            return res.json({
                                'success': false,
                                'message': message.ERROR,
                                'error': error
                            });
                        } else if(statusQuery){

                            // set profile image
                            statusQuery.forEach(function(val){
                                if(val.profilePicture != ""){
                                    var path = imgProfileImage.mainLink+'/'+val.profilePicture;
                                    if(!generalConfig.checkFilePath(path)){
                                       val.profilePicture = generalConfig.no_image_80;
                                    }else{
                                       val.profilePicture = generalConfig.imageUrl(path);
                                    }
                                } else {
                                    val.profilePicture = generalConfig.no_image_80;
                                }
                            });

                            // service request images
                            var srImages = "SELECT * FROM "+company_databasename+".`so_service_request_images` AS SRI WHERE `service_request_id` = '"+service_request_id+"'";

                            connection.query(srImages, function (error, srImagesResult, fields) {
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });
                                } else if(srImagesResult){

                                    // set profile image
                                    srImagesResult.forEach(function(val){
                                        if(val.image_name != ""){
                                            var path = imgSRImage.mainLink+'/80x80/'+val.image_name;
                                            if(!generalConfig.checkFilePath(path)){
                                               val.image_name = generalConfig.no_image_80;
                                            }else{
                                               val.image_name = generalConfig.imageUrl(path);
                                            }
                                        } else {
                                            val.image_name = generalConfig.no_image_80;
                                        }
                                    });

                                    console.log("---- sr images ----");
                                    console.log(srImagesResult);

                                    if(results){                                
                                        res.json({
                                            'success': true,
                                            'closeStatus' : (results[0].current_status != 0)? false : true,
                                            'message': message.SUCCESS,
                                            'data' : results[0],
                                            'list':statusQuery,
                                            'srImages':srImagesResult
                                        });
                                    }
                                }
                            });

                            // if(results){                                
                            //     res.json({
                            //         'success': true,
                            //         'closeStatus' : (results[0].current_status != 0)? false : true,
                            //         'message': message.SUCCESS,
                            //         'data' : results[0],
                            //         'list':statusQuery
                            //     });
                            // }
                        }
                    });                        
                    
                }
            });
        } else {
            return res.json({
                'success': false,
                'message': message.ERROR
            });  
        }
    });
}


exports.updateServiceRequest = function(req, res, next) {
    var service_request_id = req.body.service_request_id;

    var postData = {};
    postData.service_due_date = req.body.service_due_date;
    postData.assigned_user_id = req.body.assigned_user_id;
    postData.current_status = req.body.current_status;
    postData.severity = req.body.severity;
    postData.special_instruction = req.body.special_instruction;
    
    var service_due_date = (req.body.service_due_date) ? moment(req.body.service_due_date, "MM-DD-YYYY").format('YYYY-MM-DD') : '';
    var date1 = new Date(req.body.service_due_date);
    var date2 = new Date();

    var unixTime = moment().startOf('day').unix();

     var errMsg = {};

    if(date1.getTime() < unixTime * 1000) {
        // errMsg['severity_due_date'] = [message.DATE_ERROR];
        res.json({
            'success': false,
            'message': message.DATE_ERROR
        });
    }

    else {
    var assigned_user_id = (req.body.assigned_user_id)?req.body.assigned_user_id:'';
    var current_status = req.body.current_status;
    var severity = (req.body.severity)?req.body.severity:0;    
    var special_instruction = (req.body.special_instruction)?req.body.special_instruction:'';

    req.checkBody("current_status", message.SERVICE_CURRENT_STATUS_REQUIRED).notEmpty();
    req.checkBody("severity", message.SERVERITY_REQUIRED).notEmpty();
    
    var errors = req.validationErrors();

    var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        }); 
        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else {

        var updatedDate = generalConfig.getDateTimeUTC();
        var userObj = generalConfig.getUserInfo(req);
        var user = userObj.data;
        var created_by = (user.user_id)?user.user_id:'';

        generalConfig.getDataBase(req, res, function(company_databasename){

            if(company_databasename != null)
            {                
                var selectRow = "SELECT DATE_FORMAT(`service_due_date`, '%c/%d/%Y') AS service_due_date, assigned_user_id, current_status, special_instruction, severity FROM "+company_databasename+".`so_service_requests` WHERE `service_request_id` = '"+service_request_id+"'";
                connection.query(selectRow, function (error, results, fields) {
                    if(error){return res.json({'success': false, 'message': message.ERROR, 'error': error }); }
                    if(results && results!='')
                    {
                        var postDiff = getObjectDiff(results[0], postData);
                        if(Object.keys(postDiff).length)
                        {
                            var query = "UPDATE "+company_databasename+".`so_service_requests` SET `service_due_date`='"+service_due_date+"',`assigned_user_id`='"+assigned_user_id+"',`current_status`='"+current_status+"', `severity`='"+severity+"', `special_instruction`='"+special_instruction+"', `updated_at`='"+updatedDate+"' WHERE `service_request_id` = '"+service_request_id+"'";
                        

                            connection.query(query, function (error, results, fields) {                    
                                if(error){return res.json({'success': false, 'message': message.ERROR, 'error': error }); }
                                if(results){
                                    if(results.affectedRows > 0){
                                        var GUID = generalConfig.generateGUID();
                                        var serviceStatus = "INSERT INTO "+company_databasename+".`so_service_request_status` ( `service_request_status_id`, `service_request_id`, `current_status`, `service_due_date`, `severity`, `special_instruction`, `created_by`, `assigned_user_id`, `created_at`, `updated_at` ) VALUES ( '"+GUID+"', '"+service_request_id+"', "+current_status+", '"+service_due_date+"', '"+severity+"', '"+special_instruction+"','"+created_by+"', '"+assigned_user_id+"', '"+updatedDate+"', '"+updatedDate+"')";
                                        
                                        connection.query(serviceStatus, function (error, results, fields) {
                                            if(error){
                                                return res.json({
                                                    'success': false,
                                                    'message': message.ERROR,
                                                    'error': error
                                                });
                                            }
                                            if(results){
                                                return res.json({
                                                    'success' : true,
                                                    'message': message.SERVICE_UPDATE
                                                });
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        else
                        {                            
                            return res.json({
                                'success' : false,
                                'message': message.NO_UPDATES_SUBMITTED
                            });
                        }
                    }
                    else
                    {
                        return res.json({
                            'success' : false,
                            'message': message.NOT_FOUND
                        });
                    }
                });
                // ----- STOP : update operation only any updates submitted
            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
    }
}
}

