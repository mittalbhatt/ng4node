'use strict';


var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;

var conn = require('../config/mysql-connection');
var connection = conn.connection;

/**
 * @uses (getSensorList) fetch beacone sensor device list
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/
exports.getSensorList = function(req, res, next){

    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir; 
    
    generalConfig.getDataBase(req, res, function(company_databasename) { 
        if(company_databasename != null) {
            var query = "";
            query += " SELECT `Sensor`.`sensor_id`, `Sensor`.`sensor_name`, `Sensor`.`sensor_type`, `Sensor`.`sensor_uuid`, ";
            query += " `Sensor`.`sensor_major`, `Sensor`.`sensor_minor`, `Sensor`.`status`, `Sensor`.`sensor_company`, "
            query += " `Sensor`.`created_at` AS `createdAt`, `Sensor`.`updated_at` AS `updatedAt`, `Sensor`.`deleted_at`, ";
            query += " `Space`.`space_id` AS `space_id`, `Space`.`space_name` AS `space_name`,";
            query += " `Floor`.`floor_name` AS `floor_name`, `Building`.`building_name` AS `building_name`";
            query += " FROM "+company_databasename+".`so_sensor_master` AS `Sensor` LEFT OUTER JOIN "+company_databasename+" .`so_spaces` AS `Space`";
            query += " ON `Sensor`.`space_id` = `Space`.`space_id`";
            query += " LEFT OUTER JOIN "+company_databasename+" .`so_floors` AS `Floor`";
            query += " ON `Space`.`floor_id` = `Floor`.`floor_id`";
            query += " LEFT OUTER JOIN "+company_databasename+" .`so_buildings` AS `Building`";
            query += " ON `Floor`.`building_id` = `Building`.`building_id`";
            query += " WHERE `Sensor`.`deleted_at` IS NULL";
            if(req.query.space_id)
            {
                query += " AND `Sensor`.`space_id` = '"+ req.query.space_id +"'";
            }
            query += " AND (Lower(`Sensor`.`sensor_name`) LIKE Lower('%"+search+"%') OR Lower(`Sensor`.`sensor_type`) LIKE Lower('%"+search+"%') ";
            query += " OR `Sensor`.`sensor_major` LIKE '%"+search+"%' OR `Sensor`.`sensor_minor` LIKE '%"+search+"%'";
            query += " OR `Space`.`space_name` LIKE '%"+search+"%')";
            if(sort == 'space_name')
            {
                query += " ORDER BY `Space`.`"+sort+"` "+orderBy;    
            }
            else {
                query += " ORDER BY `Sensor`.`"+sort+"` "+orderBy;
            }
            var countQuery = query;
            query += " LIMIT "+perPage+" OFFSET "+offset+"";

            connection.query(query, function (error, results, fields) {
                if(error) {
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                }
                if(results) {
                    generalConfig.getSensorTotalCount(req, res, countQuery, function(count){
                        count = (count != null)?count:0;
                        return res.json({
                            'success' : true,
                            'data' : results,
                            'draw' : draw,
                            'recordsTotal' : count,
                            'recordsFiltered' : count,
                            'message': message.SUCCESS
                        });
                    });
                }
            });
        }
        else {
            return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
        }
    });
}

/**
 * @uses (addSensor) insert new sensor data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.addSensor = function(req, res, next) {

    var sensor_company = req.body.sensor_company;
    var sensor_name = req.body.sensor_name;
    var sensor_type = req.body.sensor_type;
    var sensor_major = req.body.sensor_major;
    var sensor_minor = req.body.sensor_minor;
    var space_id = req.body.space_id;
    var status = parseInt(req.body.status);
    var errMsg = [];
    var createDate = generalConfig.getDateTimeUTC();


    req.checkBody({
        'sensor_company': {
            notEmpty: true,
            errorMessage: message.DEVICE_COMPANY_REQUIRED
        },
        'sensor_name': {
            notEmpty: true,
            errorMessage: message.DEVICE_NAME_REQUIRED
        },
        'sensor_type':{
            notEmpty: true,
            errorMessage: message.DEVICE_TYPE_REQUIRED
        },
        'sensor_major':{
            notEmpty: true,
            errorMessage: message.MAJOR_REQUIRED
        },
        'sensor_minor':{
            notEmpty: true,
            errorMessage: message.MINOR_REQUIRED
        },
        'space_id':{
            notEmpty: true,
            errorMessage: message.SPACE_REQUIRED
        }
    });

    var errors = req.validationErrors();

    var errMsg = {};

    if (errors) {
        
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        });

        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else { 
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){

                var createDate = generalConfig.getDateTimeUTC();
                var GUID = generalConfig.generateGUID();

                sensor_company  = sensor_company ? sensor_company : '';
                sensor_name     = sensor_name ? sensor_name : '';
                sensor_type     = sensor_type ? sensor_type : '';
                sensor_major    = sensor_major ? sensor_major : '';
                sensor_minor    = sensor_minor ? sensor_minor : '';
                space_id        = space_id ? space_id : '';
                status          = status ? status : '';
                var space_query = "SELECT `space_id` from "+company_databasename+".`so_spaces` AS Space WHERE `Space`.`space_id` = '"+space_id+"'";
              
                connection.query(space_query, function (error, space, fields) {
                    if(space.length > 0){
                        var query = "";
                        query += " INSERT INTO "+company_databasename+".`so_sensor_master`";
                        query += " (`sensor_id`,`sensor_company`, `sensor_name`, `sensor_type`, `sensor_major`, `sensor_minor`, `space_id`, `status`, `created_at`, `updated_at`) VALUES";
                        query += " ('"+GUID+"', '"+sensor_company+"', '"+sensor_name+"', '"+sensor_type+"', '"+sensor_major+"', '"+sensor_minor+"', '"+space_id+"', '"+status+"', '"+createDate+"', '"+createDate+"')";
                    
                        connection.query(query, function (error, results, fields) {
                            if(error){
                                return res.json({
                                    'success': false,
                                    'message': message.ERROR,
                                    'error': error
                                });
                            } else if(results){
                                return res.json({
                                    'success' : true,
                                    'message': message.SENSOR_ADD_SUCCESS
                                });
                            }
                        });
                    }
                    else {
                        res.json({
                            'success': false,
                            'message': message.NOSPACE,
                        });
                    }
                });

            } else {
                 res.json({
                    'success': false,
                    'message': message.ERROR,
                });
            }
        });
    }
};

/**
 * @uses (getEditSensor) fetch selected sensor info
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.getEditSensor = function(req, res, next){
    
    var sensor_id = req.body.sensor_id;
    if(sensor_id) {
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){
                var query = "";
                query += " SELECT `Sensor`.`sensor_id`, `Sensor`.`sensor_name`, `Sensor`.`sensor_type`, `Sensor`.`sensor_uuid`, ";
                query += " `Sensor`.`sensor_major`, `Sensor`.`sensor_minor`, `Sensor`.`status`, `Sensor`.`sensor_company`, "
                query += " `Sensor`.`created_at` AS `createdAt`, `Sensor`.`updated_at` AS `updatedAt`, `Sensor`.`deleted_at`, ";
                query += " `Sensor`.`space_id` AS `space_id`, `Space`.`space_name` AS `space_name`";
                query += " FROM "+company_databasename+".`so_sensor_master` AS `Sensor` LEFT OUTER JOIN "+company_databasename+" .`so_spaces` AS `Space`";
                query += " ON `Sensor`.`space_id` = `Space`.`space_id` WHERE `Sensor`.`deleted_at` IS NULL AND `Sensor`.`sensor_id` =  '"+sensor_id+"'";
                connection.query(query, function (error, results, fields) { 
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    }
                    if(results.length > 0){
                        return res.json({
                            'success' : true,
                            'data' : results[0],
                            'message': message.SUCCESS
                        });
                    } else {
                        return res.json({
                            'success' : false,
                            'data' : null,
                            'message': message.NOT_FOUND
                        });
                    }
                });

            } else {
                 return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
        
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}


/**
 * @uses (updateSensor) Update sensor data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateSensor = function(req, res, next) {
    var sensor_id = req.body.sensor_id;
    var sensor_company = req.body.sensor_company;
    var sensor_name = req.body.sensor_name;
    var sensor_type = req.body.sensor_type;
    var sensor_major = req.body.sensor_major;
    var sensor_minor = req.body.sensor_minor;
    var space_id = req.body.space_id;    
    var updateDate = generalConfig.getDateTimeUTC();
    var status = (req.body.status ==  true)?1:0;

    var errMsg = [];


    req.checkBody({
        'sensor_company': {
            notEmpty: true,
            errorMessage: message.DEVICE_COMPANY_REQUIRED
        },
        'sensor_name': {
            notEmpty: true,
            errorMessage: message.DEVICE_NAME_REQUIRED
        },
        'sensor_type':{
            notEmpty: true,
            errorMessage: message.DEVICE_TYPE_REQUIRED
        },
        'sensor_major':{
            notEmpty: true,
            errorMessage: message.MAJOR_REQUIRED
        },
        'sensor_minor':{
            notEmpty: true,
            errorMessage: message.MINOR_REQUIRED
        },
        'space_id':{
            notEmpty: true,
            errorMessage: message.SPACE_REQUIRED
        }
    });

    var errors = req.validationErrors();

    var errMsg = {};

    if (errors) {
        
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        });

        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else { 
        if(sensor_id){
            generalConfig.getDataBase(req, res, function(company_databasename){  
                if(company_databasename != null){
                    var space_query = "SELECT `space_id` from "+company_databasename+".`so_spaces` AS Space WHERE `Space`.`space_id` = '"+space_id+"'";
                    
                    connection.query(space_query, function (error, space, fields) {
                        if(space.length > 0) {
                            var findQuery = "SELECT `sensor_id` FROM "+company_databasename+".`so_sensor_master` AS `Sensor` WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";

                            connection.query(findQuery, function (error, results, fields) {
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });
                                } else if(results){
                                    if(results.length > 0){

                                        sensor_company  = sensor_company ? sensor_company : '';
                                        sensor_name     = sensor_name ? sensor_name : '';
                                        sensor_type     = sensor_type ? sensor_type : '';
                                        sensor_major    = sensor_major ? sensor_major : '';
                                        sensor_minor    = sensor_minor ? sensor_minor : '';
                                        space_id        = space_id ? space_id : '';                                        

                                        var query = "UPDATE "+company_databasename+".`so_sensor_master` AS `Sensor`"; 
                                        query += " SET `Sensor`.`sensor_name`='"+sensor_name+"', ";
                                        query += " `Sensor`.`status`='"+status+"', ";
                                        query += " `Sensor`.`sensor_company`='"+sensor_company+"', ";
                                        query += " `Sensor`.`sensor_type`='"+sensor_type+"', ";
                                        query += " `Sensor`.`sensor_major`='"+sensor_major+"', ";
                                        query += " `Sensor`.`sensor_minor`='"+sensor_minor+"', ";
                                        query += " `Sensor`.`space_id`='"+space_id+"', ";                                        
                                        query += " `Sensor`.`updated_at`='"+updateDate+"' WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";

                                        connection.query(query, function (error, results, fields) {
                                            if(error){
                                                return res.json({
                                                    'success': false,
                                                    'message': message.ERROR,
                                                    'error': error
                                                });
                                            } else if(results){
                                                return res.json({
                                                    'success' : true,
                                                    'message': message.SENSOR_UPDATE
                                                });
                                            }
                                        });

                                    }
                                }
                            });
                        }
                        else {
                            return res.json({
                                'success': false,
                                'message': message.NOSPACE,
                                'error': error
                            });
                        }
                    });
                } else {
                    return res.json({
                        'success': false,
                        'message': message.ERROR
                    });
                }
            });
        }
    }
};

/**
 * @uses (removeSensor) remove selected sensor from database (soft delete)
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.removeSensor = function(req, res, next){
    
    var sensor_id = req.body.sensor_id;
    var deleteDate = generalConfig.getDateTimeUTC();

    if(sensor_id){
       generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){
                var query = "SELECT  `Sensor`.`sensor_id` FROM "+company_databasename+".`so_sensor_master` AS `Sensor` WHERE `Sensor`.`sensor_id` = '"+sensor_id+"' AND `Sensor`.`deleted_at` IS NULL";

                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });

                    } else if(results) {
                        if(results.length > 0) {
                            var query = "UPDATE "+company_databasename+".`so_sensor_master` AS `Sensor` SET `Sensor`.`deleted_at`='"+deleteDate+"' WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";
                            connection.query(query, function (error, results, fields) {
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });

                                } else if(results){
                                    return res.json({
                                        'success' : true,
                                        'message': message.SENSOR_DELETE
                                    });
                                }
                            });
                        }
                    }
                });
            }else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                });
            }
        });

    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}

exports.updateSensorStatus= function(req, res, next){
    
    var sensor_id = req.body.sensor_id;
    var status = (req.body.status == 1)?0:1;
    var updateDate = generalConfig.getDateTimeUTC();

    if(sensor_id) {
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){ 
                var query = "UPDATE "+company_databasename+".`so_sensor_master` AS `Sensor` SET `Sensor`.`status`='"+status+"', `Sensor`.`updated_at`='"+updateDate+"' WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        return res.json({
                            'success' : true,
                            'message': message.SENSOR_UPDATE
                        });
                    }
                });

            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}
