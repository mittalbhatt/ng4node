'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var async = require('async');


/**
 * @uses get company listing data
 *
 * @author FJ < foram.kantaria@softwebsolutions.com >
 *
 * @return json
 */
exports.companyList = function (req, res, next) {

	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;
    var domain = generalConfig.getDomain(req);

    if(generalConfig.masterDoamin == domain){
        var imagePathObj = generalConfig.getFilePath(domain, "master", "main", "sub");
    } else {
        var imagePathObj = generalConfig.getFilePath(domain, "company", "main", "sub");
    }

    master_db.models.companyMaster.findAndCountAll({
		where: {
			deleted_at: { $eq: null },
			$or: [
				{ company_name	: { $like: '%' + search + '%' } },
				{ company_email: { $like: '%' + search + '%' } },
				{ company_address1: { $like: '%' + search + '%' } },
				{ company_address2: { $like: '%' + search + '%' } },
				{ company_city: { $like: '%' + search + '%' } },
				{ company_state: { $like: '%' + search + '%' } },
				{ company_zip: { $like: '%' + search + '%' } },
				{ company_phone: { $like: '%' + search + '%' } },
				{ company_logo: { $like: '%' + search + '%' } }
			]
		},
	
		order: [[sort, orderBy]],
        offset: offset,
        limit: perPage,

    }).then(function (company) {
		if (!company)
            return next(new Error('Failed to load Floor '));
        if(company){
            async.forEach(company.rows, function (val, callback){ 
                if(val.company_logo != ""){
                    var path = imagePathObj.mainLink+'/'+val.company_logo;
                    if(!generalConfig.checkFilePath(path)){
                       val.dataValues.image_path = generalConfig.no_image;
                    }else{
                       val.dataValues.image_path = generalConfig.imageUrl(path);
                    }
                } else {
                    val.dataValues.image_path = generalConfig.no_image;
                }
                callback()
            }, function(err) {

                res.json({
                    'success': true,
                    'data': company.rows,
                    'draw': draw,
                    'recordsTotal': company.count,
                    'recordsFiltered': company.count,
                    'message': message.SUCCESS
                });

            });
            //res.json({error:false,data:users.rows,recordsTotal:users.count,  'draw' : draw, recordsFiltered:users.count,msg:null});
        }
		
    }).catch(function (err) {
    	console.log(err);
		res.json({
			success: false,
			message: message.ERROR
		});
    });
};


exports.companyStatusUpdate = function (req,res,next) {
    if(req.body.status == '1') {
       var status = 0;
    }
    else {
        var status = 1;
    }

    master_db.models.companyMaster.update(
    {
        status:status
    },
    {
    where: {
        company_id: req.body.company_id
    }
    
    }).then(function (data) {
        res.json({
            success: true,
            data: data,
            message: message.COMPANY_UPDATED
        });
    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

};

/**
 * @uses Get company data by id for update page
 *
 * @author FJ < foram.kantaria@softwebsolutions.com >
 *
 * @return json
 */

exports.getCompanyById = function (req, res, next) {
    master_db.models.companyMaster.find({ where: { company_id: req.params.id } }).then(function (company) {
        if (!company)
            return next(new Error('Failed to load Company ' + company_id));
        res.json({
            success: true,
            data: company,
            message: null
        });
    }).catch(function (err) {
        res.json({
            success: false,
            message: message.ERROR
        });
    });
};

exports.updateCompany = function (req, res, next) {
 

    var company_name = req.body.company_name;
    var company_email = req.body.company_email;
    var company_address1 = req.body.company_address1;
    var company_address2 = req.body.company_address2;
    var company_city = req.body.company_city;
    var company_state = req.body.company_state;
    var company_zip = req.body.company_zip;
    var company_phone = req.body.company_phone;
    var timezone = req.body.timezone;

    var base64Image = req.body.company_logo;
    var filename = req.body.image_name;
 
    var errMsg = [];
    req.checkBody("company_name", "Company Name is required").notEmpty();
    req.checkBody("company_email", "Company Email is required").notEmpty();
    req.checkBody("company_address1", "Address is required").notEmpty();
    req.checkBody("company_address2", "Address Number is required").notEmpty();
    req.checkBody("company_city", "City is required").notEmpty();
    req.checkBody("company_state", "State is required").notEmpty();
    req.checkBody("company_zip", "Zip Code is required").notEmpty();
    req.checkBody("company_phone", "Phone Number is required").notEmpty();
    
  

    var errors = req.validationErrors();

   
    if(req.body.status == true) {
        req.body.status = 1;
    }
    else {
        req.body.status = 0;


    }
    
    if (errors) {
        errors.forEach(function(err) {
          errMsg.push(err.msg);
        });
        res.json({
            'success' : false,
            'message': errMsg
        });

    } else {

        var new_file_name = "";
    
        var domain = generalConfig.getDomain(req);
        
        if(generalConfig.masterDoamin == domain){
            var resObj = upload.uploadImage(domain, "master", base64Image, filename, "", "", "", "");
        } else {
            var resObj = upload.uploadImage(domain, "company", base64Image, filename, "", "", "", "");
        }

          if(resObj.success == true){
            new_file_name = resObj.file_name;
        } else {
            return res.json({
                'success': resObj.success,
                'message': resObj.message
            });
        }


        master_db.models.companyMaster.find(
            {where : { company_email : req.body.company_email, company_id:{ $ne: req.body.company_id }}}).then(function(company){

            if(!company) {
        
                req.body.created_at = generalConfig.getDateTimeUTC();

                req.body.company_logo = new_file_name;
                master_db.models.companyMaster.update(req.body,{ where : {company_id : req.body.company_id }})
                .then(function (data) {

                    if (!data)
                        return next(new Error('Failed to load Company ' + company_id));
                    res.json({
                        success: true,
                        data: data,
                        message: message.COMPANY_UPDATED
                    });
                }).catch(function (err) {
                    res.json({
                        success: false,
                        data: null,
                        message: message.ERROR
                    });
                });
            }
            

            else {
                res.json({
                success:false,
                message: 'This Email Address Already Exists'
            });

        }
    });
    
    }

};

