'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg

/**
 * @uses get company listing data
 *
 * @author FJ < foram.kantaria@softwebsolutions.com >
 *
 * @return json
 */
exports.getBilling = function (req, res, next) {
    master_db.models.Plan.findAll({
        where : {
            deleted_at: {
              $eq: null
            },
           
        },

         include: [
        {
            model: master_db.models.PlanDetails,
            where: { deleted_at: { $eq: null } }, 
        },],
            
        })
        .then(function(plan) {
            console.log(plan[0].PlanDetail.feature_id);
           res.json({
                'success': true,
                'message': "success",
                'data': plan
                
            }); 
        })
        .catch(function(err) {
            console.log(err);
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });        
        });
};


exports.getFeatures = function (req, res, next) {
    // console.log(req.body);
    // console.log('------------------');

   
    // var array = JSON.parse("[" + string + "]");

    for(var i = 0; i < req.body.billing.length; i++) {

        console.log(req.body.billing[i].PlanDetail.feature_id);

   
     var featureArray = [];
    // console.log('===================');

        master_db.models.Feature.findAll({
        where : {
            deleted_at: {$eq: null},
            feature_id:  JSON.parse("[" + req.body.billing[i].PlanDetail.feature_id + "]")
        },            
        })
        .then(function(plan) {
            console.log(plan);
            featureArray.push({ feature : plan[i]
            });
        })
        .catch(function(err) {
            console.log(err);
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });        
        });


        // console.log('888888888888888888888888888');
        // console.log(featureArray);
        // console.log('888888888888888888888888888');




    }


   
};

