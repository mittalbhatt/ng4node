        'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg



/**
 * @uses get package listing data
 *
 * @author FJ < foram.kantaria@softwebsolutions.com >
 *
 * @return json
 */
exports.packageList = function (req, res, next) {


	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;

    master_db.models.Plan.findAndCountAll({
		where: {
			deleted_at: { $eq: null },
			$or: [
				{ plan_name	: { $like: '%' + search + '%' } },
				{ plan_price: { $like: '%' + search + '%' } },
                { '$PlanDetail.no_of_employee$': { $like: '%' + search + '%'}},
                { '$PlanDetail.no_of_space$': { $like: '%' + search + '%'}},
				
			]
		},
	
		order: [[sort, orderBy]],        
        offset: offset,
        limit: perPage,
        include: [
        {
            model: master_db.models.PlanDetails,
            where: { deleted_at: { $eq: null } },  

        },

        {
            model: master_db.models.PlanDurationPrice,
            where: { deleted_at: { $eq: null } }, 
            order: [['duration_id', 'ASC']], 

        },





        ],

    }).then(function (plan) {
		if (!plan)
            return next(new Error('Failed to load Plan '));
		res.json({
            'success': true,
            'data': plan.rows,
            'draw': draw,
            'recordsTotal': plan.count,
            'recordsFiltered': plan.count,
            'message': message.SUCCESS
        });
    }).catch(function (err) {
		res.json({
			success: false,
			message: message.ERROR
		});
    });
};



exports.packageStatusUpdate = function (req,res,next) {
    if(req.body.status == '1') {
       var status = 0;
    }
    else {
        var status = 1;
    }

    master_db.models.Plan.update(
    {
        status:status
    },
    {
    where: {
        plan_id: req.body.plan_id
    }
    
    }).then(function (data) {
        res.json({
            success: true,
            data: data,
            message: message.PACKAGE_UPDATED
        });
    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

};

/**
 * @uses Get company data by id for update page
 *
 * @author FJ < foram.kantaria@softwebsolutions.com >
 *
 * @return json
 */

exports.getPlanById = function (req, res, next) {

    master_db.models.Plan.find({ 
        where: { plan_id: req.params.id },

        include: [
        {
            model: master_db.models.PlanDetails,
            where: { deleted_at: { $eq: null } },      
        },
        {
            model: master_db.models.PlanDurationPrice,
            include : [{
                model: master_db.models.Duration,
                where: { deleted_at: { $eq: null } }, 
            }],
            where: { deleted_at: { $eq: null } }, 
        }],

       

        }).then(function (plan) {


        if (!plan)
            return next(new Error('Failed to load Plan ' + plan_id));
     
        res.json({
            success: true,
            data: plan,
            message: null
        });
    }).catch(function (err) {

        res.json({
            success: false,
            message: message.ERROR
        });
    });
};



exports.insertPackageData = function(req, res, next) {
    var plan_name = req.body.package.plan_name;

    var status = req.body.package.status;
    var employee = req.body.packageDetail.no_of_employee;
    var space = req.body.packageDetail.no_of_space;
    var duration_price = req.body.duration.duration_price;

    var plan_price = 0; // Variable to hold your total

    for (var i = 0, len = req.body.duration.length; i < len; i++) {
        plan_price += req.body.duration[i].duration_price; // Iterate over your first array and then grab the second element add the values up
    }

    req.body.package.plan_price = plan_price;

    var errMsg = [];
    req.checkBody("package.plan_name", "Plan Name is required").notEmpty();
    req.checkBody("packageDetail.no_of_employee", "Employee is required").notEmpty();
    req.checkBody("packageDetail.no_of_space", "Space is required").notEmpty();
    // req.checkBody("duration.duration_price", "Duration prices are required").notEmpty();
    var errors = req.validationErrors();

    if (errors) {
        errors.forEach(function(err) {
            errMsg.push(err.msg);
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {


        var plan = master_db.models.Plan.build(req.body.package);
        var planDetails = master_db.models.PlanDetails.build(req.body.packageDetail);
        var features = [];
        var id = [];

        plan.save().then(function(plan) {

            planDetails.plan_id = plan.plan_id;
            for (var feature of req.body.feature) {
                var feature = {
                    feature_id: feature.feature_id,
                    value: feature.value

                }
                features.push(feature);
            }
            for (var i = 0, len = features.length; i < len; i++) {
                // features[i].feature_id = features[i].feature_id+","+features[i+1].feature_id;
                if (features[i].value) {

                    id.push(features[i].feature_id);


                }

            }
            planDetails.feature_id = id.join(",");

            planDetails.save().then(function(planDetail) {

                if (planDetail) {
                    var products = [];
                    for (var duration of req.body.duration) {
                        var product = {
                            plan_id: plan.plan_id,
                            duration_id: duration.duration_id,
                            price: duration.duration_price,
                        }
                        products.push(product);
                    }


                    master_db.models.PlanDurationPrice.bulkCreate(products)
                        .then(function() {
                            res.json({
                                success: true,
                                data: null,
                                message: message.PACKAGE_ADDED
                            });
                        }).catch(function(err) {

                            res.json({
                                success: false,
                                message: message.ERROR
                            });
                        });


                }

            }).catch(function(err) {
                res.json({
                    success: false,
                    message: message.ERROR
                });
            });
        }).catch(function(err) {
            res.json({
                success: false,
                message: message.ERROR
            });
        });

    }

};

exports.updatePlan = function (req, res, next) {


    var plan_name = req.body.package.plan_name;
    var status = req.body.package.status;
    var employee = req.body.package.PlanDetail.no_of_employee;
    var space = req.body.package.PlanDetail.no_of_space;
   
    var errMsg = [];
    req.checkBody("package.plan_name", "Plan Name is required").notEmpty();
    req.checkBody("package.status", "Status is required").notEmpty();
    // req.checkBody("package.PlanDetail.no_of_employee", "Employee is required").notEmpty();
    // req.checkBody("package.PlanDetail.no_of_space", "Space is required").notEmpty();

   

     var plan_price = 0; // Variable to hold your total

    for (var i = 0, len = req.body.package.PlanDurationPrices.length; i < len; i++) {
        plan_price += req.body.package.PlanDurationPrices[i].price; // Iterate over your first array and then grab the second element add the values up
    }

    req.body.package.plan_price = plan_price;




    


    // req.body.package.PlanDetail.feature_id = 
    var errors = req.validationErrors();
 
    if (errors) {
        errors.forEach(function(err) {
          errMsg.push(err.msg);
        });
        res.json({
            'success' : false,
            'message': errMsg
        });

    } else {


      master_db.models.Plan.update(req.body.package,{ where : {plan_id : req.body.package.plan_id }}).then(function(plan){
                master_db.models.PlanDetails.update(req.body.package.PlanDetail, { where : {plan_id : req.body.package.plan_id}}).then(function(planDetail)
                {
                    for (var i = 0, len = req.body.package.PlanDurationPrices.length; i < len; i++) {
                        
                        master_db.models.PlanDurationPrice.update(req.body.package.PlanDurationPrices[i],
                        { where : {plan_id: req.body.package.PlanDurationPrices[i].plan_id,

                                plan_duration_id : req.body.package.PlanDurationPrices[i].plan_duration_id,
                                duration_id : req.body.package.PlanDurationPrices[i].duration_id
                        },
                    })  
                    }


                    res.json({
                        success:true,
                        data:planDetail,
                        message: message.PACKAGE_UPDATED
                    });

                 }).catch(function(err){
                    res.json({
                        success:false,
                        message:message.ERROR
                    });
                });

                }).catch(function(err){
                  
                    res.json({
                        success:false,
                        message: message.ERROR
                    });
                });

    }
  


};


exports.deletePlan = function (req, res,next) {

   var obj = {
        deleted_at: new Date()
    };

    master_db.models.Plan.update(obj, {
        where: { plan_id: req.params.id }
    }).then(function (data) {

    master_db.models.PlanDetails.update(
        obj, {
        where: { plan_id: req.params.id }

    }).then(function(data) {        
        res.json({
            success: true,
            data: null,
            message: message.PACKAGE_DELETED
        });
    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

};

exports.getFeatures = function (req, res, next) {
    master_db.models.Feature.findAll({ 
        where: { deleted_at: { $eq: null } },
        }).then(function (features) {

        if (!features)
            return next(new Error('Failed to load Feature '));
     
        res.json({
            success: true,
            data: features,
            message: null
        });
    }).catch(function (err) {
        res.json({
            success: false,
            message: message.ERROR
        });
    });
};
exports.getDuration = function (req, res, next) {
    master_db.models.Duration.findAll({ 
        where: { deleted_at: { $eq: null } },
        }).then(function (duration) {

        if (!duration)
            return next(new Error('Failed to load Feature '));
        res.json({
            success: true,
            data: duration,
            message: null
        });
    }).catch(function (err) {
        res.json({
            success: false,
            message: message.ERROR
        });
    });
};

