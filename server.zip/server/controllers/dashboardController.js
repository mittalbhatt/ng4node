'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var database = require('../config/database');
var master_database = database.master_database.name;
var async = require('async');
var dateFormat = require('dateformat');


exports.getMeetings = function (req, res, next) {
	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;

    var now = new Date();
    var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
    var accessObj = generalConfig.userAccessCheck(req);

    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

    if(user && user.user_id){
	    generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){
	        	
	        	var userQuery = "SELECT  * FROM  `"+master_database+"`.`so_users` WHERE  user_id =  '"+user.user_id+"' ";

	        	connection.query(userQuery, function (error, userResult, fields) {
	        	
		        	if(userResult.length > 0){
		        		var email_id = userResult[0].email_id;
		        		var email = userResult[0].email;
		        		var time_difference = userResult[0].time_difference;
		        	}

		        	var query  = "";
					query += "SELECT sb.space_id, s.space_name,  s.floor_id, s.space_capacity, ";
					query += " s.space_size,  s.floor_id, f.floor_name, f.building_id, b.building_name, ";
					query += " s.space_type_id, st.space_type_name,  sb.booking_id, sb.user_id,  sb.booking_title, ";
					query += " sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
					query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
					query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,   sb.booking_duration, ";
					query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, ";  
					query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_time,  ";
					query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_end_date,  ";
					query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_time,  ";
					query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%W, %M %d, %Y') as display_date, ";
					query += " (  SELECT  GROUP_CONCAT(email_address) as email_address  FROM "+company_databasename+".so_email_master AS emailmaster  ";
					query += " LEFT JOIN "+company_databasename+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id  ";
					query += " WHERE spaceattendies.booking_id = sb.booking_id GROUP BY sb.booking_id ) AS attendies, ";
					query += " sa.email_id, sa.attendies_type,e.email_address,CONCAT(u.first_name,' ',u.last_name) as organizer_full_name,  ";
					query += " LCASE(u.email) as organizer_email, u.phone_number as organizer_phone_number ";
					query += " FROM "+company_databasename+".so_space_attendies AS sa  ";
					query += " LEFT JOIN "+company_databasename+".so_email_master AS e ON e.email_id = sa.email_id  ";
					query += " LEFT JOIN "+company_databasename+".so_space_booking AS sb ON sb.booking_id = sa.booking_id  ";
					query += " LEFT JOIN "+company_databasename+".so_spaces AS s ON s.space_id = sb.space_id  ";
					query += " LEFT JOIN "+company_databasename+".so_space_type AS st ON st.space_type_id = s.space_type_id  ";
					query += " LEFT JOIN "+company_databasename+".so_floors AS f ON f.floor_id = s.floor_id  ";
					query += " LEFT JOIN "+company_databasename+".so_buildings AS b ON b.building_id = f.building_id  ";
					query += " LEFT JOIN "+master_database+".so_users AS u ON u.user_id = sb.user_id  ";
					query += " WHERE (LCASE(e.email_address) = LCASE('"+email+"') OR sb.user_id = '"+user.user_id+"')  ";
					query += " AND (b.building_name LIKE '%"+search+"%' OR s.space_name LIKE '%"+search+"%' OR u.first_name LIKE '%"+search+"%' OR u.last_name LIKE '%"+search+"%' ";
					query += " OR sb.booking_title LIKE '%"+search+"%' OR f.floor_name LIKE '%"+search+"%' ) ";
					query += " AND  sb.deleted_at IS NULL AND sb.end_time >= '"+currentDate+"'  ";
					query += " GROUP BY sb.booking_id ORDER BY "+sort+" " +orderBy+" LIMIT 5";
					//query += " GROUP BY sb.booking_id ORDER BY "+sort+" ";

	        		if(userResult){

			            connection.query(query, function (error, total_count, fields) {
			              if(error){
			                return res.json({
			                    'success': false,
			                    'message': message.ERROR,
								'data': null,
			                    'error': error
			                });
			              }
			                if(total_count){
			                	var records_count = 0;
			                	records_count = total_count.length;

			                	//query += " " +orderBy+" ";
			                	//query += " " +orderBy+" LIMIT "+perPage+" OFFSET "+offset+"";

			                	master_db.models.companyUser
						        .findOne({
						            where: { user_id: user.user_id },
						            attributes: ['user_type'],
						        })
						        .then(function(userTypeData) {
						        	var userType = userTypeData.dataValues.user_type;
				                	connection.query(query, function (error, results, fields) {
					                	async.forEach(results, function (val, callback){ 
												if(val.space_image != ""){
					                                var path = imagePathObj.mainLink+'/'+val.space_image;
					                                if(!generalConfig.checkFilePath(path)){
					                                   val.space_image_path = generalConfig.no_image_80;
					                                }else{
					                                   val.space_image_path = generalConfig.imageUrl(path);
					                                }
					                            } else {
					                                val.space_image_path = generalConfig.no_image_80;
					                            }
					                            val.timezone = userResult[0].timezone;
							                    val.time_difference = userResult[0].time_difference;

											callback()
										}, function(err) { 
											if(results){
												return res.json({
					                                'success' : true,
					                                'data' : results,
					                                'userType': userType,
					                                'draw' : draw,
					                                'recordsTotal' : records_count,
					                                'recordsFiltered' : records_count,
					                                'message': message.SUCCESS
					                            });
											}
										});
									});						        	
						        })
			                }
			            });
	        		}
	        	});

	        } else {
	            return res.json({
	                'success' : false,
	                'data' : null,
	                'draw' : draw,                
	                'recordsTotal' : 0,
	                'recordsFiltered' : 0,
	                'message': message.ERROR
	            });
	        }
	    });
    } else {
    	return res.json({
            'success' : false,
            'data' : null,
            'draw' : draw,                
            'recordsTotal' : 0,
            'recordsFiltered' : 0,
            'message': message.ERROR
        });
    }
}
