'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;

var database = require('../config/database');
var master_database = database.master_database.name;

/**
 * @uses (removeDevice) remove selected building from database (soft delete)
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/


exports.deviceList = function(req, res, next){

    db.models.DeviceMaster.findAll({
            where: { '$TabletMaster.device_id$': null },
            attributes: ['device_id','device_name'],
            include: [{
                model: db.models.TabletMaster,
                attributes: ['device_id'],
                required: false
            }]

    }).then(function(data) {
        if(data){
            res.json({
                'success' : true,
                'data': data
            }); 
        }
    })
    .catch(function(err) {
        res.json({
            'success': false,
            'message': message.ERROR,
            'error': err
        });
    });
}

/**
 * @uses (getDeviceList) get devices from database
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/


exports.getDeviceList = function(req, res, next){
    
    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir; 
    
    generalConfig.getDataBase(req, res, function(company_databasename) { 
        if(company_databasename != null) {
//            DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, "
            var query = "";
            query += " SELECT `Device`.`device_id`,`Device`.`device_uniq_id`, `Device`.`device_name`, `Device`.`app_version`, `Device`.`device_type`, `Device`.`application_name`, `Device`.`os_version`, ";
            query += " DATE_FORMAT(Device.sync_date, '%m/%d/%Y %l:%i %p') as utc_sync_date,  ";
            query += " DATE_FORMAT(Device.created_at, '%m/%d/%Y %l:%i %p') as utc_created,  ";

            // query += " `Device`.`os_version`, DATE_FORMAT(CONVERT_TZ(`Device`.`sync_date`,'+00:00', `User`.`time_difference`),'%d/%m/%Y %h:%i %p') AS sync_date, `Device`.`application_name`, ";
            // query += " DATE_FORMAT(CONVERT_TZ(`Device`.`created_at`,'+00:00', `User`.`time_difference`),'%d/%m/%Y %h:%i %p') AS created_at, `Device`.`updated_at` AS `updatedAt`, `Device`.`deleted_at`, ";
            
            query += " CONCAT(`User`.`first_name`, ' ', `User`.`last_name`) AS `user_name`, `User`.`time_difference`"
            query += " FROM "+company_databasename+".`so_device_master` AS `Device` LEFT JOIN " + master_database +".`so_users` AS `User`";
            query += " ON `User`.`user_id` = `Device`.`user_id`";
            query += " WHERE `Device`.`deleted_at` IS NULL";
            query += " AND (Lower(`Device`.`device_name`) LIKE Lower('%"+search+"%') OR `Device`.`app_version` LIKE '%"+search+"%' ";
            query += " OR CONCAT(`User`.`first_name`, ' ', `User`.`last_name`) LIKE '%"+search+"%' OR `Device`.`os_version` LIKE '%"+search+"%') ";
            
            query += "OR  `Device`.`device_uniq_id` LIKE '%"+search+"%'";
            query += "OR  Lower(`Device`.`application_name`) LIKE Lower('%"+search+"%')";
            query += "OR  Lower(`Device`.`device_type`) LIKE Lower('%"+search+"%')";

            // query += " OR `Device`.`sync_date` LIKE '%"+search+"%' OR `Device`.`created_at` LIKE '%"+search+"%')";
            if(sort == 'user_name')
            {
                query += " ORDER BY CONCAT(`User`.`first_name`, ' ', `User`.`last_name`) "+orderBy;
            }
            else {
                query += " ORDER BY `Device`.`"+sort+"` "+orderBy;
            }
            var countQuery = query;
            query += " LIMIT "+perPage+" OFFSET "+offset+"";
            
            connection.query(query, function (error, results, fields) {
       
                if(error) {
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                }
                if(results) {
                    generalConfig.getDeviceTotalCount(req, res, countQuery, function(count){
                        count = (count != null)?count:0;
                        return res.json({
                            'success' : true,
                            'data' : results,
                            'draw' : draw,
                            'recordsTotal' : count,
                            'recordsFiltered' : count,
                            'message': message.SUCCESS
                        });
                    });
                }
            });
        }
        else {
            return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
        }
    });
}
