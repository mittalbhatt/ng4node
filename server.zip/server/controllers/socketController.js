'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var Sequelize = require('sequelize');
var LANG = require('../common/language');
var message = LANG.msg;

var mysql = require('mysql');
var config    = require('../config/database');
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var moment = require('moment');


/**
 * @uses (getSpaces) for socket right side panel
 *
 * @author AV < ashwin.vadgama@softwebsolutions.com >
 *
 * @return json
*/
exports.getSocketSpaces = function(req, res, next){

    generalConfig.getDataBase(req, res, function(company_databasename){
       if(company_databasename != null){

            var now = new Date();
            var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
            var booking_start_date = currentDate;
            var booking_end_date = currentDate;
            //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
            var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");

            var SpaceQuery  = "";
            SpaceQuery += " SELECT s.space_id, s.space_name, "; //status as available

            SpaceQuery += "IF( ";
            SpaceQuery += " (SELECT booking_id FROM "+company_databasename+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
            SpaceQuery += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
            SpaceQuery += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
            SpaceQuery += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
            SpaceQuery += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
            SpaceQuery += "  IS NULL, ";

            SpaceQuery += "IF( ";
            SpaceQuery += " (SELECT maintainance_id FROM "+company_databasename+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
            SpaceQuery += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
            SpaceQuery += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
            SpaceQuery += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
            SpaceQuery += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
            SpaceQuery += "  IS NULL, ";



            //SpaceQuery += "  '0', "; //SpaceQuery += "  'Room Available', ";
            SpaceQuery += "IF( ";
            SpaceQuery += " (SELECT tbl.created_at FROM ( ";
            SpaceQuery += " SELECT sinin.created_at , sm.space_id, ";

            SpaceQuery += " (SELECT  soutout.created_at";
            SpaceQuery += " FROM "+company_databasename+".so_sensor_inout AS soutout";
            SpaceQuery += " LEFT JOIN "+company_databasename+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
            SpaceQuery += " WHERE soutout.inout = 0";
            SpaceQuery += " AND sinin.`user_id` = soutout.user_id";
            SpaceQuery += " AND sinin.`created_at`<= soutout.created_at";
            SpaceQuery += " AND sm.space_id  = soutout_sm.space_id";
            SpaceQuery += " ORDER BY soutout.created_at  LIMIT 1";
            SpaceQuery += " ) AS soutout";
            SpaceQuery += " FROM "+company_databasename+".so_sensor_inout AS sinin";
            SpaceQuery += " LEFT JOIN "+company_databasename+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
            SpaceQuery += " LEFT JOIN "+company_databasename+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
            SpaceQuery += " WHERE sinin.inout = 1";
            SpaceQuery += " AND sinin.created_at > '"+previous_4hourtime+"'";
            SpaceQuery += " ORDER BY sinin.created_at DESC";

            SpaceQuery += "  ) AS tbl WHERE tbl.soutout IS NULL AND tbl.space_id = s.space_id ";
            SpaceQuery += " GROUP BY tbl.space_id";
            SpaceQuery += " ) IS NULL, '0' , '3'), ";

            SpaceQuery += "  '2' "; //SpaceQuery += "  'Maintainance ma chhe Room NOT Available' ";
            SpaceQuery += "  ), ";

            SpaceQuery += "  '1' "; //SpaceQuery += "  'Room not available' ";
            SpaceQuery += "  ) AS available ";


            SpaceQuery += " FROM "+company_databasename+".so_spaces as s";
            SpaceQuery += " WHERE s.deleted_at IS NULL ";
            SpaceQuery += " ORDER BY s.space_name ASC ";

            /*console.log("=============================================");
            console.log(SpaceQuery);
            console.log("=============================================");*/

            connection.query(SpaceQuery, function (error, data, fields) {
                if(error){
                    res.json({
                        'success': false,
                        'message': "Woops, Something Went Wrong.",
                        'error': error,
                        'data' : [],


                    });
                }
                if(data){
                    res.json({
                        'success' : true,
                        'data' : data,
                        'message': message.SUCCESS
                    });
                }
            });
       }else{
        return res.json({
            'success': false,
            'message': message.ERROR
        });

       }
    });

}

