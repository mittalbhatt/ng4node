'use strict';


var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var async = require('async');
var database = require('../config/database');
var FRONT_CONSTANTS = require('../common/front_constants');


/**
 * @uses (addalertemails) add alert email services
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/
exports.addalertemails = function(req, res, next){

   var alertEmailObj = req.body.alertEmailObj;
   var removeEmailObj = req.body.removeEmailObj;
   var master_database = database.master_database.name;
   var mailArr = [];
   var checked = true;
   var checkMailService = true;
   var errRoll = false;

	alertEmailObj.forEach(function(email) {
		if(generalConfig.formattedEmail(email.alert_email) != null){
			mailArr.push(generalConfig.formattedEmail(email.alert_email));
		}else{
			checked = false;
		};

		if(typeof email.catering=='undefined' && typeof email.amenities=='undefined')
		{
			checkMailService = false;			
		}
	});
	
   	if(checked == false){
		res.json({
			'success': false,
			'message': message.INVAID_EMAIL
		});
		return;
   	}

   	if(checkMailService == false){
		res.json({
			'success': false,
			'message': message.SELECT_ATLEAST_ONE_SERVICE
		});
		return;
   	}

   	generalConfig.getDataBase(req, res, function(company_databasename)
   	{
       if(company_databasename != null)
       { 
			// Remove selected emails services
			if(removeEmailObj.length > 0)
			{
				removeEmailObj.forEach(function(email_id)
				{
						var remOtherMailService = "DELETE FROM "+company_databasename+".`so_other_email_services` WHERE `so_other_email_services`.`email_id` = '"+email_id+"'";
						connection.query(remOtherMailService, function (error, results, fields)
						{ 
			            if(error){ return res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }	                    
			    	});
				});
			}

		   	var returnNewEmails = [];			
		   	var insertOperation = 0;

		   	async.forEach(alertEmailObj, function (val, callback)
        	{ 
				var email =	generalConfig.formattedEmail(val.alert_email);
				var email_id = val.email_id;
				var created_at = generalConfig.getDateTimeUTC();
				var GUID = generalConfig.generateGUID();

				if(email != null)
				{				
					var mailQuery = "SELECT * FROM "+company_databasename+".`so_email_master` WHERE `so_email_master`.`email_id` = '"+email_id+"' OR `so_email_master`.`email_address` = '"+email+"'";
					connection.query(mailQuery, function (error, emailObj, fields)
					{						
						if(emailObj.length == 0)
						{
							var email_id = GUID;
							var master = "INSERT INTO  "+company_databasename+".`so_email_master` (`email_id` ,`email_address` ,`status` ,`created_at` ,`updated_at` , `deleted_at`) VALUES ( '"+email_id+"', '"+email+"',  '1',  '"+created_at+"',  '"+created_at+"', NULL )";
							connection.query(master, function (error, master, fields)
							{
								if(master)
								{
									var id = email_id;
									var keys = Object.keys(val);
									var keys = keys.filter(function(e) { return e !== 'email_id' });

									for (var i = 0; i < keys.length; i++) 
									{
										var GUID = generalConfig.generateGUID();
										if(keys[i] !== 'alert_email')
										{
											var otherMail = " INSERT INTO  "+company_databasename+".`so_other_email_services` (`service_id` , `email_id` , `service_type` , `status` , `created_at` , `updated_at` , `deleted_at` ) VALUES ( '"+GUID+"','"+id+"', '"+keys[i]+"' ,  '1',  '"+created_at+"',  '"+created_at+"', NULL )";
											connection.query(otherMail, function (error, otherMail, fields)
											{
												if(error){
													res.json({
											            'success': false,
											            'message': message.ERROR,
											        });	
												}
											});
										}
									}
								}								
							});
							returnNewEmails.push({email_id :email_id,email:email});
						}

						if(emailObj.length > 0){
							var new_email_address = email;
							var email_id = emailObj[0].email_id;
							var old_created_at = emailObj[0].created_at;

							if(email_id){
								var masterQuery = "SELECT * FROM "+company_databasename+".`so_email_master` WHERE `so_email_master`.`email_id` = '"+email_id+"'";
								connection.query(masterQuery, function (error, email, fields) { 
									var id = email[0].email_id;
									var update = "UPDATE  "+company_databasename+".`so_email_master` SET  `email_address` =  '"+new_email_address+"' WHERE  `so_email_master`.`email_id` = '"+id+"'";
									connection.query(update, function (error, update, fields) {
										if(!error){
											var bulkRemove = "DELETE FROM "+company_databasename+".`so_other_email_services` WHERE `so_other_email_services`.`email_id` = '"+id+"'";
											connection.query(bulkRemove);
											var keys = Object.keys(val);
			  								var keys = keys.filter(function(e) { return e !== 'email_id' });

			  								for (var i = 0; i < keys.length; i++) {
			  									var GUID = generalConfig.generateGUID();
					    						if(keys[i] !== 'alert_email'){
										    		var otherMail = " INSERT INTO  "+company_databasename+".`so_other_email_services` (`service_id` , `email_id` , `service_type` , `status` , `created_at` , `updated_at` , `deleted_at` ) VALUES ( '"+GUID+"','"+id+"', '"+keys[i]+"' ,  '1',  '"+created_at+"',  '"+created_at+"', NULL )";
										    		connection.query(otherMail);
					    						}
										    }
										}
									});
								});
							}
						}
					});					
				}				

				if(++insertOperation == (alertEmailObj.length))
				{	
					var counter=0;
					var query = "SELECT `em`.`email_id`, `em`.`email_address`, ( SELECT group_concat(concat(service_type) separator ',') FROM "+company_databasename+".`so_other_email_services`  WHERE email_id = `em`.`email_id` GROUP BY email_id) AS OtherServices FROM "+company_databasename+".`so_email_master` AS `em` LEFT JOIN "+company_databasename+".`so_other_email_services` as `os` ON `os`.`email_id` = `em`.`email_id` WHERE `os`.`service_type` = 'amenities' OR `os`.`service_type` = 'catering' GROUP BY `em`.`email_id`";
					connection.query(query, function (error, results, fields)
					{
						if(error)
						{						
							return false;
						}
						else if(results)
						{
							var serviceObjArr = [];
							async.forEach(results, function (val, callback){ 
								var serviceArr = val.OtherServices.split(',');
									if(serviceArr.length >0){
										for (var i = 0; i < serviceArr.length; i++) {
											serviceObjArr.push({
												service_type :serviceArr[i]
											});
										}
									}
									val.OtherMailServices = serviceObjArr;
									serviceObjArr = [];
									if(++counter == (results.length))
									{			
										callback("--- 1 ----");									
									}
							}, function(results) {
								callback("--- 2 ----");
							});
						}
					});					
				}
			},
			function(data)
			{
				res.json({
				    'success': true,
				    'newMails': returnNewEmails,			    
				    'message': message.ADD_SUCCESS			    
				});
			});
       } else {
	       	return res.json({
	            'success': false,
	            'message': message.ERROR
	        }); 
       }
    });

}

/**
 * @uses get so setup
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getSoSetup = function(req, res, next)
{		
	var returnObj = {};	
 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {        	
	       	var query = "SELECT config_title, config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = 'SOSETUP_APP_ID' OR `config_title` = 'SOSETUP_APP_TOKEN'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{		
					if(results!='')
					{
						results.forEach(function(item)
						{
							if(item['config_title']=='SOSETUP_APP_ID')
							{
								returnObj.SOSETUP_APP_ID = item['config_value'];
							}
							if(item['config_title']=='SOSETUP_APP_TOKEN')
							{
								returnObj.SOSETUP_APP_TOKEN = item['config_value'];	
							}
						});					
						res.json({
					        'success' : true,					            
					        'data' : returnObj
					    });						
					}										
				}
       		});
    	}
    });
}

/**
 * @uses (addSOSId) add SOS setup Id settings
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/

exports.addSOSId = function(req, res, next){
	req.checkBody("app_id", message.APP_ID_REQUIRE).notEmpty();
	req.checkBody("app_token", message.APP_TOKEN_REQUIRE).notEmpty();

	var errors = req.validationErrors();

	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {			
			errMsg[err.param] = [err.msg];
        });	
        res.json({
            'success': false,
            'message': errMsg
        });
        
    }
    else
    { 
    	// company database
		generalConfig.getDataBase(req, res, function(company_databasename)
		{
	       if(company_databasename != null)
	       {
	       		var q1 = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.app_id+"' WHERE `config_title`='SOSETUP_APP_ID'";
				connection.query(q1, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }					
	       		});
	       		var q2 = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.app_token+"' WHERE `config_title`='SOSETUP_APP_TOKEN'";
				connection.query(q2, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }					
	       		});
				res.json({
	                'success' : true,
	                'message': message.SO_SETUP_UPDATE
	            });	       		
	    	}
	    });
    }
}	


/**
 * @uses (getalertemails) fetch service alert email list
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/

exports.getalertemails = function(req, res, next){
	generalConfig.getDataBase(req, res, function(company_databasename){
		if(company_databasename != null){ 
			var query = "SELECT `em`.`email_id`, `em`.`email_address`, ( SELECT group_concat(concat(service_type) separator ',') FROM "+company_databasename+".`so_other_email_services`  WHERE email_id = `em`.`email_id` GROUP BY email_id) AS OtherServices FROM "+company_databasename+".`so_email_master` AS `em` LEFT JOIN "+company_databasename+".`so_other_email_services` as `os` ON `os`.`email_id` = `em`.`email_id` WHERE `os`.`service_type` = 'amenities' OR `os`.`service_type` = 'catering' GROUP BY `em`.`email_id`";
			connection.query(query, function (error, results, fields) {
				if(error){
					return res.json({
						'success': false,
						'message': message.ERROR,
						'error': error
					});
				} else if(results){
					var serviceObjArr = [];

					async.forEach(results, function (val, callback){ 
						var serviceArr = val.OtherServices.split(',');
							if(serviceArr.length >0){
								for (var i = 0; i < serviceArr.length; i++) {
									serviceObjArr.push({
										service_type :serviceArr[i]
									});
								}
							}
							val.OtherMailServices = serviceObjArr;
							serviceObjArr = [];
						callback()
					}, function(err) {
						res.json({
							success: true,
							data:results,
							message: message.SUCCESS
						});
					});
				}
			});

		} else {
			res.json({
				'success': false,
				'message': message.ERROR
			});
		}
	});
}

/**
 * @uses upload company Logo from Settings
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json object
*/
exports.uploadCompanyLogo = function(req, res, next)
{
	var domain = generalConfig.getDomain(req);	
 	var master_database = database.master_database.name;
 	var updateDate = generalConfig.getDateTimeUTC(); 	 	
 	var base64Image = req.body.company_logo;
 	var filename = req.body.image_name;

 	// upload image
 	var new_file_name = "";
    var createDate = generalConfig.getDateTimeUTC();
    var GUID = generalConfig.generateGUID();
 	var oldCompanyImage = "";

    master_db.models.companyMaster.findOne({
        where : { company_domain_prefix : domain },        
        })
        .then(function(objCompanyMaster)
        {
        	if(objCompanyMaster)
        	{
	           oldCompanyImage = objCompanyMaster.company_logo;
	           var resObj = upload.uploadImage(domain, "company", base64Image, filename, oldCompanyImage, "", "");	           
	           if(resObj.success == true){
			        new_file_name = resObj.file_name;
			    } else {
			        return res.json({
			            'success': resObj.success,
			            'message': resObj.message
			        });
			    }

			    var company_logo = (new_file_name)? new_file_name:'';
			    objCompanyMaster.update({ company_logo : company_logo });
			    
			    var companyLogoPath = "";
			    var imagePathObjAfterUpload = generalConfig.getFilePath(domain, "company", "main", "sub");	
			    var makePathNewUploadedImage = imagePathObjAfterUpload.mainLink+'/'+company_logo;                
                if(!generalConfig.checkFilePath(makePathNewUploadedImage))
                {
                   companyLogoPath = generalConfig.no_image_200;
                }
                else
                {
                   companyLogoPath = generalConfig.imageUrl(makePathNewUploadedImage);
                }

		        res.json({
		                'success' : true,
		                'message': message.COMPANY_LOGO_UPDATE_SUCCESS,
		                'company_logo' : companyLogoPath
		            });    

        	}
        	else
        	{
        		res.json({
	                'success': false,
	                'message': message.ERROR,
	                'error': err
	            });
        	}
        })
        .catch(function(err) {
            res.json({
                'success': false,
                'message': message.ERROR,
                'error': err
            });        
        });	
}

/**
 * @uses get settings
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getSettings = function(req, res, next)
{	
	var returnObj = {};
	var domain = generalConfig.getDomain(req);
	var imagePathObj = generalConfig.getFilePath(domain, "company", "main", "sub");	
 	var master_database = database.master_database.name;
 	var updateDate = generalConfig.getDateTimeUTC(); 	 	

 	// model companyMaster
 	var qGetCompanyMaster = "SELECT company_domain_prefix, company_logo FROM `"+master_database+"`.`so_company_master` WHERE `company_domain_prefix` = '"+domain+"'";
	connection.query(qGetCompanyMaster, function (error, results, fields)
	{
		if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
		else if(results)
		{	

			var companyLogoPath = "";	
			// if(val.amenity_image != "")
			if(results[0]['company_logo'] != "" && results[0]['company_logo']!=null)
			{
                var path = imagePathObj.mainLink+'/'+results[0]['company_logo'];                
                if(!generalConfig.checkFilePath(path))
                {
                   companyLogoPath = generalConfig.no_image_200;
                }
                else
                {
                   companyLogoPath = generalConfig.imageUrl(path);
                }                
            }
            else
            {				
                companyLogoPath = generalConfig.no_image_200;				
            }

			returnObj.companyLogo = {'company_name':results[0]['company_domain_prefix'],'company_logo':companyLogoPath};
		}

		// company database
		generalConfig.getDataBase(req, res, function(company_databasename)
		{
	       if(company_databasename != null)
	       {
	        	// get powered by
	       		var qPoweredBy = "SELECT config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = 'POWERED_BY'";
				connection.query(qPoweredBy, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
					else if(results)
					{	
						if(typeof results[0] != 'undefined')
						{
							returnObj.POWERED_BY = results[0]['config_value'];						
							res.json({
						        'success' : true,					            
						        'data' : returnObj
						    });							
						}						
					}
	       		});
	    	}
	    });		
	});
}

/**
 * @uses update status for Show Powered By
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.showPoweredBy = function(req, res, next)
{
	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {
 			if([true,false].includes(req.body.show_powered_by))
 			{
	       		var qPoweredBy = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.show_powered_by+"' WHERE `config_title`='POWERED_BY'";
				connection.query(qPoweredBy, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
					else if(results)
					{
						if(results.affectedRows)
						{
							if(req.body.show_powered_by)
							{
								res.json({
							        'success' : true,					            
							        'message' : message.SHOW_POWERED_BY_ENABLED
							    });

							}
							else
							{
								res.json({
							        'success' : true,					            
							        'message' : message.SHOW_POWERED_BY_DISABLED
							    });						
							}						
						}					
					}
	       		});
 			}
 			else
 			{
 				res.json({
			        'success' : false,					            
			        'message' : message.INVALID_VALUE_SUBMITTED
			    });
 			}
    	}
    });	
}

/**
 * @uses update 24 Hours timing format
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.timingFormat = function(req, res, next)
{
	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {
       		if([true,false].includes(req.body.timing_format))
       		{
	       		var query = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.timing_format+"' WHERE `config_title`='24_HOUR_FORMAT'";
				connection.query(query, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
					else if(results)
					{							
						if(results.affectedRows)
						{
							res.json({
						        'success' : true,					            
						        'message' : message.TIMING_FORMAT_UPDATE
						    });						
						}
					}
	       		});       			
       		}
       		else
 			{
 				res.json({
			        'success' : false,					            
			        'message' : message.INVALID_VALUE_SUBMITTED
			    });
 			}
    	}
    });	
}

/**
 * @uses get configured 24 Hourse Time Format
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getTimingInfo = function(req, res, next)
{	
	var returnObj = {};	

 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {
        	// get powered by
       		var query = "SELECT config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = '24_HOUR_FORMAT'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{							
					if(typeof results[0] != 'undefined')
					{
						returnObj.TIMING_FORMAT = results[0]['config_value'];
						res.json({
					        'success' : true,					            
					        'data' : returnObj
					    });						
					}
				}
       		});
    	}
    });
}

/**
 * @uses update status of integrated App for Calendar
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.appIntegration = function(req, res, next)
{
	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
        if(company_databasename != null)
        {
       		var query = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.selectedAppStatus+"' WHERE `config_title`='"+req.body.integrationAppName+"'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{			
					if(results.affectedRows)
					{
						if(req.body.selectedAppStatus=='true')				
						{
							if(req.body.integrationAppName=='CUSTOM_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.CUSTOM_CALENDER_CONNECTED
							    });								
							}
							else if(req.body.integrationAppName=='GOOGLE_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.GOOGLE_CALENDER_CONNECTED
							    });	
							}
							else if(req.body.integrationAppName=='OFFICE365_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.OFFICE365_CALENDER_CONNECTED
							    });	
							}
						}
						else
						{
							if(req.body.integrationAppName=='CUSTOM_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.CUSTOM_CALENDER_DISCONNECTED
							    });								
							}
							else if(req.body.integrationAppName=='GOOGLE_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.GOOGLE_CALENDER_DISCONNECTED
							    });	
							}
							else if(req.body.integrationAppName=='OFFICE365_CALENDER')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.OFFICE365_CALENDER_DISCONNECTED
							    });	
							}	
						}						
					}
				}
       		});
    	}
    });	
}

/**
 * @uses get configured value for integrated calender
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getAppIntegrationInfo = function(req, res, next)
{	
	var returnObj = {};	
 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {        	
       		var query = "SELECT config_title, config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = 'CUSTOM_CALENDER' OR `config_title` = 'GOOGLE_CALENDER' OR `config_title` = 'OFFICE365_CALENDER'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{					
					returnObj.integratedApp = results;
					res.json({
				        'success' : true,					            
				        'data' : returnObj
				    });
				}
       		});
    	}
    });
}

/**
 * @uses remove company logo image
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.removeCompanyLogoImage = function(req, res, next)
{	
	var domain = generalConfig.getDomain(req);
	var master_database = database.master_database.name;
	var structureObj = (generalConfig.uploadpath["company"])?generalConfig.uploadpath["company"]:generalConfig.uploadpath["default"];
	var basePath = generalConfig.uploadBasePath;	
	var uploadFolder = structureObj.folder;
	var subFolder = structureObj.size_folder;

 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {        	
       		var query = "SELECT company_logo FROM `"+master_database+"`.`so_company_master` WHERE `company_domain_prefix` = '"+domain+"'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{				
					upload.remvoeUploadedFile(domain, uploadFolder, subFolder, basePath, results[0]['company_logo']);
					var queryForNull = "UPDATE `"+master_database+"`.`so_company_master` SET `company_logo` = NULL WHERE `company_domain_prefix` = '"+domain+"'";
					connection.query(queryForNull, function (error, results, fields)
					{
						if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
						else if(results)
						{
							res.json({
						        'success' : true,					            
						        'message' : message.REMOVE_COMPANY_LOGO_IMAGE_SUCCESS,
						        'company_logo' : generalConfig.no_image_200
						    });							
						}						
					});
				}
       		});
    	}
    });
}

/**
 * @uses get status of ESTIMOTE_BEACON_STATUS
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getSensors = function(req, res, next)
{		
	var returnObj = {};		
	returnObj.ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY_VALUES = FRONT_CONSTANTS.estimoteBeaconAutoCheckoutEntryArray;

 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {        	
	       	var query = "SELECT config_title, config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = 'ESTIMOTE_BEACON' OR `config_title` = 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{	
					if(results!='')
					{
						results.forEach(function(item)
						{
							if(item['config_title']=='ESTIMOTE_BEACON')
							{
								returnObj.ESTIMOTE_BEACON = item['config_value'];
							}
							if(item['config_title']=='ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY')
							{
								returnObj.ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY = item['config_value'];	
							}
						});					
						res.json({
					        'success' : true,					            
					        'data' : returnObj
					    });						
					}

				}
       		});
    	}
    });
}

/**
 * @uses update status of estimote beacon
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.updateSensors = function(req, res, next)
{
	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
        if(company_databasename != null)
        {
        	// ESTIMOTE_BEACON_STATUS
        	if(req.body.item == 'ESTIMOTE_BEACON_STATUS')
        	{
        		if([true,false].includes(req.body.estimote_beacon_status))
        		{
		       		var query = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.estimote_beacon_status+"' WHERE `config_title`='ESTIMOTE_BEACON'";
					connection.query(query, function (error, results, fields)
					{
						if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
						else if(results)
						{			
							if(results.affectedRows)
							{
								if(req.body.estimote_beacon_status)				
								{
									res.json({
								        'success' : true,					            
								        'message' : message.ESTIMOTE_BEACON_ENABLED
								    });						
								}
								else
								{
									res.json({
								        'success' : true,					            
								        'message' : message.ESTIMOTE_BEACON_DISABLED
								    });	
								}							
							}
						}
		       		});        			
        		}
        		else
	 			{
	 				res.json({
				        'success' : false,					            
				        'message' : message.INVALID_VALUE_SUBMITTED
				    });
	 			}
        	}

        	// ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY
        	if(req.body.item == 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY')
        	{
        		var estimoteBeaconAutoCheckoutEntryArray = FRONT_CONSTANTS.estimoteBeaconAutoCheckoutEntryArray;
        		if(estimoteBeaconAutoCheckoutEntryArray.includes(parseInt(req.body.estimoteBeaconAutoCheckout)))
        		{
		       		var query = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.estimoteBeaconAutoCheckout+"' WHERE `config_title`='ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY'";
					connection.query(query, function (error, results, fields)
					{
						if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
						else if(results)
						{			
							if(results.affectedRows)
							{
								res.json({
							        'success' : true,					            
							        'message' : message.ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY_UPDATED
							    });							
							}
						}
		       		});				        				        			
        		}
        		else
        		{
        			res.json({
				        'success' : false,					            
				        'message' : message.INVALID_VALUE_SUBMITTED
				    });
        		}        		
        	}
    	}
    });	
}

/**
 * @uses get status of ESTIMOTE_BEACON_STATUS
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.getPushNotification = function(req, res, next)
{		
	var returnObj = {};
	returnObj.pushNotificationTimeInterval = FRONT_CONSTANTS.pushNotificationTimeInterval;	
 	
 	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
       if(company_databasename != null)
       {        	
	       	var query = "SELECT config_title, config_value FROM `"+company_databasename+"`.`so_configuration` WHERE `config_title` = 'PUSH_NOTIFICATION_FOR_MEETING_DURATION_BEFORE' OR `config_title` = 'PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY'";
			connection.query(query, function (error, results, fields)
			{
				if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
				else if(results)
				{		
					if(results!='')
					{
						results.forEach(function(item)
						{
							if(item['config_title']=='PUSH_NOTIFICATION_FOR_MEETING_DURATION_BEFORE')
							{
								returnObj.PUSH_NOTIFICATION_FOR_MEETING_DURATION_BEFORE = item['config_value'];
							}
							if(item['config_title']=='PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY')
							{
								returnObj.PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY = item['config_value'];	
							}
						});					
						res.json({
					        'success' : true,					            
					        'data' : returnObj
					    });						
					}										
				}
       		});
    	}
    });
}

/**
 * @uses update before meeting time duration
 *
 * @author KT < ketan@softwebsolutions.com >
 *
 * @return json
*/
exports.updatePushNotification = function(req, res, next)
{
	// company database
	generalConfig.getDataBase(req, res, function(company_databasename)
	{
        if(company_databasename != null)
        {
        	var pushNotificationTimeInterval = FRONT_CONSTANTS.pushNotificationTimeInterval;
    		if(pushNotificationTimeInterval.includes(parseInt(req.body.item_value)))
    		{
	       		var query = "UPDATE `"+company_databasename+"`.`so_configuration` SET `config_value` = '"+req.body.item_value+"' WHERE `config_title`='"+req.body.item+"'";
				connection.query(query, function (error, results, fields)
				{
					if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
					else if(results)
					{						
						if(results.affectedRows)
						{
							if(req.body.item == 'PUSH_NOTIFICATION_FOR_MEETING_DURATION_BEFORE')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.BEFORE_MEETING_TIME_UPDATED
							    });
							}
							else if (req.body.item == 'PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY')
							{
								res.json({
							        'success' : true,					            
							        'message' : message.PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY_UPDATED
							    });
							}
						}
						else
						{
							res.json({
								'success': false,
								'message': message.ERROR
							});	
						}
					}
	       		});    			
    		}
    		else
    		{
    			res.json({
			        'success' : false,					            
			        'message' : message.INVALID_VALUE_SUBMITTED
			    });	
    		}
    	}
    });	
}