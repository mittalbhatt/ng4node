'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var database = require('../config/database');
var master_database = database.master_database.name;
var async = require('async');
/**
 * @uses Get user inforamation
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
// exports.userInfo = function (req, res, next) {
// 	var userInfo = generalConfig.getUserInfo(req);
// 	console.log(userInfo);
// }


/**
 * @uses Get event data by id for update page
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.getEventById = function (req, res, next) {
    db.models.SpaceBooking.find({ 
		where: { 
			booking_id: req.params.id,
			deleted_at: { $eq: null } 
		},		
		include: [{
				model: db.models.SpaceAttendies,
				attributes: ['email_id'],
				include: [{
					model: db.models.EmailMaster,
					attributes: ['email_address']
				}],
				required: false
			}]
	}).then(function (events) {
			
		if (!events)
            return next(new Error('Failed to load Event ' + booking_id));		    
        res.json({
			success: true,
			data: events,
			message: null
		});
    }).catch(function (err) {
        res.json({
			success: false,
			message: message.ERROR
		});
    });
};


/**
 * @uses Get attendies emails by id for update page
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
*/

// exports.getAttendiesEmails = function(req, res, next){
// 	db.models.SpaceAttendies.findAll({
// 		where: {
// 			booking_id: req.param.id,
// 			deleted_at: { $eq: null }
// 		},
// 		attributes: [
// 			'email_address',
// 			'email_id',
// 		],
// 		include: [{
// 			model: db.models.SpaceAttendies,
// 		}]

//     }).then(function (emails) {
// 		if(emails){
// 			res.json({
// 				success: true,
// 				data:emails,
// 				message: message.SUCCESS
// 			});
// 		}

//     }).catch(function (err) {
// 		res.json({
// 			success: false,
// 			data:err,
// 			message: message.ERROR
// 		});
//     });
// }

/**
 * @uses Get all listing data for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.allListingData = function (req, res, next) {
	var data = {};

    generalConfig.getDataBase(req, res, function(company_databasename){
    if(company_databasename != null){ 
            var query = "SELECT  `SPACE`.*  FROM "+company_databasename+".`so_spaces` as `SPACE` where `SPACE`.deleted_at is null = ''";
            connection.query(query, function (error, results, fields) {
       
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                	data.space = results;
					res.json({
						'success': true,
						'data': data,
						'message': message.SUCCESS
					});

           
                }
            });
        } else {
        	return res.json({
            	'success' : false,
            	'data' : null,
            	          
            	'recordsTotal' : 0,
            	'recordsFiltered' : 0,
            	'message': message.ERROR
        	});
        }
    });

	//////////////////////////////////////////////////////////

	// var data = {};

	// db.models.Space.findAll({
	// 	where: {
	// 		deleted_at: { $eq: null }
	// 	},
	// 	attributes: [
	// 		'space_id',
	// 		'space_name',
	// 		'space_capacity'
	// 	]
	// }).then(function (space) {
	// 	data.space = space;
	// 	res.json({
	// 		'success': true,
	// 		'data': data,
	// 		'message': message.SUCCESS
	// 	});
	// }).catch(function (err) {
	// 	res.json({
	// 		'success': false,
	// 		'message': message.ERROR,
	// 		'error': err
	// 	});
	// });
}


/**
 * @uses create new event
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.bookEvent = function (req, res, next) {


	// Validation messages
    req.checkBody("booking_title", message.TITLE_REQUIRED).notEmpty();
	req.checkBody("start_datetime", message.START_TIME_REQUIRE).notEmpty();
	req.checkBody("end_datetime", message.END_TIME_REQUIRE).notEmpty();
	req.checkBody("space_id", message.SPACE_NAME_REUIRED).notEmpty();
	
	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {
		
		// utc Converted datetime 
	
	


    	generalConfig.getDataBase(req, res, function(company_databasename){
    	var createdDate = generalConfig.getDateTimeUTC();



		var date1 = new Date(req.body.start_datetime);
        var startDateTime = dateFormat(date1, "UTC:yyyy-mm-dd HH:MM:ss");



        var date2 = new Date(req.body.end_datetime);
        var endDateTime = dateFormat(date2, "UTC:yyyy-mm-dd HH:MM:ss");


    
    		var query  = "";
		    query += "SELECT ";
		    query += " sb.booking_id, sb.space_id, sb.user_id, ";
		    query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
		    query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
		    query += " sb.booking_duration, ";
		    query += "IF( ";
		    query += " (SELECT booking_id FROM "+company_databasename+".so_space_booking as sb WHERE sb.space_id = '"+req.body.space_id+"' ";
		    query += " AND ((sb.start_time < '"+startDateTime+"' AND sb.end_time > '"+startDateTime+"') ";
		    query += " OR (sb.start_time < '"+endDateTime+"' AND sb.end_time > '"+endDateTime+"') ";
		    query += " OR (sb.start_time >= '"+startDateTime+"' AND sb.end_time <= '"+endDateTime+"')) ";
		    query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
		    query += "  IS NULL, ";

	        query += "IF( ";
	        query += " (SELECT maintainance_id FROM "+company_databasename+".so_space_maintainance as sm WHERE sm.space_id = '"+req.body.space_id+"' ";
	        query += " AND ((sm.start_time < '"+startDateTime+"' AND sm.end_time > '"+startDateTime+"') ";
	        query += " OR (sm.start_time < '"+endDateTime+"' AND sm.end_time > '"+endDateTime+"') ";
	        query += " OR (sm.start_time >= '"+startDateTime+"' AND sm.end_time <= '"+endDateTime+"')) ";
	        query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
	        query += "  IS NULL, ";
	        query += "  '0', "; //query += "  'Room Available', ";
	        query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
	        query += "  ), ";

		    query += "  '1' "; //query += "  'Room not available' ";
		    query += "  ) AS is_available ";
		    query += " FROM "+company_databasename+".so_space_booking AS sb ";
		    query += " WHERE sb.deleted_at IS NULL ";
		    query += " AND sb.space_id = '"+req.body.space_id+"' GROUP BY sb.space_id " ;

			var result = connection.query(query);

			
		connection.query(query, function (error, findresult, fields) {
		if(findresult.length == 0 || findresult[0].is_available == 0) {

	


		var startTimeUtc = generalConfig.getDateTimeUTC(req.body.start_datetime);
		var endTimeUtc = generalConfig.getDateTimeUTC(req.body.end_datetime);




		var obj = {
			space_id: req.body.space_id,
			user_id: req.body.user_id,
			booking_title: req.body.booking_title,
			booking_details: req.body.booking_details,
			booking_status: req.body.booking_status,
			amenities_notes: req.body.amenities_notes,
			catering_notes: req.body.catering_notes,
			start_time:startTimeUtc,
			end_time: endTimeUtc,
			booking_duration: req.body.booking_duration,
			// device_id:req.body.device_id,
			status: req.body.status,
			createdAt: createdDate,
			updatedAt: createdDate
        };


        var GUID = generalConfig.generateGUID();
		var InsertId = GUID;

		var insertQuery = "INSERT INTO "+company_databasename+".`so_space_booking` (`booking_id`,`space_id`,`user_id`,`booking_title`,`booking_details`,`booking_status`,`amenities_notes`,`catering_notes`,`start_time`,`end_time`,`booking_duration`, `status`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+obj.space_id+"','"+obj.user_id+"','"+obj.booking_title+"','"+obj.booking_details+"','"+obj.booking_status+"','"+obj.amenities_notes+"','"+obj.catering_notes+"','"+obj.start_time+"','"+obj.end_time+"','"+obj.booking_duration+"', '"+obj.status+"','"+obj.createdAt+"','"+obj.updatedAt+"')";
	
		connection.query(insertQuery, function (error, results, fields) { 
        

        	if(error){
                return res.json({
					success: false,
					data: null,
					message: message.ERROR
			});
            } else if(results){

		 		addEmailTags(req,res,req.body.emailTags, InsertId);
				res.json({
					'success' : true,
					'data' : results,
					'message': 'Event Created Successfully'
				});
            }
        });


			     }
			     else {



            	res.json({
					success: false,
					data: null,
					message: 'Meeting already booked at this space on this time duration.'
				});

			    }
			});

    	})

    }
};



/**
 * @uses update event booking
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.updateEvent = function (req, res, next) {

	var statusValue = (req.body.status==1 || req.body.status==true) ? 1 : 0; 	

    // Validation messages
    req.checkBody("booking_title", message.TITLE_REQUIRED).notEmpty();
	req.checkBody("start_datetime", message.START_TIME_REQUIRE).notEmpty();
	req.checkBody("end_datetime", message.END_TIME_REQUIRE).notEmpty();
	req.checkBody("space_id", message.SPACE_NAME_REUIRED).notEmpty();

	var errors = req.validationErrors();
	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {
			errMsg[err.param] = [err.msg];
        });
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {
    	
		// utc Converted datetime 
		var startDateTime = generalConfig.getDateTimeUTC(req.body.start_datetime);
		var endDateTime = generalConfig.getDateTimeUTC(req.body.end_datetime);
		var updatedAt = generalConfig.getDateTimeUTC();
		
		var obj = {
			space_id: req.body.space_id,
			//user_id: req.body.user_id,
			booking_title: req.body.booking_title,
			booking_details: req.body.booking_details,
			//booking_status: req.body.booking_status,
			amenities_notes: req.body.amenities_notes,
			catering_notes: req.body.catering_notes,
			start_time:startDateTime,
			end_time: endDateTime,
			// booking_duration: req.body.booking_duration,
			// device_id:req.body.device_id,
			status: req.body.status,
			updatedAt: updatedAt
        };	
		
        db.models.SpaceBooking.update(obj, { where: { booking_id: req.body.booking_id } }).then(function () {
		 	addEmailTags(req.body.emailTags, data.booking_id);

            res.json({
                success: true,
                data: obj,
                message: message.ADD_SUCCESS
            });
        }).catch(function (err) {
            res.json({
				success: false,
				data: null,
				message: message.ERROR
			});
        });
    }
};



function addEmailTags(req,res,emailArr, bookingId) {
	var	attentiesType = '';
	emailArr.forEach(function(email) {
		if(email != null){
        var GUID = generalConfig.generateGUID();
		var InsertId = GUID;
	    generalConfig.getDataBase(req, res, function(company_databasename){
		var selectQuery = "SELECT  `EmailMaster`.*  FROM "+company_databasename+".`so_email_master` as `EmailMaster` where `EmailMaster`.email_address =  '"+email.value+"'";
		connection.query(selectQuery, function (error, results, fields) { 
			if(results.length == 0) {
				var insertQuery = "INSERT INTO "+company_databasename+".`so_email_master` (`email_id`,`email_address`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+email.value+"','"+generalConfig.getDateTimeUTC()+"','"+generalConfig.getDateTimeUTC()+"')";
				

				connection.query(insertQuery, function (error, results, fields) { 
		
				
				var insertAttentiesQuery = "INSERT INTO "+company_databasename+".`so_space_attendies` (`attendies_id`,`booking_id`,`email_id`,`attendies_type`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+bookingId+"','"+results[0].email_id+"','"+''+"','"+generalConfig.getDateTimeUTC()+"','"+generalConfig.getDateTimeUTC()+"')";

						connection.query(insertAttentiesQuery, function (error, results, fields) { 
		
						 });

		        });


			}

			else if(results.length > 0) {

				var new_email_address = email.value;
				var email_id = results[0].email_id;
				var old_created_at = results[0].created_at;

				if(email_id) {



				var insertAttentiesQuery = "INSERT INTO "+company_databasename+".`so_space_attendies` (`attendies_id`,`booking_id`,`email_id`,`attendies_type`,`created_at`, `updated_at`) VALUES ('"+InsertId+"','"+bookingId+"','"+email_id+"','"+''+"','"+generalConfig.getDateTimeUTC()+"','"+generalConfig.getDateTimeUTC()+"')";

						connection.query(insertAttentiesQuery, function (error, results, fields) { 
		
						
		        });





				}



			}



		})


	})




		}
	});
}


exports.getScheduleList = function (req, res, next) {

	var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;
    var dateTime = req.query.dt;
    var TimeUTC = generalConfig.getDateTimeUTC(dateTime);

    // var domain = generalConfig.getDomain(req);
    // var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");
    var accessObj = generalConfig.userAccessCheck(req);
    

    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

    if(user && user.user_id){
	    generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){

	        	var userQuery = "SELECT  `U`.first_name,  `U`.last_name,  `U`.email, `U`.timezone, `U`.time_difference,  `EM`.email_id, `U`.user_id ";
	        		userQuery += " FROM  `"+master_database+"`.`so_users` AS  `U` LEFT JOIN  `"+company_databasename+"`.`so_email_master` AS  `EM` ";
	        		userQuery += " ON  `EM`.email_address =  `U`.email WHERE  `U`.`user_id` =  '"+user.user_id+"'";

	        	connection.query(userQuery, function (error, userResult, fields) {
	        	
		        	if(userResult.length > 0){
		        		var email_id = userResult[0].email_id;
		        	}

		            var query = "SELECT `SB`.booking_id as booking_id, `SB`.space_id as space_id, `SB`.user_id as user_id, `SB`.booking_title as booking_title, ";
		             	query +=" `SB`.booking_details as booking_details, `SB`.booking_status as booking_status, `SB`.amenities_notes as amenities_notes, ";
		              	query +=" `SB`.catering_notes as catering_notes, `SB`.start_time AS start_time, `SB`.end_time AS end_time, ";
		              	query +=" `SB`.booking_duration as booking_duration, `SB`.device_id as device_id, `SB`.status as status, ";
		              	query +=" `SB`.created_at as created_at, `SB`.deleted_at as deleted_at, CONCAT(`U`.first_name,' ',`U`.last_name) AS organizer, ";
		              	query +=" `S`.space_name as space_name, `BD`.building_name as building_name, ";
		              	query +=" IF(DATE_FORMAT(`SB`.start_time,'%Y-%m-%d %H:%i')  >= '"+TimeUTC+"', true, false) as is_delete_valid ";
		              	query +=" FROM "+company_databasename+".`so_space_booking` AS `SB` ";
		              	query +=" LEFT JOIN "+master_database+".so_users AS `U` ON `U`.user_id = `SB`.user_id ";
		              	query +=" LEFT JOIN "+company_databasename+".so_spaces AS `S` ON `S`.space_id = `SB`.space_id ";
		              	query +=" LEFT JOIN "+company_databasename+".so_floors AS `FL` ON `S`.floor_id = `FL`.floor_id ";
		              	query +=" LEFT JOIN "+company_databasename+".so_buildings AS `BD` ON `BD`.building_id = `FL`.building_id ";
		              	query +=" LEFT JOIN "+company_databasename+".so_space_attendies AS `SA` ON `SA`.booking_id = `SB`.booking_id  ";
		              	query +=" WHERE `SB`.user_id = '"+user.user_id+"' ";
		              	query +=" AND (`BD`.building_name LIKE '%"+search+"%' OR `S`.space_name LIKE '%"+search+"%' OR `U`.first_name LIKE '%"+search+"%' OR `U`.last_name LIKE '%"+search+"%' ) ";
		              	query +=" OR `SA`.email_id = '"+email_id+"' ";
		              	query +=" ORDER BY `"+sort+"` "+orderBy+" LIMIT "+perPage+" OFFSET "+offset+"";
		            

		            connection.query(query, function (error, results, fields) {
		              if(error){
		                return res.json({
		                    'success': false,
		                    'message': message.ERROR,
		                    'error': error
		                });
		              }
		                if(results){
		                        generalConfig.getScheduleMeetingTotalCount(req, res, company_databasename,  function(count){
	                            async.forEach(results, function (val, callback){ 
		                            val.timezone = userResult[0].timezone;
				                    val.time_difference = userResult[0].time_difference;

									callback()
								}, function(err) {

									count = (count != null)?count:0;
		                            return res.json({
		                                'success' : true,
		                                'data' : results,
		                                'draw' : draw,
		                                //'accessObj' :resp,
		                                'recordsTotal' : count,
		                                'recordsFiltered' : count,
		                                'message': message.SUCCESS
		                            });
								});

		                        });
		                }
		            });
		        });

	        } else {
	            return res.json({
	                'success' : false,
	                'data' : null,
	                'draw' : draw,                
	                'recordsTotal' : 0,
	                'recordsFiltered' : 0,
	                'message': message.ERROR
	            });
	        }
	    });
    } else {
    	return res.json({
            'success' : false,
            'data' : null,
            'draw' : draw,                
            'recordsTotal' : 0,
            'recordsFiltered' : 0,
            'message': message.ERROR
        });
    }
}

exports.removeMeeting = function(req, res, next){
	var booking_id = req.body.booking_id;
	var deleted_at = generalConfig.getDateTimeUTC();
	if(booking_id){ 
	    generalConfig.getDataBase(req, res, function(company_databasename){
		    if(company_databasename != null){ 
		    	var query = "UPDATE  "+company_databasename+".`so_space_booking` SET  `deleted_at` = '"+deleted_at+"' WHERE  `so_space_booking`.`booking_id` = '"+booking_id+"'";
		    	connection.query(query, function (error, results, fields) { 
		    		if(error){
		                return res.json({
		                    'success': false,
		                    'message': message.ERROR,
		                    'error': error
		                });
		            }

		            if(results){
		            	return res.json({
                        	'success' : true,
                        	'message': message.SCHEDULE_DELETE
                    	});
		            }

		    	});

		    } else {
		    	res.json({
					'success': false,
					'message': message.ERROR
				});
		    }
		});

	} else {
		res.json({
			'success': false,
			'message': message.ERROR
		});
	}
	
}


exports.getMeetingDetailsById = function(req, res, next){
	var booking_id = req.body.booking_id;
	if(booking_id){
		generalConfig.getDataBase(req, res, function(company_databasename){
	        if(company_databasename != null){  
	        	var query = "SELECT `SB`.booking_id as booking_id, `SB`.space_id as space_id, `SB`.user_id as user_id, `SB`.booking_title as booking_title,";
	        		query += " `SB`.booking_details as booking_details, `SB`.booking_status as booking_status, `SB`.amenities_notes as amenities_notes,";
	        		query += " `SB`.catering_notes as catering_notes, DATE_FORMAT(`SB`.start_time, '%c/%d/%Y %k:%i %p') AS start_time,";
	        		query += " DATE_FORMAT(`SB`.end_time, '%c/%d/%Y %k:%i %p') AS end_time, `SB`.booking_duration as booking_duration,";
	        		query += " `SB`.device_id as device_id, `SB`.status as status, `SB`.created_at as created_at, `SB`.deleted_at as deleted_at,";
	        		query += " CONCAT(`U`.first_name,' ',`U`.last_name) AS organizer, `S`.space_name as space_name, `BD`.building_name as building_name";
	        		query += " FROM "+company_databasename+".`so_space_booking` AS `SB` LEFT JOIN "+master_database+".so_users AS `U` ON `U`.user_id = `SB`.user_id ";
	        		query += " LEFT JOIN "+company_databasename+".so_spaces AS `S` ON `S`.space_id = `SB`.space_id ";
	        		query += " LEFT JOIN "+company_databasename+".so_floors AS `FL` ON `S`.floor_id = `FL`.floor_id ";
	        		query += " LEFT JOIN "+company_databasename+".so_buildings AS `BD` ON `BD`.building_id = `FL`.building_id ";
	        		query += " WHERE `SB`.booking_id = '"+booking_id+"'";
	        		

	        		

	        	connection.query(query, function (error, results, fields) {
	              if(error){
	                return res.json({
	                    'success': false,
	                    'message': message.ERROR,
	                    'error': error
	                });
	              }
	                if(results){
                        generalConfig.getScheduleMeetingTotalCount(req, res, company_databasename,  function(count){
                            return res.json({
                                'success' : true,
                                'data' : results[0],
                                'message': message.SUCCESS
                            });
                        });
	                }
	            });
	        } else {
	        	res.json({
					'success': false,
					'message': message.ERROR
				});
	        }
	    });
	}
}