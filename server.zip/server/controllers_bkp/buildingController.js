'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var upload = require('../config/upload');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var Sequelize = require('sequelize');
var LANG = require('../common/language');
var message = LANG.msg;
fs = require('fs-extra');

var config    = require('../config/database');
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var AuthController = require('./authController');

/**
 * @uses (getBuilding) fetch building list
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json with datatable param
*/
exports.getBuilding = function(req, res, next){

    var offset = parseInt(req.query.start);
    var perPage = parseInt(req.query.length);
    var draw = parseInt(req.query.draw);
    var search = req.query.search.value;
    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir; 
    

    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "building", "main", "sub");
    //var accessObj = generalConfig.userAccessCheck(req);

    generalConfig.getDataBase(req, res, function(company_databasename){ 
        if(company_databasename != null){

            var query = "";
            query += " SELECT `building_id`, `building_name`, `no_of_floor`, `address_1`, `address_2`, ";
            query += " `street_no`, `state`, `city`, `country`, `postal_code`, `contact_no`, `latitude`, `longitude`, ";
            query += " `notes`, `building_image`, `status`, `created_at` AS `createdAt`, `updated_at` AS `updatedAt`, ";
            query += " `deleted_at` FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`deleted_at` IS NULL ";
            query += " AND (concat(`address_1`, ' ', `address_2`, ' ', `street_no`, ' ', `city`, ' ', `state`, ' ', `country`, ' ', `postal_code`) ";
            query += " LIKE '%"+search+"%' OR `Building`.`building_name` LIKE '%"+search+"%' OR `Building`.`no_of_floor` LIKE '%"+search+"%') ";
            query += " ORDER BY `Building`.`"+sort+"` "+orderBy;
            var countQuery = query;
            query += " LIMIT "+perPage+" OFFSET "+offset+"";

            connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                    //accessObj.then(function(resp){
                        results.forEach(function(val){
                            if(val.building_image != ""){
                                var path = imagePathObj.mainLink+'/80x80/'+val.building_image;

                                if(!generalConfig.checkFilePath(path)){
                                   val.image_path = generalConfig.no_image_80;
                                   
                                }else{
                                   val.image_path = generalConfig.imageUrl(path);
                                }
                            } else {
                                val.image_path = generalConfig.no_image_80;
                            }
                        });
                        generalConfig.getBuildingTotalCount(req, res, countQuery,  function(count){
                            count = (count != null)?count:0;
                            return res.json({
                                'success' : true,
                                'data' : results,
                                'draw' : draw,
                                //'accessObj' :resp,
                                'recordsTotal' : count,
                                'recordsFiltered' : count,
                                'message': message.SUCCESS
                            });
                        });
                    // });
                }
            });


        } else {
            return res.json({
                'success' : false,
                'data' : null,
                'draw' : draw,                
                'recordsTotal' : 0,
                'recordsFiltered' : 0,
                'message': message.ERROR
            });
        }
    });
}

/**
 * @uses (addBuilding) insert new building data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.addBuilding = function(req, res, next) {
    var building_name = req.body.building_name;
    var no_of_floor = req.body.no_of_floor;
    var address_1 = req.body.address_1;
    var address_2 = req.body.address_2;
    var street_no = req.body.street_no;
    var city = req.body.city;
    var state = req.body.state;
    var postal_code = req.body.postal_code;
    var contact_no = req.body.contact_no;
    var country = req.body.country;
    var notes = req.body.notes;
    var base64Image = req.body.building_image;
    var filename = req.body.image_name;
    var status = 1; //parseInt(req.body.status);
    
    var errMsg = [];

    req.checkBody("building_name", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("no_of_floor", message.NO_FLOOR_REQUIRE).notEmpty();

    if(no_of_floor){
        req.checkBody("no_of_floor", message.NO_FLOOR_NUMERIC).isInt();
    }
    
    if(postal_code){
        req.checkBody("postal_code", message.POSTAL_CODE_NUMERIC).isInt();
    }

    var errors = req.validationErrors();

	var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {			
			errMsg[err.param] = [err.msg];
        });	
        res.json({
            'success': false,
            'message': errMsg
        });
    } else {
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){

            	var new_file_name = "";
                var createDate = generalConfig.getDateTimeUTC();
                var GUID = generalConfig.generateGUID();
                var doamin = generalConfig.getDomain(req);
                var resObj = upload.uploadImage(doamin, "building", base64Image, filename, "", "", "");

                if(resObj.success == true){
                    new_file_name = resObj.file_name;
                } else {
                    return res.json({
                        'success': resObj.success,
                        'message': resObj.message
                    });
                }

                  building_name = (building_name)? building_name:'';
                  no_of_floor   = (no_of_floor)? no_of_floor:'';
                  address_1     = (address_1)? address_1:'';
                  address_2     = (address_2)? address_2:'';
                  street_no     = (street_no)? street_no:'';
                  city          = (city)? city:'';
                  state         = (state)? state:'';
                  postal_code   = (postal_code)? postal_code:'';
                  contact_no    = (contact_no)? contact_no:'';
                  country       = (country)? country:'';
                  notes         = (notes)? notes:'';
                  status        = (status)? status:0;
                  var building_image = (new_file_name)? new_file_name:'';

                var query = "";
                query += " INSERT INTO "+company_databasename+".`so_buildings`  (`building_id`,`building_name`, `no_of_floor`, `address_1`, `address_2`, `street_no`, `city`, `state`, `postal_code`, `contact_no`, `country`, `notes`, `status`, `building_image`, `created_at`, `updated_at`) VALUES ('"+GUID+"', '"+building_name+"', '"+no_of_floor+"', '"+address_1+"', '"+address_2+"', '"+street_no+"', '"+city+"', '"+state+"', '"+postal_code+"', '"+contact_no+"', '"+country+"', '"+notes+"', '"+status+"', '"+building_image+"', '"+createDate+"', '"+createDate+"')";
            
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        return res.json({
                            'success' : true,
                            'message': message.BUILDING_ADD_SUCCESS
                        });
                    }
                });

            } else {
                 res.json({
                    'success': false,
                    'message': message.ERROR,
                });
            }
        });
    }
};

/**
 * @uses (editBuilding) fetch selected building info
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.editBuilding = function(req, res, next){
    var build_id = req.body.building_id;
    var domain = generalConfig.getDomain(req);
    var imagePathObj = generalConfig.getFilePath(domain, "building", "main", "sub");

    if(build_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){
                var query = "SELECT `address_1`, `address_2`, `building_id`, `building_image`, `building_name`, `city`, `contact_no`, `country`, `created_at` AS `createdAt`, `no_of_floor`, `notes`, `postal_code`, `state`, `street_no`,`status`, CONCAT('"+imagePathObj.mainLink+"','/','building_image') as image FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`building_id` =  '"+build_id+"'";
                connection.query(query, function (error, results, fields) { 
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    }
                    if(results.length > 0){
                        if(results[0].building_image != ""){
                            var path = imagePathObj.mainLink+'/'+results[0].building_image;
                            if(!generalConfig.checkFilePath(path)){
                               results[0].image = generalConfig.no_image_200;
                            }else{
                               results[0].image = generalConfig.imageUrl(path);
                            }
                        } else {
                            results[0].image = generalConfig.no_image_200;
                        }

                        return res.json({
                            'success' : true,
                            'data' : results[0],
                            'message': message.SUCCESS
                        });
                    } else {
                        return res.json({
                            'success' : false,
                            'data' : null,
                            'message': message.NOT_FOUND
                        });
                    }
                });

            } else {
                 return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
        
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}

/**
 * @uses (updateBuilding) updated new building data
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json
*/
exports.updateBuilding = function(req, res, next) {

    var building_id = req.body.building_id;
    var building_name = req.body.building_name;
    var no_of_floor = req.body.no_of_floor;
    var address_1 = req.body.address_1;
    var address_2 = req.body.address_2;
    var street_no = req.body.street_no;
    var city = req.body.city;
    var state = req.body.state;
    var postal_code = req.body.postal_code;
    var contact_no = req.body.contact_no;
    var country = req.body.country;
    var notes = req.body.notes;
    var status = 1; //parseInt(req.body.status);
    var base64Image = req.body.building_image;
    var filename = req.body.new_image_name;
    var old_filename = req.body.old_build_image;
    var removeImage = req.body.removeImage;
    var errMsg = [];

    req.checkBody("building_name", message.BUILDING_NAME_REQUIRE).notEmpty();
    req.checkBody("no_of_floor", message.NO_FLOOR_REQUIRE).notEmpty();
    req.checkBody("building_id", message.INVALID).notEmpty();

    if(no_of_floor){
        req.checkBody("no_of_floor", message.NO_FLOOR_NUMERIC).isInt();
    }

    if(postal_code){
        req.checkBody("postal_code", message.POSTAL_CODE_NUMERIC).isInt();
    }

    var errors = req.validationErrors();

    var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        }); 
        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else {


        generalConfig.getDataBase(req, res, function(company_databasename){  
            if(company_databasename != null){
                var findQuery = "SELECT `building_id` FROM "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.`building_id` = '"+building_id+"'";

                connection.query(findQuery, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        if(results.length > 0){
                            var new_file_name = "";
                            var updateDate = generalConfig.getDateTimeUTC();
                            var doamin = generalConfig.getDomain(req);
                            var resObj = upload.uploadImage(doamin, "building", base64Image, filename, old_filename, removeImage, "");

                            if(resObj.success == true){
                                new_file_name = resObj.file_name;
                            } else {
                                res.json({
                                    'success': resObj.success,
                                    'message': resObj.message
                                });
                                return;
                            }

                            building_name     = (building_name)?building_name:'';
                            no_of_floor       = (no_of_floor)?no_of_floor:'';
                            address_1         = (address_1)?address_1:'';
                            address_2         = (address_2)?address_2:'';
                            street_no         = (street_no)?street_no:'';
                            city              = (city)?city:'';
                            state             = (state)?state:'';
                            postal_code       = (postal_code)?postal_code:'';
                            contact_no        = (contact_no)?contact_no:'';
                            country           = (country)?country:'';
                            notes             = (notes)?notes:'';
                            status            = (status)?status:0;
                            var building_image    = (new_file_name)?new_file_name:'';

                            var query = "UPDATE "+company_databasename+".`so_buildings` AS `Building` SET `Building`.`building_name`='"+building_name+"', `Building`.`no_of_floor`='"+no_of_floor+"', `Building`.`address_1`='"+address_1+"', `Building`.`address_2`='"+address_2+"', `Building`.`street_no`='"+street_no+"',`Building`.`city`='"+city+"', `Building`.`state`='"+state+"', `Building`.`postal_code`='"+postal_code+"', `Building`.`contact_no`='"+contact_no+"', `Building`.`country`='"+country+"', `Building`.`notes`='"+notes+"', `Building`.`status`='"+status+"', `Building`.`building_image`='"+building_image+"', `Building`.`updated_at`='"+updateDate+"' WHERE `Building`.`building_id` = '"+building_id+"'";

                            connection.query(query, function (error, results, fields) {
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });
                                } else if(results){
                                    return res.json({
                                        'success' : true,
                                        'message': message.BUILDING_UPDATE_SUCCESS
                                    });
                                }
                            });

                        }
                    }
                });

            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                });
            }
        });
    }

};

/**
 * @uses (removeBuilding) remove selected building from database (soft delete)
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json autocommit: false
*/
exports.removeBuilding = function(req, res, next){
    var building_id = req.body.building_id;
    if(building_id){
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){
                var query = "SELECT  `Building`.building_name, `FLOOR`.floor_name  FROM "+company_databasename+".`so_floors` AS `FLOOR` LEFT JOIN "+company_databasename+".`so_buildings` AS `Building`ON `Building`.building_id = `FLOOR`.building_id WHERE `Building`.`building_id` = '"+building_id+"' AND `FLOOR`.`deleted_at` IS NULL";

                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });

                    } else if(results){
                        if(results.length > 0){
                            res.json({
                                'success': false,
                                'message': message.BUILDING_ASS_FLOOR
                            });
                        } else {
                            var deleteDate = generalConfig.getDateTimeUTC();
                            var query = "UPDATE "+company_databasename+".`so_buildings` AS `Building` SET `Building`.`deleted_at`='"+deleteDate+"' WHERE `Building`.`building_id` = '"+building_id+"'";
                            connection.query(query, function (error, results, fields) {
                                if(error){
                                    return res.json({
                                        'success': false,
                                        'message': message.ERROR,
                                        'error': error
                                    });

                                } else if(results){
                                    return res.json({
                                        'success' : true,
                                        'message': message.BUILDING_DELETE
                                    });
                                }
                            });
                        }
                    }
                });
            }else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                });
            }
        });

    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}

/**
 * @uses (updateBuildingSatus) update building status from database
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json autocommit: false
*/
exports.updateBuildingSatus= function(req, res, next){

    var building_id = req.body.building_id;
    var status = (req.body.status == 1)?0:1;
    var updateDate = generalConfig.getDateTimeUTC();

    if(building_id){
        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){ 
                var query = "UPDATE "+company_databasename+".`so_buildings` AS `Building` SET `Building`.`status`='"+status+"', `Building`.`updated_at`='"+updateDate+"' WHERE `Building`.`building_id` = '"+building_id+"'";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });
                    } else if(results){
                        return res.json({
                            'success' : true,
                            'message': message.STATUS_UPDATE
                        });
                    }
                });

            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });
    } else {
        res.json({
            'success': false,
            'message': message.ERROR,
        });
    }
}


/**
 * @uses (FloorCount) return No of floors a building has
 *
 * @author Rk < rakesh.rathava@softwebsolutions.com >
 *
 * @return json autocommit: false
*/
exports.FloorCount = function(req, res, next){
    var building_id = req.body.building_id;
    if(building_id){
        generalConfig.getDataBase(req, res, function(company_databasename){ 
            if(company_databasename != null){
                var query = "SELECT  `Building`.no_of_floor FROM  "+company_databasename+".`so_buildings` AS `Building` WHERE `Building`.building_id = '"+building_id+"'";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return res.json({
                            'success': false,
                            'message': message.ERROR,
                            'error': error
                        });

                    } else if(results){

                        if(results){
                            var no_floor = results[0].no_of_floor;
                            var floorArr = [];

                            if(no_floor > 0){
                                for (var i = 1; i <= no_floor; i++) {
                                   floorArr.push({"key":i, "value":i});
                                }
                            }
                        }
                        return res.json({
                            'success' : true,
                            'data' : floorArr,
                            'message': message.SUCCESS
                        });
                    }
                });
            } else {
                res.json({
                    'success': false,
                    'message': message.ERROR,
                });
            }
        });
    }
}