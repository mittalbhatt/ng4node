'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var Sequelize = require('sequelize');
var LANG = require('../common/language');
var message = LANG.msg;

//var DateTime = require('date-and-time');
var dateFormat = require('dateformat');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../config/database');
var conn = require('../config/mysql-connection');
var connection = conn.connection;


/**
 * @author AV < ashwin.vadgama@softwebsolutions.com >
 *
 * @return json
*/


exports.getSocketCheckUpcomingSpaceBooking = function(io) {
    return function(req, res, next){

        var current_datetime = new Date();
        var upcoming_datetime = new Date(current_datetime.getTime() + 60000);

        var current_utc_datetime = dateFormat(current_datetime, 'UTC:yyyy-mm-dd HH:MM:00');
        var upcoming_utc_datetime = dateFormat(upcoming_datetime, 'UTC:yyyy-mm-dd HH:MM:00');

        current_datetime = dateFormat(current_datetime, 'yyyy-mm-dd HH:MM:00');
        upcoming_datetime = dateFormat(upcoming_datetime, 'yyyy-mm-dd HH:MM:00');


        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
        //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");


        /*console.log("========================");
        console.log("current start utc time = ");
        console.log(current_utc_datetime);
        console.log("current next one minute utc time = ");
        console.log(upcoming_utc_datetime);*/

        console.log("CRON JOB FOR SOCKET UPDATE => "+current_utc_datetime+' => '+upcoming_utc_datetime);


        var MainQuery  = "";
        MainQuery += " SELECT company_id, company_domain_prefix, company_db_name ";
        MainQuery += " FROM so_company_master ";
        MainQuery += " WHERE deleted_at IS NULL ";

        connection.query(MainQuery, function (error, data, fields) {
            if(error){
                res.json({
                    'success': false,
                    'message': "Woops, Something Went Wrong.",
                    'error': error
                });
            }
            if(data){

                var CompanyLists = data;
                var totalcompany = data.length;
                var index = 0;
                var query  = " SELECT * FROM ( ";
                //var company = {"company_db_name":"smartoffice_softweb"};
                CompanyLists.forEach(function(company){
                    query += " (SELECT booking_id, space_id, start_time, end_time, ";
                    query += " IF(start_time>='"+current_utc_datetime+"' AND start_time<'"+upcoming_utc_datetime+"',1, ";
                    query += " IF(end_time>='"+current_utc_datetime+"' AND end_time<'"+upcoming_utc_datetime+"',0,2)) AS is_available ";


                    //FOR occupied status - START
                    //query += " ,0 AS is_checkin_count ";
                    query += " , (SELECT COUNT(newtbl.created_at) as is_checkin_count ";
                    query += " FROM ( ";
                    query += " SELECT  ";
                    query += " '"+company.company_db_name+"' as company_db_name,sinout.inout, sinout.user_id, sinout.sensor_id, sinout.created_at,out_sm.space_id, ";

                    query += " ( SELECT spacebooking.booking_id ";
                    query += " FROM  "+company.company_db_name+".so_space_booking  AS spacebooking ";
                    query += " WHERE spacebooking.space_id = out_sm.space_id ";
                    query += " AND spacebooking.start_time <= '"+current_utc_datetime+"'  AND  ";
                    query += " spacebooking.end_time >= '"+upcoming_utc_datetime+"' AND spacebooking.deleted_at IS NULL LIMIT 1 ";
                    query += " ) AS booking_id, ";

                    query += " ( SELECT  soutout.created_at ";
                    query += " FROM "+company.company_db_name+".so_sensor_inout AS soutout ";
                    query += " LEFT JOIN "+company.company_db_name+".so_sensor_master  AS soutout_sm ON soutout_sm.sensor_id = soutout.sensor_id ";
                    query += " WHERE soutout.inout = 0 AND sinout.user_id = soutout.user_id ";
                    query += " AND sinout.created_at <= soutout.created_at AND out_sm.space_id  = soutout_sm.space_id ";
                    query += " ORDER BY soutout.created_at  LIMIT 1 ";
                    query += " ) AS soutout ";

                    query += " FROM "+company.company_db_name+".so_sensor_inout AS sinout ";
                    query += " LEFT JOIN "+company.company_db_name+".so_sensor_master AS out_sm ON out_sm.sensor_id = sinout.sensor_id ";
                    query += " WHERE sinout.inout = 1 ";
                    query += " AND sinout.created_at > '"+previous_4hourtime+"'";
                    query += " ORDER BY sinout.created_at DESC  ) ";
                    query += " AS newtbl ";
                    query += " WHERE newtbl.soutout IS NULL ";
                    query += " AND newtbl.booking_id IS NULL AND newtbl.space_id = MainSpaceBooking.space_id ) AS is_checkin_count";
                    //FOR occupied status - END


                    query += " FROM "+company.company_db_name+".so_space_booking AS MainSpaceBooking ";
                    query += " WHERE MainSpaceBooking.deleted_at IS NULL ";
                    query += " AND ((MainSpaceBooking.start_time >= '"+current_utc_datetime+"' AND MainSpaceBooking.start_time < '"+upcoming_utc_datetime+"') ";
                    query += " OR (MainSpaceBooking.end_time >= '"+current_utc_datetime+"' AND MainSpaceBooking.end_time < '"+upcoming_utc_datetime+"')) ";
                    query += " ORDER BY MainSpaceBooking.space_id asc)";
                    index++;
                    if(index != totalcompany){
                        query += " UNION ";
                    }
                });
                query  += " ) AS tbl";

                /*console.log("====================");
                console.log(query);
                console.log("====================");*/


                connection.query(query, function (error, data, fields) {
                    if(error){
                        res.json({
                            'success': false,
                            'message': "Woops, Something Went Wrong.",
                            'error': error
                        });
                    }
                    if(data){

                        var FinalData = data;
                        FinalData.forEach(function(value){

                            if(value.is_available == 1){
                                io.sockets.emit('getNewSpaces', {
                                    type: 'available-or-not',
                                    space_id: value.space_id,
                                    available : 1
                                });
                            }

                            if(value.is_available == 0){
                                if(value.is_checkin_count > 0){
                                    io.sockets.emit('getNewSpaces', {
                                        type: 'available-or-not',
                                        space_id: value.space_id,
                                        available : 3
                                    });
                                }else{
                                    io.sockets.emit('getNewSpaces', {
                                        type: 'available-or-not',
                                        space_id: value.space_id,
                                        available : 0
                                    });
                                }
                            }
                        });

                        res.json({
                            'success' : true,
                            'data' : data,
                            'message': "success"
                        });
                    }
                });
            }
        });
    }

},


/**
 * @author AV < ashwin.vadgama@softwebsolutions.com >
 *
 * @return json
*/


exports.AutoCheckOutEntry = function(io) {
    return function(req, res, next){

        var current_datetime = new Date();
        var upcoming_datetime = new Date(current_datetime.getTime() + 60000);
        //var previous_4hourtimeDate = new Date(current_datetime.getTime() - 14400);
        var previous_4hourtimeDate = new Date(current_datetime.getTime() - 900);

        var current_utc_datetime = dateFormat(current_datetime, 'UTC:yyyy-mm-dd HH:MM:00');
        var upcoming_utc_datetime = dateFormat(upcoming_datetime, 'UTC:yyyy-mm-dd HH:MM:00');
        var previous_4hourtime = dateFormat(previous_4hourtimeDate, 'UTC:yyyy-mm-dd HH:MM:00');
        var booking_start_date = current_utc_datetime;
        var booking_end_date = current_utc_datetime;

        current_datetime = dateFormat(current_datetime, 'yyyy-mm-dd HH:MM:00');
        upcoming_datetime = dateFormat(upcoming_datetime, 'yyyy-mm-dd HH:MM:00');

        //previous_4hourtime = '2017-01-01 00:00:00';

        console.log("CRON JOB FOR AUTOCHECKOUT FOR "+current_utc_datetime);

        var MainQuery  = "";
        MainQuery += " SELECT company_id, company_domain_prefix, company_db_name ";
        MainQuery += " FROM so_company_master ";
        MainQuery += " WHERE deleted_at IS NULL ";

        connection.query(MainQuery, function (error, data, fields) {
            if(error){
                res.json({
                    'success': false,
                    'message': "Woops, Something Went Wrong.",
                    'error': error
                });
            }
            if(data){

                var CompanyLists = data;
                var totalcompany = data.length;
                var index = 0;
                var query  = " SELECT mainTable.* FROM ( ";
                CompanyLists.forEach(function(company){

                    query += " (SELECT newtbl.* ";
                    query += " FROM ( ";
                    query += " SELECT  ";
                    query += " '"+company.company_db_name+"' as company_db_name,sinout.inout, sinout.user_id, sinout.sensor_id, sinout.created_at,out_sm.space_id, ";

                    query += " ( SELECT spacebooking.booking_id ";
                    query += " FROM  "+company.company_db_name+".so_space_booking  AS spacebooking ";
                    query += " WHERE spacebooking.space_id = out_sm.space_id ";
                    query += " AND spacebooking.start_time <= '"+current_utc_datetime+"'  AND  ";
                    query += " spacebooking.end_time >= '"+current_utc_datetime+"' AND spacebooking.deleted_at IS NULL LIMIT 1 ";
                    query += " ) AS booking_id, ";

                    query += " (SELECT  config_value FROM "+company.company_db_name+".so_configuration WHERE config_title = 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY') AS autocheckout_time, ";
                    query += " (sinout.created_at + INTERVAL (SELECT  config_value FROM "+company.company_db_name+".so_configuration WHERE config_title = 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY')  MINUTE) AS autocheckout_datetime, ";

                    query += " ( SELECT  soutout.created_at ";
                    query += " FROM "+company.company_db_name+".so_sensor_inout AS soutout ";
                    query += " LEFT JOIN "+company.company_db_name+".so_sensor_master  AS soutout_sm ON soutout_sm.sensor_id = soutout.sensor_id ";
                    query += " WHERE soutout.inout = 0 AND sinout.user_id = soutout.user_id ";
                    query += " AND sinout.created_at <= soutout.created_at AND out_sm.space_id  = soutout_sm.space_id ";
                    query += " ORDER BY soutout.created_at  LIMIT 1 ";
                    query += " ) AS soutout ";

                    query += " FROM "+company.company_db_name+".so_sensor_inout AS sinout ";
                    query += " LEFT JOIN "+company.company_db_name+".so_sensor_master AS out_sm ON out_sm.sensor_id = sinout.sensor_id ";
                    query += " WHERE sinout.inout = 1 ";
                    query += " AND sinout.created_at > '"+previous_4hourtime+"'";
                    query += " ORDER BY sinout.created_at DESC  ) ";
                    query += " AS newtbl ";
                    query += " WHERE newtbl.soutout IS NULL ";
                    query += " AND newtbl.autocheckout_datetime < '"+current_utc_datetime+"' ";
                    query += " AND newtbl.booking_id IS NULL ) ";
                    index++;
                    if(index != totalcompany){
                        query += " UNION ";
                    }
                });
                query  += " ) AS mainTable";

                //console.log(query);

                connection.query(query, function (error, data, fields) {
                    if(error){
                        res.json({
                            'success': false,
                            'message': "Woops, Something Went Wrong.",
                            'error': error
                        });
                    }
                    if(data){
                        var FinalData = data;
                        FinalData.forEach(function(value){
                            var InsertAutoCheckoutQuery = "";
                            var now = new Date();
                            var currentDate = dateFormat(now, 'UTC:yyyy-mm-dd HH:MM:00');
                            InsertAutoCheckoutQuery += " INSERT INTO "+value.company_db_name+".so_sensor_inout ";
                            InsertAutoCheckoutQuery += "(id, `inout`, user_id, sensor_id, auto_checkout, created_at, updated_at) ";
                            InsertAutoCheckoutQuery += "VALUES (UUID(), '0', '"+value.user_id+"', '"+value.sensor_id+"', '1', '"+currentDate+"','"+currentDate+"'); ";
                            connection.query(InsertAutoCheckoutQuery);
                        });
                        res.json({
                            'success' : true,
                            //'data' : data,
                            'message': "success"
                        });
                    }
                });
            }
        });


        // SINGLE QUERY -- START
        /*var query = "";
        query += " SELECT newtbl.* ";
        query += " FROM ( ";
        query += " SELECT  ";
        query += " '"+company_db_name+"' as company_db_name,sinout.inout, sinout.user_id, sinout.sensor_id, sinout.created_at,out_sm.space_id, ";

        query += " ( SELECT spacebooking.booking_id ";
        query += " FROM  "+company_db_name+".so_space_booking  AS spacebooking ";
        query += " WHERE spacebooking.space_id = out_sm.space_id ";
        query += " AND spacebooking.start_time <= '"+current_utc_datetime+"'  AND  ";
        query += " spacebooking.end_time >= '"+current_utc_datetime+"' AND spacebooking.deleted_at IS NULL LIMIT 1 ";
        query += " ) AS booking_id, ";

        query += " (SELECT  config_value FROM "+company_db_name+".so_configuration WHERE config_title = 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY') AS autocheckout_time, ";
        query += " (sinout.created_at + INTERVAL (SELECT  config_value FROM "+company_db_name+".so_configuration WHERE config_title = 'ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY')  MINUTE) AS autocheckout_datetime, ";

        query += " ( SELECT  soutout.created_at ";
        query += " FROM "+company_db_name+".so_sensor_inout AS soutout ";
        query += " LEFT JOIN "+company_db_name+".so_sensor_master  AS soutout_sm ON soutout_sm.sensor_id = soutout.sensor_id ";
        query += " WHERE soutout.inout = 0 AND sinout.user_id = soutout.user_id ";
        query += " AND sinout.created_at <= soutout.created_at AND out_sm.space_id  = soutout_sm.space_id ";
        query += " ORDER BY soutout.created_at  LIMIT 1 ";
        query += " ) AS soutout ";

        query += " FROM "+company_db_name+".so_sensor_inout AS sinout ";
        query += " LEFT JOIN "+company_db_name+".so_sensor_master AS out_sm ON out_sm.sensor_id = sinout.sensor_id ";
        query += " WHERE sinout.inout = 1 ";
        query += " AND sinout.created_at > '"+previous_4hourtime+"'";
        query += " ORDER BY sinout.created_at DESC  ) ";
        query += " AS newtbl ";
        query += " WHERE newtbl.soutout IS NULL ";
        query += " AND newtbl.autocheckout_datetime < '"+current_utc_datetime+"' ";
        query += " AND newtbl.booking_id IS NULL ";

        console.log("========================");
        console.log(query);
        console.log("========================");*/
        // SINGLE QUERY -- END

    }

}