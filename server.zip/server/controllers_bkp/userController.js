'use strict';

var Sequelize = require('sequelize');
var sequlizeConfig = require('../config/sequelize');
var generalConfig = require('../config/generalConfig');
var LANG = require('../common/language');
var upload = require('../config/upload');
var message = LANG.msg;
var search;
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var async = require('async');
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var database = require('../config/database');
var master_database = database.master_database.name;
var crypto      = require('crypto');


module.exports.userList = function(req, res){

    var orderId = req.query.order[0].column;
    var sort = req.query.columns[orderId].name;
    var orderBy = req.query.order[0].dir;
    var draw = parseInt(req.query.draw); 
    
    if(!(JSON.stringify(req.query.search))){
        search = 'undefined';
    }
    else {
        search = JSON.parse(JSON.stringify(req.query.search.value));
    }

    var roleAllowed = generalConfig.getRoleFromDomain(req);
    if(roleAllowed == 1)  {
        var role = ['CompanyAdmin', 'SubAdmin', 'Member'];

    }
    else if(roleAllowed == 0) {
        var role = ['MasterAdmin', 'Admin'];
    }

    var domain = generalConfig.getDomain(req);
    var domainUsers = [];

    // get company id ( domain id )
    var qGetCompanyId = "SELECT company_id FROM `"+master_database+"`.`so_company_master` WHERE `company_domain_prefix` = '"+domain+"'";
    connection.query(qGetCompanyId, function (error, results, fields)
    {
        if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
        else if(results)
        {              
            var qDomainUsers = "SELECT user_id FROM `"+master_database+"`.`so_company_users_map` WHERE `company_id` = '"+results[0]['company_id']+"'";
            connection.query(qDomainUsers, function (error, qrDomainUser, fields)
            {
                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                else if(qrDomainUser)
                {               
                    async.forEach(qrDomainUser, function(v,i)
                    {                        
                        domainUsers.push(v['user_id']);
                    });

                    if(generalConfig.masterDoamin == domain){
                        var imagePathObj = generalConfig.getFilePath(domain, "master", "main", "sub");
                    } else {
                        var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
                    }

                    master_db.models.User.findAndCountAll({
                        where : {
                           $or: [   {first_name: {$like: '%' + search + '%'}},        
                                    {last_name: {$like: '%' + search + '%'}}, 
                                    {email: {$like: '%' + search + '%'}},
                                    {phone_number: {$like: '%' + search + '%'}}
                                ],
                            deleted_at: { $eq: null }
                            
                        },
                        offset : parseInt(req.query.start),
                        limit : parseInt(req.query.length),
                        order: [[sort, orderBy]],

                        include: [
                        {
                            model: master_db.models.companyUser,
                            where: { deleted_at: { $eq: null }, user_type: { $in: role}, user_id : {$in: domainUsers } },

                        }],

                    }).then(function(users) {
                        if (!users) 
                            return next(new Error('Failed to load Genre ' + id));

                        if(users){
                            async.forEach(users.rows, function (val, callback){ 
                                if(val.profile_picture != ""){
                                    var path = imagePathObj.mainLink+'/'+val.profile_picture;

                                    if(!generalConfig.checkFilePath(path)){
                                       val.dataValues.image_path = generalConfig.no_image_80;
                                    }else{
                                       val.dataValues.image_path = generalConfig.imageUrl(path);
                                    }
                                } else {
                                    val.dataValues.image_path = generalConfig.no_image_80;
                                }
                                callback()
                            }, function(err) {
                                
                                res.json({error:false,data:users.rows,recordsTotal:users.count,  'draw' : draw, recordsFiltered:users.count,msg:null});
                            });
                        }

                    }).catch(function(err){
                        
                    })


                }


            });
        }
    });
};


/**
 * Add User
*/

module.exports.insert = function(req, res, next) { 
    var first_name = req.body.user.first_name;
    var last_name = req.body.user.last_name;
    var email = req.body.user.email;
    var phone_number = req.body.user.phone_number;
    var user_type = req.body.user.user_type;
    var status = req.body.user.status;
    var building_id = req.body.company.building_id;
    var floor_id = req.body.company.floor_id;
    var base64Image = req.body.user.profile_image;
    var filename = req.body.user.image_name;
    var originalPassword = req.body.user.password;
    req.body.user.password = generalConfig.encryptPassword(req.body.user.password);
    var timezone = req.body.user.timezone;
    req.body.user.created_at = generalConfig.getDateTimeUTC();

    var errMsg = [];
    req.checkBody("user.first_name", "message.FIRST_NAME_REQUIRED").notEmpty();
    req.checkBody("user.last_name", "message.LAST_NAME_REQUIRED").notEmpty();
    req.checkBody("user.email", "message.EMAIL_REQUIRED").notEmpty();
    req.checkBody("user.phone_number", "message.PHONE_REQUIRED").notEmpty();
    
    var errors = req.validationErrors();
    if (errors) {
        errors.forEach(function(err) {
          errMsg.push(err.msg);
        });

        res.json({
            'success' : false,
            'message': errMsg
        });

    } else {

        var new_file_name = "";
        var domain = generalConfig.getDomain(req);
      
        if(generalConfig.masterDoamin == domain){
            var resObj = upload.uploadImage(domain, "master", base64Image, filename, "", "", "", "");
        } else {
            var resObj = upload.uploadImage(domain, "user", base64Image, filename, "", "", "", "");
        }

        if(resObj.success == true){
            new_file_name = resObj.file_name;

        } else {
            res.json({
                'success': resObj.success,
                'message': resObj.message
            });
            return;
        }


        master_db.models.User.find({where :
        {   email : req.body.user.email ,
            deleted_at: { $eq: null }

        },
        }).then(function(users){

            if(!users) {

                var users = master_db.models.User.build(req.body.user);
                var company = master_db.models.companyUser.build(req.body.company);
                users.profile_picture = new_file_name;
                users.save().then(function(user){
                    company.user_id = user.user_id;
                    company.user_type = req.body.user.user_type;
                    var domain = generalConfig.getDomain(req);

                    master_db.models.companyMaster.find({
                        where: { company_domain_prefix: domain},
                    }).then(function(master) {

                        if(master) {

                            company.company_domain_prefix = master.company_domain_prefix;
                            company.company_id = master.company_id;

                            company.save().then(function(){


                            var replacements = {
                                
                                url:company.company_domain_prefix+".softwebsmartoffice.com",
                                username:req.body.user.email,
                                password: originalPassword,
                                companyName: master.company_name,
                            
                            };


                            var to = req.body.user.email;
                            var subject = "You are added in "+master.company_name;

                            generalConfig.sendMail('addUserTemplate.html',replacements,to,subject);

                            res.json({
                                success:true,
                                data:null,
                                message:message.USER_ADDED
                            });
                            }).catch(function(err){

                                
                                res.json({
                                    success:false,
                                    message:message.ERROR
                                });
                            });
                        }

                        else {

                        company.company_domain_prefix = '';
                        company.company_id = '';

                        company.save().then(function(){
                        res.json({
                            success:true,
                            data:null,
                            message:message.USER_ADDED
                        });
                        }).catch(function(err){
                            res.json({
                                success:false,
                                message:message.ERROR
                            });
                        });
                        }

                    })                 
                }).catch(function(err){
                    res.json({
                        success:false,
                        message: message.ERROR
                    });
                });
            }

            else {
                res.json({
                success:false,
                message: 'This Email Address Already Exists'
            });

        }
        
    }).catch(function(err){

        console.log('+++++++++++++++++');
        
        console.log(err);
        console.log('+++++++++++++++++');
        res.json({
            success:false,
            message: message.ERROR
            });
        });

        }
};

/**
 * Get User By Id
*/

exports.getDomainReq = function(req,res,next){
    
    if(req && req.headers['x-forwarded-host']){
        var subdomain = req.headers['x-forwarded-host'];
        if(subdomain){

            var domain = generalConfig.getDomain(req);
            var query = "SELECT company_name, company_logo FROM `"+master_db.config.database+"`.`so_company_master` WHERE `company_domain_prefix` = '"+domain+"'";
            connection.query(query, function (error, results, fields)
            {
                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                else if(results)
                {       
                    if(results!='')
                    {
                        var subDomainObj = subdomain.toString().split(".");

                        var imgPathObj = generalConfig.getFilePath(domain, "company", "main", "sub");  
                        var makeImagePath = imgPathObj.mainLink+'/'+results[0]['company_logo'];                
                        if(!generalConfig.checkFilePath(makeImagePath))
                        {
                           results[0]['company_logo'] = "";
                        }
                        else
                        {
                           results[0]['company_logo'] = generalConfig.imageUrl(makeImagePath);
                        }

                         return res.json({
                            success: true,
                            data : subDomainObj[0],
                            domainInfo : results[0]
                        });                        
                    }                                       
                }
            });
        }
    }
}

/**
 * Send toke through email for Reset Password (KT) 
*/
exports.forgotPassword = function(req,res,next) {

    var email = req.body.email;
    var domain = generalConfig.getDomain(req);
    var fromDomainName = req.protocol + "://" + req.headers.host;
    var imagePathObj = generalConfig.getFilePath(domain, "company", "main", "sub");

    generalConfig.getDataBase(req, res, function(company_databasename)
    {
       if(company_databasename != null)
       {            
            var qEmail = "SELECT * FROM `"+master_database+"`.`so_users` WHERE `email` = '"+email+"'";
            connection.query(qEmail, function (error, qrEmail, fields)
            {
                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                else if(qrEmail && qrEmail!='')
                {                    
                    var randomString = new Date().getTime()+email;
                    var forgotToken = crypto.createHash('md5').update(randomString).digest('hex');
                    var qUpdateForgotToken = "UPDATE `"+master_database+"`.`so_users` SET `forgotToken` = '"+forgotToken+"', `updated_at` = '"+generalConfig.getDateTimeUTC()+"' WHERE `email` = '"+email+"'";
                    connection.query(qUpdateForgotToken, function (error, qrUpdateForgotToken, fields)
                    {
                        if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                        else if(qrUpdateForgotToken)
                        {   
                            generalConfig.getCompanyFromDomain(domain, function (companyInfo) {
                                var companyName = companyInfo.company_name;
                                var companyLogoPath = "";
                                if(companyInfo.company_logo)
                                {
                                    var path = imagePathObj.mainLink+'/'+companyInfo.company_logo;
                                    if(generalConfig.checkFilePath(path))
                                    {                                       
                                       companyLogoPath = fromDomainName + '/' + generalConfig.imageUrl(path);
                                    }                                                                        
                                }                                
                                var replacements = {
                                    companyName : companyName,
                                    companyLogo : companyLogoPath,
                                    username : qrEmail[0]['first_name'] + ' ' + qrEmail[0]['last_name'],
                                    link : fromDomainName+'/reset/password/'+forgotToken,
                                };                                
                                var to = email;
                                var subject = "Forgot Password Link"                                                                
                                generalConfig.sendMail('resetPasswordTemplate.html',replacements,to,subject);
                                
                                return res.json({
                                    success: true,                                    
                                    message: message.RESET_LINK_SENT
                                });
                            })
                        }
                    });
                }
                else
                {
                    return res.json({
                        'success': false,
                        'message': message.OOPS_WRONG_PLANET
                    });
                }
            });
        }
        else
        {
            return res.json({
                'success': false,
                'message': message.ERROR
            });
        }
    });
}

/**
 * Update Password (KT) 
*/
module.exports.updatePassword= function(req, res, next){  
    
    var newPassword = req.body.newPassword;    
    req.body.newPassword = generalConfig.encryptPassword(req.body.newPassword);

    var errMsg = [];
    req.checkBody("newPassword", "New Password is required").notEmpty();    
    var errors = req.validationErrors();
    if (errors)
    {
        errors.forEach(function(err) {
            errMsg.push(err.msg);
        });
        res.json({
            'success': false,
            'message': errMsg
        });
    }
    else
    {
        var findTokenEmail = "SELECT * FROM `"+master_database+"`.`so_users` WHERE `forgotToken` = '"+req.body.forgotToken+"'";
        connection.query(findTokenEmail, function (error, qrFindTokenEmail, fields)
        {
            if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
            else if(qrFindTokenEmail && qrFindTokenEmail!='')
            {   
                var qUpdatePassword = "UPDATE `"+master_database+"`.`so_users` SET `password` = '"+req.body.newPassword+"', `forgotToken`='', `updated_at` = '"+generalConfig.getDateTimeUTC()+"' WHERE `user_id` = '"+qrFindTokenEmail[0]['user_id']+"'";
                connection.query(qUpdatePassword, function (error, qrUpdatePassword, fields)
                {
                    if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                    else if(qrUpdatePassword)
                    {   
                        return res.json({
                            'success': true,
                            'message': message.NEW_PASSWORD_UPDATED
                        });
                    }
                });                
            }
            else
            {
                return res.json({
                    'success': false,
                    'message': message.OOPS_WRONG_PLANET
                });
            }
        });        
    }
}

exports.getCompanyFromDomain = function(req, res, next) {

  
    var companyDomainPrefix = req.params.domain;

    master_db.models.companyMaster.findOne(
  
    {
        where: {
            company_domain_prefix: req.params.domain
        }
    }).then(function (data) {
      
        res.json({
            success: true,
            data: data,
            message: message.USER_UPDATED
        });
    }).catch(function (err) {
        console.log(err);
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });






}

exports.getCompanyInfo = function(req,res,next){

    master_db.models.companyUser.find({where: {user_id : req.params.id}}).then(function(companyUser)
    {
        res.json({error:false,data:{company:companyUser},msg:null});
    }).catch(function(err){
        res.json({error:true,data:null,msg:"Something went wrong! Please try again"});
    });

  
}

exports.getUserById = function(req, res, next) {
    var domain = generalConfig.getDomain(req);

    if(generalConfig.masterDoamin == domain){
        var imagePathObj = generalConfig.getFilePath(domain, "master", "main", "sub");
    } else {
        var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
    }

    master_db.models.User.find({where : { user_id : req.params.id }}).then(function(users){
    master_db.models.companyUser.find({where: {user_id : users.user_id}}).then(function(company)
    
    {
        if(!users){
            return next(new Error('Failed to load Composer ' + id));
        } 

        if(users.profile_picture != ""){
            var path = imagePathObj.mainLink+'/'+users.profile_picture;
            if(!generalConfig.checkFilePath(path)){
               users.dataValues.image_path = generalConfig.no_image_200;
            }else{
               users.dataValues.image_path = generalConfig.imageUrl(path);
            }
        } else {
            users.dataValues.image_path = generalConfig.no_image_200;
        }

        res.json({error:false,data:{users:users,company:company},msg:null});
    }).catch(function(err){
        res.json({error:true,data:null,msg:"Something went wrong! Please try again"});
    });

    })
};

/**
 * Update User
*/

module.exports.update = function(req, res, next) {

    var first_name = req.body.user.first_name;
    var last_name = req.body.user.last_name;
    var email = req.body.user.email;
    var phone_number = req.body.user.phone_number;
    var user_type = req.body.user.user_type;
    var status = req.body.user.status;
    var building_id = req.body.company.building_id;
    var floor_id = req.body.company.floor_id;
    var base64Image = req.body.user.profile_image;
    var old_filename = req.body.user.old_profile_picture;
    var removeImage = req.body.user.removeImage;
    var filename = req.body.user.image_name;
    var timezone = req.body.user.timezone;
 
    var errMsg = [];
    req.checkBody("user.first_name", "First Name is required").notEmpty();
    req.checkBody("user.last_name", "Last Name is required").notEmpty();
    req.checkBody("user.email", "Email is required").notEmpty();
    req.checkBody("user.phone_number", "Phone Number is required").notEmpty();
    
    if(req.body.user.password == '') {

        delete req.body.user['password'];
    }
    else {
        req.body.user.password = generalConfig.encryptPassword(req.body.user.password);
    }

    var errors = req.validationErrors();
    
    if (errors) {
        errors.forEach(function(err) {
          errMsg.push(err.msg);
        });
        res.json({
            'success' : false,
            'message': errMsg
        });

    } else {

        var new_file_name = "";
    
        var domain = generalConfig.getDomain(req);
        
        if(generalConfig.masterDoamin == domain){
            var resObj = upload.uploadImage(domain, "master", base64Image, filename, old_filename, removeImage, "", "");
        } else {
            var resObj = upload.uploadImage(domain, "user", base64Image, filename, old_filename, removeImage, "", "");
        }


        if(resObj.success == true){
            new_file_name = resObj.file_name;
        } else {
            return res.json({
                'success': resObj.success,
                'message': resObj.message
            });
        }


        master_db.models.User.find(
            {where : { email : req.body.user.email, user_id:{ $ne: req.body.user.user_id }}}).then(function(users){
                
            if(!users) {
            req.body.user.updated_at = generalConfig.getDateTimeUTC();
                req.body.user.profile_picture = new_file_name;
                req.body.company.user_type = req.body.user.user_type;
                master_db.models.User.update(req.body.user,{ where : {user_id : req.body.user.user_id }}).then(function(user){
                master_db.models.companyUser.update(req.body.company, { where : {user_id : req.body.user.user_id}}).then(function(company)
                {
                    res.json({
                        success:true,
                        data:user,
                        message: message.USER_UPDATED
                    });

                 }).catch(function(err){
                    res.json({
                        success:false,
                        message:message.ERROR
                    });
                });

                }).catch(function(err){
                    res.json({
                        success:false,
                        message: message.ERROR
                    });
                });
            }

            else {
                res.json({
                success: false,
                message: message.EMAIL_EXISTS //'This Email Address Already Exists'
            });

        }
    });


        
            
    }

};

module.exports.delete = function (req, res,next) {
    var obj = {
        deleted_at: generalConfig.getDateTimeUTC(),
    };
    master_db.models.User.update(obj, {
        where: { user_id: req.params.id }
    }).then(function () {

       res.json({
                success: true,
                data: null,
                message: message.USER_DELETED
            });

    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

};

module.exports.updateStatus = function (req, res,next) {
    if(req.body.status == '1') {
       var status = 0;
    }
    else {
        var status = 1;
    }

    master_db.models.User.update(
    {
        status:status,
        updated_at:generalConfig.getDateTimeUTC(),
    },
    {
        where: {
            user_id: req.body.user_id
        }
    }).then(function (data) {
        res.json({
            success: true,
            data: data,
            message: message.USER_UPDATED
        });
    }).catch(function (err) {
        res.json({
            success: false,
            data: null,
            message: message.ERROR
        });
    });

};

/**
 * Change current user password (RK)
*/
module.exports.changePassword = function(req, res, next) {   
        
    var current_password = req.body.current_password;
    var confirm_password = req.body.confirm_password;
    var password = req.body.password;

    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;

    if(password != confirm_password) {

        res.json({
            "success": false,            
            "message": "Invalid Confirm password"
        });
    }

    req.checkBody("current_password", message.CURRENT_PASSWORD_REQUIRED).notEmpty();
    req.checkBody("confirm_password", message.CONFIRM_PASSWORD_REQUIRED).notEmpty();
    req.checkBody("password", message.PASSWORD_REQUIRED).notEmpty();
    
    
    var errors = req.validationErrors();

    var errMsg = {};

    if (errors) {
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        }); 
        res.json({
            'success': false,
            'message': errMsg
        });

    } else {
        
        master_db.models.User.findOne({
            where: { user_id: user.user_id }
        }).then(function(userObj) {
            
            if(userObj){

                if(generalConfig.authenticate(current_password,userObj.dataValues.password)){

                    var encryptedPassWord = generalConfig.encryptPassword(password);
                    
                    if(userObj.update({ password : encryptedPassWord})){
                        res.json({
                            "success": true,
                            "message": "Password updated success"
                        });
                    }

                } else {
                    res.json({
                        "success": false,
                        "message": "Password dose not exists"
                    });
                }
            }
        })
        .catch(function(err) {
            res.json({
                "success": false,
                "err": err,
                "message": message.ERROR
            });
        });
    }

};


/**
 * Get Logged in user whole data for profile update  (RK)
*/
module.exports.getCurrentUserInfo = function(req, res, next) {
    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;
    var domain = generalConfig.getDomain(req);
    //(domain, type, mainLink, subLink, http path)
    var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
    
    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){ 
            var query = "";
            query += " SELECT `User`.`user_id`, `User`.`first_name`, `User`.`last_name`, ";
            query += " `User`.`email`, `User`.`phone_number`, `User`.`time_difference` as `timezone`, `User`.`profile_picture`, ";
            query += " CONCAT('"+imagePathObj.mainLink+"/', `profile_picture`) AS `image`, `User`.`status`, ";
            query += " `companyUser`.`company_user_id` AS `company_user_id`, `companyUser`.`building_id` AS `building_id`, ";
            query += " `companyUser`.`floor_id` AS `floor_id` FROM `"+master_database+"`.`so_users` AS `User` ";
            query += " LEFT OUTER JOIN `"+master_database+"`.`so_company_users_map` AS `companyUser` ON `User`.`user_id` = `companyUser`.`user_id` ";
            query += " WHERE `User`.`user_id` = '"+user.user_id+"'";

            connection.query(query, function (error, results, fields) {
                if(error){
                    return res.json({
                        'success': false,
                        'message': message.ERROR,
                        'error': error
                    });
                }

                if(results){

                    if(results[0].profile_picture != ""){
                        var path = imagePathObj.mainLink+'/'+results[0].profile_picture;
                        if(!generalConfig.checkFilePath(path)){
                           results[0].image = generalConfig.no_image_200;
                        }else{
                           results[0].image = generalConfig.imageUrl(path);
                        }
                    } else {
                        results[0].image = generalConfig.no_image_200;
                    }

                  res.json({
                        'success' : true,
                        'data' : results[0],
                        'message': message.SUCCESS
                    });  
                }
            });
        } else {
            return res.json({
                'success': false,
                'message': message.ERROR
            }); 
        }
    });
}



module.exports.getCompanyConfiguration = function(req, res, next) {

    var userObj = generalConfig.getUserInfo(req);
    var user = userObj.data;
    var domain = generalConfig.getDomain(req);
    //(domain, type, mainLink, subLink, http path)
    var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
    
    generalConfig.getDataBase(req, res, function(company_databasename){
        if(company_databasename != null){ 
        var query = "SELECT *  FROM "+company_databasename+".so_configuration";


        connection.query(query, function (error, results, fields) {
              if(error){
                return res.json({
                    'success': false,
                    'message': message.ERROR,
                    'error': error
                });
              }
                if(results){
                    res.json({
                        'success': true,
                        'data': results,
                        'message': message.SUCCESS
                    });
                }
            });
        } else {
            return res.json({
                'success': false,
                'message': message.ERROR
            }); 
        }
    });

}


/**
 * Update Current User Profile Data (RK) 
*/
module.exports.updateProfile= function(req, res, next) {  

    var first_name = req.body.first_name;
    var last_name = req.body.last_name;
    var phone_number = req.body.phone_number;
    var timezone = req.body.time_zone;
    var timezoneDiff = req.body.time_difference;

    var floor_id = req.body.floor_id;
    var building_id = req.body.building_id;
    
    var base64Image = req.body.profile_picture;
    var filename = req.body.profile_picture_name;
    var old_filename = req.body.old_profile_image;
    
    var removeImage = req.body.removeImage;

    var email = req.body.email;

    
    var errMsg = [];

    req.checkBody("first_name", "message.FIRST_NAME_REQUIRED").notEmpty();
    req.checkBody("last_name", "message.LAST_NAME_REQUIRED").notEmpty();
    req.checkBody("email", "message.EMAIL_REQUIRED").notEmpty();
    req.checkBody("phone_number", "message.PHONE_REQUIRED").notEmpty();
    req.checkBody("time_zone", "message.TIMEZONE_REQUIRED").notEmpty();

    var errors = req.validationErrors();

    if(generalConfig.formattedEmail(email) != null){
        email = generalConfig.formattedEmail(email);
    } else {

        res.json({
            'success': false,
            'message': message.INVAID_EMAIL
        });
        return;
    }

    var errMsg = {};
    if (errors) {
        errors.forEach(function (err) {         
            errMsg[err.param] = [err.msg];
        }); 
        res.json({
            'success': false,
            'message': errMsg
        });
        
    } else {

        var userObj = generalConfig.getUserInfo(req);
        var user = userObj.data;


        var new_file_name = "";
        var updateDate = generalConfig.getDateTimeUTC();
        var doamin = generalConfig.getDomain(req);
        //param (doamin, base64Image, filename, old_filename, removeImage, doc/image);
        var resObj = upload.uploadImage(doamin, "user", base64Image, filename, old_filename, removeImage, "");

        if(resObj.success == true){
            
            new_file_name = resObj.file_name;

        } else {
            res.json({
                'success': resObj.success,
                'message': resObj.message
            });
            return;
        }

        var userObj = {
            first_name:first_name,
            last_name:last_name,
            phone_number:phone_number,
            email:email,
            profile_picture:new_file_name,
            timezone:timezone,
            time_difference:timezoneDiff
        };

        var domain = generalConfig.getDomain(req);

        if(generalConfig.masterDoamin == domain){
            var imagePathObj = generalConfig.getFilePath(domain, "master", "main", "sub");
        } else {
            var imagePathObj = generalConfig.getFilePath(domain, "user", "main", "sub");
        }


        generalConfig.getDataBase(req, res, function(company_databasename){
            if(company_databasename != null){ 

                    var query = "UPDATE `"+master_database+"`.`so_users` SET `first_name`='"+first_name+"', `last_name`='"+last_name+"', `phone_number`='"+phone_number+"', `email`='"+email+"', `profile_picture`='"+new_file_name+"', `timezone`='"+timezone+"', `time_difference`='"+timezoneDiff+"', `updated_at`='"+updateDate+"' WHERE `user_id` = '"+user.user_id+"'";

                    connection.query(query, function (error, results, fields) {
                        if(error){
                            return res.json({
                                'success': false,
                                'message': message.ERROR,
                                'error': error
                            });
                        }

                        if(results){
                            
                            var userQuery = "SELECT * FROM `"+master_database+"`.`so_users`  WHERE `user_id` = '"+user.user_id+"'";
                            connection.query(userQuery, function (error, user_result, fields) { 

                                if(user_result[0].profile_picture != ""){
                                    var path = imagePathObj.mainLink+'/'+user_result[0].profile_picture;
                                    if(!generalConfig.checkFilePath(path)){
                                       user_result[0].image = generalConfig.no_image_200;
                                    }else{
                                       user_result[0].image = generalConfig.imageUrl(path);
                                    }
                                } else {
                                    user_result[0].image = generalConfig.no_image_200;
                                }

                                user_result[0].password = "";
                                var update = "UPDATE `"+master_database+"`.`so_company_users_map` SET `floor_id`='"+floor_id+"', `building_id`='"+building_id+"',`updated_at`='2017-07-31 14:34:07' WHERE `user_id` = '"+user.user_id+"'"; 
                                connection.query(update, function (error, update, fields) { 
                                    if(error){
                                        return res.json({
                                            'success': false,
                                            'message': message.ERROR,
                                            'error': error
                                        });
                                    }

                                    if(update){
                                        res.json({
                                            success: true,
                                            data:user_result[0],
                                            message: message.USER_UPDATED
                                        });
                                    }
                               });
                            });
                        }
                });
            } else {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                }); 
            }
        });

        // master_db.models.User.update(userObj,
        //     { where: { user_id: user.user_id } })

        // .then(function (resObj) {
        //     if(resObj[0] == 1){
        //         var companyObj = { floor_id:floor_id, building_id:building_id }
        //         master_db.models.companyUser.update(companyObj, { where : {user_id : user.user_id}}).then(function (result){
        //             if(result[0] == 1){
        //                 res.json({
        //                     success: true,
        //                     message: message.USER_UPDATED
        //                 });
        //             }
        //         }); 
        //     }
        // }).catch(function (err) {
        //     res.json({
        //         success: false,
        //         data: null,
        //         message: message.ERROR
        //     });
        // });

    }
}

    /**
     * @uses remove company logo image
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return json
    */
    
    exports.removeProfileLogo = function(req, res, next)
    {   
        var userObj = generalConfig.getUserInfo(req);
        var user = userObj.data;        
        var domain = generalConfig.getDomain(req);
        var master_database = database.master_database.name;
        var structureObj = (generalConfig.uploadpath["user"])?generalConfig.uploadpath["user"]:generalConfig.uploadpath["default"];
        var basePath = generalConfig.uploadBasePath;    
        var uploadFolder = structureObj.folder;
        var subFolder = structureObj.size_folder;

        // company database
        generalConfig.getDataBase(req, res, function(company_databasename)
        {
           if(company_databasename != null)
           {            
                var query = "SELECT profile_picture FROM `"+master_database+"`.`so_users` WHERE `user_id` = '"+user.user_id+"'";
                connection.query(query, function (error, results, fields)
                {
                    if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                    else if(results)
                    {      
                        if(results!='')         
                        {
                            upload.remvoeUploadedFile(domain, uploadFolder, subFolder, basePath, results[0]['profile_picture']);
                            var queryForNull = "UPDATE `"+master_database+"`.`so_users` SET `profile_picture` = NULL WHERE `user_id` = '"+user.user_id+"'";
                            connection.query(queryForNull, function (error, results, fields)
                            {
                                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                                else if(results)
                                {
                                    return res.json({
                                        'success' : true,                               
                                        'message' : message.REMOVE_PROFILE_IMAGE_SUCCESS,
                                        'profile_picture' : generalConfig.no_image_200
                                    });                         
                                }                       
                            });                            
                        }
                    }
                });
            }
            else
            {
                return res.json({
                    'success': false,
                    'message': message.ERROR
                });
            }
        });
    }
