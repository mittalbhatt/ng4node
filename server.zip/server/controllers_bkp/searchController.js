'use strict';

var fs = require("fs");
var generalConfig = require('../config/generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var LANG = require('../common/language');
var message = LANG.msg;
var conn = require('../config/mysql-connection');
var connection = conn.connection;
var database = require('../config/database');
var master_database = database.master_database.name;
var async = require('async');
var dateFormat = require('dateformat');
var difference = require('array-difference');
var smtpTransport = generalConfig.smtpTransport;
var handlebars = require('handlebars');
var database = require('../config/database');
var master_database = database.master_database.name;
var moment = require('moment-timezone');
var dbDateTimeFormat = 'YYYY-MM-DD HH:mm:00';




/**
 * @uses Space listing for search data
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */
exports.getSearchSpacesList = function (req, res, next) {

	let currentUTCDatetime = moment.utc().format(dbDateTimeFormat);
	let flag = req.query.flag;
    let offset = parseInt(req.query.start);
    let perPage = parseInt(req.query.length);
    let draw = parseInt(req.query.draw);
    let search = req.query.search.value;
    let orderId = req.query.order[0].column;
    let sort = req.query.columns[orderId].name;
    let orderBy = req.query.order[0].dir;
    let dateTime = req.query.dt;
	if (dateTime != undefined) {
		let TimeUTC = generalConfig.getDateTimeUTC(dateTime);
    }
	let userObj = generalConfig.getUserInfo(req);
    let user = userObj.data;

	let timezone = '';
	let timeDiffOffset = '';
	if (userObj) {
		timezone = userObj.data.timezone;
		timeDiffOffset = userObj.data.time_difference;
	}

	let domain = generalConfig.getDomain(req);
    //(domain, type, mainLink, subLink, http path)
    let imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");
    let imageSpacePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
    let accessObj = generalConfig.userAccessCheck(req);


	var currentDateTime = moment().tz(timezone).format(dbDateTimeFormat);

	let event_date = (req.query.event_date) ? req.query.event_date : moment(currentDateTime).format('MM/DD/YYYY');
	let start_time = (req.query.start_time) ? req.query.start_time : moment(currentDateTime).format('LT');
	let hours = (req.query.hours) ? req.query.hours : 0;
	let minutes = (req.query.minutes) ? req.query.minutes : 0;
	if(hours==0 && minutes==0){
		minutes = 15;
	}
	
	let requestStartDateTime = moment(event_date + ' ' + start_time)
		.format(dbDateTimeFormat);
	let requestEndDateTime = moment(event_date + ' ' + start_time)
		.add(minutes, 'minutes')
		.add(hours, 'hours')
		.format(dbDateTimeFormat);

	// Request search data
	let building_id = (flag == 1) ? req.query.building_id : '';
	let floor_id = (flag == 1) ? req.query.floor_id : '';
	let space_type_id = (flag == 1) ? req.query.space_type_id : '';
	let space_capacity = (flag == 1) ? req.query.capacity : '';
	let amenities = (flag == 1) ? JSON.parse(req.query.amenities) : '';
		if(amenities) {
			var amenitiesString = "'" + amenities.join("','") + "'";
		}
	
	if (user && user.user_id) {

		let utcStartDateTime = '';
		utcStartDateTime = generalConfig.getUTCDateTime(event_date + ' ' + start_time, timeDiffOffset, timezone);
		let utcEndDateTime = '';
		for (let hIndex = 1; hIndex <= 3; hIndex++) {
			utcEndDateTime = moment(utcStartDateTime)
				.add(minutes * hIndex, 'minutes')
				.add(hours * hIndex, 'hours')
				.format(dbDateTimeFormat);
		}

		generalConfig.getDataBase(req, res, function (company_databasename) {
			if (company_databasename != null) {

				let query = "SELECT  `SPACE`.*, "
				query += "(SELECT group_concat(concat(`A`.amenity_name,':',`A`.amenity_image) separator ',') FROM " + company_databasename + ".`so_space_amenities` AS `SA` ";
				query += " LEFT JOIN " + company_databasename + ".`so_amenities` AS `A` ON `SA`.amenity_id = `A`.amenity_id WHERE `SA`.space_id = `SPACE`.space_id group by `SA`.space_id) as space_amenities";
				query += " FROM ( SELECT `Space`.`space_id`, `Space`.`space_name`,  `Space`.`floor_id`, `Space`.`space_capacity`, `Space`.`space_type_id`, `Space`.`space_size`, `Space`.`space_bookable`, `Space`.`space_is_private`, `Space`.`space_notes`, `Space`.`space_image`, `Space`.`status`,`Floor`.floor_name, `Building`.building_name,`SPACETYPE`.space_type_name, ";
				query += "group_concat(DISTINCT(concat(`SpaceBooking`.start_time, '|', `SpaceBooking`.end_time )) separator ',')	as spaceBookingTime";
				query += " FROM " + company_databasename + ".`so_spaces` AS `Space` ";
				query += " LEFT JOIN " + company_databasename + ".`so_floors` AS `Floor` ON `Space`.floor_id = `Floor`.floor_id LEFT JOIN " + company_databasename + ".`so_buildings` AS `Building` ON `Building`.building_id = `Floor`.building_id LEFT JOIN " + company_databasename + ".`so_space_type` AS `SPACETYPE` ON `SPACETYPE`.space_type_id = `Space`.space_type_id";
				
				query += " LEFT JOIN "+ company_databasename +".`so_space_amenities` AS `SPACEAMENITIES` ON `SPACEAMENITIES`.space_id = `Space`.space_id";

				query += " LEFT JOIN " + company_databasename + ".`so_space_booking` AS `SpaceBooking` ON `Space`.space_id = `SpaceBooking`.space_id ";
				query += " AND `SpaceBooking`.`deleted_at` IS NULL AND DATE_FORMAT(`SpaceBooking`.start_time,'%Y-%m-%d %H:%i:%s') >= '" + utcStartDateTime + "' AND DATE_FORMAT(`SpaceBooking`.end_time,'%Y-%m-%d') <=  '" + utcEndDateTime + "' ";

				query += " WHERE `Space`.`deleted_at` IS NULL";

				if(amenities != undefined && amenities.length>0){
					query += " AND `SPACEAMENITIES`.amenity_id IN (" + amenitiesString + ") ";
				}

				query += " group by `Space`.space_id";
							
				
				let countQuery = '';
				if (flag == 0) {

					if(amenities != undefined && amenities.length>0){
						query += " HAVING COUNT(`SPACEAMENITIES`.amenity_id) = "+amenities.length;
					}
					
					query += " ORDER BY `Space`.`" + sort + "` " + orderBy;

					countQuery = query + ") AS  `SPACE`";

					query += " LIMIT " + perPage + " OFFSET " + offset;
					query += ") AS  `SPACE`";

				} else {

					if (building_id != undefined && building_id) {
						query += " AND `Building`.building_id LIKE '" + building_id + "' ";
					}

					if (floor_id != "" && floor_id != undefined) {
						query += " AND ( `Space`.floor_id LIKE '" + floor_id + "') "
					}

					if (space_type_id != "" && space_type_id != undefined) {
						query += " AND ( `Space`.space_type_id LIKE '" + space_type_id + "') "
					}

					if (space_capacity != "" && space_capacity != undefined) {
						query += " AND `Space`.`space_capacity` <= '" + space_capacity + "' ";
					}	

					if(amenities != undefined && amenities.length>0){
						query += " HAVING COUNT(`SPACEAMENITIES`.amenity_id) = "+amenities.length;
					}			

					query += " ORDER BY `Space`.`" + sort + "` " + orderBy;

					countQuery = query + ") AS  `SPACE`";

					query += " LIMIT " + perPage + " OFFSET " + offset;
					query += ") AS  `SPACE`";

				}					
				

				// console.log('query===========');
				// console.log(query);
								
				connection.query(query, function (error, results, fields) {
					
					if (error) {
						return res.json({
							'success': false,
							'message': message.ERROR,
							'error': error
						});
					}
					if (results) {
						async.forEach(results, function (space, callback) {
												
							let timeArray = [];
							// loop for get next 3 times 				
							for (let index = 0; index < 3; index++) {
								let objStartTime = moment(requestStartDateTime).format('LT');;
								let objEndTime = moment(requestEndDateTime).format('LT');
								let objDateVal = event_date;
								let objStartTimeVal = objStartTime;
								let objEndTimeVal = objEndTime;

								// add hour and minute for next time button
								let nextStartTime = moment(requestStartDateTime).add(minutes * index, 'minutes').add(hours * index, 'hours').format(dbDateTimeFormat);
								let nextEndTime = moment(requestEndDateTime).add(minutes * index, 'minutes').add(hours * index, 'hours').format(dbDateTimeFormat);

								// formattted value
								objDateVal = moment(nextStartTime).format('MM/DD/YYYY');
								objStartTimeVal = moment(nextStartTime).format('LT');
								objEndTimeVal = moment(nextEndTime).format('LT');

								// Each next time is convert to utc time for compare with db datetime
								let utcRequestStartDateTime = generalConfig.getUTCDateTime(nextStartTime, timeDiffOffset, timezone);
								let utcRequestEndDateTime = generalConfig.getUTCDateTime(nextEndTime, timeDiffOffset, timezone);

								// Time object for push into specific space
								let timeObj = {
									date: objDateVal,
									start_time: objStartTimeVal,
									end_time: objEndTimeVal,
									available: true
								};																

								// if spaceBookingTime is not null then check time is booked or not booked
								if (space.spaceBookingTime != null) {
									let bothDateTimes = '';
									let bookedUtcStartTime = '';
									let bookedUtcEndTime = '';
									// split all booked times and get array
									let bookedDateArray = space.spaceBookingTime.split(',');
									
									// console.log('bookedDateArray===========');
									// console.log(bookedDateArray);

									console.log('timeobj===========');
									console.log(space.space_name);
									
									// get All booked datetime for current space from db								
									bookedDateArray.forEach(function (bookedArr) {
										// split starttime and endtime
										bothDateTimes = bookedArr.split('|');
										bookedUtcStartTime = bothDateTimes[0];
										bookedUtcEndTime = bothDateTimes[1];
										
										
										console.log(bookedUtcStartTime +' >= '+ utcRequestStartDateTime +' && '+ bookedUtcStartTime +' <= '+ utcRequestEndDateTime);
										// console.log(bookedUtcEndTime +' >= '+ utcRequestStartDateTime +' && '+ bookedUtcEndTime +' <= '+ utcRequestEndDateTime);								
										console.log(timeObj);
										
										// Compare with database utc time and requested utc time for booking time is booked or not										
										
										if ((bookedUtcStartTime >= utcRequestStartDateTime && bookedUtcStartTime < utcRequestEndDateTime) || (bookedUtcEndTime > utcRequestStartDateTime && bookedUtcEndTime <= utcRequestEndDateTime)) {
											timeObj.available = false;
										}	
																			
									});
								}
																

								// If end time is grater than selected date 11:45 hours then object not push
								let compareStartDate = moment(requestStartDateTime).format('YYYY-MM-DD');
								let compareEndDate = moment(nextEndTime).format('YYYY-MM-DD');
								if (compareStartDate == compareEndDate) {
									timeArray.push(timeObj);
								}
							}
							// timearray send with space object					
							space.nextTimeArray = timeArray;						

							if (space.space_image != '' && space.space_image != null) {
								let path = imageSpacePathObj.mainLink + '/80x80/' + space.space_image;
								if (!generalConfig.checkFilePath(path)) {
									space.image_path = generalConfig.no_image_80;
                                } else {
									space.image_path = generalConfig.imageUrl(path);
                                }
							} else {
								space.image_path = generalConfig.no_image_80;
							}

							callback();
						}, function (err) {

							generalConfig.getSpaceTotalCount(req, res, countQuery, function (count) {
								accessObj.then(function (resp) {
									let amenityFinArr = [];
									let amenityObj = {};

									async.forEach(results, function (item, callback) {

										if (item.space_amenities != null) {
											let space_amenity_arr = item.space_amenities.split(",");

											for (let i = 0; i < space_amenity_arr.length; i++) {
												let amenityArr = space_amenity_arr[i].split(":");
												let amenity_name = amenityArr[0];
												let amenity_image = amenityArr[1];

												if (amenity_image != "") {
													let path = imagePathObj.mainLink + '/' + amenity_image;
													if (!generalConfig.checkFilePath(path)) {
														amenityObj = { name: amenity_name, path: generalConfig.no_image_80 };
														amenityFinArr.push(amenityObj);
														amenityObj = { name: "", path: "" }
													} else {
														amenityObj = { name: amenity_name, path: generalConfig.imageUrl(path) };
														amenityFinArr.push(amenityObj);
														amenityObj = { name: "", path: generalConfig.no_image_80 }
													}

												}
											}

											item.amenityArray = amenityFinArr;
											amenityFinArr = [];
										} else {
											item.amenityArray = null;
											amenityFinArr = [];
										}

										callback();
									}, function (err) {
										count = (count != null) ? count : 0;
										return res.json({
											'success': true,
											'data': results,
											'draw': draw,
											'accessObj': resp,
											'recordsTotal': count,
											'recordsFiltered': count,
											'message': message.SUCCESS
										});
									});
								});

							});
                        });
					}
				});
			} else {
				return res.json({
					'success': false,
					'data': null,
					'draw': draw,
					'recordsTotal': 0,
					'recordsFiltered': 0,
					'message': message.ERROR
				});
			}
		});


    } else {
		return res.json({
            'success': false,
            'data': null,
            'draw': draw,
            'recordsTotal': 0,
            'recordsFiltered': 0,
            'message': message.ERROR
        });
    }
}


/**
 * @uses Get all listing data for display in dropdown
 *
 * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
 *
 * @return json
 */

exports.allListingData = function (req, res, next) {
	generalConfig.getDataBase(req, res, function (company_databasename) {
		if (company_databasename != null) {
			var floor = " SELECT floor_id, floor_name FROM " + company_databasename + ".`so_floors` WHERE deleted_at IS NULL ";			
			var building = " SELECT building_id, building_name FROM " + company_databasename + ".`so_buildings` WHERE deleted_at IS NULL ";
			var spacetypes = "SELECT `space_type_id`, `space_type_name` FROM " + company_databasename + ".`so_space_type` AS `SpaceType` WHERE `SpaceType`.`deleted_at` IS NULL";
			var amenity = "SELECT `amenity_id`, `amenity_name`, `amenity_image` FROM " + company_databasename + ".`so_amenities` AS `Amenities` WHERE `Amenities`.`deleted_at` IS NULL AND `Amenities`.`status` = 1";

			var resultsObj = {};
			var domain = generalConfig.getDomain(req);
			var imagePathObj = generalConfig.getFilePath(domain, "amenity", "main", "sub");

			connection.query(building, function (error, building, fields) {
				if (building) {
					resultsObj.building = building;
					connection.query(floor, function (error, floor, fields) {
						if (floor) {
							resultsObj.floor = floor;
							connection.query(spacetypes, function (error, spacetypes, fields) {
								resultsObj.spacetypes = spacetypes;
								connection.query(amenity, function (error, amenity, fields) {
									async.forEach(amenity, function (val, callback) {
										if (val.amenity_image != "" && val.amenity_image != null) {
											var path = imagePathObj.mainLink + '/' + val.amenity_image;
											if (!generalConfig.checkFilePath(path)) {
												val.image_path = generalConfig.no_image_80;
											} else {
												val.image_path = generalConfig.imageUrl(path);
											}
										} else {
											val.image_path = generalConfig.no_image_80;
										}
										callback()
									}, function (err) {
										resultsObj.amenities = (amenity) ? amenity : {};
									});

									res.json({
										"success": true,
										"data": resultsObj,
										"message": null
									});
								});

							});
						}

					});
				}
			});

		} else {
			res.json({
				'success': false,
				'message': message.ERROR,
			});
		}
	});
}


function arrayUnique(a) {
		return a.reduce(function(p, c) {
		if (p.indexOf(c) < 0) p.push(c);
		return p;
	}, []);
};