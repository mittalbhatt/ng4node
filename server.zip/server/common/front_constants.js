// Estimote Beacon Auto Checkout Entry Array      
var estimoteBeaconAutoCheckoutEntryArray = [1,2,3,4,5,7,10];

// Estimote Beacon Auto Checkout Entry Array      
var pushNotificationTimeInterval = [1,2,3,4,5,7,10];

module.exports = {
    estimoteBeaconAutoCheckoutEntryArray:estimoteBeaconAutoCheckoutEntryArray,
    pushNotificationTimeInterval:pushNotificationTimeInterval
};