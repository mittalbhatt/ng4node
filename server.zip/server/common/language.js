var msg = {
	// success / failure / error common message start

	"SUCCESS" : "Records fetch successfully.",
	"FAILURE" : "Record found successfully",
	"ERROR" : "Something went wrong! Please try again",
	"ADD_SUCCESS" : "Record added successfully",
	"NOT_FOUND" : "Record not found",
	"DELETE" : "Record deleted successfully.",
	"UPDATE" : "Record updated successfully.",
	"STATUS_UPDATE":"Status has been updated successfully",
	"EMAIL_EXIST":"Email address is already in use",
	"INVALID" : "Invalid request",
	"SUBSCRIPTION_EXPIRE" : "Subscription has been expired",
	"NO_UPDATES_SUBMITTED" : "No Updates submitted",
	"NEW_PASSWORD_UPDATED" : "New Password updated successfully",
	"OOPS_WRONG_PLANET" : "Oops ! You are on wrong planet",
	"ENTER_YOUR_EMAIL_ADDRESS" : "Please enter your email address",
	"LINK_MAY_EXPIRED" : "Oops! This link may have expired",

	// success / failure / error common message end

	// Amenity module messages start
	"AMENITY_EXIST" : "Amenity name already in use",
	"AMENITY_REQUIRE" : "Name is required",
	"AMENITY_DELETE" : "Amenity has been deleted successfully",
	"AMENITY_PREVENT_DEFAULT" : "Default amenity not to be deleted",
	"AMENITY_ADD_SUCCESS":"Amenity has been added successfully",
	"AMENITY_UPDATE":"Amenity has been updated successfully",
	// Amenity module messages end

	// Building module messages start
	"BUILDING_NAME_REQUIRE" : "Name is required",
	"NO_FLOOR_REQUIRE" : "No of Floor is required",
	"FLOOR_NAME_REQUIRE" : "Floor Name is required",
	"NO_FLOOR_NUMERIC" : "No of Floor should be numeric",
	"POSTAL_CODE_NUMERIC" : "Zip Code should be numeric",
	"BUILDING_ASS_FLOOR":"One or more floors are assigned to this building.!",
	"BUILDING_ADD_SUCCESS" : "Building has been added successfully",
	"BUILDING_UPDATE_SUCCESS" : "Building has been updated successfully",
	"BUILDING_DELETE" :"Building has been deleted successfully",
	// Building module messages end

	//Floor module messages start

	"STATUS_REQUIRED" : "Status is required",
	"CAPACITY_REUIRED" : "Space Capacity is required",
	"FLOOR_UPDATE_SUCCESS" : "Floor has been updated successfully",
	"FLOOR_IN_USED" : "Floor name or floor is already in used",
	"FLOOR_ADD_SUCCESS":"Floor has been added successfully",
	"FLOOR_ASS_SPACE":"One or more Space are  assigned to this floor.!",
	"FLOOR_DELETE":"Floor has been deleted successfully",
	//Floor module messages end


	//User module messages start

	"FIRST_NAME_REQUIRED" 		: "First Name is required",
	"LAST_NAME_REQUIRED"  		: "Last Name is required",
	"EMAIL_REQUIRED"      		: "Email is required",
	"INVAID_EMAIL"      		: "Invalid Email address",
	"PHONE_REQUIRED"      		: "Phone Number is required",
	"BUILDING_ID_REQUIRED"		: "Building Id is required",
	"FLOOR_ID_REQUIRED"   		: "Floor Id is required",
	"TIMEZONE_REQUIRED" 		: "Time Zone is required",
	"PASSWORD_REQUIRED"  		: "Password is required",
	"CURRENT_PASSWORD_REQUIRED" : "Current Password is required",
	"CONFIRM_PASSWORD_REQUIRED" : "Confirm Password is required",
	"INVALID_USER_ID" 			: "Invalid User request",
	"USER_ADDED"				: "User has been added successfully",
	"USER_UPDATED"				: "User details has been updated successfully",
	"USER_DELETED"				: "User has been deleted successfully",
	//User module messages end


	//company module messages start
	"COMPANY_UPDATED" : "Company details updated successfully",


	"SPACE_NAME_REQUIRED":"Space Name is required",
	"SPACE_CAPACITY_NUMERIC" : "Space Capacity should be numeric",
	"SPACE_ADD_SUCCESS":"Space has been added successfully",
	"SPACE_UPDATE_SUCCESS":"Space has been updated successfully",
	"NOSPACE": "Please select valid space",
	//Settings module messages start
	"APP_ID_REQUIRE":"App ID is required",
	"APP_TOKEN_REQUIRE":"App Token is required",
	"COMPANY_LOGO_UPDATE_SUCCESS":"Company Logo updated successfully",
	"SHOW_POWERED_BY_ENABLED":"Enabled Powered by",
	"SHOW_POWERED_BY_DISABLED":"Disabled Powered by",
	"TIMING_FORMAT_UPDATE":"Timing Format updated successfully",
	"CUSTOM_CALENDER_CONNECTED":"Custom Calender connected successfully",
	"GOOGLE_CALENDER_CONNECTED":"Google calender connected successfully",
	"OFFICE365_CALENDER_CONNECTED":"Office 365 calender connected successfully",
	"CUSTOM_CALENDER_DISCONNECTED":"Custom calender disconnected successfully",
	"GOOGLE_CALENDER_DISCONNECTED":"Google calender disconnected successfully",
	"OFFICE365_CALENDER_DISCONNECTED":"Office 365 calender disconnected successfully",
	"REMOVE_COMPANY_LOGO_IMAGE_SUCCESS":"Company Logo image removed",
	"ESTIMOTE_BEACON_DISABLED":"Disabled Estimote Beacon",
	"ESTIMOTE_BEACON_ENABLED":"Enabled Estimote Beacon",
	"BEFORE_MEETING_TIME_UPDATED":"Push notification time updated for before meeting",
	"PUSH_NOTIFICATION_FOR_AUTOCHECKOUT_ENTRY_UPDATED":"Push notification time updated for autocheckout entry",
	"ESTIMOTE_BEACON_AUTOCHECKOUT_ENTRY_UPDATED":"Estimote Beacon Autocheckout entry updated",
	"SO_SETUP_UPDATE":"So Setup updated",
	"SELECT_ATLEAST_ONE_SERVICE" : "Please select at least one service",
	"INVALID_VALUE_SUBMITTED":"Invalid value submitted",
	//Settings module messages end

	//Device module messages start
	"DEVICE_COMPANY_REQUIRED" : "Device Company is required",
	"DEVICE_NAME_REQUIRED" : "Device Name is required",
	"DEVICE_TYPE_REQUIRED" : "Device Type is required",
	"MAJOR_REQUIRED" : "Sensor Major range is required",
	"MINOR_REQUIRED" : "Sensor Minor range is required",
	"SPACE_REQUIRED" : "Space is required",
	"DEVICE_UUID_LENGTH" : "Must be 36 chars long",
	"DEVICE_UUID_REQUIRED" : "Device UUID is required",
	"SENSOR_ADD_SUCCESS":"Sensor has been added successfully",
	"SENSOR_UPDATE":"Sensor has been updated successfully",
	"SENSOR_DELETE":"Sensor has been deleted successfully",
	"TABLET_ADD_SUCCESS" : "Tablet has been added successfully",
	"TABLET_UPDATE" :"Tablet has been updated successfully",
	"TABLET_DELETE" : "Tablet has been deleted successfully",

	//DEvice module messages end


	//package module messages start
	"PACKAGE_UPDATED" : "Package Details are updated",
	"PACKAGE_ADDED" : "Package added successfully",
	"PACKAGE_DELETED" : "Package deleted successfully",

	// Service Request start
	"SERVICE_TITLE_REQUIRED" : "Title is required",
	"SERVICE_USER_REQUIRED" : "User Name is required",
	"SERVICE_CURRENT_STATUS_REQUIRED" : "Current Status is required",
	"SERVERITY_REQUIRED" : "Please select Severity",
	"SERVICE_CATEGORY_REQUIRED" : "Please select Category",
	"SERVICE_ADD_SUCCESS" : "Service Request has been added successfully",
	"SERVICE_UPDATE":"Service request has been updated successfully",
	"SERVICE_DELETE":"Service request has been deleted successfully",

	//service Request End

	// Profile
	"REMOVE_PROFILE_IMAGE_SUCCESS":"Profile image removed",

	//Event module messages start
	"SCHEDULE_DELETE" : "Schedule has been deleted successfully",
	'EVENT_TITLE_REQUIRED' : 'Title is required',
	"START_TIME_REQUIRED":"Start time is required.",
	"END_TIME_REQUIRED":"End time is required",
	"EMAIL_TAGS_REQUIRED":"Email Tag is  required",
	"EVENT_ADD_SUCCESS" : "Event has been added successfully",
	"EVENT_UPDATE_SUCCESS" : "Event has been updated successfully",
	"EVENT_DELETE" :"Event has been deleted successfully",
	"EVENT_ALREADY_BOOKED" : "Meeting already booked at this space on this time duration.",
	'EVENT_END_TIME_GRATER' : "End time should be greater than start time.",
	'EVENT_INVALID_DATETIME' : "Invalid date time.",
	'EVENT_START_TIME_GRATER_THAN_CURRENT_TIME' : "Start Time should be greater than current time.",
	'AMENITIES_NOTES_REQUIRED': 'Aminities note is required and should not be greater than 70 characters.',
	'CATERING_REQUEST_REQUIRED': 'Catering request is required and should not be greater than 70 characters.',
	//Event module messages end
	
	//reset password
	"RESET_LINK_SENT" : "Password reset link has been successfully sent to this email address",
	"EMAIL_NOT_EXISTS" : "This email address is not registered. Please enter correct email address",
	"EMAIL_EXISTS" : "This email address alreay exists.",

	"DATE_ERROR": "Service Due Date should not be less than current date",
};



module.exports = {
    msg:msg
};