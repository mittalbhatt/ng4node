/*
	* User Model
*/

var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var Amenities = sequelize.define('Amenities',
		{
			amenity_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			amenity_name: {
		        type: DataTypes.STRING,
		        validate: {
	                isUnique: function (value, next) {
	                    var self = this;
	                    Amenities.find({
	                    		where: {
	                    			amenity_name: value,
		                    		deleted_at: { $eq: null }
	                    		},
	                    	})
	                        .then(function (amenity) {
	                            //reject if a different user wants to use the same email
	                            if (amenity && self.amenity_id !== amenity.amenity_id) {
	                                return next('Amenity Name is already in used!');
	                            }
	                            return next();
	                        })
	                        .catch(function (err) {
	                            return next(err);
	                        });
	                }
            	}
		    },
			amenity_image: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			timestamps: false,
  			//define the table's name
  			tableName: 'so_amenities',
			
			associate: function (models) {
				Amenities.hasOne(models.SpaceAmenities, { foreignKey: 'amenity_id' });
			},

			instanceMethods: {
				
			}

		}
	);
	return Amenities;
};
