
module.exports = function(sequelizeMasterConnection, DataTypes) {
	
	var companyUser = sequelizeMasterConnection.define('companyUser',
		{


			company_user_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			user_id: DataTypes.STRING,
			company_id: DataTypes.STRING,
			building_id: DataTypes.STRING,
			floor_id:DataTypes.STRING,
			user_type:DataTypes.STRING,
			status:DataTypes.INTEGER,
			 createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
  			freezeTableName: true,
  			tableName: 'so_company_users_map',
  			schema: sequelizeMasterConnection.config.database,
            associate: function(models) {
                companyUser.belongsTo(models.User,{ foreignKey: 'user_id' });
            
                


            },
					

		}	
	);
	return companyUser;
};

