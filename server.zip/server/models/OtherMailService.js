/*
	* so_other_email_services /email service
*/

var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var OtherMailService = sequelize.define('OtherMailService',
		{
			
			service_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			email_id: DataTypes.STRING,
			service_type: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_other_email_services',
  			associate: function (models) {
				OtherMailService.hasOne(models.EmailMaster, {foreignKey: 'email_id'});
			},
			instanceMethods: {
				
			}

		}
	);
	return OtherMailService;
};
