/*
	* Sensor Master Model
*/


var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var SensorMaster = sequelize.define('SensorMaster',
		{
			
			sensor_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			sensor_name: DataTypes.STRING,
			sensor_type: DataTypes.STRING,
			sensor_uuid: DataTypes.STRING,
			sensor_major: DataTypes.STRING,
			sensor_minor: DataTypes.STRING,
			space_id: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_sensor_master',
			associate: function(models) {
				SensorMaster.belongsTo(models.Space, {foreignKey: 'space_id', targetKey: 'space_id'});
			},

			instanceMethods: {
				
			}

		}
	);
	return SensorMaster;
};
