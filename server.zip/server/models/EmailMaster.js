/*
	* so_other_email_services /email service
*/

var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var EmailMaster = sequelize.define('EmailMaster',
		{
			
			email_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			email_address: {
		        type: DataTypes.STRING,
		        validate: {
	                isUnique: function (value, next) {
	                    var self = this;
	                    EmailMaster.find({
	                    		where: {
	                    			email_address: value,
		                    		deleted_at: { $eq: null }
	                    		},
	                    	})
	                        .then(function (email) {
	                            //reject if a different user wants to use the same email
	                            if (email && self.email_address !== email.email_address) {
	                                return next('Email is already in used!');
	                            }
	                            return next();
	                        })
	                        .catch(function (err) {
	                            return next(err);
	                        });
	                }
            	}
		    },
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_email_master',
  			associate: function (models) {
				EmailMaster.hasMany(models.OtherMailService, {foreignKey: 'email_id', onDelete: 'cascade'});
				EmailMaster.hasOne(models.SpaceAttendies, { foreignKey: 'email_id' });

			},
			instanceMethods: {
				
			}

		}
	);
	return EmailMaster;
};
