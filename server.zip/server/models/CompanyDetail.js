/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {
	var CompanyDetails = sequelize.define('CompanyDetails',
		{
			company_plan_id	: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			company_id: DataTypes.UUID,
			plan_id: DataTypes.UUID,
			plan_name: DataTypes.STRING,
			plan_price: DataTypes.INTEGER,
			no_of_month: DataTypes.INTEGER,
			no_of_user: DataTypes.INTEGER,
			no_of_space: DataTypes.INTEGER,
			is_renew: DataTypes.INTEGER,
			plan_start_date: DataTypes.DATE,
			plan_end_date: DataTypes.DATE,
			status: DataTypes.INTEGER,
			feature_detail: DataTypes.STRING,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			freezeTableName: true,
			tableName: 'so_company_plan_details',
			associate: function(models) {
                // Plan.hasOne(models.PlanDetails, {
                //     foreignKey: 'so_company_plan_details'
                // })

                CompanyDetails.belongsTo(models.Plan,{ foreignKey: 'plan_id' })

                
            },

		}
	);
	return CompanyDetails;
};