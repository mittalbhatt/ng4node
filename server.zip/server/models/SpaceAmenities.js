/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var SpaceAmenities = sequelize.define('SpaceAmenities',
		{
			space_amenities_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			space_id: DataTypes.STRING,			
			amenity_id: DataTypes.STRING,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_space_amenities',
			associate: function (models) {
				SpaceAmenities.belongsTo(models.Space, {foreignKey: 'space_id' });
				SpaceAmenities.belongsTo(models.Amenities, {foreignKey: 'amenity_id' });

			}
		}
	);
	return SpaceAmenities;
};