/*
	* Service Requests Model
*/


var crypto = require('crypto');
var moment = require('moment');


module.exports = function(sequelize, DataTypes) {
	
	var ServiceRequests = sequelize.define('ServiceRequests',
		{
			
			service_request_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			service_title: DataTypes.STRING,
			special_instruction: DataTypes.STRING,
			service_ticket_number: DataTypes.STRING,
			service_due_date: {
		        type: DataTypes.DATE,
		        get: function() {
		          return moment(this.getDataValue('service_due_date')).format('MM/DD/YYYY');
		        }
		    },
			space_id: DataTypes.STRING,
			space_name: DataTypes.STRING,
			created_by: DataTypes.STRING,
			assigned_user_id: DataTypes.STRING,
			category_name: DataTypes.STRING,
			severity: DataTypes.INTEGER,
			current_status:DataTypes.INTEGER,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at',
		        get: function() {
		          return moment(this.getDataValue('createdAt')).format('D MMM, YYYY | h:mm A');
		        }
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_service_requests',
			associate: function(models) {
				//ServiceRequests.hasOne(models.User, { foreignKey: 'created_by' });
				ServiceRequests.belongsTo(models.Space, { foreignKey: 'space_id', targetKey: 'space_id' });
			},

			instanceMethods: {
				
			}

		}
	);
	return ServiceRequests;
};
