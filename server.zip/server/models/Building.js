/*
	* User Model
*/


var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var Building = sequelize.define('Building',
		{
			
			building_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			building_name: DataTypes.STRING,
			no_of_floor: DataTypes.INTEGER,
			address_1: DataTypes.STRING,
			address_2: DataTypes.STRING,
			street_no: DataTypes.STRING,
			state: DataTypes.STRING,
			city: DataTypes.STRING,
			country: DataTypes.STRING,
			postal_code: DataTypes.STRING,
			contact_no: DataTypes.STRING,
			latitude: DataTypes.STRING,
			longitude: DataTypes.STRING,
			notes: DataTypes.STRING,
			building_image: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_buildings',

			associate: function(models) {				
				Building.hasMany(models.Floors, {foreignKey: 'building_id' });
				// Building.hasOne(models.companyUser, {foreignKey: 'building_id' });
				
			},

			instanceMethods: {
				
			}

		}
	);
	return Building;
};
