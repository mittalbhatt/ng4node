/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var Feature = sequelize.define('Feature',
		{
			feature_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			feature_title: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE

		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_feature_master',

			associate: function (models) {

				Feature.hasMany(models.PlanDetails, {
                    foreignKey: 'feature_id'
                });
			}

			


		}
	);
	return Feature;
};