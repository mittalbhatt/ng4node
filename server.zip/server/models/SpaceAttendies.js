
var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var SpaceAttendies = sequelize.define('SpaceAttendies',
		{
			
			attendies_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			booking_id: DataTypes.STRING,
			email_id: DataTypes.STRING,
			attendies_type: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_space_attendies',
  			associate: function (models) {
				//SpaceAttendies.hasOne(models.EmailMaster, {foreignKey: 'email_id'});
				SpaceAttendies.belongsTo(models.SpaceBooking, {foreignKey: 'booking_id' });
				SpaceAttendies.belongsTo(models.EmailMaster, {foreignKey: 'email_id' });


			},
			instanceMethods: {
				
			}

		}
	);
	return SpaceAttendies;
};
