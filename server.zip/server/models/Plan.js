/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {
	var Plan = sequelize.define('Plan',
		{
			plan_id	: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			plan_name: DataTypes.STRING,
			plan_price: DataTypes.INTEGER,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_plans',
			associate: function(models) {
                Plan.hasOne(models.PlanDetails, {
                    foreignKey: 'plan_id'
                }),
                Plan.hasOne(models.CompanyDetails, {
                    foreignKey: 'plan_id'
                }),
                Plan.hasMany(models.PlanDurationPrice, {
                    foreignKey: 'plan_id'
                })
                
            },

		}
	);
	return Plan;
};