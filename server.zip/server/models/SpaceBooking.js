/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var SpaceBooking = sequelize.define('SpaceBooking',
		{
			booking_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			space_id: DataTypes.CHAR,
			user_id: DataTypes.CHAR,
			booking_title: DataTypes.STRING,			
			booking_details: DataTypes.TEXT,
			booking_status: DataTypes.STRING,
			amenities_notes: DataTypes.TEXT,
			catering_notes: DataTypes.TEXT,
			start_time: DataTypes.DATE,
			end_time: DataTypes.DATE,
			booking_duration: DataTypes.INTEGER,
			device_id: DataTypes.CHAR,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE

		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_space_booking',

			associate: function (models) {				
				SpaceBooking.hasMany(models.SpaceAttendies, { foreignKey: 'booking_id', targetKey: 'email_id' });
			}		
		}
	);
	return SpaceBooking;
};