/*
	* Service Requests Model
*/


var crypto = require('crypto');
var moment = require('moment');

module.exports = function(sequelize, DataTypes) {
	
	var ServiceRequestStatus = sequelize.define('ServiceRequestStatus',
		{
			
			service_request_status_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			service_request_id: DataTypes.STRING,
			current_status: DataTypes.INTEGER,
			service_due_date: DataTypes.DATE,
			severity: DataTypes.INTEGER,
			special_instruction: DataTypes.STRING,
			created_by: DataTypes.STRING,
			assigned_user_id: DataTypes.STRING,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at',
		        get: function() {
		          return moment(this.getDataValue('createdAt')).format('D MMM, YYYY | h:mm A');
		        }
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_service_request_status',
			associate: function(models) {
				
			},

			instanceMethods: {
				
			}

		}
	);
	return ServiceRequestStatus;
};
