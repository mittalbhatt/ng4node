
module.exports = function(sequelize, DataTypes) {
	
	var companyMaster = sequelize.define('companyMaster',
		{


			company_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
            company_name: DataTypes.STRING,
            company_email: DataTypes.STRING,
            company_address1: DataTypes.STRING,
            company_address2: DataTypes.STRING,
            company_city: DataTypes.STRING, 
            company_state: DataTypes.STRING, 
            company_zip: DataTypes.STRING,
            company_phone: DataTypes.STRING,
            company_logo: DataTypes.STRING,
            company_domain_prefix: DataTypes.STRING,
            company_db_name: DataTypes.STRING,
            timezone: DataTypes.STRING,
            time_difference: DataTypes.STRING,
            status: DataTypes.INTEGER,
            createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
  			freezeTableName: true,
  			tableName: 'so_company_master',
            associate: function(models) {
                // companyUser.belongsTo(models.User,{ foreignKey: 'user_id' })
                // companyUser.belongsTo(db,{ foreignKey: 'building_id' })
            },
					

		}	
	);
	return companyMaster;
};

