/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var Floors = sequelize.define('Floors',
		{
			floor_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			floor_name: DataTypes.STRING,
			floor_no: DataTypes.INTEGER,
			building_id: DataTypes.CHAR,
			floor_plan_image: DataTypes.STRING,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE

		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_floors',
			schema: sequelize.config.database,

			associate: function (models) {
				Floors.belongsTo(models.Building, { foreignKey: 'building_id' });
				Floors.hasOne(models.Space, {foreignKey: 'floor_id' });
			}
		}
	);
	return Floors;
};