/*
 * User Model
 */
var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {

	var User = sequelize.define('User',
		{


			user_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
                
            },
			first_name: DataTypes.STRING,
			last_name: DataTypes.STRING,
			email: DataTypes.STRING,
			password: DataTypes.STRING,
			phone_number: DataTypes.STRING,
			profile_picture: DataTypes.STRING,
			timezone: DataTypes.STRING,
            time_difference: DataTypes.STRING,
            forgotToken: DataTypes.STRING,
			status: DataTypes.INTEGER,
			 createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_users',
  			schema: sequelize.config.database,
        	schemaDelimiter: '.',

			instanceMethods: {
				makeSalt: function() {
					return crypto.randomBytes(16).toString('base64');
				},
				authenticate: function(plainText){
					// return this.encryptPassword(plainText, this.salt) === this.hashedPassword;
					return true;
				},
				encryptPassword: function(password, salt) {
					if (!password || !salt) return '';
					salt = new Buffer(salt, 'base64');
					return crypto.pbkdf2Sync(password, salt, 10000, 64).toString('base64');
				}
			},
			

             associate: function(models) {
                    User.hasOne(models.companyUser, {
                        foreignKey: 'user_id'
                    })
                    
                },




		}
	);
	return User;
};