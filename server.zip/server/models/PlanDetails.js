/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {
	var PlanDetails = sequelize.define('PlanDetails',
		{
			plan_detail_id	: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
            plan_id : DataTypes.UUID,
            feature_id : DataTypes.STRING,
			no_of_employee: DataTypes.INTEGER,
			no_of_space: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_plan_details',
			associate: function(models) {
                PlanDetails.belongsTo(models.Plan,{ foreignKey: 'plan_id' })
                PlanDetails.belongsTo(models.Feature,{ foreignKey: 'feature_id' })
                
                // companyUser.belongsTo(db,{ foreignKey: 'building_id' })
            },
		}
	);
	return PlanDetails;
};