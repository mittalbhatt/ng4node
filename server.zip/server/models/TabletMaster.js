/*
	* Tablet Master Model
*/


var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var TabletMaster = sequelize.define('TabletMaster',
		{
			
			tablet_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			device_id: DataTypes.STRING,
			device_activation_key: DataTypes.STRING,
			space_id: DataTypes.STRING,
			is_booking: DataTypes.INTEGER,
			mask_meeting_title: DataTypes.INTEGER,
			hide_attendees: DataTypes.INTEGER,
			status: DataTypes.INTEGER,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_tablet_master',
			associate: function(models) {
				TabletMaster.belongsTo(models.Space, {foreignKey: 'space_id', targetKey: 'space_id'});
				TabletMaster.belongsTo(models.DeviceMaster, {foreignKey: 'device_id', targetKey: 'device_id'});
			},

			instanceMethods: {
				
			}

		}
	);
	return TabletMaster;
};
