
module.exports = function(sequelize, DataTypes) {
	
	var companyMasterAmenities = sequelize.define('companyMasterAmenities',
		{


			amenity_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
            amenity_name: DataTypes.STRING,
            amenity_image: DataTypes.STRING,

            status: DataTypes.INTEGER,
            createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
  			freezeTableName: true,
  			tableName: 'so_company_master_amenities',
            associate: function(models) {
                // companyUser.belongsTo(models.User,{ foreignKey: 'user_id' })
                // companyUser.belongsTo(db,{ foreignKey: 'building_id' })
            },
					

		}	
	);
	return companyMasterAmenities;
};

