/*
	* User Model
*/


var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {
	
	var DeviceMaster = sequelize.define('DeviceMaster',
		{
			
			device_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			device_name: DataTypes.STRING,
			app_version: DataTypes.STRING,
			api_version: DataTypes.STRING,
			device_type: {
			    type:   DataTypes.ENUM,
			    values: ['ANDROID', 'IOS']
			},
			os_version: DataTypes.STRING,
			user_id: DataTypes.STRING,
			device_token: DataTypes.STRING,
			status: DataTypes.INTEGER,
			sync_date:DataTypes.DATE,
			createdAt: {
		        type: DataTypes.DATE,
		        field: 'created_at'
		    },
		    updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
		    deleted_at: DataTypes.DATE
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'so_device_master',

			associate: function(models) {				
				DeviceMaster.hasOne(models.TabletMaster, {foreignKey: 'device_id', targetKey: 'device_id'});
			},

			instanceMethods: {
				
			}

		}
	);
	return DeviceMaster;
};
