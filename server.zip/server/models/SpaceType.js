/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var SpaceType = sequelize.define('SpaceType',
		{
			space_type_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			space_type_name: DataTypes.STRING,			
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_space_type',

			associate: function (models) {
				SpaceType.hasOne(models.Space, {foreignKey: 'space_type_id' });
			}
		}
	);
	return SpaceType;
};