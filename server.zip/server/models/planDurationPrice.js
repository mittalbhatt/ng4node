/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {
	var PlanDurationPrice = sequelize.define('PlanDurationPrice',
		{
			plan_duration_id	: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
            plan_id : DataTypes.UUID,
            duration_id : DataTypes.UUID,
			price : DataTypes.INTEGER,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
				type: DataTypes.DATE,
				field: 'updated_at'
			},
			deleted_at: DataTypes.DATE
		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_plan_duration_price',
			associate: function(models) {
                PlanDurationPrice.belongsTo(models.Plan,{ foreignKey: 'plan_id' })
                PlanDurationPrice.belongsTo(models.Duration,{ foreignKey: 'duration_id' })
                // companyUser.belongsTo(db,{ foreignKey: 'building_id' })
            },

		}
	);
	return PlanDurationPrice;
};