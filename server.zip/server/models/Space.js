/* Floor Model */

var crypto = require('crypto');

module.exports = function (sequelize, DataTypes) {

	var Space = sequelize.define('Space',
		{
			space_id: {
                primaryKey: true,
				type: DataTypes.UUID,
				defaultValue: DataTypes.UUIDV4,
            },
			space_name: DataTypes.STRING,
			floor_id: DataTypes.CHAR,
			space_capacity: DataTypes.INTEGER,
			space_type_id: DataTypes.CHAR,
			space_size: DataTypes.STRING,
			space_bookable: DataTypes.INTEGER,
			space_is_private: DataTypes.INTEGER,
			space_notes: DataTypes.TEXT,
			space_image: DataTypes.STRING,
			is_maintenance: DataTypes.INTEGER,
			status: DataTypes.INTEGER,
			createdAt: {
				type: DataTypes.DATE,
				field: 'created_at'
			},
			updatedAt: {
		        type: DataTypes.DATE,
		        field: 'updated_at'
		    },
			deleted_at: DataTypes.DATE

		},
		{
			timestamps: false,
			freezeTableName: true,
			tableName: 'so_spaces',

			associate: function (models) {
				Space.belongsTo(models.Floors, { foreignKey: 'floor_id' });
				Space.belongsTo(models.SpaceType, { foreignKey: 'space_type_id' });
				Space.hasMany(models.SpaceAmenities, { foreignKey: 'space_id', targetKey: 'amenity_id' });
			}
		}
	);
	return Space;
};