var jwt = require('jwt-simple');
var passport = require('passport');
var generalConfig = require('./generalConfig');
var async = require('async');
var db = require('./sequelize').db;
var DataTypes = require("sequelize");
var base64 = require('base-64');
var utf8 = require('utf8');
var localStorage = require('localStorage');
var util = require('util'); 
var model = module.exports;

//tokens expiration time
model.accessTokenLifetime = 10800;
model.refreshTokenLifetime = 86400;

// JWT secret keys
var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;
var dynamicHeader = '';

/**
 * allowJson() will convert content-type from json to x-www-form-urlencoded to allow this request
 * @param  {req}   req
 * @param  {res}   res
 * @param  {Function} next
 * @return {Function} next
 */
model.allowJson = function(req, res, next) {
    
    dynamicHeader = req.headers.referer;
    if (req.is('json'))
        req.headers['content-type'] = 'application/x-www-form-urlencoded';

    next();
};

/**
 * getClient() will verify client
 * @param  {String}   clientId
 * @param  {String}   clientSecret
 * @param  {Function} callback
 * @return {Function} callback
 */
model.getClient = function(clientId, clientSecret, callback) {
    var decoded = '';
    var randNum = '';
    async.series([
        function(cb){   
            decoded = jwt.decode(clientSecret, secretKey);
            cb(null,null);
        },
        function(cb){   
            randNum = localStorage.getItem('randNum');
            cb(null,null);
        }
    ],
    function(err, results) {
        if(decoded.import === randNum)
        {
            //localStorage.clear();
            return callback(null, {
                "clientId": clientId,
                "clientSecret": clientSecret
            });
        }
        else
        {   
            //localStorage.clear();
            return callback({"error":"Token mismatched"}, null);
        }
    })
};

/**
 * grantTypeAllowed() will check for allowed grant type and allow user to authorized
 * @param  {String}   clientId
 * @param  {String}   grantType
 * @param  {Function} callback
 * @return {Function} callback
 */
model.grantTypeAllowed = function(clientId, grantType, callback) {
    callback(false, true);
};

/**
 * getUser() will verify user via grant type password
 * @param  {String}   username  email of user
 * @param  {String}   password
 * @param  {Function} callback
 * @return {Function} callback
 */
model.getUser = function(username, password, callback) {
     
        var req = {
            body: {
                email: username,
                password: password,
                grant_type: 'password',
                url: dynamicHeader
            }
        };
    var res = {};

    
    //verify user name and password with local strategy
   passport.authenticate('local', function(err, user, info) {
        // console.log(user);
        // console.log('===========');
        if(!user) {
            if(info) {
                console.log("----Out and failed to session ----"+err);
                return callback(err);
            } else {
                console.log("----Out and failed to session --- ----"+err);
                return callback(err);
            }
        } else {

            console.log("============== In success and set session =================");
            var curUserID = user.user_id;
            console.log("============== In success and set session =================");

            // var curUserID = encrypt(curUserID.toString());
            // req.session.admin = user;

            return callback(null, {
                success: true,
                data:user,
                message:'Login successfully'
            });
            
        }
    })(req, res);
};

/**
 * generateToken() will generate new token
 * @param  {String}   type token type
 * @param  {req}   req
 * @param  {Function} callback
 * @return {Function} callback
 */
model.generateToken = function(type, req, callback) {

    //Use the default implementation for refresh tokens
    if (type === 'refreshToken') {
        callback(null, null);
        return;
    }
    var is_admin = req.user.isadmin; 
    var expireDate = new Date();
    expireDate.setTime(expireDate.getTime() + model.accessTokenLifetime * 1000);

    //on refresh token will carry old user information
    var userInfo = {};
    if(is_admin) // Super Admin 
    {
        if (req.cookies && req.cookies.adminUserSession)
        {
            var oldToken = (JSON.parse(req.cookies.adminUserSession)).access_token;
            if (oldToken) {
                var decoded = jwt.decode(oldToken, secretKey);
                userInfo = decoded.user;
            } else {
                userInfo = req.user;
            }
        }
        else
        {
            userInfo = req.user;
        }
    }
    else // Client user
    {
        if (req.cookies && req.cookies.userSession)
        {
           
            var oldToken = (JSON.parse(JSON.stringify(req.cookies.userSession))).access_token;
            if (oldToken) {
                var decoded = jwt.decode(oldToken, secretKey);
                userInfo = decoded.user;
            } else {
                userInfo = req.user;
            }
        }
        else
        {
            userInfo = req.user;
        }
    }
    var token = jwt.encode({
        user: userInfo,
        subject: req.client.clientId,
        exp: expireDate
    }, secretKey);

    callback(null, token);
};

/**
 * saveAccessToken() will save access token
 * @param  {String}   token
 * @param  {String}   clientId
 * @param  {Timestamp}   expires
 * @param  {Object}   user
 * @param  {Function} callback
 * @return {Function} callback
 */
model.saveAccessToken = function(token, clientId, expires, user, callback) {
    //No need to store JWT tokens.
    callback(null, user);
};

/**
 * getAccessToken() will get bearer token
 * @param  {String}   bearerToken
 * @param  {Function} callback
 * @return {Function} callback
 */
model.getAccessToken = function(bearerToken, callback) {
    try {
        var decoded = jwt.decode(bearerToken, secretKey);
        if(decoded.user.id != '0')
        {
            callback(null, {
                accessToken: bearerToken,
                clientId: decoded.sub,
                userId: decoded.user,
                expires: new Date(decoded.exp)
            });
        }
        else
        {
            //callback({"error":"Token mismateched"}, null);
            callback(null);
        }
    } catch (e) {
        callback(e);
    }
};

/**
 * getRefreshToken() get refresh token from database
 * @param  {String}   refreshToken
 * @param  {Function} callback
 * @return {Function} callback
 */
model.getRefreshToken = function(refreshToken, callback) {
   db.models.user.findOne({ where: { refreshtoken: refreshToken} })
      .then(function(user) {
        if(user){
            callback(null, {
                    refreshToken: user.refreshtoken,
                    clientId: 'testclient',
                    userId: user.id,
                    expires: user.expireon
                });
        }else{
            callback(null,{
                    refreshToken: '',
                    clientId: '',
                    userId: '',
                    expires: ''
                });
        }
    }).catch(function(error) {
        callback(error);
    });
};

/**
 * saveRefreshToken will save refresh token in database
 * @param  {String}   token
 * @param  {String}   clientId
 * @param  {Timestamp}  expires
 * @param  {Object}   user
 * @param  {Function} callback
 * @return {Function} callback
 */
model.saveRefreshToken = function(token, clientId, expires, user, callback) {
    callback(null,user);
    // var refreshToken = {
    //     refreshToken: token,
    //     clientId: clientId,
    //     userId: user.id,
    //     expires: expires
    // };

    // var updatefields = {};
    // updatefields['refreshtoken'] = token;
    // updatefields['expireon'] = expires;
   
    // if(user.isadmin)
    // {
    //     db.models.admin_user.update(updatefields, { where: { id: user.id} })
    //       .then(function(UserSchemaUpdate) {
    //         if(UserSchemaUpdate){
    //             callback(null, UserSchemaUpdate);
    //         } else {
    //             callback(UserSchemaUpdate);
    //         }
    //       });
    // }
    // else
    // {
    //     db.models.user.update(updatefields, { where: { id: user.id} })
    //       .then(function(UserSchemaUpdate) {
    //         if(UserSchemaUpdate){
    //             callback(null, UserSchemaUpdate);
    //         } else {
    //             callback(UserSchemaUpdate);
    //         }
    //       });
    // }
      
};

model.validateScope = function(user, client) {
    return user.scope === client.scope
};