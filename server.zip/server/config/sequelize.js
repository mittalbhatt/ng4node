var fs        = require('fs');
var path      = require('path');
var Sequelize = require('sequelize');
var _         = require('lodash');
var config    = require('./database');

var db = {};
var master_db = {};

// Company Database: create your instance of sequelize
// var sequelize = new Sequelize(config.db.name, config.db.username, config.db.password, {
//     host: config.db.host,
//     port: config.db.port,
//     dialect: 'mysql',
//     storage: config.db.storage,
//     logging: console.log,
//     timezone: 'Etc/GMT'
// });
// sequelize.dialect.supports.schemas = true;

// Master Database: Create master database instance of sequelize
var sequelizeMasterConnection = new Sequelize(config.master_database.name, config.master_database.username, config.master_database.password, {
    host: config.master_database.host,
    port: config.master_database.port,
    dialect: 'mysql',
    storage: config.master_database.storage,
    //logging: false,
    timezone: 'Etc/GMT'
}); 
sequelizeMasterConnection.dialect.supports.schemas = true;

fs.readdirSync(config.modelsDir.path)
    .filter(function(file) {
        return (file.indexOf('.') !== 0) && (file !== 'index.js') && (file !== 'data');
    })
//import model files and save model names
.forEach(function(file) {


    //console.log('Loading model file ' + file);
    // var model = sequelize.import(path.join(config.modelsDir.path, file));
    // db[model.name] = model;

});
//invoke associations on each of the models
// Object.keys(db).forEach(function(modelName) {
//     if (db[modelName].options.hasOwnProperty('associate')) {
//         db[modelName].options.associate(db)    }
// });


// Loop through all files in models (master_database) directory ignoring hidden files and this file
fs.readdirSync(config.modelsDir.master_path)
    .filter(function(file) {    
        return (file.indexOf('.') !== 0);
    })
//import model files and save model names
.forEach(function(file) {

   var model = sequelizeMasterConnection.import(path.join(config.modelsDir.master_path, file));
   master_db[model.name] = model;
});
//invoke associations on each of the models
Object.keys(master_db).forEach(function(modelName) {
    if (master_db[modelName].options.hasOwnProperty('associate')) {
        master_db[modelName].options.associate(master_db)
    }
});




/**
 * Creates a object representing a column in the DB. This is often useful in conjunction with `sequelize.fn`, since raw string arguments to fn will be escaped.
 * @see {Sequelize#fn}
 *
 * @method col
 * @param {String} col The name of the column
 * @since v2.0.0-dev3
 * @return {Sequelize.col}
 */
// Sequelize.col = Sequelize.prototype.col = function(col) {
//   return new Utils.col(col);
// };


//assign the sequelize variables to the db object and returning the db.
module.exports = {
    // db: sequelize,
    master_db: sequelizeMasterConnection,
     Sequelize: Sequelize
}


