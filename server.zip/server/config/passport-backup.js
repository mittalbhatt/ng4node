//Use local strategy
passport.use(new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback : true // allows us to pass back the entire request to the callback
},function(req, email, password, done) {

console.log("---OM : Gte user data 001----");
    master_db.models.User.find({
            attributes : ['user_id','first_name', 'last_name', 'email','password'],
            where: {
                        email: email
                    }
        }).then(function(user) {

            console.log(user.user_id);
            master_db.models.companyUser.find({
                attributes : ['company_id'],
                where: {


                        user_id : user.user_id


                }
            }).then(function(companyUser) {

             
                if(companyUser) {

                master_db.models.CompanyDetails.find({

                    where : {

                        company_id: companyUser.company_id
                    }
                }).then(function(CompanyDetail){

                  
                    console.log(CompanyDetail.plan_end_date);
                    if(CompanyDetail) {


                          console.log('-----------------');
                   
                    console.log('-----------------');




                         if (!user) {
                            done(null, false, {
                                message: 'Unknown user'
                            });
                        } else if (!generalConfig.authenticate(password, user.password)) {
                            done(null, false, {
                                message: 'Invalid password'
                            });
                        } else if (user.active == false) {
                            done(null, false, {
                                message: 'Inactive User'
                            });
                        } else {
                            done(null, user, {
                                message: 'Success'
                            });
                        }






                        // Math.abs(CompanyDetail.plan_end_date.getTime() > new Date().getTime());






                    }
                    else {


                        console.log('++++++++++++++++++++');


                         done(null, user, {
                        message: 'Your free plan is expired. Purchase a plan to continue.!'
                    });

                    }
                })

                }



            })










             
        }).catch(function(err) {
             done(err, null);
        });

                

          
        //         console.log("---OM : Gte user data----");
        //         if (!user) {
        //             done(null, false, { message: 'Unknown user' });
        //             console.log('----Un known user---');
        //         } else if (!generalConfig.authenticate(password, user.password)) {
        //                        done(null, false, {
        //             message: 'Invalid password'
        //         });
        //     }  else {
        //             console.log('Login (local) : { id: ' + user.user_id + ', firstname: ' + user.first_name + ' }');
        //             done(null, user);
        //         }


        // }).catch(function(err){
        //     console.log('----Query error---');
        //     done(err);
        // });
}));
