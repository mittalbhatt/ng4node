var fs = require("fs");
var pathFunc = require('path');
var Jimp = require("jimp");
var generalConfig    = require('./generalConfig');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;

function checkFileType(filename, type){
	
	type = (type != "")?type:"image";
	
	var filename = filename.toString().split(".");
    var ext = filename[filename.length-1];

	var fileType = generalConfig.fileType;

	if(!fileType.hasOwnProperty(type)){
		type = "image";
	};

	return (fileType[type].indexOf(ext) > -1);
}

function uploadImage(domain, service, base64Image, new_image_name, old_image_name, removealTag, filetype){
	
	var structureObj = (generalConfig.uploadpath[service])?generalConfig.uploadpath[service]:generalConfig.uploadpath["default"];
	var basePath = generalConfig.uploadBasePath;
	
	var uploadFolder = structureObj.folder;
	var subFolder = structureObj.size_folder;
	
	var GUID = generalConfig.generateGUID();
	var extension = pathFunc.extname(new_image_name);

	var uploadPath = (domain)? basePath+domain+'/'+uploadFolder : basePath+uploadFolder;

	checkFileType(new_image_name, filetype);
	var oldmask = process.umask(0);

	if(!fs.existsSync(basePath)){
		fs.mkdirSync(basePath);
		process.umask(oldmask);
	}

	if(!fs.existsSync(basePath+'/'+domain)){
		fs.mkdirSync(basePath+'/'+domain);
		process.umask(oldmask);
	}

	if(!fs.existsSync(uploadPath)){
		fs.mkdirSync(uploadPath);
		process.umask(oldmask);
	}

	if(subFolder.length > 0){
		subFolder.forEach(function(size){
			if(!fs.existsSync(uploadPath+'/'+size+'x'+size)){
				fs.mkdirSync(uploadPath+'/'+size+'x'+size);
				process.umask(oldmask);
			}
		});
	}

	if(base64Image != "" && new_image_name != ""){

		if(checkFileType(new_image_name, filetype)){

			if(old_image_name != ""){
				remvoeUploadedFile(domain, uploadFolder, subFolder, basePath, old_image_name);
			}

			var uploaded_image_name = GUID+extension;

			fs.writeFile(uploadPath+'/'+uploaded_image_name, base64Image, {encoding: 'base64'}, function(err) {
	            if (!err)

	            Jimp.read(uploadPath+'/'+uploaded_image_name, function (err, lenna) {
				    if (err) { 
				    	return {'success': false,'file_name': '', 'message': 'File should be jpg, png, jpeg, gif.!'};						
				    	//throw err;
				    } 
				    else {
					    if(subFolder.length > 0){
					    	subFolder.forEach(function(size){
								if(fs.existsSync(uploadPath+'/'+size+'x'+size))
								{
									// lenna.resize(size, size)            // resize 
							  //        .quality(80)                 // set greyscale 
							  //        .write(uploadPath+'/'+size+'x'+size+'/'+uploaded_image_name); // save 		

							         lenna.resize(size, Jimp.AUTO)            // resize 
							         .quality(80)                 // set greyscale 
							         .write(uploadPath+'/'+size+'x'+size+'/'+uploaded_image_name); // save 		
								}
							});
					    }
					}
				});
            
        	});

        	return {'success': true, 'file_name': uploaded_image_name, 'message': null};	

		}else{
			return {'success': false,'file_name': '', 'message': 'File should be jpg, png, jpeg, gif.!'};
		}

	}else if(removealTag == true && new_image_name == "" && old_image_name != ""){
		remvoeUploadedFile(domain, uploadFolder, subFolder, basePath, old_image_name);
		return {'success': true, 'file_name': '', 'message': null};

	} else {
		return {'success': true, 'file_name': old_image_name, 'message': null};
	}


}

function remvoeUploadedFile(domain, dir, sub_dir, path, file) {
	
	var pathName = (domain)? path+domain+'/'+dir+'/'+file : path+dir+'/'+file;

    var exists = fs.existsSync(pathName);
	
    if(exists){
        fs.unlink(pathName);
    }

    if(sub_dir.length > 0){
    	sub_dir.forEach(function(size){
    		var subPathName = (domain)? path+domain+'/'+dir+'/'+size+'x'+size+'/'+file : path+dir+'/'+size+'x'+size+'/'+file;
			if(fs.existsSync(subPathName)){
				fs.unlink(subPathName);
			}
		});
    }


}

module.exports = {
    uploadImage: uploadImage,
    remvoeUploadedFile: remvoeUploadedFile,
    checkFileType:checkFileType
};