module.exports = {
    //This is your MYSQL Database configuration
 

    dev : {
        username: "root",
        password: "password",
        host:"192.168.3.113",
        port:3306,
        driver:'mysql',

        multipleStatements:true,
    // },
    // master_database: {
    //     username: "root",
    //     password: "password",
    //     name: "smartoffice_master",
    //     host: "192.168.3.113",
    //     port: 3306,
    //     driver:'mysql',

    //     multipleStatements:true
    // },
    // modelsDir : {
    //     path : __dirname + '/../models',
    //     master_path : __dirname + '/../models'
    // }

    }
   
};