var bcrypt = require('bcrypt-nodejs');
var passport = require('passport');
var _ = require('lodash');

//These are different types of authentication strategies that can be used with Passport.
var LocalStrategy = require('passport-local').Strategy;
var generalConfig = require('./generalConfig');


// var db = require('./sequelize');
var sequlizeConfig = require('../config/sequelize');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;

//Serialize sessions
passport.serializeUser(function(user, done) {
    done(null, user.id);
});

passport.deserializeUser(function(id, done) {
    db.models.User.find({where: {id: id}}).then(function(user){
        
        done(null, user);

    }).catch(function(err){

        done(err, null);

    });
});

//Use local strategy
passport.use(new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback: true // allows us to pass back the entire request to the callback
}, function(req, email, password, done) {
    
    master_db.models.User.find({
        attributes: ['user_id', 'first_name', 'status', 'last_name', 'email', 'password','phone_number','profile_picture','timezone','time_difference'],
        where: {
            email: email,
            deleted_at : null,
        }
    }).then(function(user) {

        if (user) {
            master_db.models.companyUser.find({
                attributes: ['company_id', 'user_type'],
                where: {
                    user_id: user.user_id
                }
            }).then(function(companyUser) {
                var masterUrl = generalConfig.masterUrl.includes(req.body.url);
                if (companyUser && (companyUser.user_type == 'MasterAdmin' || companyUser.user_type == 'Admin')) {
                    if (!generalConfig.authenticate(password, user.password)) {
                        var err = new Error('You have entered an invalid email or password.');
                        done(err, false, {
                            message: 'You have entered an invalid email or password.'
                        });
                    } else if (masterUrl == false) {

                        var err = new Error('Product admin cannot log in into company.');
                        done(err, false, {
                            message: 'Product admin cannot log in into company.'
                        });

                    } else {

                        done(null, user, {
                            message: 'Success'
                        });
                    }

                } else {
                    if (companyUser) {
                        master_db.models.companyMaster.find({
                            where: {
                                company_id: companyUser.company_id
                            }

                        }).then(function(companyMaster) {

                            if(req.body.url){
                                var url = (req.body.url).toString().split(".");
                                var url2 = url[0].toString().split("//");

                                if (companyMaster.company_domain_prefix != url2[1]) {

                                    var err = new Error('You are not registered with this company.');
                                    done(err, false, {
                                        message: 'You are not registered with this company.'
                                    });

                                } else {
                                    master_db.models.CompanyDetails.find({
                                        where: {
                                            company_id: companyUser.company_id
                                        }
                                    }).then(function(CompanyDetail) {
                                        if (CompanyDetail) {
                                            if (!user) {
                                                var err = new Error('Please enter valid email address.');
                                                done(err, false, {
                                                    message: 'Unknown user'
                                                });
                                            } else if (!generalConfig.authenticate(password, user.password)) {
                                                var err = new Error('You have entered an invalid email or password.');
                                                done(err, false, {
                                                    message: 'You have entered an invalid email or password.'
                                                });
                                            } else if (user.status === 0) {
                                                var err = new Error('This user status in inactive');
                                                done(err, false, {
                                                    message: 'This user status in inactive'
                                                });
                                            } else {
                                                done(null, user, {
                                                    message: 'Success'
                                                });
                                            }

                                        } else {
                                            var err = new Error('There is no plan attached with this company');
                                            done(err, user, {
                                                message: 'There is no plan attached with this company!'
                                            });
                                        }
                                    })
                                }

                            }else{

                                master_db.models.CompanyDetails.find({
                                        where: {
                                            company_id: companyUser.company_id
                                        }
                                    }).then(function(CompanyDetail) {
                                    if (CompanyDetail) {
                                        if (!user) {
                                            var err = new Error('Please enter valid email address.');
                                            done(err, false, {
                                                message: 'Unknown user'
                                            });
                                        } else if (!generalConfig.authenticate(password, user.password)) {
                                            var err = new Error('You have entered an invalid email or password.');
                                            done(err, false, {
                                                message: 'You have entered an invalid email or password.'
                                            });
                                        } else if (user.status === 0) {
                                            var err = new Error('This user status in inactive');
                                            done(err, false, {
                                                message: 'This user status in inactive'
                                            });
                                        } else {
                                            done(null, user, {
                                                message: 'Success'
                                            });
                                        }

                                    } else {
                                        var err = new Error('There is no plan attached with this company');
                                        done(err, user, {
                                            message: 'There is no plan attached with this company!'
                                        });
                                    }
                                })
                            }

                        })

                    } else {
                        var err = new Error('This user does not belong to any company');
                        done(err, false, {
                            message: 'This user does not belong to any company'
                        });
                    }

                }
            })
        } else {

            var err = new Error('You have entered an invalid email or password.');
            done(err, false, {
                message: 'You have entered an invalid email or password.'
            });
        }

    }).catch(function(err) {
        done(err, null);
    });
}));

module.exports = passport;