var fs = require("fs");
var crypto = require('crypto');
var sequlizeConfig = require('../config/sequelize');
var LANG = require('../common/language');
var jwt = require('jwt-simple');
var moment = require('moment');
var db = sequlizeConfig.db;
var master_db = sequlizeConfig.master_db;
var mysql = require('mysql');
var config    = require('../config/database');
var conn = require('../config/mysql-connection');
var nodemailer = require("nodemailer");
var handlebars = require('handlebars');


var connection = conn.connection;

global.DATABASE = "";
global.WS_LIMIT = "20";

/**
 * Secret ket encrypt/decrypt
*/
var saltKey = process.env.SALTKEY;
var secretKey = process.env.SECRETKEY;
var clientKey = process.env.CLIENTKEY;


var host =  process.env.MASTER_DATABASE_HOST;
var user = process.env.MASTER_DATABASE_USERNAME;
var password = process.env.MASTER_DATABASE_PASSWORD;
var default_timezone = process.env.DEFAULT_TIMEZONE;

var fileBasePath = "images/";
var uploadBasePath = "images/uploads/";
var no_image_50 = "images/default/no_images/50X50.png";
var no_image_80 = "images/default/no_images/80X80.png";
var no_image_200 = "images/default/no_images/200X200.png";
var no_image_512 = "images/default/no_images/512X512.png";
var ticketTag = "TC";

var ical = require('ical-generator');

//node mailer configurations

// var smtpTransport = nodemailer.createTransport({
//     service: "mail.softwebcms.com",
//     host:"mail.softwebcms.com",
//     port:2525,
//     auth: {
//         user: "test@softwebcms.com",
//         pass: "G;%S12|:{h/}]4kUR"
//     }
// });

var smtpTransport = nodemailer.createTransport({
    service: "mail.softwebopensource.com",
    host: 'mail.softwebopensource.com',
    port: 587,
    secure: false, // secure:true for port 465, secure:false for port 587
    auth: {
        user: "test@softwebopensource.com",
        pass: "Q9JkuC@.,@PdA5n;zD"
    },
    tls: {
        rejectUnauthorized: false
    }
});






// var fromEmail = "Smart Office <no-reply@smartoffice.com>";
var fromEmail = "Smart Office <smartoffice@softwebsolutions.com>";



var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};

var fileType = {
        "image" : ["jpeg", "jpg", "png", "gif", "svg"],
        "doc" : ["xls", "xlsx", "pdf", "doc", "docx"]
};

var masterUrl = [
    'http://localhost:3000/login',
    'http://smartoffice.local/login',
    'http://admin.softwebsmartoffice.com/login'

];

var masterDoamin = process.env.MASTER_DOMAIN;

var uploadpath = {
    "default"   : {"folder":"default","size_folder":[80]},
    "amenity"   : {"folder":"amenities_images","size_folder":[80]},
    "building"  : {"folder":"building_image","size_folder":[80]},
    "floor"     : {"folder":"floor_plan","size_folder":[80]},
    "space"     : {"folder":"space_image","size_folder":[512, 80]},
    "user"      : {"folder":"user_image","size_folder":[80]},
    "company"   : {"folder":"company_image", "size_folder":[80]},
    "serviceRequest"   : {"folder":"service_request_image", "size_folder":[512, 80]},
    "master"    : {"folder":"company_image", "size_folder":[80]}

};




/**
CUSTOMIZATION START - ASHWIN
*/
function CheckSpaceAvailability(req, res, tokenData, callback){

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;

        var booking_start_date = all_form_fields.booking_start_date;
        var booking_end_date = all_form_fields.booking_end_date;
        var space_id = all_form_fields.space_id;

        var query  = "";
        query += "SELECT s.space_id,";
        query += " space_name, space_capacity, space_notes, ";

        query += "IF( ";
        query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id, booking_id HAVING COUNT(booking_id) > 0 ) ";
        query += "  IS NULL, ";

            query += "IF( ";
            query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
            query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
            query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
            query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id, maintainance_id HAVING COUNT(maintainance_id) > 0 ) ";
            query += "  IS NULL, ";
            query += "  '0', "; //query += "  'Room Available', ";
            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
            query += "  ), ";

        query += "  '1' "; //query += "  'Room not available' ";
        query += "  ) AS is_available ";

        query += " FROM "+company_db_name+".so_spaces AS s ";
        query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";

        if(all_form_fields.space_id && all_form_fields.space_id != ""){
            query += " AND s.space_id = '"+all_form_fields.space_id+"'";
        }
        query += " GROUP BY s.space_id ORDER BY s.space_name";

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    //WS.Output(req, res, false, 200, "Success",results);
                    callback(results);
                }else{
                    results = {};
                    WS.Output(req, res, false, 200, "No data found..",results);
                }
            }
        });
}



/*
    Dynamic domain fetch and set db name by ashwin
*/
function getDomain(req){

    if(req && (req.headers['x-forwarded-host'] || req.headers['host'] )){
     
        var xhost = req.headers['x-forwarded-host'];
        var host = req.headers['host'];
        var subdomain = ((xhost) ? xhost : host);

        if(subdomain){
            var subDomainObj = subdomain.toString().split(".");
            return subDomainObj[0];
        }
    }
}

function getCompanyFromDomain(domain,callback) {
    var companyDomainPrefix = domain;
    master_db.models.companyMaster.findOne(
  
    {
        where: {
            company_domain_prefix: companyDomainPrefix
        }
    }).then(function (data) {

        callback(data);
    

    }).catch(function (err) {
        callback(err);
    });

}

function sendMailWithics(htmlFile,replacements,to,subject,value) {
    readHTMLFile( process.cwd() + '/server/template/' + htmlFile, function(err, html) {
            var template = handlebars.compile(html);
          
            var htmlToSend = template(replacements);
           

 cal = ical({
    domain: 'texas.softwebsmartoffice.com',
    prodId: '//superman-industries.com//ical-generator//EN',
    //timezone: 'America/Chicago',
    events: [value]
}).toString();


                    var mailOptions = {
                                  from: fromEmail, // sender address
                                  to: to, // list of receivers  
                                  subject: subject, // Subject line
                                  html: htmlToSend,
                                 
                                 icalEvent: {
                                    filename: 'invitation.ics',
                                    method: 'request',
                                    content: cal
                                }

                    }
            smtpTransport.sendMail(mailOptions, function (error, response) {
                if (error) { 
                    console.log(error);
                }
            });


        });
}

function sendMail(htmlFile,replacements,to,subject) {
    readHTMLFile( process.cwd() + '/server/template/' + htmlFile, function(err, html) {
            var template = handlebars.compile(html);
          
            var htmlToSend = template(replacements);
           

            var mailOptions = {
                  from: fromEmail, // sender address
                  to: to, // list of receivers  
                  subject: subject, // Subject line
                  html: htmlToSend
            }

         
            smtpTransport.sendMail(mailOptions, function (error, response) {
                if (error) { 
                    console.log(error);
                }
            });
        });
}


// function getDomainReq(req){
//     if(req && req.headers['x-forwarded-host']){
//         var subdomain = req.headers['x-forwarded-host'];
//         if(subdomain){
//             var subDomainObj = subdomain.toString().split(".");
            
//             callback(subDomainObj[0]);
//         }
//     }
// }

/**
 * return valid Database name based on given request
*/
function getDataBase(req, res, callback){
    var hostname = module.exports.getDomain(req);
    
    if(hostname){
        var query = "SELECT `company_db_name` FROM  smartoffice_master.`so_company_master` WHERE  `company_domain_prefix` =  '"+hostname+"' LIMIT 1";
        var result = connection.query(query);
        result.on('result', function(row){
            if(row.company_db_name){
                callback(row.company_db_name);
            }else{
                callback(null);
            }
        });
    }

}

function getRoleId(role){
    var roleName = "";

    if(role === "MasterAdmin"){
        roleName = "1";
    } else if(role === "Admin"){
        roleName = "2";
    } else if(role === "CompanyAdmin"){
        roleName = "3";
    } else if(role === "SubAdmin") {
        roleName = "4";
    } else if(role === "Member") {
        roleName = "5";
    }

    return statusSearch;
}


function getRoleFromDomain(req, res) {



    // 0 stands for company
    // 1 stands  for product admin

    var hostname = module.exports.getDomain(req);
    if(hostname != 'admin') {
        var role  = 1;
        return role;
    }
    else {
        var role = 0;
        return role;
    }
}



function authenticate(plainText, hashedPassword) {
    return encryptPassword(plainText, saltKey) === hashedPassword;
}

function encryptPassword(password) {
    if (!password) return '';
    // return crypto.pbkdf2Sync(password, saltKey, 10000, 64).toString('hex');
     return crypto.pbkdf2Sync(password, saltKey, 10000, 64, 'sha512').toString('hex');
}

/**
 * Convert string first letter into capital (Rk)
*/

function strUpperCase(string){
    return string.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

/**
 * Generate random number for Device Activation Key (Rk)
*/
function generateRandomNum(){
    var timestemp =  (new Date().getTime());
    var randomNumber = Math.floor(timestemp + Math.random() * 999999999999)
    return randomNumber = randomNumber.toString().substring(0, 6);
}

/**
 * Generate random ticket number for Service Request (Rk)
*/
function getTicketNumber(prefix){
    var timestemp =  (new Date().getTime());
    var randomNumber = Math.floor(timestemp + Math.random() * 999999999999)
    return randomNumber = prefix+randomNumber.toString().substring(0, 6);
}

/**
 * Generate and convert current time into UTC time  (Rk)
*/
function getDateTimeUTC(date=""){
    date = (date!='') ? new Date(date) : new Date();
    newDate = date.toISOString().replace(/T/, ' ').replace(/\..+/, '');
    //console.log("========="+date+"=======");
    //var newDate = moment.tz(date, "UTC").format('YYYY-MM-DD h:mm:ss');
    return newDate;
}

/**
 * Return valid formatted Email address (Rk)
*/
function formattedEmail(email){
    var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return (regex.test(email))? email.toLowerCase() : null;
}

/**
 * Get authenticated user obj based on useing authorization token (FM)
*/
function getUserInfo(req) {
    if(req.headers.authorization) {
        var accesstoken = req.headers.authorization.split(" ")[1];
        var obj = jwt.decode(accesstoken, secretKey);        
        return obj.user;

    } else {
        return {
            userId: '',
        };
    }
}

/**
 * Get authenticated user obj based on useing authorization token (FM)
*/
function getUserRole(userId) {
    master_db.models.companyUser
        .findOne({
            where: { user_id: userId },
            attributes: ['user_type'],
        })
        .then(function(data) {
            return data.dataValues.user_type;
        })    
}



/**
 * Generate and return unique GUID (Rk)
*/
function generateGUID() {
   function s4() {
      return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
   }
   return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}


function getTimeZoneDiif(timezone){

    if(timezone == 'America/Los_Angeles') {
        return 7;
    }
    else if(timezone == 'America/Denver') {
        return 6;
    }
    else if(timezone == 'America/Chicago') {
        return 5;
    }
    else {
        return 4;
    }
}

function statusFilter(search){
    var statusSearch = "";

    if(search === "Open" || search === "open" || search === "OPEN"){
        statusSearch = "1";
    } else if(search === "Assigned" || search === "assigned" || search === "assign" || search === "ASSIGNED"){
        statusSearch = "2";
    } else if(search === "Close" || search === "close" || search === "CLOSE"){
        statusSearch = "0";
    }

    return statusSearch;
}

function severityFilter(search){
    var severitySearch = "";

    if(search === "Moderate" || search === "moderate" || search === "MODERATE"){
        severitySearch = "1";
    } else if(search === "High" || search === "high" || search === "HIGH"){
        severitySearch = "2";
    } else if(search === "Low" || search === "low" || search === "LOW"){
        severitySearch = "0";
    }

    return severitySearch;
}

/**
 * Generate File Path
*/

function getFilePath(domain, type, mainV, subV){

    var basePath = uploadBasePath;
    var uploadFolder = "uploads/";
    var serviceObj = uploadpath[type];
    var main = serviceObj.folder;
    var sub = serviceObj.size_folder;

    var generatedPath = {};
    var uploadPath = (domain)? basePath+domain+'/'+main : null;
    var showlink = (domain)? uploadFolder+domain+'/'+main : null;

    if(mainV !== ""){
        if(fs.existsSync(uploadPath)){
            generatedPath.mainLink = showlink;
        }
    }

    if(subV !== ""){
        if(sub.length > 0){
            var subObj = [];
            sub.forEach(function(size){
                if(fs.existsSync(uploadPath+'/'+size+'x'+size)){
                    subObj.push(showlink+'/'+size+'x'+size);
                }
            });
        }
    }

    if(subObj){
        if(subObj.length > 0){
            generatedPath.subLink = subObj;
        }
    };

    return generatedPath;
}

function imageUrl(path){
	return fileBasePath+path;
}

function checkFilePath(path){
    var fileBase = fileBasePath;

    if(path != ""){
        var path = fileBase+path;

        if(!fs.existsSync(path)){
           return false;
        } else {
            return true;
        }
    }
}


function checkMail(email){
    var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return (regex.test(email))? email : null;
}

function getDateTimeZoneWise(date, req){
    var userObj =  getUserInfo(req);
    var timeZone = "Asia/Kolkata";
    var newDate = moment.tz(date, timeZone).format("D MMM, YYYY | h:mm a");
}



function userAccessCheck(req){
    var userObj = module.exports.getUserInfo(req);
    var currentDate = module.exports.getDateTimeUTC();

    var user_id = userObj.data.user_id;

    return master_db.models.companyUser
        .findOne({
            where: { user_id: user_id },
            attributes: ['company_id'],
        })
        .then(function(user) {

            if(user && user.company_id) {

            return  master_db.models.CompanyDetails.findOne({
                    where: {
                        company_id: user.company_id,
                        plan_start_date: { $lte: currentDate },
                        plan_end_date: { $gte: currentDate }
                    }
                })
                .then(function(company) {
                    var access = {};

                    if(company){
                        access.is_renew = (company.is_renew)?company.is_renew :'';
                        access.no_of_month = (company.no_of_month)?company.no_of_month:'';
                        access.no_of_space = (company.no_of_space)?company.no_of_space:'';
                        access.no_of_user = (company.no_of_user)?company.no_of_user:'';
                        access.plan_end_date = (company.plan_end_date)?company.plan_end_date:'';
                        access.plan_start_date = (company.plan_start_date)?company.plan_start_date:'';
                        access.plan_name = (company.plan_name)?company.plan_name:'';
                        access.plan_price = (company.plan_price)?company.plan_price:'';
                        access.company_id = (company.company_id)?company.company_id:'';

                    }

                    return access;
                });
            }
        });
}

/**
* return Amenity total count for datatable
*/
function getAminityTotalCount(req, res, query, callback){

    connection.query(query,function(err, results){
        if(err) { 
            callback(null);
        }
        else {
            callback(results.length);
        }
    });
}

/**
* return Building total count for datatable
*/
function getBuildingTotalCount(req, res, query, callback){
    connection.query(query,function(err, results){
        if(err) { 
            callback(null);
        }
        else {
            callback(results.length);
        }
    });
}

/**
* return Sensor total count for datatable
*/
function getSensorTotalCount(req, res, query, callback){
    
    connection.query(query, function(err, results){
        if(err){
            callback(null);
        }else{
            callback(results.length);
        }
    });
}

/**
* return Device total count for datatable
*/
function getDeviceTotalCount(req, res, query, callback){

    connection.query(query,function(err, results){
        if(err) { 
            callback(null);
        }
        else {
            callback(results.length);
        }
    });
}

/**
* return Floors total count for datatable
*/
function getFloorTotalCount(req, res, query, callback){

    connection.query(query,function(err, results){
        if(err) { 
            callback(null);
        }
        else {
            callback(results.length);
        }
    });
}



/**
* return Floors total count for datatable
*/
function getSpaceTotalCount(req, res, query, callback){
    connection.query(query,function(err, results){
        if(err) { 
            callback(null);
        }
        else {
            callback(results.length);
        }
    });
}

/**
* return service request total count for datatable
*/
function getServiceRequestTotalCount(req, res, database, callback){
    var query = "SELECT count(*) as totalCount FROM "+database+".`so_service_requests` WHERE `deleted_at` IS NULL";
    var result = connection.query(query);
    result.on('result', function(row){
        if(row.totalCount){
            callback(row.totalCount);
        }else{
            callback(null);
        }
    });
}


/**
* return schedule meetings total count for datatable
*/
function getScheduleMeetingTotalCount(req, res, database, callback){
    var user = module.exports.getUserInfo(req);
    var user_id = user.data.user_id;
    var query = "SELECT count(*) as totalCount FROM "+database+".`so_space_booking` WHERE user_id = '"+user_id+"'";
    var result = connection.query(query);
    result.on('result', function(row){
        if(row.totalCount){
            callback(row.totalCount);
        }else{
            callback(null);
        }
    });
}

/**
* return UTC datetime from date and timezone offset
*/
function getUTCDateTime(date="", timezoneOffset="", timezone="") {

    let utcDatetime = '';    
    if (date) {        
        date = moment(date);
        if(timezoneOffset || timezone) {     
            if(timezone){
                timezoneOffset = moment(date).tz(timezone).format('Z');
            }    
            var duration = timezoneOffset.split([':']);									
            var hourSign = (duration[0]) ? Math.sign(duration[0]) : 1;
            var hMinutes = (duration[0]) ? Math.abs(duration[0])*60 : 0;	
            var mMinutes = (duration[1]) ? Math.abs(duration[1]) : 0;
            var totalMin =  (hMinutes+mMinutes);
            if(hourSign==-1) {
                utcDatetime = moment(date).add(totalMin, 'minutes').format('YYYY-MM-DD HH:mm:00');
            } else {
                utcDatetime = moment(date).subtract(totalMin, 'minutes').format("YYYY-MM-DD HH:mm:00");
            }            
        } else {
             utcDatetime = moment(date).format('YYYY-MM-DD HH:mm:00');
        }
    } else {
        utcDatetime = moment.utc().format('YYYY-MM-DD HH:mm:00');
    }  
        
    return utcDatetime;
}

/**
* return user configuration of meeting like google,o365 or not
*/
function configurationUser(req,company_databasename,callback){
    var user = module.exports.getUserInfo(req);
    var user_id = user.data.user_id;    
    connection.query("SELECT google,office_365 FROM "+company_databasename+".`so_configuration_user` WHERE user_id = '"+user_id+"'", function(err, result)
    {
        if (err)
        {
            console.log(err);
        } 
        else
        {
            callback(result[0]);
        }
    });
}

module.exports = {
    uploadBasePath:uploadBasePath,
    getDomain:getDomain,
    getCompanyFromDomain:getCompanyFromDomain,
    uploadpath:uploadpath,
    fileType:fileType,
    secretKey:secretKey,
    clientKey:clientKey,
    authenticate: authenticate,
    encryptPassword: encryptPassword,
    saltKey: saltKey,
    getUserInfo:getUserInfo,
    getUserRole:getUserRole,
    generateRandomNum:generateRandomNum,
    getDateTimeUTC:getDateTimeUTC,
    formattedEmail:formattedEmail,
    generateGUID:generateGUID,
    checkMail:checkMail,
    getFilePath:getFilePath,
    getTimeZoneDiif:getTimeZoneDiif,
    getTicketNumber:getTicketNumber,
    statusFilter:statusFilter,
    severityFilter:severityFilter,
    getDateTimeZoneWise:getDateTimeZoneWise,
    userAccessCheck:userAccessCheck,
    fileBasePath:fileBasePath,
    checkFilePath:checkFilePath,
    ticketTag:ticketTag,
    getDataBase:getDataBase,
    getAminityTotalCount:getAminityTotalCount,
    getBuildingTotalCount:getBuildingTotalCount,
    getSensorTotalCount: getSensorTotalCount,
    getDeviceTotalCount:getDeviceTotalCount,
    getFloorTotalCount:getFloorTotalCount,
    getSpaceTotalCount:getSpaceTotalCount,
    getServiceRequestTotalCount:getServiceRequestTotalCount,
    getScheduleMeetingTotalCount:getScheduleMeetingTotalCount,
    strUpperCase:strUpperCase,
    host:host,
    user:user,
    password:password,
    getRoleFromDomain: getRoleFromDomain,
    masterUrl: masterUrl,
    default_timezone: default_timezone,
    CheckSpaceAvailability: CheckSpaceAvailability,
    masterDoamin:masterDoamin,
    no_image_80:no_image_80,
    no_image_200:no_image_200,
    imageUrl:imageUrl,
    fromEmail:fromEmail,
    smtpTransport:smtpTransport,
    readHTMLFile:readHTMLFile,
    sendMail:sendMail,
    sendMailWithics:sendMailWithics,
    getUTCDateTime:getUTCDateTime,

    configurationUser:configurationUser
};