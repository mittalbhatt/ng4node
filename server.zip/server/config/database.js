var dotenv = require('dotenv').config();


module.exports = {
    //This is your MYSQL Database configuration
    // db: {
    //     name: "smartoffice_softweb",
    //     username: "root",
    //     password: "password",
    //     host:"192.168.3.113",
    //     port:3306
    // },
    master_database: {
        username: process.env.MASTER_DATABASE_USERNAME,
        password: process.env.MASTER_DATABASE_PASSWORD,
        name: process.env.MASTER_DATABASE_NAME,
        host: process.env.MASTER_DATABASE_HOST,
        port: process.env.DB_PORT
    },
    modelsDir : {
        path : __dirname + '/../models',
        master_path : __dirname + '/../models'
    },
    
    databases: {
        path: {
            path: __dirname + '/../models',
        },
        master_path: {
            path: __dirname + '/../models'
        }
    }


};