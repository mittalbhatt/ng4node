var mysql = require('mysql');
var config    = require('./database');

var connection = mysql.createConnection({
  host     : config.master_database.host,
  user     : config.master_database.username,
  password : config.master_database.password,
  database : config.master_database.name,
  debug    : false
});

connection.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
 
  console.log('connected as id ' + connection.threadId);
});

module.exports = {
    connection:connection
};