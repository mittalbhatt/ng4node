'use strict';

var appAuth = require('./controllers/authController');
var floorAuth = require('./controllers/floorController');
var spaceAuth = require('./controllers/spaceController');
var localStorage = require('localStorage');

var jwt = require('jwt-simple');
var generalConfig = require('./config/generalConfig');
var crypto = require('crypto');
var base64 = require('base-64');
var utf8 = require('utf8');

var oauthserver = require('oauth2-server');
var oAuthModel = require('./config/oAuthModel');

module.exports = function (app, io) {


	var oauthserver = require('oauth2-server');
    var oAuthModel = require('./config/oAuthModel');

    /* Oauth server setup */
    app.oauth = oauthserver({
        model: oAuthModel,
        grants: ['password', 'refresh_token','client_credentials', 'authorization_code'],
        debug: false,
        accessTokenLifetime: oAuthModel.accessTokenLifetime,
        refreshTokenLifetime: oAuthModel.refreshTokenLifetime
    });


	app.get('/webapi/getToken', function(req,res,next){
        localStorage.clear();
        var secretKey = generalConfig.secretKey;
        var randomnumber = Math.random().toString(36).slice(-10);
        localStorage.setItem('randNum', randomnumber);
        var randNum = localStorage.getItem('randNum');
        var token = jwt.encode({
            'import': randomnumber
        }, secretKey);

        var text = 'screteKEY:'+token;
        var bytes = utf8.encode(text);
        var encoded = base64.encode(bytes);
        var token = encoded;

        if(token)
        {
            res.json({
                status: true,
                data: token,
                message: 'Token get successfully.'
            });
        }
        else
        {
            res.json({
                status: false,
                data: null,
                message: 'Failed to get token.'
            });
        }
    });



    app.all('/webapi/login', oAuthModel.allowJson, app.oauth.grant());

        // app.all('/api/*', app.oauth.authorise(), function(req, res, next) {
        //     next();
        // });


     app.use(function(err, req, res, next) {

        return res.json({
            status: 'fail',
            message:((err.message)?err.message : err.error_description),
        });
    });


	// login routes
	// app.post('/webapi/login', appAuth.login);
    app.get('/webapi/signout', appAuth.signout);

    // socket routes
    var socketRoutes = require('./routes/socketRoute.js');
	new socketRoutes(app);

    // socket routes
    var cronRoutes = require('./routes/cronRoute.js');
    new cronRoutes(app, io);

    // user routes
    var userRoutes = require('./routes/userRoutes.js');
	new userRoutes(app);

	// building routes
    var buildingRoutes = require('./routes/buildingRoute.js');
	new buildingRoutes(app);

	// Floors routes
    var floorRoutes = require('./routes/floorRoute.js');
	new floorRoutes(app);

	// amenities routes
    var amenitiesRoutes = require('./routes/amenitiesRoute.js');
	new amenitiesRoutes(app);

	// Space routes
    var spaceRoutes = require('./routes/spaceRoute.js');
	new spaceRoutes(app);

	// Settings  routes
    var settingsRoutes = require('./routes/settingsRoute.js');
	new settingsRoutes(app);

	// Sensor Management  routes
    var sensorManageRoute = require('./routes/sensorManageRoute.js');
	new sensorManageRoute(app);

    // Device Management  routes
    var deviceRoute = require('./routes/deviceRoute.js');
	new deviceRoute(app);

    //Company routes
    var companyRoutes = require('./routes/companyRoutes.js');
    new companyRoutes(app);

	// Event routes
    var eventRoutes = require('./routes/eventRoute.js');
	new eventRoutes(app);

    // Plan routes
    var planRoutes = require('./routes/planRoute.js');
    new planRoutes(app,io);

    // Plan routes
    var billingRoutes = require('./routes/billingRoutes.js');
    new billingRoutes(app);
    // Service Request routes
    var serviceRequestRoutes = require('./routes/serviceRequestRoutes.js');
    new serviceRequestRoutes(app);

    // Dashboard routes
    var dashboardRoutes = require('./routes/dashboardRoutes.js');
    new dashboardRoutes(app);

    // Search routes
    var searchRoutes = require('./routes/searchRoute.js');
	new searchRoutes(app);

};

