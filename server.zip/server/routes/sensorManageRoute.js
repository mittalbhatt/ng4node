'use strict';

var appAuth = require('../controllers/sensorManageController');
var spaceAuth = require('../controllers/spaceController');
var tablAuth = require('../controllers/tabletManageController');
var deviceAuth = require('../controllers/deviceMasterController');



module.exports = function (app) {
	app.get('/api/sensor/spaceList', spaceAuth.getSpaceList);
	app.get('/api/sensor/deviceList',deviceAuth.deviceList);
	app.post('/api/sensor/addSensor',appAuth.addSensor);
	app.get('/api/sensor/getSensorList', appAuth.getSensorList);
	app.post('/api/sensor/editSensor',appAuth.getEditSensor);
	app.post('/api/sensor/updateSensor',appAuth.updateSensor);
	app.post('/api/sensor/removeSensor',appAuth.removeSensor);
	app.post('/api/sensor/updateSensorStatus',appAuth.updateSensorStatus);

	// Tablet sensor
	app.post('/api/sensor/addTablet',tablAuth.addTablet);
	app.get('/api/sensor/getTabletList', tablAuth.getTabletList);
	app.post('/api/sensor/editTablet',tablAuth.getEditTablet);
	app.post('/api/sensor/updateTablet',tablAuth.updateTablet);
	app.post('/api/sensor/removeTablet',tablAuth.removeTablet);
	app.post('/api/sensor/updateTabletStatus',tablAuth.updateTabletStatus);
	app.post('/api/sensor/updateTabletBookStatus',tablAuth.updateTabletBookStatus);
};
