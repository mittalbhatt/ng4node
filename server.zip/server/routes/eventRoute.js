'use strict';

var appAuth = require('../controllers/eventController');
var appSpace = require('../controllers/spaceController');

module.exports = function (app) {
	//app.get('/api/event/userinfo', appAuth.userInfo);	
    app.get('/api/event/list-data', appAuth.allListingData);
	app.post('/api/event/book-event', appAuth.bookEvent);
	app.get('/api/event/event-update-data/:id', appAuth.getEventById);
	app.post('/api/event/update-event', appAuth.updateEvent);
	app.get('/api/schedule/getschedule', appAuth.getScheduleList);
	app.post('/api/schedule/delete-meeting',appAuth.removeMeeting);
	//app.post('/api/schedule/meeting', appAuth.getMeetingDetailsById);
	app.post('/api/schedule/space/meeting', appSpace.getMeetingSpaceById);
	app.get('/api/schedule/all-BFS-data', appSpace.allBuildingFloorListData);
	//app.post('/api/schedule/meeting/details', appAuth.getMeetingDetailsById)
	app.get('/api/meetings/upcoming/:spaceId',appAuth.getUpcomingMeetings);
	app.get('/api/meetings/current/:spaceId',appAuth.getCurrentMeetings);
	app.post('/api/schedule/my-meetings', appAuth.getMyMeetingList);

	app.post('/api/event/alexabookspace', appAuth.alexaBookspace);

};
