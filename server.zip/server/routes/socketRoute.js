'use strict';

var socketroute = require('../controllers/socketController');

module.exports = function(app) {
	//app.post('/api/login', appUser.login);
    app.get('/api/getsocketspaces', socketroute.getSocketSpaces);
};
