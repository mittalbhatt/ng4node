'use strict';

var appAuth = require('../controllers/spaceController');

module.exports = function (app) {
	app.get('/api/space', appAuth.spaceList);
    app.get('/api/space/floor-list/:id', appAuth.floorList);
    app.get('/api/space/space-list-id/:id',appAuth.spaceListData);
    app.get('/api/space/all-list-data/', appAuth.AllListingData);
	app.post('/api/space/addspaces', appAuth.addSpace);
	app.get('/api/space/edit/:id', appAuth.getSpaceById);
	app.post('/api/space/updatespaces', appAuth.updateSpace);
	app.post('/api/space/updatespacesstatus', appAuth.updateSpaceStatus);
	app.post('/api/space/delete-space', appAuth.removeSpace);
};
