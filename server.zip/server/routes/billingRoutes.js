'use strict';

var billing = require('../controllers/billingController');

module.exports = function(app) {
	// app.post('/api/addBuilding', appAuth.addBuilding);
	app.get('/api/billing/getbilling', billing.getBilling);
	app.post('/api/billing/getFeatureTitle',billing.getFeatures);
	// app.post('/api/editBuilding', appAuth.editBuilding);
	// app.post('/api/updateBuilding', appAuth.updateBuilding);
	// app.post('/api/removeBuilding', appAuth.removeBuilding);
	// app.post('/api/updateBuildingSatus', appAuth.updateBuildingSatus);
}; 