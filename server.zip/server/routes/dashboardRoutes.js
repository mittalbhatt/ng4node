'use strict';

var appDash = require('../controllers/dashboardController');

module.exports = function (app) {
	app.get('/api/dashboard/meetings', appDash.getMeetings);
};
