'use strict';

var users = require('../controllers/userController');
var appUser = require('../controllers/authController');
var config = require('../config/generalConfig');


module.exports = function(app) {
	
	app.post('/api/login', appUser.login);
	app.post('/webapi/register', appUser.register);
	app.post('/webapi/save-office', appUser.saveUserOffice);
    app.get('/api/signout', appUser.signout);
	app.get('/api/users', users.userList);
	app.get('/api/users/user-update-data/:id', users.getUserById);
	app.put('/api/users', users.update);
	app.post('/api/users',users.insert);
	app.post('/api/users/status-update',users.updateStatus);
	app.get('/api/users/delete-user/:id',users.delete);
	app.post('/api/user/changePassword', users.changePassword);
	app.get('/api/user/info/', appUser.getUserInfo);
	app.get('/api/users/get-current-users', users.getCurrentUserInfo);
	app.post('/api/users/update-profile',users.updateProfile);
	app.get('/api/users/get-role-from-domain', appUser.getRoleFromDomain);
	app.get('/api/getDomain',users.getDomainReq);
	app.get('/webapi/getDomain',users.getDomainReq);
	app.get('/webapi/getCompanyFromDomain/:domain',users.getCompanyFromDomain);
	app.get('/api/companyInfo/:id',users.getCompanyInfo);
	app.get('/webapi/getCompanyConfiguration',users.getCompanyConfiguration);
	app.post('/api/users/remove-profile-logo',users.removeProfileLogo);	
	app.post('/webapi/users/forgotPassword',users.forgotPassword);
	app.post('/webapi/users/reset-password',users.updatePassword);
	
};

