'use strict';

var cronroute = require('../controllers/cronController');

module.exports = function(app, io) {
    app.get('/cron/checkupcomingbooking', cronroute.getSocketCheckUpcomingSpaceBooking(io));
    app.get('/cron/autocheckoutentry', cronroute.AutoCheckOutEntry(io));

};
