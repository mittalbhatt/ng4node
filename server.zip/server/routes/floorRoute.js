'use strict';

var appAuth = require('../controllers/floorController');
var buildingAuth = require('../controllers/buildingController');

module.exports = function (app) {

    app.get('/api/floor/building-list', appAuth.buildingList);
	app.get('/api/floor/getfloors', appAuth.floorsList);
	app.post('/api/floor/addfloors', appAuth.insertFloor);
	app.get('/api/floor/floor-update-data/:id', appAuth.getFloorById);
	app.post('/api/floor/updatefloors', appAuth.updateFloor);
	app.post('/api/floor/updatefloorstatus', appAuth.updateFloorStatus);
	app.post('/api/floor/delete-floor', appAuth.removeFloorById);
	app.post('/api/floor/floor-count', buildingAuth.FloorCount);

};