'use strict';

var users = require('../controllers/userController');
var appSR = require('../controllers/serviceRequestController');
var appEvent = require('../controllers/eventController');



module.exports = function(app) {
	app.get('/api/serviceRequest/getServiceRequestList', appSR.getServiceRequestList);
	app.get('/api/serviceRequest/getInitList', appSR.getInitList);
	app.post('/api/serviceRequest/addServiceRequest', appSR.addServiceRequest);
	app.post('/api/serviceRequest/updateServiceRequest', appSR.updateServiceRequest);
	app.post('/api/serviceRequest/getEditServiceRequest', appSR.getEditServiceRequest);
};

