'use strict';

var appAuth = require('../controllers/searchController');

module.exports = function (app) {
	app.get('/api/search/all-list-data', appAuth.allListingData);
	app.get('/api/search/get-space-listing', appAuth.getSearchSpacesList);
};
