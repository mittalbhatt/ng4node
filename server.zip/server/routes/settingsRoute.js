'use strict';

var appAuth = require('../controllers/settingsController');

module.exports = function(app) {
	app.post('/api/addalertemails', appAuth.addalertemails);
	app.get('/api/getSoSetup', appAuth.getSoSetup);
	app.post('/api/addsosId', appAuth.addSOSId);
	app.get('/api/getalertemails', appAuth.getalertemails);
	app.post('/api/company/uploadCompanyLogo', appAuth.uploadCompanyLogo);
	app.get('/api/company/getEditSettings', appAuth.getSettings);
	app.post('/api/company/showPoweredBy', appAuth.showPoweredBy);
	app.post('/api/company/timingFormat', appAuth.timingFormat);
	app.post('/api/company/getTimingInfo', appAuth.getTimingInfo);
	app.post('/api/company/appIntegration', appAuth.appIntegration);
	app.post('/api/company/setApiIntegration', appAuth.setApiIntegration);
	app.get('/api/company/getAppIntegrationInfo', appAuth.getAppIntegrationInfo);
	app.post('/api/company/removeCompanyLogoImage', appAuth.removeCompanyLogoImage);
	app.get('/api/company/getSensors', appAuth.getSensors);
	app.post('/api/company/updateSensors', appAuth.updateSensors);
	app.get('/api/company/getPushNotification', appAuth.getPushNotification);
	app.post('/api/company/updatePushNotification', appAuth.updatePushNotification);
};