'use strict';

var plan = require('../controllers/planController');

module.exports = function (app) {
	
	app.get('/api/package/getpackage',plan.packageList);
	app.get('/api/package/package-update-data/:id', plan.getPlanById);
	app.post('/api/package/update_package', plan.updatePlan);
	app.post('/api/package/getpackage',plan.insertPackageData);
	app.post('/api/package/status-update', plan.packageStatusUpdate);
	app.post('/api/package/delete-package/:id',plan.deletePlan);
	app.get('/api/package/get-duration', plan.getDuration);
	app.get('/api/package/get-features', plan.getFeatures);
};