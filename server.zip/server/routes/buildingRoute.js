'use strict';

var appAuth = require('../controllers/buildingController');

module.exports = function(app) {
	app.post('/api/addBuilding', appAuth.addBuilding);
	app.get('/api/getBuilding', appAuth.getBuilding);
	app.post('/api/editBuilding', appAuth.editBuilding);
	app.post('/api/updateBuilding', appAuth.updateBuilding);
	app.post('/api/removeBuilding', appAuth.removeBuilding);
	app.post('/api/updateBuildingSatus', appAuth.updateBuildingSatus);
};