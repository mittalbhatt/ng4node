'use strict';

var appAuth = require('../controllers/companyController');

module.exports = function (app) {

	app.get('/api/company/getcompany', appAuth.companyList);
	app.post('/api/company/status-update', appAuth.companyStatusUpdate);
	app.get('/api/company/company-update-data/:id', appAuth.getCompanyById);
	app.put('/api/company/update_company', appAuth.updateCompany);

};