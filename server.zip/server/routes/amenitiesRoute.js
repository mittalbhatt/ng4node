'use strict';

var appAuth = require('../controllers/amenitiesController');
var mainAuth = require('../controllers/authController');

module.exports = function(app) {
	app.get('/api/accessRights', mainAuth.getAccessRight);
	app.post('/api/addAmenity', appAuth.addAmenity);
	app.get('/api/getAmenity', appAuth.getAmenity);
	app.post('/api/getEditAmenity', appAuth.getEditAmenity);
	app.post('/api/updateAmenity', appAuth.updateAmenity);
	app.post('/api/removeAmenity', appAuth.removeAmenity);
	app.post('/api/updateAmenityStatus', appAuth.updateAmenityStatus);
};