'use strict';

var deviceAuth = require('../controllers/deviceMasterController');



module.exports = function (app) {
	app.get('/api/device/getDeviceList', deviceAuth.getDeviceList);
};
