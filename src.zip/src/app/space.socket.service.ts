import { Injectable } from '@angular/core';
import { Constants } from './common/services/constants';
import { HttpClient } from './common/services/http.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import * as io from 'socket.io-client';

@Injectable()
export class SpaceSocketService {

  //private url = 'http://192.168.3.146:3000';
  private url = window.location.origin; //window.location.origin;
  private requestUrl:String;
  moduleParam:any;
  private socket;

  constructor(private constant:Constants, private httpClient:HttpClient) {
      this.requestUrl = this.constant.baseUrl;
  }

  addNewSpacesForSocket(space_id, space_name){
    //this.socket.emit('add-message', message);
    this.socket.emit('add-new-spaces', { space_id: space_id, space_name: space_name, available : 0 });
  }


  SpaceAvailable(space_id){
    this.socket.emit('space-available', { space_id: space_id});
  }
  SpaceNotAvailable(space_id){
    this.socket.emit('space-not-available', { space_id: space_id});
  }

  getSpaceInformation(){
      let url = this.requestUrl+'getsocketspaces';
      return this.httpClient.get(url);
  }
  // getSocketSpaces() {
    
  //   let observable = new Observable(observer => {
  //     this.socket = io('http://texas.softwebsmartoffice.com');
  //     this.socket.on('getNewSpaces', (data) => {
  //       observer.next(data);
        
  //     });
  //     return () => {
  //       this.socket.disconnect();
  //     };
  //   })
  //   return observable;
  // }

  // getMessages() {

  //   let observable = new Observable(observer => {
  //     this.socket = io('http://texas.softwebsmartoffice.com');
  //     this.socket.on('getNewSpaces', (data) => {
  //       observer.next(data);
  //     });
  //     return () => {
  //       this.socket.disconnect();
  //     };
  //   })
  //   return observable;
  // }
}