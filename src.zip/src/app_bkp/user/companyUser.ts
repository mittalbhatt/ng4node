export class companyUser {
  company_user_id: number;
  building_id:number;
  floor_id:number;
}

