import { Component, OnInit,ViewChild } from '@angular/core';
import {UserService} from "./user.service";
import {User} from "./user";
import { ActivatedRoute, Router } from '@angular/router';
import { Constants } from '../common/services/constants';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { AuthService } from '../auth/auth.service';
import { LocalStorageModule } from 'angular-2-local-storage';

declare var jQuery: any;
declare var swal: any;

@Component({
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

    users: any;
    errMesg: any;
    baseUrl: any;
    moduleParam: any;
    errorMessage: any = {};
    localVal: any;
    Formtoken: any;
    DomainUrl:any;

    private pageLength: any;
    public popCarrierid: number;
    public _popupMtitle: string;
    public _popupMsg: string;
    public _popupBtn;number;

    constructor(private userService: UserService, private auth: AuthService, private _notificationService: NotificationService, public router: Router, private constant: Constants) {}

    ngOnInit() {
        this.moduleParam = this.constant.user;
        this.baseUrl = this.constant.baseUrl + this.moduleParam.user_link;
        //this.getUser();
        this.getUserData(this.baseUrl);
        this.getFormToken();
        var url = window.location.origin;
        this.DomainUrl = url.split('//')[1].split('.')[0];
    }

    getUser() {
        this.userService.getUsers()
            .subscribe((data) => {
                this.users = data;

            })
    }

    getUserData(serviceUrl) {
        var self = this;
        jQuery.fn.dataTableExt.sErrMode = function(settings, helpPage, message) {
            if (message) {

            }
        };

        var self = this;
        var dataTable = jQuery("#user-list")
        .on( 'processing.dt', function ( e, settings, processing ) {
            if(processing)
            {
                if(!($('#user-list').find('#loader-container').length))
                {
                    $("#user-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
                }
            }
            else {
                $('#loader-container').remove();
            }
        })
        .DataTable({
            "destroy": true,
            "serverSide": true,
            "lengthMenu": self.constant.showRecords,
            "scrollX": false,
            "scrollY": false,
            "responsive": true,
            "order": [[1, 'asc']],


            "ajax": {

                url: serviceUrl,
                type: 'get',
                 "beforeSend": function(xhr){
                    xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
                },
                "dataFilter": function(data){
                    var json = $.parseJSON(data);
                    var respData = json;
                    if(respData.status === "fail"){
                        self.auth.logout();
                        self._notificationService.add(new Notification('error', self.constant.expired_message));
                    }
                    return JSON.stringify(json);
                }

            },
            "columns": [{
                    "data": "user_id",
                    "name": "user_id",
                    "width": "3%",
                    "orderable": false,
                    "searchable": false,
                                    },


                {
                    "data": "profile_picture",
                    "name": "profile_picture",
                    "width": "40%",
                    "orderable": false,
                    "searchable": false,
                    "render": function(data, type, full, meta) {
                       var imageHtml = "";
                       /*if (full.profile_picture != null && full.image_path != "") {
                           imageHtml = "<img  src='"+full.image_path+"' title='" +  full.first_name  + "' [onError]='this.src=" + "uploads/noImage.png" + "' width='70'  style=border:1px;border-style:solid;border-color:#021a40;  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span><span  style= font-weight:bold;font-size:16px >" + full.first_name + " " + full.last_name + "</span><br><span style = font-style:italic;color:green;font-size:14px;font-weight:bold;><b>" + "(" + full.companyUser.user_type + ")" + "</b><span></span>"


                       } else {
                           imageHtml = "<img  src='uploads/noImage.png' style=border:1px;border-style:solid;border-color:#021a40; title='" + full.first_name + "' width='70' />&nbsp;<span><span style= font-weight:bold;font-size:16px>" + full.first_name + "&nbsp;" + full.last_name + "</span><br><span  style =font-style:italic;color:green;font-size:14px;font-weight:bold;>" + "(" + full.companyUser.user_type + ")" + "<span></span>"
                       }*/

                        imageHtml = '<div class="company_box">';
                        imageHtml += '<span class="companyImage">';

                                if (full.profile_picture != null && full.image_path != "") {
                                    imageHtml += '<img style="cursor: pointer"; src="'+full.image_path+'" onerror="this.onerror=null;this.src=\'/images/default/no_images/70X70.png\';" class="borderimg" width="70" height="70" />';
                                }else{
                                    imageHtml += '<img style="cursor: pointer"; src="/images/default/no_images/70X70.png" onerror="this.onerror=null;this.src=\'/images/default/no_images/70X70.png\';" width="70"  class="borderimg" />';
                                }

                            imageHtml += '</span>';
                            imageHtml += '<span class="companyText">';
                                imageHtml += '<span class="companyname">'+full.first_name+' '+full.last_name+'</span>';
                                imageHtml += '<br />';
                                imageHtml += '<span class="subdomain">';
                                    imageHtml += '<div class="ipad_company_url">';
                                        imageHtml += '<i class="fa fa-key" aria-hidden="true" style="margin-right:5px;"></i> '+full.companyUser.user_type;
                                    imageHtml += '</div>';
                                imageHtml += '</span>';
                                imageHtml += '<div class="company_email">';

                                    imageHtml += '<i class="fa fa-phone" aria-hidden="true" style="margin-right:5px;"></i>';
                                    imageHtml += '<span> '+full.phone_number+'</span>';
                                imageHtml += '</div>';
                            imageHtml += '</span>';
                        imageHtml += '</div>';

                       return imageHtml;
                    }
                },
                {
                    "data": "email",
                    "name": "email",
                    "width": "30%"
                },
                {
                    "data": "status",
                    "name": "status",
                    "width": "3%",
                    "orderable": false,
                    "render": function(data, type, full, meta) {
                        var statusStr = '';
                        if(full.companyUser.user_type != 'CompanyAdmin' &&  full.companyUser.user_type != 'MasterAdmin') {
                            statusStr = '<div title="Inactive"  class="checkbox-bird user-status-update" id="buildingSatusUpdate_' + full.user_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox"/><label></label></div>';
                            if (full.status == 1) {
                                statusStr = '<div title="Active"  class="checkbox-bird green user-status-update" id="buildingSatusUpdate_' + full.user_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox" checked/><label></label></div>';
                            }
                        }
                        else {
                            statusStr = '<div title="Inactive"  class="checkbox-bird " id="buildingSatusUpdate_' + full.user_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox"/><label></label></div>';
                            if (full.status == 1) {
                                statusStr = '<div title="Active"   class="checkbox-bird green " id="buildingSatusUpdate_' + full.user_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox" checked/><label></label></div>';
                            }
                        }
                        return statusStr;
                    }
                },
                {
                    "data": "action",
                    "name": "action",
                    "orderable": false,
                    "searchable": false,
                    "width": "12%",
                    "render": function(data, type, full, meta) {
                        var actionLinks = '';
                        if(full.companyUser.user_type != 'CompanyAdmin' &&  full.companyUser.user_type != 'MasterAdmin') {
                            // actionLinks += '<a title="Edit" id="' + full.user_id + '" class="btn btn-primary-outline btn-sm user-edit"><i class="fa fa-edit"></i></a>&nbsp;';
                            // actionLinks += '<a title="Delete" class="btn btn-danger-outline btn-sm user-delete" id="deleteData_' + full.user_id + '"><i class="fa fa-trash-o"></i></a>';
                            actionLinks += '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="' + full.user_id + '" class="tabledit-edit-button btn btn-sm btn-default user-edit" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button><button type="button" id="delete_'+full.user_id+'" class="tabledit-delete-button btn btn-sm btn-default user-delete" style="float: none;"><span class="glyphicon glyphicon-trash"></span></button></div>';



                        }
                        else {
                            actionLinks += '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="' + full.user_id + '" class="tabledit-edit-button btn btn-sm btn-default user-edit" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button></div>';
                            /*actionLinks += '<a title="Delete" class="btn btn-danger-outline btn-sm user-delete" style="background-color: #dbe4ea ; border-color: #dbe4ea; color: #6c7a86;  pointer-events: none; cursor: default;" id="deleteData_' + full.user_id + '"><i class="fa fa-trash-o"></i></a>';*/
                        }
                        return actionLinks;
                    }
                }
            ],
            fnRowCallback: function(nRow, aData, iDisplayIndex) {


                var display_number = self.dataTableNo(dataTable, iDisplayIndex);
                jQuery('td:eq(0)', nRow).html(display_number);
                $('td:eq(0)',nRow).addClass('aligncenter');
                $('td:eq(3)',nRow).addClass('aligncenter');
                $('td:eq(4)',nRow).addClass('aligncenter');

                /*var name = '<div class="color-blue">' + aData.email + '</div><br>' + aData.phone_number;
                jQuery('td:eq(2)', nRow).html(name);*/

                // var str = '<a title="Edit" id="' + aData.user_id + '" class="btn btn-primary-outline btn-sm user-edit"><i class="fa fa-edit"></i></a>&nbsp;<a title="Delete" class="btn btn-danger-outline btn-sm user-delete" id="deleteData_' + aData.user_id + '"><i class="fa fa-trash-o"></i></a>';
                // jQuery('td:eq(6)', nRow).html(str);
                // return nRow;
            },
            fnDrawCallback: function(oSettings) {

                jQuery(document).on('click', 'button.user-edit', function(e) {
                    var userId = this.id;
                    self.editData(userId);
                    e.preventDefault();
                });

                jQuery(document).on('click', '.user-status-update', function(e) {
                    var userStatusIdVal = this.id;
                    e.preventDefault();
                    swal({
                            title: "Are you sure?",
                            text: "This User status will be update!",
                            type: "info",
                            showCancelButton: true,
                            confirmButtonClass: "btn-confirm",
                            confirmButtonText: "Update",
                            cancelButtonText: "Cancel"
                        },
                        function(isConfirm) {
                            if (isConfirm) {
                                var userIdSplitted = userStatusIdVal.split('_');
                                var userStatusId = userIdSplitted[1];
                                var userStatus = userIdSplitted[2];
                                self.userStatusUpdate(userStatusId, userStatus, dataTable);
                            }
                        });
                });

                jQuery(document).on('click', 'button.user-delete', function(e) {
                    var deleteId = this.id;
                    var delId = deleteId.split('_');
                    var delIdFinal = delId[1];


                    e.preventDefault();
                    swal({
                            title: "Are you sure?",
                            text: "You want to remove this ?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Delete",
                            cancelButtonText: "Cancel"
                        },
                        function(isConfirm) {
                            if (isConfirm) {
                                self.deleteData(delIdFinal, dataTable);
                            }

                        });
                });

            }
        });
    }


    deleteData(userId, dataTable) {
        // let data = {"id":floorId, "_csrf":this.Formtoken}
        this.userService.userDelete(userId)
            .subscribe((data) => {
                    if (data) {
                        this.localVal = data;
                        if (this.localVal.success == true) {
                            this.getUserData(this.baseUrl);
                            this._notificationService.add(new Notification('success', this.localVal.message));

                        } else {
                            this._notificationService.add(new Notification('error', this.localVal.message));
                        }
                    }
                },
                error => {
                    this.errorMessage = < any > error
                });
    }

    editData(userId) {
        this.router.navigate(['/user/edit/', userId]);
    }

    userStatusUpdate(userId, status, dataTable) {
        this.userService.userStatusUpdate({
                'user_id': userId,
                'status': status,
                "_csrf": this.Formtoken
            })
            .subscribe((data) => {
                    if (data) {
                        this.localVal = data;
                        if (this.localVal.success == true) {
                            dataTable.ajax.reload(null, false);
                            this.getUserData(this.baseUrl);
                            this._notificationService.add(new Notification('success', this.localVal.message));

                        } else {
                            this._notificationService.add(new Notification('error', this.localVal.message));
                        }
                    }
                },
                error => {
                    this.errorMessage = < any > error
                });
    }



    getFormToken() {
        this.auth.getToken()
            .subscribe(
                response => {
                    if (response) {
                        this.Formtoken = response;
                    }
                },
                error => {
                    this.errorMessage = < any > error
                });
    }




    dataTableNo(dataTable, iDisplayIndex) {
        var pageinfo = dataTable.page.info();
        var currentpage = (pageinfo.page) * pageinfo.length;
        var display_number = (iDisplayIndex + 1) + currentpage;
        return display_number;
    }

}