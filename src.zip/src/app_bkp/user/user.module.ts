import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { userRoute } from './user.route';
import { FormsModule, FormBuilder } from '@angular/forms';
import { HttpModule,RequestOptions} from '@angular/http';
import { UserComponent } from './user.component';
import { UserUpdateComponent } from './edit.component';
import { UserAddComponent } from './add.component';
import { UiSwitchModule } from 'ng2-ui-switch';
import { DefaultRequestOptions } from '../common/services/default-request-options.service';
import {UserService} from './user.service';
import {SpaceService} from '../space/space.service';
import { EqualValidator } from './../common/directives/equal-validator.directive';  // import validator



@NgModule({
  imports: [
    CommonModule,
    userRoute,
    FormsModule,
    UiSwitchModule
  ],
  providers: [UserService, FormBuilder, SpaceService,

  { provide: RequestOptions, useClass: DefaultRequestOptions }

  ],
  declarations: [UserComponent, UserUpdateComponent,UserAddComponent,EqualValidator]
})
export class UserModule { 


}