import { NgModule,ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { UserAddComponent } from './add.component';
import {UserUpdateComponent} from './edit.component';
import { FormsModule,ReactiveFormsModule }   from '@angular/forms';
import { UserService } from './user.service';
import { PlanExpiredGuardService } from '../common/services/plan-expired-guard.service';


export const userRoutes: Routes = [
   	{path: '', component: UserComponent },
   	{path: 'add',canActivate: [PlanExpiredGuardService], component: UserAddComponent},
 	{path: 'edit/:id', canActivate: [PlanExpiredGuardService], component: UserUpdateComponent}
];

export const userRoute: ModuleWithProviders = RouterModule.forChild(userRoutes);




