export class User {
  profile_picture: string;
  profile_image: string;
  phone_number: number;
  first_name: string;
  image_name: string;
  last_name: string;
  user_type: string;
  user_id: number;
  country: string;
  status: number;
  email: string;
  old_profile_image: string;

}

