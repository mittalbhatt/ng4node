import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {UserService} from "./user.service";
import {companyUser} from "./companyUser";
import {User} from "./user";
import { NotificationService, Notification } from '../common/services/notifications.service';
import { AuthService } from '../auth/auth.service';
import { SpaceService } from '../space/space.service';
import { EqualValidator } from './../common/directives/equal-validator.directive';  // import validator
import { Constants } from '../common/services/constants';



/**
 * User Update Component
 *
 */
 declare var swal: any;


@Component({
	templateUrl: './edit.html',
  providers: [UserService]

})

export class UserUpdateComponent implements OnInit {
  userModel = {
    'first_name':'',
    'last_name':''
  }; 

  buildingList = [
    {id:'1',value:'India'},
    {id:'2',value:'US'},
    {id:'3',value:'Chicago'}
  ];
  

  private base64textString:String="";
  public responseData: any;
  errorMessage: any = {};
  private submitFlag: any;
  removeImage: boolean =  false;

  floorList: any;
  floorDisabled: any;
  listResponseData: any;
  localVal: any;
  private id: any;
  Formtoken:any;
  users: any;
  company: any;
  companyUsers: any;
  filename:string='';
  binaryString:any;
  files:any;
  file:any;
  role:any;
  dataLoadingStatus: boolean;

  constructor(private userService: UserService, private constant: Constants,private _spaceService:SpaceService, private auth:AuthService,private _notificationService: NotificationService,private route: ActivatedRoute,public router: Router) { 
    this.users = {};
    this.companyUsers = {};
    this.submitFlag = false;  
    this.company = {};
    this.id = this.route.snapshot.params['id'];
    this.role;
  }

  ngOnInit() {
    this.updateUser();
    this.getFormToken();
    this.getRole();
    this.getAllListData();
  
	}

  timezoneArray = this.constant.timezoneArray;

  getRole() {

       this.userService.getRoleFromDomain() 
        .subscribe((data)=>{ 
          if(data){

            this.localVal = data;
            if(this.localVal.success == true){
              if(data.data == 1 ) {
                this.role = 'company';
              }
              else{
                this.role = 'product';
              }

            } else{         
            }
        }
      },
       error =>  {
        this.errorMessage = <any>error
      });

    }


    getAllListData() {
    this._spaceService.allListData()
      .then((res) => {
        this.listResponseData = res;
        if (this.listResponseData) {
          this.buildingList = this.listResponseData.data.buildings;
        
        }
      });
  }


     onBuildingChange(id,floor_id){
      if(id!=''){
        this.getFloorFromBuilding(id,floor_id);
        this.floorDisabled = false;
      } else {
        this.floorDisabled = true;
      }    
    }

    getFloorFromBuilding(buildingId,floorId) {
       this._spaceService.floorListData(buildingId)
        .then((res) => {


          console.log(floorId);


          
        
          if (res) {
            this.floorList = res;
            this.users.floor = this.floorList.data;
            if(this.users.floor.length > 0 && floorId != undefined) {
              this.company.floor_id = floorId;

            }
            else {
              this.company.floor_id = '';
            }
           
          }
         
        });

    }

  updateUser() {
    this.dataLoadingStatus = true;
    this.userService.userUpdateData(this.id) 
       .subscribe((data)=>{

      this.users = data.users;
      this.users.password = '';
      this.users.confirm_password = '';
      this.company = data.company;
      this.users.user_type = this.company.user_type;
      this.users.time_difference = data.users.time_difference;

      if(this.company.building_id != undefined && this.company.building_id != '') {
          this.onBuildingChange(this.company.building_id,this.company.floor_id);
      }
      else {

        this.company.building_id = '';
        this.floorDisabled = true;



      }
      this.company.floor_id = '';
      if(this.users.building_id != '') {

        this.floorDisabled = false;
        this.company.floor_id = '';
      }

      if(this.company.building_id == null) {
        this.company.building_id = '';
        this.floorDisabled = true;


      }
       this.dataLoadingStatus = false;
    })
  }

    /**
   * @uses (getFormToken) get csrf form token
   *
   *
   */
    getFormToken() {
     this.auth.getToken()
     .subscribe(
       response => {
         if(response){
           this.Formtoken = response;
         }
       },
       error =>  {
         this.errorMessage = <any>error  
       });
   }


  updateData(user) {

     user._csrf = this.Formtoken;
     this.company._csrf = this.Formtoken;
     user.profile_image = this.base64textString; // image base64 string to insert into form obj 
     user.image_name = this.filename; 
     // var splitTimezone = this.users.timezone.split('-');
     user.removeImage = this.removeImage;
     // user.timezone = splitTimezone[1];
     // user.time_difference = splitTimezone[0];
     var globalTime_difference = this.users.time_difference;
  
    for (let obj of this.constant.timezoneArray) {
    for (let key in obj) {


     
        if(this.users.time_difference === obj.key){
          var timezone = obj[key];
        }
        else {

          user.time_difference = '';

        }
    }
}

    user.timezone = timezone;
    user.time_difference = globalTime_difference;

    
    this.dataLoadingStatus = true;
     this.userService.userDataUpdate(user,this.company) 
     .subscribe((data)=>{ 

       if(data){
         this.localVal = data;
         if(this.localVal.success == true){
           this.dataLoadingStatus = false;
           this.router.navigate(['/user']);
           this._notificationService.add(new Notification('success', this.localVal.message));

         }else{
           this._notificationService.add(new Notification('error', this.localVal.message));
           this.dataLoadingStatus = false;
         }
       }
     },
     error =>  {
       this.errorMessage = <any>error
     });
    }


    onChange(evt){
       this.files = evt.target.files;
       this.file = this.files[0];
       this.filename = this.file.name;
       if (this.files && this.file) {
         var reader = new FileReader();
         reader.onload =this._handleReaderLoaded.bind(this);
         reader.readAsBinaryString(this.file);
       }

    }

    removeConfirmPlanImage(e) {
      e.preventDefault();
        var self = this;    
      swal({
          title: "Are you sure?",
          text: "This user image will be deleted.",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel"        
        },
        function(isConfirm) {
          if (isConfirm) {          
            self.removePlanImageData();                                    
          }        
        });
  }

    removePlanImageData() {
      this.users.profile_image = ''; // image base64 string to insert into form obj 
       this.users.image_name = ''; 
        this.removeImage = true;
    
    }

    _handleReaderLoaded(readerEvt) {
       this.binaryString = readerEvt.target.result;
       this.base64textString= btoa(this.binaryString);
       //console.log(btoa(this.binaryString));
    }
}