import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {User} from "./user";
import {Http, Response,Headers,RequestOptions} from '@angular/http';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class UserService {

  private requestUrl: String;
  moduleParam: any;
  registerUrl: any;

  constructor(private _http: Http, private constant: Constants, private httpClient: HttpClient) {
    this.requestUrl = this.constant.baseUrl;
    this.moduleParam = this.constant.user;
    this.registerUrl = this.constant.registerUrl;
  }

  getUsers(): Observable < User[] > {

    // let options = new RequestOptions({
    //   headers: new Headers({
    //     'Content-Type': 'application/json;charset=UTF-8'
    //   }),
    // })

    let url = this.requestUrl + this.moduleParam.user_link;
    return this._http.get(url)
      .map(this.extractData)
      .catch(this.handleError)
  }


  userAdd(formDataUser, formDataCompany) {

    var combineData = {
      user: formDataUser,
      company: formDataCompany,
      _csrf: formDataUser._csrf
    }

    let url = this.requestUrl + this.moduleParam.user;
    return this._http.post(url, combineData)
      .map(res => res.json())
      .catch(this.handleError)
  }
  userStatusUpdate(data) {

    let url = this.requestUrl + this.moduleParam.userStatus;
    return this._http.post(url, data)
      .map(res => res.json())
      .catch(this.handleError)

  }

  getUserInfo() {

    let url = this.requestUrl + 'user/info';
    return this._http.get(url)
      .map(this.extractData)
      .catch(this.handleError)


  }

  getCompanyUserInfo(userId) {
    let url = this.requestUrl + 'companyInfo/' + userId;
    return this._http.get(url)
      .map(res => res.json())
      .catch(this.handleError)
  }

  userDelete(delId) {

   
    
    let url = this.requestUrl + this.moduleParam.remove_param+delId;
   
    return this._http.get(url)
      .map(res => res.json())
      .catch(this.handleError)
  }

  userUpdateData(userId) {
    let url = this.requestUrl + this.moduleParam.edit_user_link+userId;
    return this._http.get(url)
      .map(this.extractData)
      .catch(this.handleError)
  }

  userDataUpdate(formDataUser, formDataCompany) {
    let url = this.requestUrl + this.moduleParam.user_link;
    var combineData = {
      user: formDataUser,
      company: formDataCompany,
      _csrf: formDataUser._csrf

    }
    console.log(url);
    return this._http.put(url, combineData)
      .map(res => res.json())
      .catch(this.handleError)

  }

  private extractData(res: Response) {
    let body = res.json();
    return body.data || {};
  }

  getBuildingList() {

    let url = this.requestUrl + 'floor/building-list';
       return this._http.get(url)
      .map(res => res.json())
      .catch(this.handleError)

  }


   getRoleFromDomain() {
    let url = this.requestUrl + 'users/get-role-from-domain';
    return this._http.get(url)
      .map(res => res.json())
      .catch(this.handleError)

  } 

  forgotPassword(data) {
    let url = this.registerUrl+'users/forgotPassword';    
    return this._http.post(url, data)
      .map(res => res.json())
      .catch(this.handleError)
  }

  updatePassword(data)
  {
    let url = this.registerUrl + 'users/reset-password';    
    return this._http.post(url, data)
      .map(res => res.json())
      .catch(this.handleError)
  }

  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;

    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }

    return Observable.throw(errMsg);
  }

}