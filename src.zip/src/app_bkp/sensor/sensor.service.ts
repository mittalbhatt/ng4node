﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class SensorManageService {
    
    private requestUrl:String;
    moduleParam:any;


    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.sensor_management;
    }

    /**
     * @uses (addSensor) send sensor add form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    addSensor(data) {
        let url = this.requestUrl+this.moduleParam.add_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (addTablet) send tablet add form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    addTablet(data) {
        let url = this.requestUrl+this.moduleParam.add_tab_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getSpaceList) get space list with id
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json space list
    */

    getSpaceList() {
        let url = this.requestUrl+this.moduleParam.get_space_list;
        return this.httpClient.get(url);
    }

    /**
     * @uses (getDeviceList) get space list with id
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json space list
    */

    getDeviceList() {
        let url = this.requestUrl+this.moduleParam.get_device_list;
        return this.httpClient.get(url);
    }


    /**
     * @uses (getSensorData) get sensor data for update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getSensorData(data) {
        let url = this.requestUrl+this.moduleParam.edit_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getTabletData) get tablet data for update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getTabletData(data) {
        let url = this.requestUrl+this.moduleParam.edit_tablet_param;
        return this.httpClient.post(url, data);
    }


    /**
     * @uses (updateSensor) send Sensor update form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    updateSensor(data) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (updateTablet) send Tablet update form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    updateTablet(data) {
        let url = this.requestUrl+this.moduleParam.update_tablet_param;
        return this.httpClient.post(url, data);
    }


    /**
     * @uses (sensorStatusUpdate) send Sensor status update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    sensorStatusUpdate(data){
        let url = this.requestUrl+this.moduleParam.update_status;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (tabletStatusUpdate) send tablet status update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    tabletStatusUpdate(data){
        let url = this.requestUrl+this.moduleParam.update_tablet_status;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (tabletBookStatusUpdate) send tablet book status update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    tabletBookStatusUpdate(data){
        let url = this.requestUrl+this.moduleParam.update_tablet_book_status;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (removeSensor) get selected sensor info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeSensor(data){
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (removeTablet) get selected tablet info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeTablet(data){
        let url = this.requestUrl+this.moduleParam.remove_tablet_param;
        return this.httpClient.post(url, data);
    }

   
}