import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { AddComponent } from './beacon/addBeacon/add.component';
import { EditComponent } from './beacon/editBeacon/edit.component';
import { AddTabletComponent } from './tablet/addTable/add.component';
import { EditTabletComponent } from './tablet/editTablet/edit.component';
import { TabletManageComponent } from './tablet/tablet.component';
import { SensorManageComponent }     from './sensor.component';


export const SensorRoutes: Routes = [
	{ path: '', component: SensorManageComponent },
	{ path: 'add', component: AddComponent },
	{ path: 'edit/:id', component: EditComponent },
	{ path: 'tablet/add', component: AddTabletComponent },
	{ path: 'tablet', component: TabletManageComponent },
	{ path: 'tablet/edit/:id', component: EditTabletComponent },
];

export const SensorManageRoute: ModuleWithProviders = RouterModule.forChild(SensorRoutes);