import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule }   from './../common/components/shared.module';
import { FormsModule } from '@angular/forms';

import { SensorManageComponent } from './sensor.component';
import { SensorManageRoute } from './sensor.routing';
import { AddComponent } from './beacon/addBeacon/add.component';
import { EditComponent } from './beacon/editBeacon/edit.component';
import { AddTabletComponent } from './tablet/addTable/add.component';
import { EditTabletComponent } from './tablet/editTablet/edit.component';
import { TabletManageComponent } from './tablet/tablet.component';


@NgModule({
  imports: [
    CommonModule,
    SensorManageRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [
  SensorManageComponent,
	AddComponent,
	EditComponent,
	AddTabletComponent,
	EditTabletComponent,
  TabletManageComponent
  ]
})
export class SensorManageModule { }
