import { Component, OnInit } from '@angular/core';
import { SensorManageService } from './sensor.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-sensor',
  templateUrl: './sensor.component.html',
  providers:[SensorManageService]
})

export class SensorManageComponent implements OnInit {
  private requestUrl:String;
  errorMessage:String;
  moduleParam:any;
  Formtoken:any;
  localVal:any;

  constructor(
    private sensorMangeService:SensorManageService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
    this.moduleParam = this.constant.sensor_management;
    this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param;
    this.getSensorList(this.requestUrl);
    this.getFormToken();
  }

  /**
	 * @uses  (getSensor) Sensor list using server side datatable
	 *
	 * @author RK < rakesh.rathava@softwebsolutions.com >
	 *
   */   
   getSensorList(serviceUrl) {
     var self = this;  
     $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };      
     var dataTable = $("#sensor-list")
     .on( 'processing.dt', function ( e, settings, processing ) {
          if(processing)
          {
              if(!($('#sensor-list').find('#loader-container').length))
              {
                  $("#sensor-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
              }
          }
          else {
              $('#loader-container').remove();
          }
      })
     .DataTable({
       "destroy": true,
       "serverSide": true,
       "lengthMenu": self.constant.showRecords,
       "searching":true,
       "responsive": true,    
       "order": [[1, 'asc']],
       "ajax": {
         url : serviceUrl,
         type: 'get',
         "beforeSend": function(xhr){
              xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
          },
          "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;
            
            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
       },
       "columns": [
       {"data": "sensor_id", "name": "sensor_id","width": "5%","orderable": false}, 
       {"data": "sensor_name", "name": "sensor_name","width": "15%"},
       {"data": "attributes", "name": "attributes","width": "10%", "orderable": false,
          "render": function (data, type, full, meta) {
           var attributes = '<p><b>Major:</b> '+ full.sensor_major +'</p>';
           attributes += '<p><b>Minor:</b> '+ full.sensor_minor +'</p>';
           return attributes;
        } },
       {"data": "space_name", "name": "space_name","width": "10%",
          "render": function(data, type, full, meta) {
            var building_name = "";
            var space_name = "";
            var floor_name = "";

            if(full.building_name){
              building_name = full.building_name;
            }

            if(full.space_name){
              space_name = full.space_name;
            }

            if(full.floor_name){
              floor_name = full.floor_name;
            }


            var actionLinks ="";

            if(full.space_image_path != "" && full.space_name != "" && full.space_id) {
              actionLinks += "<span><b><a id='info_"+full.space_id+"' class='sensor-details' style='border-bottom: none;' title='Click to detail view'>"+space_name+"</a></b></span><br/><i class='font-icon font-icon-burger color-orange'>&nbsp;</i><span style='font-style:italic;color:grey;font-size:14px;font-weight:bold;'> " + floor_name+"</span><br/><i class='font-icon font-icon-build color-red'>&nbsp;</i><span style='font-style:italic;color:gray;font-size:14px;font-weight:bold;'>" + building_name+"</span>";
            }
          return actionLinks;
          }},
       {"data": "sensor_type", "name": "sensor_type","width": "10%"},
       {
         "data": "status",
         "name": "status",
         "width": "5%",
         "orderable": false,
         "render": function (data, type, full, meta) {

           var statusStr = '';
           statusStr = '<div title="Inactive"  class="checkbox-bird sensor-status-update" id="sensorSatusUpdate_' + full.sensor_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox"/><label></label></div>';
           if (full.status == 1) {
             statusStr = '<div title="Active"  class="checkbox-bird green sensor-status-update" id="sensorSatusUpdate_' + full.sensor_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox" checked/><label></label></div>';
           }

           return statusStr;
         }
       },
       {
         "data": "action", 
         "name": "action", 
         "orderable": false,
         "searchable": false, 
         "width": "12%",
         "render": function (data, type, full, meta) {
           // var actionLinks = '<a title="Edit" id="'+full.sensor_id+'" class="btn btn-primary-outline btn-sm sensor-edit"><i class="fa fa-edit"></i></a>';
           // actionLinks += '&nbsp;<a title="Delete" class="btn btn-danger-outline btn-sm sensor-delete" id="delete_'+full.sensor_id+'"><i class="fa fa-trash-o"></i></a>';
            var actionLinks = '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="'+full.sensor_id+'" class="tabledit-edit-button btn btn-sm btn-default sensor-edit" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button><button type="button" id="delete_'+full.sensor_id+'" class="tabledit-delete-button btn btn-sm btn-default sensor-delete" style="float: none;"><span class="glyphicon glyphicon-trash"></span></button></div>';
            return actionLinks;
         }          
       }          
       ]
       ,
       fnRowCallback: function( nRow, aData, iDisplayIndex )
       {  
         var display_number = self.constant.dataTableNo(dataTable, iDisplayIndex);
         $('td:eq(0)', nRow).html(display_number);
         return nRow;
       },
       fnDrawCallback: function( oSettings )
       {

         $(document).on('click', 'button.sensor-edit', function (e) {
           var sensorId = this.id;
           self.editSensor(sensorId);
           e.preventDefault();
         });

         $(document).on('click', '.sensor-status-update', function (e) {
           var sensorIdStatusIdVal = this.id;

           e.preventDefault();
           swal({
             title: "Are you sure?",
             text: "You want to update this status!",
             type: "info",
             showCancelButton: true,
             confirmButtonClass: "btn-confirm",
             confirmButtonText: "Update",
             cancelButtonText: "Cancel"
           },
           function (isConfirm) {
             if (isConfirm) {
               var sensorIdSplitted = sensorIdStatusIdVal.split('_');
               var sensorStatusId = sensorIdSplitted[1];
               var sensorStatus = sensorIdSplitted[2];
               self.sensorStatusUpdate(sensorStatusId, sensorStatus, dataTable);
             }
           });
         });

         $(document).on('click', 'button.sensor-delete', function (e) {

           var deleteId = this.id;
           var delId = deleteId.split('_');
           var delIdFinal = delId[1];

           e.preventDefault();
           swal({
             title: "Are you sure?",
             text: "You want to remove this record?",
             type: "warning",
             showCancelButton: true,
             confirmButtonClass: "btn-danger",
             confirmButtonText: "Delete",
             cancelButtonText: "Cancel"        
           },
           function(isConfirm) {
             if (isConfirm) {          
               self.deleteSensor(delIdFinal, dataTable);
             }        

           });
         });
         $(document).on('click', 'a.sensor-details', function (e) {
            var bookingId = this.id;
            var bookid = bookingId.split('_');
            var bookIdFinal = bookid[1];
              self.showSpaceById(bookIdFinal);
          });
       }
     });
   }
    showSpaceById(bookIdFinal){
      this.router.navigate([this.moduleParam.show_space+bookIdFinal]);
    }
    /**
     * @uses (editSensor) get sensro data for update
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */
     
    editSensor(sensor_id){
      this.router.navigate([this.moduleParam.edit_sensor_link+sensor_id]);
    }

    /**
     * @uses (sensorStatusUpdate) update sensor status from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */

    sensorStatusUpdate(sensor_id, status, dataTable){

        this.sensorMangeService.sensorStatusUpdate({'sensor_id':sensor_id,'status':status, "_csrf":this.Formtoken})
                .then(
                response => {
                  if(response){
                     this.localVal = response;
                     if(this.localVal.success){
                        dataTable.ajax.reload(null, false);
                       this.router.navigate([this.moduleParam.sensor_link]);
                        this._notificationService.add(new Notification('success', this.localVal.message));
                     }else{
                        this._notificationService.add(new Notification('error', this.localVal.message));   
                     }
                  }
                },
                error =>  {
                  this.errorMessage = <any>error;
                    this._notificationService.add(new Notification('error', error));
                });
    }

    
    /**
     * @uses (deleteSensor) remove amenities from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */
    deleteSensor(id, dataTable){

      this.sensorMangeService.removeSensor({'sensor_id':id, "_csrf":this.Formtoken})
                .then(
                response => {
                  if(response){
                     this.localVal = response;
                     if(this.localVal.success){
                        dataTable.ajax.reload(null, false);
                       this.router.navigate([this.moduleParam.sensor_link]);
                        this._notificationService.add(new Notification('success', this.localVal.message));
                     }else{
                        this._notificationService.add(new Notification('error', this.localVal.message));   
                     }
                  }
                },
                error =>  {
                  this.errorMessage = <any>error;
                    this._notificationService.add(new Notification('error', error));
                });
    }


    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

    getFormToken() {
     this.auth.getToken()
     .subscribe( response => {
       if(response){
         this.Formtoken = response;
       }
     },error =>  {
       this.errorMessage = <any>error
     });
}


   }
