import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { ProfileComponent }     from './profile.component';

export const ProfileRoutes: Routes = [
	{ path: '', component: ProfileComponent }
];

export const ProfilesRoutes: ModuleWithProviders = RouterModule.forChild(ProfileRoutes);