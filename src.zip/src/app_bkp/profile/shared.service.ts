import { Component, Injectable,Input,Output,EventEmitter } from '@angular/core'


@Injectable()
export class ChangeProfileService {
    @Output() profile: EventEmitter<any> = new EventEmitter();

    constructor() {
    }

    change(profile) {
        this.profile.emit(profile);
    }

    getEmittedValue() {
        return this.profile;
    }
}

@Injectable()
export class ChangeRoleService {
    @Output() role: EventEmitter<any> = new EventEmitter();

    constructor() {
    }

    change(role) {
        this.role.emit(role);
    }

    getEmittedValue() {
        return this.role;
    }
}