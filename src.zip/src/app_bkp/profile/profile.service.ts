﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()

export class ProfileService {
    private requestUrl:String;
    response:any;
    moduleParam:any;

    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.profile;
    }

    /**
     * @uses (changePassword) send building add form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    changePassword(data) {
        let url = this.requestUrl+this.moduleParam.change_password;
        return this.httpClient.post(url, data);
    }


    /**
     * @uses (updateProfile) send user profile updated form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    updateProfile(data) {
        let url = this.requestUrl+this.moduleParam.update_profile;
        return this.httpClient.post(url, data);
    }
   

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    getCurrentUser(){
        let url = this.requestUrl+this.moduleParam.get_current_user;
        return this.httpClient.get(url);
    }

    removeProfileLogo(data)
    {
        let url = this.requestUrl+this.moduleParam.remove_profile_logo;
        return this.httpClient.post(url, data);
    }
    
}