import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingsComponent } from './settings.component';
import { SettingsRoute } from './settings.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { EmailComponent } from './additional/email.component';
import { IntegrationsAppComponent } from './additional/integrations-app.component';
import { BrandingComponent } from './additional/branding.component';
import { GeneralComponent } from './additional/general.component';
import { SOSetupComponent } from './additional/sosetup.component';
import { TimingComponent } from './additional/timing.component';
import { SensorsComponent } from './additional/sensors.component';
import { PushnotificationComponent } from './additional/pushnotification.component';


@NgModule({
  imports: [
    CommonModule,
    SettingsRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [
	  SettingsComponent,
	  EmailComponent,
	  IntegrationsAppComponent,
	  BrandingComponent,
	  GeneralComponent,
	  SOSetupComponent,
    TimingComponent,
    SensorsComponent,
    PushnotificationComponent
  ],
})
export class SettingsModule { }
