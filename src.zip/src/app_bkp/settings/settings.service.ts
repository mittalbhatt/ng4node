﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class SettingsService {
    
    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.settings;
    }

     /**
     * @uses (amenityEmails) send extra amenity email form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    amenityEmails(data) {
        let url = this.requestUrl+this.moduleParam.alert_email_param;
        return this.httpClient.post(url, data);
    }

    getSoSetup(){        
        let url = this.requestUrl+this.moduleParam.get_so_setup;
        return this.httpClient.get(url);
    }

    addsosetupid(data) {
        let url = this.requestUrl+this.moduleParam.add_sos_param;
        return this.httpClient.post(url, data);
    }
    getAlertEmails(){
        let url = this.requestUrl+this.moduleParam.get_alert_email;
        return this.httpClient.get(url);
    }

    /**
     * @uses (uploadCompanyLogo) send building add form post data
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    uploadCompanyLogo(data) {
        let url = this.requestUrl+this.moduleParam.upload_company_logo;        
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getCompanyLogo)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */

    getEditSettings() {        
        let url = this.requestUrl+this.moduleParam.get_settings;
        return this.httpClient.get(url);
    }

    /**
     * @uses (submit powered by change event)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    submitShowPoweredByChangeEvent(data)
    {        
        let url = this.requestUrl+this.moduleParam.show_powered_by;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (submit Timing Format change event)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    submitTimingFormatChangeEvent(data)
    {        
        let url = this.requestUrl+this.moduleParam.timing_format;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getTimingInfo)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    getTimingInfo()
    {
        let url = this.requestUrl+this.moduleParam.get_timing_info;
        return this.httpClient.get(url);
    }

    /**
     * @uses (appIntegration)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    appIntegration(data)
    {
        let url = this.requestUrl+this.moduleParam.app_integration;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getTimingInfo)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    getAppIntegrationInfo()
    {
        let url = this.requestUrl+this.moduleParam.get_app_integration_info;
        return this.httpClient.get(url);
    }

    /**
     * @uses (remove company logo image)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    removeCompanyLogoImage(data)
    {
        let url = this.requestUrl+this.moduleParam.remove_company_logo_image;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (get status of ESTIMOTE_BEACON)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    getSensors()
    {        
        let url = this.requestUrl+this.moduleParam.get_sensors;
        return this.httpClient.get(url);
    }

    /**
     * @uses (remove company logo image)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    updateSensors(data)
    {
        let url = this.requestUrl+this.moduleParam.update_sensors;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (get before meeting time duration for push notification)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    getPushNotification()
    {        
        let url = this.requestUrl+this.moduleParam.get_push_notification;
        return this.httpClient.get(url);
    }

    /**
     * @uses (update push notification duration for before meeting)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    updatePushNotification(data)
    {
        let url = this.requestUrl+this.moduleParam.update_push_notification;
        return this.httpClient.post(url, data);
    }
       
}