import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CanDeactivateGuardService }       from './auth/can-deactivate-guard.service';
import { AuthGuardService }                from './auth/auth-guard.service';
import { SelectivePreloadingStrategy } from './selective-preloading-strategy';
import { PageNotFoundComponent }    from './page-not-found.component';
import { PreventLoggedInAccess }    from './auth/preventLoggedInAccess.service';

const appRoutes: Routes = [
  {
    path: 'login',
    canActivate: [PreventLoggedInAccess],
    loadChildren: './auth/login.module#LoginModule'
    // ,data: { preload: true }
  },{
    path: 'reset',
    canActivate: [PreventLoggedInAccess],
    loadChildren: './auth/reset.module#ResetModule'
    // ,data: { preload: true }
  },{
    path: '',
    loadChildren: './site/site.module#SiteModule'
    // ,data: { preload: true }
  },
  {
    path: 'register',
    canActivate: [PreventLoggedInAccess],
    loadChildren: './auth/register.module#RegisterModule'
    // ,data: { preload: true }
  },
  {
  	path: '**',
  	component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { preloadingStrategy: SelectivePreloadingStrategy }
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [
    CanDeactivateGuardService,
    SelectivePreloadingStrategy,
    PreventLoggedInAccess
  ]
})
export class AppRoutingModule { }
