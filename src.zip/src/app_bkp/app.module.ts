import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // this is needed! 

import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule,RequestOptions} from '@angular/http';
import { AppRoutingModule }        from './app-routing.module';
import { Router } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthService } from './auth/auth.service';
import { PageNotFoundComponent }    from './page-not-found.component';
import { SharedModule } from './common/components/shared.module';
import {Notifications} from './common/components/notifications.component';
import { Constants } from './common/services/constants';
import { HttpClient } from './common/services/http.service';
import { AuthGuardService } from './auth/auth-guard.service';
import { PlanExpiredGuardService } from './common/services/plan-expired-guard.service';

import { menuService } from './site/menu/menu.service';
import { UserService } from './user/user.service';
import { ResetService } from './auth/reset/reset.service';


import { SpaceSocketService } from './space.socket.service';

// Service
import { NotificationService, Notification } from './common/services/notifications.service';
import { DefaultRequestOptions } from './common/services/default-request-options.service';
import { CompanyLogo } from './common/services/shared.service';
import { ProfileLogo } from './common/services/shared.service';
import { AuthUserInfo } from './common/services/shared.service';

import { SocketIoModule, SocketIoConfig } from 'ng2-socket-io';
const config: SocketIoConfig = { url: 'http://192.168.3.131:3000', options: {} };

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    Notifications,

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    HttpModule,
    SharedModule,
    SocketIoModule.forRoot(config)
  ],

  providers: [AuthService, AuthGuardService,
  NotificationService, Constants, HttpClient,menuService,
  SpaceSocketService, PlanExpiredGuardService, UserService, ResetService, CompanyLogo, ProfileLogo, AuthUserInfo,
  { provide: RequestOptions, useClass: DefaultRequestOptions }

  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  // Diagnostic only: inspect router configuration
  constructor(router: Router) {

  }
}
