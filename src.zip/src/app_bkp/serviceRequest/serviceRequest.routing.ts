import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { ServiceRequestComponent }     from './serviceRequest.component';
import { AddComponent }     from './addServiceRequest/add.component';
import { EditComponent }     from './editServiceRequest/edit.component';


export const ServiceRequestRoutes: Routes = [
	{ path: '', component: ServiceRequestComponent },
	{ path: 'add', component: AddComponent },
	{ path: 'edit/:id', component: EditComponent },
];

export const ServiceRequestsRoute: ModuleWithProviders = RouterModule.forChild(ServiceRequestRoutes);