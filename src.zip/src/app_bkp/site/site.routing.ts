import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SiteComponent }    from './site.component';

import { AuthGuardService } from './../auth/auth-guard.service';


const siteRoutes: Routes = [
  {
    path: '',
    canActivate: [AuthGuardService],
    component: SiteComponent,
    children: [
      {
        path: '',
        canActivate: [AuthGuardService],
        loadChildren: './../home/home.module#HomeModule'
      },
      {
        path: 'building',
        canActivate: [AuthGuardService],
        loadChildren: './../building/building.module#BuildingModule'
      },
      {
        path: 'floor',
        canActivate: [AuthGuardService],
        loadChildren: './../floor/floor.module#FloorModule'
      },
      {
        path: 'user',
        canActivate: [AuthGuardService],
        loadChildren: './../user/user.module#UserModule'
      },
      {
        path: 'amenities',
        canActivate: [AuthGuardService],
        loadChildren: './../amenities/amenities.module#AmenitiesModule'
      },
      {
        path: 'space',
        canActivate: [AuthGuardService],
        loadChildren: './../space/space.module#SpaceModule'
      },
      {
        path: 'analytics',
        canActivate: [AuthGuardService],
        loadChildren: './../analytics/analytics.module#AnalyticsModule'
      },
      {
        path: 'settings',
        canActivate: [AuthGuardService],
        loadChildren: './../settings/settings.module#SettingsModule'
      },
      {

        path: 'get-user',
        canActivate:[AuthGuardService],
        loadChildren: './../profile/profile.module#ProfileModule'
      },
      {
        path: 'profile',
        canActivate: [AuthGuardService],
        loadChildren: './../profile/profile.module#ProfileModule'
      },
      {
        path: 'company',
        canActivate: [AuthGuardService],
        loadChildren: './../company/company.module#CompanyModule'
      },
      {
        path: 'sensor',
        loadChildren: './../sensor/sensor.module#SensorManageModule'
      },
      {
        path: 'device',
        loadChildren: './../device/device.module#DeviceManageModule'
      },
      {
        path: 'logout',
        canActivate: [AuthGuardService],
        loadChildren: './../auth/logout.module#LogoutModule'
      },
      {
        path: 'event',
        canActivate: [AuthGuardService],
        loadChildren: './../event/event.module#EventModule'
      },
      {
        path: 'package',
        canActivate: [AuthGuardService],
        loadChildren: './../package/package.module#PackageModule'
      },
      {
        path: 'billing',
        canActivate: [AuthGuardService],
        loadChildren: './../billing/billing.module#BillingModule'
      },
      {
        path: 'service-request',
        canActivate: [AuthGuardService],
        loadChildren: './../serviceRequest/serviceRequest.module#ServiceRequestsModule'
      },
      {
        path:'schedule',
        canActivate:[AuthGuardService],
        loadChildren:'./../meeting/meetings.module#MeetingsModule'
      },
      {
        path:'search',
        canActivate:[AuthGuardService],
        loadChildren:'./../search/search.module#SearchModule'
      }

    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(siteRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SiteRoutingModule {}
