import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { MeetingsService } from './meetings.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { CalendarComponent } from "ap-angular2-fullcalendar/src/calendar/calendar";
import { environment } from '../../environments/environment';
import { EventService } from "../event/event.service";
import { UserService } from "../user/user.service";

import * as moment from 'moment';


/** for socket to available room or not - Start - ashwin */
import { SpaceSocketService } from '../space.socket.service';
/** for socket to available room or not - End - ashwin */

declare var swal: any;
declare var $: any;
var self = this;

@Component({
  selector: 'app-meetings-show',
  templateUrl: './currentMeetingSapce.component.html',
  styleUrls: ['./currentMeetingSapce.component.css'],
  providers: [MeetingsService, EventService]
})
export class currentMeetingSpaceComponent implements OnInit {

  @ViewChild(CalendarComponent) myCalendar: CalendarComponent;
  
  eventIsPopup: any='popup';
  eventUpdateId: any = '';
  private serverMessage;
  errorMessage: String;
  space_name: string;
  space_id: string;
  space_amenities: any = [];
  moduleParam: any;
  Formtoken: any;
  localVal: any;
  paramId: any;
  editId: any;
  spaceObj: any;
  space_capacity: any;
  building_name: any;
  floor_name: any;
  currentDate: any;
  currentDate_string: any;
  space_type_name: any;
  space_image: any;
  currentDateArr = [];
  calendarOptions: any;
  eventFromTimeSettings: any;
  eventToTimeSettings: any;
  minuteStepSlot: any;
  dateTimeNow: any;
  eventDatesettings: any;
  emailTagsData: any = [];
  count: any = 0;
  listResponseData: any;
  userEmail: any;
  timezone: any;
  timezoneOffset: any;
  userId: any;
  responseData: any = {};
  // Date variables
  dateNow: any;
  private id: any;
  displayDate: any;
  currentDateForUpComingMeetings: any;
  upcomingMeeting: any;
  currentMeeting: any;
  // date time format
  datetimeFormat: any='YYYY-MM-DD hh:mm:ss';
  displayCurrentMeeting: any='MMM DD, YYYY hh:mm A';
  currentDateTime: any;

  clickeMore: boolean=false;
 
  socketSpaceData: any = [];
  constructor(
    private meetingsService: MeetingsService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth: AuthService,
    private spacesocket: SpaceSocketService,
    private _eventService: EventService,
    private _userService: UserService
  ) {
    this.minuteStepSlot = environment.minuteSlot;
    this.moduleParam = this.constant.meetings;   
    this.getUserInfo(); 
  }


  // set id and get popup for update data
  openEventPopup(id, display) {
    this.eventIsPopup = 'popup';
    this.eventUpdateId = id;
    if (id) {
      if(display=='view') {
        $('#viewEventModal').modal('show');
      } else {
        $('#updateEventModal').modal('show');
      }
    } else {
      if(display=='add') {
        $('#addEventModal').modal('show');
      }
    }
  }

  // When event update calendar initialize
  changeEventEmit(event) {    
    this.showInitCalendar(this.constant.baseUrl, this.paramId);  
  }


  ngOnInit() {
       
    this.activeRoute.params.subscribe(params => {
      this.paramId = params['id']; // --> Name must match wanted paramter
      this.showInitCalendar(this.constant.baseUrl, this.paramId);

      this.currentDateForUpComingMeetings = moment().format('YYYY-MM-DD HH:mm');
       
      this.moduleParam = this.constant.meetings;
      this.currentDate = new Date();
      this.currentDate_string = moment().format('dddd, MMMM DD, YYYY');
             
          
      /* for socket call start */

      this.spacesocket.getSpaceInformation().then(
        (response: any) => {
          if (response) {
            if (response.success == true) {
              this.socketSpaceData = response.data;              
              this.socketSpaceData.forEach(function (element) {                            
                if(element.space_id != undefined && element.available != undefined) {
                  if (element.space_id == element.space_id) {
                    element.available = element.available;
                  }
                }
              });
            }

          }
        });

      this.spacesocket.getSocketSpaces().subscribe((data: any) => {
        if (data.type == 'new-space') {
          this.socketSpaceData.push(data);
        } else if (data.type == 'available-or-not') {
          this.socketSpaceData.forEach(function (element) {
            if (element.space_id == data.space_id) {
              element.available = data.available;
            }
          });
        }
      });

      this.getCurrentMeeting();
      this.getUpcomingMeetings();
      this.getSensorList(this.constant.baseUrl + this.constant.sensor_management.get_list_param, this.paramId);
      this.getFormToken();

    });
}


  getUpcomingMeetings() {

    this.meetingsService.getUpcomingMeetings(this.paramId).then((res) => {
            
      if (res) {
        this.localVal = res;
        if (this.localVal.success) {

          // this.displayDate = this.upcomingMeeting.display
          if (this.localVal.data.length > 0) {
            this.displayDate = this.localVal.data[0].display_date;

          }
          else {
            this.displayDate = '';
          }
        }
        this.localVal.data.forEach(function (obj) {
          // obj.access = true;
          obj.attendiesProfilePicture = obj.attendiesProfilePicture.split(',');
        });
        this.upcomingMeeting = this.localVal.data;
      }
    });
  }

  getCurrentMeeting() {
    this.meetingsService.getCurrentMeetings(this.paramId).then((res) => {            
      if (res) {
        this.localVal = res;      
         
        if (this.localVal.success) {
          this.localVal.data[0].attendiesProfilePicture = this.localVal.data[0].attendiesProfilePicture.split(',');                
          if(this.localVal.data[0] !== undefined && this.localVal.data[0].utc_end_time !== undefined ) {
            this.localVal.data[0].endTime = this.constant.utcToTimezone(this.localVal.data[0].utc_end_time, this.timezone, this.displayCurrentMeeting);
          }
          
           this.currentMeeting = this.localVal.data; 
       }
       
      }
    });
  }


  getUserInfo() {
    this._userService.getUserInfo().subscribe((res) => {
      if (res) {
        this.userEmail = res.email;
        this.timezone = res.timezone;
        this.timezoneOffset = res.time_difference;
        this.userId = res.user_id;

        console.log('timezone');
        console.log(this.timezone);
        // Current event data
        this.currentDateTime = moment.tz(this.timezone).format(this.datetimeFormat);
        

      }
    });
  }


  showInitCalendar(baseUrl, spaceId) {
              
    var self = this;

    this.myCalendar.fullCalendar('destroy');
       
    this.calendarOptions = {
      header: {
        left: '',
        center: 'prev, title, next',
        right: ''
      },

      defaultDate: this.currentDate,
      // height: 'parent',

      events: function (start, end, timezone, callback) {
        $.ajax({
          url: baseUrl + 'schedule/space/meeting',
          dataType: 'JSON',
          type: "POST",
          data: {
            // our hypothetical feed requires UNIX timestamps
            start: start.unix(),
            end: end.unix(),
            space_id: spaceId,
            _csrf: this.Formtoken
          },
          "beforeSend": function (xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + localStorage.getItem('userAccessToken'));
          },
          success: function (doc) {
            var data = doc.booking_data;
            var events = [];
            data.forEach(element => {
               
              // Converted utc to user timezone
              var startDateTime = self.constant.utcToTimezone(element.utc_start_time, self.timezone, 'MM/DD/YYYY h:mm A');
              var endDateTime = self.constant.utcToTimezone(element.utc_end_time, self.timezone, 'MM/DD/YYYY h:mm A');
              
              events.push({
                title: element.title,
                start: startDateTime, // will be parsed
                booking_id: element.booking_id,
                is_delete_valid: element.is_delete_valid,
                display_start_date: startDateTime,
                display_end_date: endDateTime


              });
            })

            callback(events);
          }
        });
      },
      eventRender: function (event, element) {
        var Xmas95 = new Date(event.display_start_date);
        var month = Xmas95.getDate();

        if (month < 6 && month > 0) {
          element.addClass('event-green');
        }
        else if (month < 11 && month > 5) {
          element.addClass('event-red');

        }
        else if (month < 16 && month > 10) {
          element.addClass('event-coral');

        }
        else if (month < 21 && month > 15) {
          element.addClass('event-orange');

        }
        else if (month < 26 && month > 20) {
          element.addClass('event-green');

        }
        else {
          element.addClass('event-coral');
        }
      },
      editable: false,
      selectable: true,
      eventLimit: 2, // allow "more" link when too many events
      timeFormat: 'H(:mm)',
      viewRender: function (view, element) {
        if (!("ontouchstart" in document.documentElement)) {
          $('.fc-scroller').jScrollPane({
            autoReinitialise: true,
            autoReinitialiseDelay: 100
          });
        }

        $('.fc-popover.click').remove();
      },
      eventClick: function (calEvent, jsEvent, view) {
        var eventEl = $(this);

        // Add and remove event border class
        if (!$(this).hasClass('event-clicked')) {
          $('.fc-event').removeClass('event-clicked');
          $(this).addClass('event-clicked');
        }

        var appendString = '<div class="fc-popover click">' +
          '<div class="fc-header">' +
          moment(calEvent.start).format('dddd • D') +
          '<button type="button" class="cl"><i class="font-icon-close-2"></i></button>' +
          '</div>' +

          '<div class="fc-body main-screen">' +
          '<p>' +
          moment(calEvent.start).format('dddd, D YYYY, h:mm A') +
          '</p>' +
          '<p class="color-blue-grey"><b>Title : </b>' + calEvent.title + '</p>' +
          '<ul class="actions">';
        if (calEvent.is_delete_valid == 0) {

          appendString += 
            '<li><a href="javascript::void(0)" id="open_view">View Event</a></li>' +
            '</ul>' +
            '</div>' +
            '</div>'
        }
        else {
          appendString +=
            '<li *ngIf = "' + calEvent.is_delete_valid + "==1" + '" ><a  *ngIf = "' + calEvent.is_delete_valid + "==1" + '" href="javascript::void(0)" id="open_modal">Edit Event</a></li>' +
            // '<li><a href="#" class="fc-event-action-edit">Edit event</a></li>' +
            '<li *ngIf = "' + calEvent.is_delete_valid + "== 1" + '"><a href="#" id="deleteId_' + calEvent.booking_id + '"" class="fc-event-action-remove">Remove</a></li>' +
            '</ul>' +
            '</div>' +
            '</div>'
        }

        // Add popover
        $('body').append(appendString);


        $(document).on('click', 'a.fc-event-action-remove', function (e) {
          var deleteId = this.id;
          var delId = deleteId.split('_');
          var delIdFinal = delId[1];
          e.preventDefault();
          swal({
            title: "Are you sure?",
            text: "You want to delete this meeting ?",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Delete",
            cancelButtonText: "Cancel"
          },
            function (isConfirm) {
              if (isConfirm) {
                self.deleteMeeting(delIdFinal);
              }

            });
        });

        // Position popover
        function posPopover() {
          $('.fc-popover.click').css({
            left: eventEl.offset().left + eventEl.outerWidth() / 2,
            top: eventEl.offset().top + eventEl.outerHeight()
          });
        }

        posPopover();

        $('.fc-scroller, .calendar-page-content, body').scroll(function () {
          posPopover();
        });

        $(window).resize(function () {
          posPopover();
        });


        // Remove old popover
        if ($('.fc-popover.click').length > 1) {
          for (var i = 0; i < ($('.fc-popover.click').length - 1); i++) {
            $('.fc-popover.click').eq(i).remove();
          }
        }

        // Close buttons
        $('.fc-popover.click .cl, .fc-popover.click .remove-popover').click(function () {
          $('.fc-popover.click').remove();
          $('.fc-event').removeClass('event-clicked');
        });

        // Actions link
        $('.fc-event-action-edit').click(function (e) {
          e.preventDefault();

          $('.fc-popover.click .main-screen').hide();
          $('.fc-popover.click .edit-event').show();
        });

        $('.fc-event-action-remove').click(function (e) {
          e.preventDefault();

          $('.fc-popover.click .main-screen').hide();
          $('.fc-popover.click .remove-confirm').show();
        });

        $("#open_view").click(function (e) {         
          $('.fc-popover.click').remove();
          $('.fc-event').removeClass('event-clicked');
          self.openEventPopup(calEvent.booking_id, 'view');
        });

        $("#open_modal").click(function (e) {

          //$('#modalTitle').html(calEvent.title);

          //close popup
          $('.fc-popover.click').remove();
          $('.fc-event').removeClass('event-clicked');
          self.openEventPopup(calEvent.booking_id, 'edit');
        })
      },
      dayClick: function (date, jsEvent, view) {
        $('.fc-popover.click').remove();
        $('.fc-event').removeClass('event-clicked');
      }
    }
    this.myCalendar.fullCalendar(this.calendarOptions);
  }


	deleteMeeting(booking_id) {
	    this.meetingsService.removeMeetings({ 'booking_id': booking_id, "_csrf": this.Formtoken })
	      .then(
	      response => {
	        if (response) {
	          this.localVal = response;
	          if (this.localVal.success) {
	              this.myCalendar.fullCalendar( 'refetchEvents' );
	              $('.fc-popover.click').remove();
	            // this.router.navigate([this.moduleParam.meetings_link]);
	            this._notificationService.add(new Notification('success', this.localVal.message));
	          } else {
	            this._notificationService.add(new Notification('error', this.localVal.message));
	          }
	        }
	      },
	      error => {
	        this.errorMessage = <any>error;
	        this._notificationService.add(new Notification('error', error));
	      });
	 }

  
  /**
   * @uses (editBuildingInfo) fetch building data
   *
   * @author RK < rakesh.rathava@softwebsolutions.com >
   *
   */
  showSpaceForMeeting(id) {

    let Obj = { "space_id": id, "_csrf": this.Formtoken };
   
    this.meetingsService.getSpaceById(Obj)
      .then(
      response => {
        
        if (response) {
          this.localVal = response;

          if (this.localVal.success) {
            this.spaceObj = this.localVal.data;
            this.space_name = this.spaceObj.space_name;
            this.space_id = this.spaceObj.space_id;
            this.space_image = this.spaceObj.image_path;
            this.space_amenities = this.spaceObj.SpaceAmenities;
            this.space_capacity = (this.spaceObj.space_capacity) ? this.spaceObj.space_capacity : "";
            this.building_name = (this.spaceObj.building_name) ? this.spaceObj.building_name : "";
            this.space_type_name = (this.spaceObj.space_type_name) ? this.spaceObj.space_type_name : "";
            this.floor_name = (this.spaceObj.floor_name) ? this.spaceObj.floor_name : "";

            if (this.localVal.booking_data.length > 0 || this.localVal.booking_data != "") {
              this.currentDateArr = this.localVal.booking_data;
              this.myCalendar.fullCalendar('baseUrl', this.constant.baseUrl, ['true']);
            }
          } else {
            if (typeof this.localVal.message === 'object') {
              this.serverMessage = this.localVal.message;
            } else {
              this._notificationService.add(new Notification('error', this.localVal.message));
            }
          }
        }
      },
      error => {
        this.errorMessage = <any>error
      });
  }


  /**
    * @uses (getFormToken) get csrf form token
    *
    * @author RK < rakesh.rathava@softwebsolutions.com >
    *
    */
  getFormToken() {
    this.auth.getToken().subscribe(response => {
      if (response) {
        this.Formtoken = response;
        this.showSpaceForMeeting(this.paramId);
      }
    },
      error => {
        this.errorMessage = <any>error
      });
  }

  morePictureClick(e){
    if(this.clickeMore) {
      this.clickeMore = false;
    } else {
      this.clickeMore = true;
    }
  }

  /**
* @uses  (getSensor) Sensor list using server side datatable
*
* @author RK < rakesh.rathava@softwebsolutions.com >
*
*/
  getSensorList(serviceUrl, space_id) {
    var self = this;
    $.fn.dataTableExt.sErrMode = function (settings, helpPage, message) { if (message) { console.log(message) } };
    var dataTable = $("#sensors-list")
      .on('processing.dt', function (e, settings, processing) {
        if (processing) {
          if (!($('#sensors-list').find('#loader-container').length)) {
            $("#sensors-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
          }
        }
        else {
          $('#loader-container').remove();
        }
      })
      .DataTable({
        "destroy": true,
        "serverSide": true,
        "lengthMenu": self.constant.showRecords,
        "searching": false,
        "bLengthChange": false,
        "responsive": true,
        "order": [[1, 'asc']],
        "ajax": {
          url: serviceUrl + '?space_id=' + space_id,
          type: 'get',
          "beforeSend": function (xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + localStorage.getItem('userAccessToken'));
          },
          "dataFilter": function (data) {
            var json = $.parseJSON(data);
            var respData = json;

            if (respData.status === "fail") {
              self.auth.logout();
              self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
        },
        "columns": [
          { "data": "sensor_id", "name": "sensor_id", "width": "5%", "orderable": false },
          { "data": "sensor_name", "name": "sensor_name", "width": "15%" },
          {
            "data": "attributes", "name": "attributes", "width": "10%", "orderable": false,
            "render": function (data, type, full, meta) {
              var attributes = '<p><b>Major:</b> ' + full.sensor_major + '</p>';
              attributes += '<p><b>Minor:</b> ' + full.sensor_minor + '</p>';
              return attributes;
            }
          },
          { "data": "sensor_type", "name": "sensor_type", "width": "10%" },
        ]
        ,
        fnRowCallback: function (nRow, aData, iDisplayIndex) {
          var display_number = self.constant.dataTableNo(dataTable, iDisplayIndex);
          $('td:eq(0)', nRow).html(display_number);
          return nRow;
        },
      });
  }
}
