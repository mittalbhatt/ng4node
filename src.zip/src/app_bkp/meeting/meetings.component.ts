import { Component, OnInit } from '@angular/core';
import { MeetingsService } from './meetings.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { SpaceService } from "../space/space.service";
import { UserService } from "../user/user.service";

import * as moment from 'moment';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-meetings',
  templateUrl: './meetings.component.html',  
  providers:[MeetingsService, SpaceService]
})
export class MeetingsComponent implements OnInit {
    private requestUrl:String;
    meeting = {
      "title":"",
      "organizer":"",
      "start_date":"",
      "end_date":"",
      "building_id":"",
      "floor_id":"",
      "space_id":""
    };
    timezone:any;
    errorMessage:String;
    moduleParam:any;
    Formtoken:any;
    localVal:any;
    user_id : any;
    user_type: any;
    currentDate:any;
    listResponseData:any;
    buildingList: any = [];
    floorList: any = [];
    spaceList: any = [];

  constructor(
    private meetingsService:MeetingsService,
    private router: Router,
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService,
    private spaceService:SpaceService,
    private _userService: UserService   
    ) { }

  ngOnInit() {           
     this.currentDate = moment().format('YYYY-MM-DD HH:mm');
     this.moduleParam = this.constant.meetings;
     this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param+'?dt='+this.currentDate+'&flag=0';
     this.getUserInfo();   
     this.getSchedule(this.requestUrl);
     this.getFormToken();
     this.datePickerData();
     this.getAllListData();     
  }

  getUserInfo() {
    this._userService.getUserInfo().subscribe((res) => {
      if (res) {
        this.timezone = res.timezone;       
      }
    });
  }

  /**
   * @uses get all data for building, spacetype and amenities listing
   *
   * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
   *
   */
  getAllListData() {
    this.meetingsService.allDrowDownListData()
      .then((res) => {
        this.listResponseData = res;
        if (this.listResponseData) {
          this.buildingList = this.listResponseData.data.building;
          this.floorList = this.listResponseData.data.floor;
          this.spaceList = this.listResponseData.data.space;
        }
      });
  }

  getBuildingChangeStatus(evt){
    if(evt.value){
      this.spaceService.floorListData(evt.value)
      .then((res) => {
        if (res) {
          this.listResponseData = res;
          this.meeting.floor_id = "";
          this.meeting.space_id = "";
          this.spaceList = [];
          this.floorList = this.listResponseData.data;
        }
      });
    } else {
      this.meeting.floor_id = "";
      this.meeting.space_id = "";
      this.getAllListData();
    }
  }

  getFloorChangeStatus(evt){
    if(evt.value){
      this.spaceService.spaceListData(evt.value)
      .then((res) => {
        if (res) {
          this.listResponseData = res;
          this.meeting.space_id = "";
          this.spaceList = (this.listResponseData.data)?this.listResponseData.data:'';
        }
      });
    } else {
      this.meeting.space_id = "";
      this.getAllListData();
    }
  }

  onSubmit(form){

    let selected_bulding ="";
    let selected_floor  ="";
    let selected_space  ="";

    this.buildingList.forEach(function(val){
      if(val.building_id === form.building_id){
        selected_bulding = val.building_name;
      }
    });

    this.floorList.forEach(function(val){
      if(val.floor_id === form.floor_id){
        selected_floor = val.floor_name;
      }
    });

    this.spaceList.forEach(function(val){
      if(val.space_id === form.space_id){
        selected_space = val.space_name;
      }
    });



    let title = (form.title)?form.title:'';
    let organizer = (form.organizer)?form.organizer:'';
    let start_date = (form.start_date)?form.start_date:'';
    let end_date = (form.end_date)?form.end_date:'';
    let building_name = (selected_bulding)?selected_bulding:'';
    let floor_name = (selected_floor)?selected_floor:'';
    let space_name = (selected_space)?selected_space:'';


    start_date = (start_date)?moment(start_date, 'MM/DD/YYYY').format('YYYY-MM-DD'):'';
    end_date = (end_date)?moment(end_date, 'MM/DD/YYYY').format('YYYY-MM-DD'):'';
    this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param+'?title='+title+'&organizer='+organizer+'&start_date='+start_date+'&end_date='+end_date+'&building_name='+building_name+'&floor_name='+floor_name+'&space_name='+space_name+'&dt='+this.currentDate+'&flag=1';
    this.getSchedule(this.requestUrl);
  }

  getSchedule(serviceUrl) {
    var self = this;
    var userType = '';
    $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };
    var dataTable = $("#schedule-list")
      .on( 'processing.dt', function ( e, settings, processing ) {
            if(processing)
            {
                if(!($('#schedule-list').find('#loader-container').length))
                {
                    $("#schedule-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
                }
            }
            else {
                $('#loader-container').remove();
            }
        })
    .DataTable({
      "destroy": true,
      "serverSide": true,
      "lengthMenu": self.constant.showRecords,
      "searching":true,
      "responsive": true,
      "order": [[3, 'desc']],
      "ajax": {
        url : serviceUrl,
        type: 'get',
        "beforeSend": function(xhr){
            xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
        },
        "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;
            userType = respData.userType;
            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
      },

      "columns": [
      {"data": "space_name", "name": "space_name","width": "25%",
        "render": function (data, type, full, meta) {          
          var actionLinks = "";
          var building_name = "";
          var space_name = "";
          var floor_name = "";

          if(full.building_name){
            building_name = full.building_name;
          }

          if(full.space_name){
            space_name = full.space_name;
          }

          if(full.floor_name){
            floor_name = full.floor_name;
          }


          var imageHtml ="";

          if(full.space_image_path != "" && full.space_name != "") {
            if(userType=='Member')
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:gray;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
            else
            {
              imageHtml += "<span><b><a id='info_"+full.space_id+"' class='meeting-details' style='border-bottom: none;' title='Click to detail view'>"+space_name+"</a></b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:gray;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
          } else {
            
            if(userType=='Member')
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:gray;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
            else
            {
              imageHtml += "<span><b><a id='info_"+full.space_id+"' class='meeting-details' style='border-bottom: none;' title='Click to detail view'>"+space_name+"</a></b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:gray;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
          }


          //actionLinks = "<b><a id='info_"+full.space_id+"' class='meeting-details' style='border-bottom: none;' title='Click to detail view'>"+space_name+"</a></b><br /><i class='font-icon font-icon-build color-blue'></i><i> " + building_name+'</i>';
          return imageHtml;
        }
      },
      {"data": "booking_title", "name": "booking_title","width": "30%"},
      {"data": "start_time", "name": "start_time","width": "30%",
        "render": function (data, type, full, meta) {
        
            // Converted utc to user timezone
            var displayStartDate = self.constant.utcToTimezone(full.utc_start_time, self.timezone, 'MM/DD/YYYY');
            var displayStartTime = self.constant.utcToTimezone(full.utc_start_time, self.timezone, 'h:mm A'); 
            var displayEndTime = self.constant.utcToTimezone(full.utc_end_time, self.timezone, 'h:mm A'); 
            var start_time = moment(displayStartDate).format('D MMM, YYYY') + '<br> '+displayStartTime;
            var end_time = displayEndTime;

            var imageHtml = '';
            imageHtml += "<span style='color:grey;font-size:14px;'>"+start_time + " - " + end_time + "</span>";
            imageHtml += '<br><span class="subdomain">';
                imageHtml += '<div class="ipad_company_url" style="color:green">';
                    imageHtml += '<i class="fa fa-clock-o" aria-hidden="true"></i> '+full.booking_duration+' Minutes';
                imageHtml += '</div>';
            imageHtml += '</span>';

            return imageHtml;
        }
      },
      

      {"data": "end_time", "name": "end_time","width": "30%", "orderable": false,
        "render": function (data, type, full, meta) {
          var actionLinks = "";
          if(full.is_delete_valid == 1){
            actionLinks += '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="'+full.booking_id+'" class="tabledit-edit-button btn btn-sm btn-default meeting-edit" style="float: none;" title="Edit"><span class="glyphicon glyphicon-pencil"></span></button><button type="button" id="delete_'+full.booking_id+'" class="tabledit-delete-button btn btn-sm btn-default meeting-delete" style="float: none;"><span class="glyphicon glyphicon-trash" title="Delete"></span></button></div>';
          }  else {
            actionLinks += '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="'+full.booking_id+'" class="tablview-button btn btn-sm btn-default meeting-view" style="float: none;" title="View"><span class="glyphicon glyphicon-eye-open" ></span></button></button></div>';
          }        
          return actionLinks;
        }
      }
    ],
  	fnRowCallback: function( nRow, aData, iDisplayIndex )
  	{
      $('td:eq(3)',nRow).addClass('aligncenter');
  		return nRow;
  	},
  	fnDrawCallback: function( oSettings )
  	{
  		if(oSettings.aoData[0] == undefined) {
            $('#schedule-list_info').hide();
            $('#schedule-list_paginate').hide();
        }


      $(document).on('click', 'button.meeting-delete', function (e) {


        var deleteId = this.id;
        var delId = deleteId.split('_');
        var delIdFinal = delId[1];

        e.preventDefault();
        swal({
          title: "Are you sure?",
          text: "You want to remove this record?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel"
        },
        function(isConfirm) {
          if (isConfirm) {
            self.deletemeetings(delIdFinal, dataTable);
          }

        });
      });


      $(document).on('click', 'button.meeting-edit', function (e) {

        var bookingId = this.id;
        self.editmeetings(bookingId);
        e.preventDefault();
      });

      $(document).on('click', 'button.meeting-view', function (e) {

        var bookingId = this.id;
        self.viewmeetings(bookingId);
        e.preventDefault();
      });

      $(document).on('click', 'a.meeting-details', function (e) {
        var bookingId = this.id;
        var bookid = bookingId.split('_');
        var bookIdFinal = bookid[1];
          self.showSpaceById(bookIdFinal);
      });

    }
  });
  }


    editmeetings(bookingId) {
        this.router.navigate(['/event/edit/', bookingId]);
    }

    viewmeetings(bookingId) {
        this.router.navigate(['/event/view/', bookingId]);
    }

    showSpaceById(bookIdFinal){
      this.router.navigate([this.moduleParam.show_space+bookIdFinal]);
    }


    changeDate(date, time_difference){
      return date;
      //return moment(date).utcOffset(time_difference).format('DD/MM/YYYY hh:mm A');
    }
    /**
     * @uses (deletemeetings) remove meeting from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */

    deletemeetings(id, dataTable){
        this.meetingsService.removeMeetings({'booking_id':id, "_csrf":this.Formtoken})
            .then(
            response => {
              if(response){
                 this.localVal = response;
                 if(this.localVal.success){
                    dataTable.ajax.reload(null, false);
                    this.router.navigate([this.moduleParam.meetings_link]);
                    this._notificationService.add(new Notification('success', this.localVal.message));
                 }else{
                    this._notificationService.add(new Notification('error', this.localVal.message));
                 }
              }
            },
            error =>  {
              this.errorMessage = <any>error;
                this._notificationService.add(new Notification('error', error));
            });
    }

    datePickerData() {

        var self = this;
        // Booking date

        $('.datePicker').datetimepicker({
            format: 'MM/DD/YYYY',
            //minDate: this.convertDateFormate(new Date())
        });


        $("#start_date").click(function () {
          $('.start_date').trigger("click");
        });

        $("#start_date").keydown(function (event) {
          return false;
        });

         $("#end_date").click(function () {
          $('.end_date').trigger("click");
        });

        $("#end_date").keydown(function (event) {
          return false;
        });

    }

    convertDateFormate(date){
        return ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();
      }

    // On change methods
    dueStartDateChange(e) {
      this.meeting.start_date = e;
    }

    dueEndDateChange(e) {
      this.meeting.end_date = e;
    }


     /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

      getFormToken() {
         this.auth.getToken()
         .subscribe( response => {
             if(response){
               this.Formtoken = response;
             }
           },error =>  {
             this.errorMessage = <any>error
           });
      }

    clearSearch(){
      this.meeting.title = "";
      this.meeting.organizer = "";
      this.meeting.start_date = "";
      this.meeting.end_date = "";
      this.meeting.building_id = "";
      this.meeting.floor_id = "";
      this.meeting.space_id = "";
      this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param+'?dt='+this.currentDate+'&flag=0';
      this.getSchedule(this.requestUrl);
    }    
}