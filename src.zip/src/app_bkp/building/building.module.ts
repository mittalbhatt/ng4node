import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BuildingComponent } from './building.component';
import { AddComponent }     from './addBuilding/add.component';
import { EditComponent }     from './editBuilding/edit.component';
import { BuildRoute } from './building.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';


@NgModule({
  imports: [
    CommonModule,
    BuildRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [BuildingComponent,AddComponent,EditComponent]
})
export class BuildingModule { }
