import { Component, OnInit } from '@angular/core';
import { BuildingService } from './building.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-building',
  templateUrl: './building.component.html',
  providers:[BuildingService]
})
export class BuildingComponent implements OnInit {
    private requestUrl:String;
    errorMessage:String;
    selectedCountry:any;
    selectedState:any;
    build:Object = {};
    countryList:any;
    moduleParam:any;
    buildData:any;
    Formtoken:any;
    statList:any;
    localVal:any;
    delId:any;

  constructor(
    private buildService:BuildingService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {

    this.moduleParam = this.constant.building;
    this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param;
    this.countryList = this.constant.country;
    this.statList = this.constant.us_state;
    this.getBuldingInfo(this.requestUrl);
    this.getFormToken();


  }

  /**
	 * @uses  (getBuldingInfo) Building list using server side datatable
	 *
	 * @author RK < rakesh.rathava@softwebsolutions.com >
	 *
	*/   
  getBuldingInfo(serviceUrl) {
  	var self = this;
    $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };
  	var dataTable = $("#building-list")
    .on( 'processing.dt', function ( e, settings, processing ) {
          if(processing)
          {
              if(!($('#building-list').find('#loader-container').length))
              {
                  $("#building-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
              }
          }
          else {
              $('#loader-container').remove();
          }
      })
    .DataTable({
  		"destroy": true,
  		"serverSide": true,
  		"lengthMenu": self.constant.showRecords,
  		"searching":true,
  		"responsive": true,    
  		"order": [[1, 'asc']],
  		"ajax": {
          url: serviceUrl,
          type: 'get',
          "beforeSend": function(xhr){
              xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
          },
          "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;
            
            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }

      },
  		"columns": [
      {"data": "building_id", "name": "building_id","width": "5%","orderable": false}, 
  		{"data": "building_name", "name": "building_name","width": "35%",

  			"render": function (data, type, full, meta) {
  				var imageHtml ="";



		          // if(full.building_image != "" && full.image_path != "") {
		          //   imageHtml += "<img src='"+ full.image_path + "' title='" + full.building_name + "' [onError]='this.src="+"images/default/no_images/80X80.png"+"' width='35%' style='border:1px;border-style:solid;border-color:#021a40;'/>&nbsp;&nbsp;<span><i><b>"+full.building_name+"<b/></i></span>";
		          // } else {
		          //   imageHtml += "<img src='images/default/no_images/80X80.png' title='" + full.building_name  + "' width='35%' style='border:1px;border-style:solid;border-color:#021a40;'/>&nbsp;<span><i><b>"+full.building_name+"<b/></i></span>";
		          // }

            imageHtml += '<div class="company_box">';
              imageHtml += '<span class="companyImage">';
                imageHtml += '<img src="'+full.image_path+'" onerror="this.onerror=null;this.src="/images/default/no_images/70X70.png";" style="max-width: 80px;" class="borderimg">';
              imageHtml += '</span>';
              imageHtml += '<span class="companyText">';
                imageHtml += '<span class="companyname">'+full.building_name+'</span><br>';
              imageHtml += '</span>';
            imageHtml += '</div>';

          return imageHtml;

		          
  			}
  		}, 
  		{"data": "full_address","name": "address_1","width": "38%",

        "render": function (data, type, full, meta) {
          
          if(full.country === "united_states_of_america"){
	          var country = self.getCountry(full.country);
	            if(country != undefined && country != ""){
	              full.country = country;
	          };

	          var state = self.getState(full.state);
	            if(state != undefined && state != ""){
	              full.state = state;
	          };
          }
          

          var address_1 = "";
          if(full.address_1 !== "" && full.address_1 != null){
          	address_1 = "<span style='color:grey;font-size:14px;'>"+full.address_1.substring(0,1).toUpperCase()+full.address_1.substring(1)+', ';
          }

          var address_2 = "";
          if(full.address_2 !== "" && full.address_2 != null){
          	address_2 = full.address_2.substring(0,1).toUpperCase()+full.address_2.substring(1)+', ';
          }

          var city = "";
          if(full.city !== "" && full.city != null){
          	city = full.city.charAt(0).toUpperCase() + full.city.substr(1).toLowerCase()+', '; 
          }

          var postal_code = "";
          if(full.postal_code !== "" && full.postal_code != null){
          	postal_code = full.postal_code+', </span>';
          }

          var full_state = "";
          full.state = full.state.charAt(0).toUpperCase() + full.state.substr(1).toLowerCase(); 
          if(full.state !== "" && full.state != null){
          	full_state = ' <br /><span class="color-blue">'+full.state+',</span>';
          }

          var full_country = "";
          full.country = full.country.charAt(0).toUpperCase() + full.country.substr(1).toLowerCase(); 
          if(full.country !== "" && full.country != null){
          	full_country =  '<br /><span class="color-blue">'+full.country+'</span>';
          }

          var fullAddress = address_1+' '+address_2+' '+city+' '+postal_code+full_state+full_country;
            return fullAddress;
          }

      },           
  		{"data": "no_of_floor", "name": "no_of_floor","width": "5%","orderable": false},
      {
          "data": "status",
          "name": "status",
          "width": "5%",
          "orderable": true,
          "searchable": true,
          "render": function (data, type, full, meta) {

            var statusStr = '';
            statusStr = '<div title="Inactive"  class="checkbox-bird building-status-update" id="buildingSatusUpdate_' + full.building_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox"/><label></label></div>';
            if (full.status == 1) {
              statusStr = '<div title="Active"  class="checkbox-bird green building-status-update" id="buildingSatusUpdate_' + full.building_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox" checked/><label></label></div>';
            }

            return statusStr;
          }
      },
  		{
	  		"data": "action", 
	  		"name": "action", 
	  		"orderable": false,
	  		"searchable": false, 
	  		"width": "15%",
	  		"render": function (data, type, full, meta) {
          // var actionLinks = '<a title="Edit" id="'+full.building_id+'" class="btn btn-primary-outline btn-sm building-edit"><i class="fa fa-edit"></i></a>';
          // actionLinks += '&nbsp;<a title="Delete" class="btn btn-danger-outline btn-sm building-delete" id="delete_'+full.building_id+'"><i class="fa fa-trash-o"></i></a>
          var actionLinks = '<div class="btn-group btn-group-sm" style="float: none;"><button type="button" id="'+full.building_id+'" class="tabledit-edit-button btn btn-sm btn-default building-edit" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button><button type="button" id="delete_'+full.building_id+'" class="tabledit-delete-button btn btn-sm btn-default building-delete" style="float: none;"><span class="glyphicon glyphicon-trash"></span></button></div>';
	  			return actionLinks;
  		}     
  	}          
  	]
  	,
  	fnRowCallback: function( nRow, aData, iDisplayIndex )
  	{  
      var display_number = self.constant.dataTableNo(dataTable, iDisplayIndex);
      $('td:eq(0)', nRow).html(display_number);      
      $('td:eq(0)',nRow).addClass('aligncenter');
      $('td:eq(3)',nRow).addClass('aligncenter');
      $('td:eq(4)',nRow).addClass('aligncenter');
      $('td:eq(5)',nRow).addClass('aligncenter');
      return nRow;
  	},
  	fnDrawCallback: function( oSettings )
  	{  
      if(oSettings.aoData[0] == undefined) {
          $('#schedule-list_info').hide();
          $('#schedule-list_paginate').hide();
      }

  		$(document).on('click', 'button.building-edit', function (e) {
  			var buildId = this.id;
  			self.editBuilding(buildId);
  			e.preventDefault();
  		});

      $(document).on('click', '.building-status-update', function (e) {
          var buildingStatusIdVal = this.id;

          e.preventDefault();
          swal({
            title: "Are you sure?",
            text: "You want to update this status!",
            type: "info",
            showCancelButton: true,
            confirmButtonClass: "btn-confirm",
            confirmButtonText: "Update",
            cancelButtonText: "Cancel"
          },
            function (isConfirm) {
              if (isConfirm) {
                  var buildingIdSplitted = buildingStatusIdVal.split('_');
                  var buildingStatusId = buildingIdSplitted[1];
                  var buildingStatus = buildingIdSplitted[2];
                  self.buildingStatusUpdate(buildingStatusId, buildingStatus, dataTable);
              }
            });
        });



  		$(document).on('click', 'button.building-delete', function (e) {

  			var deleteId = this.id;
  			var delId = deleteId.split('_');
  			var delIdFinal = delId[1];

  			e.preventDefault();
  			swal({
  				title: "Are you sure?",
  				text: "You want to remove this record?",
  				type: "warning",
  				showCancelButton: true,
  				confirmButtonClass: "btn-danger",
  				confirmButtonText: "Delete",
  				cancelButtonText: "Cancel"        
  			},
  			function(isConfirm) {
  				if (isConfirm) {          
  					self.deleteBuilding(delIdFinal, dataTable);
  				}        

  			});
        
  		});

  	}
  });
  }

  	/**
  	 * @uses (editBuilding) to edit selected building record
  	 *
  	 * @author RK < rakesh.rathava@softwebsolutions.com >
  	 *
  	*/
    editBuilding(id){
      this.router.navigate([this.moduleParam.edit_building_link+id]);
    }


    buildingStatusUpdate(buildingId, status, dataTable){
        this.buildService.buildingStatusUpdate({'building_id':buildingId,'status':status, "_csrf":this.Formtoken})
                .then(
                response => {
                  if(response){
                     this.localVal = response;
                     if(this.localVal.success){
                       dataTable.ajax.reload(null, false);
                       this.router.navigate([this.moduleParam.building_link]);
                        this._notificationService.add(new Notification('success', this.localVal.message));
                     }else{
                        this._notificationService.add(new Notification('error', this.localVal.message));   
                     }
                  }
                },
                error =>  {
                  this.errorMessage = <any>error;
                    this._notificationService.add(new Notification('error', error));
                });
    }



    getCountry(county_code){
      for(let data of this.countryList) {
        if(data.key === county_code){
          this.selectedCountry = data.value;
        }
      }
      return this.selectedCountry;
    }

    getState(state_code){
      for(let data of this.statList) {
        if(data.key === state_code){
          this.selectedState = data.value;
        }
      }
      return this.selectedState;
    }
    
    /**
     * @uses (deleteBuilding) remove building from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */
    deleteBuilding(id, dataTable) {
    
      this.delId = {'building_id':id,"_csrf":this.Formtoken};
          this.buildService.removeBuilding(this.delId)
                .then(
                response => {
                  if(response){
                     this.localVal = response;
                     if(this.localVal.success){
                       dataTable.ajax.reload(null, false);
                       this.router.navigate([this.moduleParam.building_link]);
                       this._notificationService.add(new Notification('success', this.localVal.message));   
                     }else{
                        this._notificationService.add(new Notification('error', this.localVal.message));   
                     }
                  }
                },
                error =>  {
                  this.errorMessage = <any>error;
                    this._notificationService.add(new Notification('error', error));
                });
      
    }

    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */
    getFormToken() {
       	this.auth.getToken()
       	.subscribe( response => {
           if(response) {
             this.Formtoken = response;
           }
        },error =>  {
           this.errorMessage = <any>error
         });
    }

}
