import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from './../common/services/notifications.service';
import { Constants } from './../common/services/constants';
import { AuthService } from './../auth/auth.service';
import { SearchService } from './search.service';
import { SpaceService } from "./../space/space.service";
import { UserService } from "./../user/user.service";
import { EventService } from "./../event/event.service";

import * as moment from 'moment';
import 'moment-timezone';
declare var $: any;

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  providers: [SearchService, SpaceService, EventService]
})

export class SearchComponent implements OnInit {

  // Model
  searchModel = { 
    "event_date":"",
    "start_time":"",    
    "building_id":"",
    "floor_id":"",
    "space_type_id":"",
    "capacity":"",
    "hours":"",
    "minutes":""
  };
  

  // Variables
  // currentDate: any;
  //currentTime: any;
  fixTimeData: any;
  timezone: any;
  currentDateTime: any;
  currentTimeRounded: any;
  displayDateTimeFormat: string='MM/DD/YYYY h:mm A';
  displayDateFormat: string='MM/DD/YYYY';
  displayTimeFormat: string= 'h:mm A';
  standardTime: any;
  dateSettings: any;
  startTimeSettings: any;
  moduleParam: any;
  listResponseData:any;
  buildingList: any = [];
  floorList: any = [];
  spaceTypeList: any = [];  
  amenitiesList: any = [];  
  selectedAmenitiesList: any = {};
  hoursList: any = [0,1,2,3,4,5,6,7,8,9];
  minutesList: any = [15,30,45];
  hourStepSlot: number;
  minuteStepSlot: number;
  eventIsPopup: any='popup';
  meetingParam: any;
  private requestUrl: String;
  defaultDatetime: any;
  minDate: any;
  Formtoken:any;
  errorMessage: any = {};
  // Constructor
  constructor(
    private auth: AuthService,
    private router: Router,
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private searchService:SearchService,
    private spaceService:SpaceService,
    private _userService:UserService,    
    private _eventService: EventService    
    
  ) {
    this.hourStepSlot = 0;
    this.minuteStepSlot = 15;    
  }


  // On init
  ngOnInit() {
    this.getUserInfo();
    this.getAllListData();
    this.getFormToken();
  }


  /**
   * @uses get user info
   *
   * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
   *
   */
	getUserInfo() {
		this._userService.getUserInfo().subscribe((res) => {
			if (res) {      
				this.timezone = res.timezone;
				this.standardTime = res.timezone;
        this.renderData(res.timezone);
      }
		});
	}


  renderData(timezone){
        this.meetingParam = this.constant.meetings;
        this.searchModel.event_date = (this.searchModel.event_date) ? this.searchModel.event_date : this.momentDateTime('', timezone, this.displayDateFormat); 
        this.currentDateTime = this.momentDateTime('', timezone, this.displayDateTimeFormat); 
        this.currentTimeRounded = this.roundTime(this.currentDateTime, this.minuteStepSlot, this.displayTimeFormat); 
        this.searchModel.start_time = this.currentTimeRounded;
        this.defaultDatetime = moment(this.searchModel.event_date+' '+this.searchModel.start_time);    

        // *******                  
        // var momentEventTime = moment(this.defaultDatetime).format('YYYY-MM-DD');
        // var momentCurrentTime = this.momentDateTime('', timezone, 'YYYY-MM-DD');
        // if(momentCurrentTime != momentEventTime){
        //   this.minDate = this.momentDateTime(this.defaultDatetime, timezone, 'MM/DD/YYYY 00:01:00');             
        // } else {
        //   this.minDate = this.momentDateTime('', timezone);
        // }
        
        // Date and time Picker settings
        this.dateSettings = {
          format: 'MM/DD/YYYY',
          minDate: this.momentDateTime('', timezone),
          defaultDate:this.momentDateTime('', timezone),
        };
        this.startTimeSettings = {
          format: 'LT',
          defaultDate: this.defaultDatetime,
          stepping: this.minuteStepSlot,
          //minDate: this.minDate,
          maxDate: this.momentDateTime('', timezone, 'MM/DD/YYYY 23:59:00'),
          useCurrent: true,	
        };       
        $('#eventDatepicker').datetimepicker(this.dateSettings);
        $('#eventTimepicker').datetimepicker(this.startTimeSettings);
        
        
        this.moduleParam = this.constant.search;
        this.requestUrl = this.constant.baseUrl + this.moduleParam.get_list_param + '?&event_date='+this.searchModel.event_date+'&start_time='+this.searchModel.start_time+'&hours='+this.hourStepSlot+'&minutes='+this.minuteStepSlot+'&flag=0'; 
        this.getSpaceListing(this.requestUrl);
  }

  /**
   * @uses get all listing data
   *
   * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
   *
   */
  getAllListData() {
    this.searchService.getAllListData()
      .then((res) => {
        this.listResponseData = res;               
        if (this.listResponseData) {
          this.buildingList = this.listResponseData.data.building;
          this.floorList = this.listResponseData.data.floor;
          this.spaceTypeList = this.listResponseData.data.spacetypes;
          this.amenitiesList = this.listResponseData.data.amenities;          
        }
      });
    }

   
  // get Space listing with datatable
  getSpaceListing(serviceUrl) {
    var self = this;
    var userType = '';
    $.fn.dataTableExt.sErrMode = function (settings, helpPage, message) { if (message) { console.log(message) } };
    var dataTable = $("#searched-space-list")
      .on('processing.dt', function (e, settings, processing) {
        if (processing) {
          if (!($('#searched-space-list').find('#loader-container').length)) {
            $("#searched-space-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
          }
        }
        else {
          $('#loader-container').remove();
        }
      })
      .DataTable({
        "destroy": true,
        "serverSide": true,
        "lengthChange": false,
        "searching": false,        
        "responsive": true,
        "iDisplayLength": 5,
        "order": [[0, 'ASC']],
        "ajax": {
          url: serviceUrl,
          type: 'get',
          "beforeSend": function (xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + localStorage.getItem('userAccessToken'));
          },
          "dataFilter": function (data) {
            var json = $.parseJSON(data);
            var respData = json;
            userType = respData.userType;
            if (respData.status === "fail") {
              self.auth.logout();
              self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
        },
        "columns": [
          {
            "data": "space_name",
            "name": "space_name",
            "width": "25%",
            "render": function (data, type, full, meta) {
                           
              var timeArray = full.nextTimeArray; 
                                        
              // Time array html
              var timeHtml = '';
              Object.keys(timeArray).forEach(function(key) {
                          
                if(timeArray[key].available) {
                  timeHtml += '<a id="booktime_'+key+'_'+full.space_id+'" data-spaceid="'+full.space_id+'" data-date="'+timeArray[key].date+'" data-start_time="'+timeArray[key].start_time+'" data-end_time="'+timeArray[key].end_time+'" class="btn btn-inline btn-secondary-outline  space_time_button">';                
                  timeHtml += '<span>'+timeArray[key].start_time+'</span>';
                  timeHtml += '<span class="endTime" style="display:none"> - '+timeArray[key].end_time+'</span>';       
                  timeHtml +='</a>';
                } else {
                  timeHtml += '<span class="btn btn-inline btn-secondary">';  
                  timeHtml += '<span>'+timeArray[key].start_time+'</span>';
                  timeHtml += '<span class="endTime"> - '+timeArray[key].end_time+'</span>';
                  timeHtml += '</span>';
                }
              });

              // Space Image and Title
              var imageHtml = '';
              imageHtml += '<div class="company_box">';
                imageHtml += '<span class="companyImage">';
                  imageHtml += '<img src="'+full.image_path+'" onerror="this.onerror=null;this.src="/images/default/no_images/70X70.png";" style="min-width: 80px; max-width: 80px;">';
                imageHtml += '</span>';
                imageHtml += '<span class="companyText">';
                  imageHtml += "<span class='companyname'><a id='info_"+full.space_id+"' class='meeting-details' style='border-bottom: none;' title='Click to detail view'>"+data+"</a></span>";           
                  imageHtml += '<div><br />'; 
                  imageHtml += timeHtml;                
                  imageHtml += '</div>';
                imageHtml += '</span>';
              imageHtml += '</div>';

              // Space Amenities list
              var spaceAmenities = '';
              var spaceAmenitiesArr = [];
              if (full.amenityArray != null) {
                full.amenityArray.forEach(res => {
                  var amenityHtml = '';
                  if (res.name != "") {
                    amenityHtml = '<span>';                    
                    if(res.name != "" && res.path != "") {
                      amenityHtml += "<img style='margin:5px;' src='"+ res.path + "' title='" + res.name + "' [onError]='this.src="+"uploads/noImage.png"+"' width='30' />";
                    } else {
                      amenityHtml += "<img style='margin:5px;' src='uploads/noImage.png' title='" + res.name + "' width='30' />";
                    }
                    amenityHtml += '</span>';
                  }
                  spaceAmenitiesArr.push(amenityHtml);
                });
              }
              spaceAmenities = spaceAmenitiesArr.join(' ');
      
              // Main Inner Html
              var innerHtml = "";
              innerHtml += '<div class="row">';
              innerHtml += '<div class="col-md-9">';
              innerHtml += imageHtml;     
              innerHtml += '</div>';

              innerHtml += '<div class="col-md-3 text-right">';

              innerHtml += '<div>';
              innerHtml += spaceAmenities;
              innerHtml += '</div>';

              innerHtml += '<div><br />';
             
              innerHtml += '<a id="'+full.space_id+'" data-spaceid="'+full.space_id+'" type="button" class="btn btn-inline book_meeting" >Book Meeting </a>';
							
              innerHtml += '</div>';

              innerHtml += '</div>';  

              innerHtml += '</div>';

              return innerHtml;
            }
          }         
          
        ],
        fnRowCallback: function (nRow, aData, iDisplayIndex) {
          return nRow;
        },
        fnDrawCallback: function (oSettings) {

          $(document).on('click', 'a.meeting-details', function (e) {
              var bookingId = this.id;
              var bookid = bookingId.split('_');
              var bookIdFinal = bookid[1];
              self.showSpaceById(bookIdFinal);
      	  });

          $(document).on('mouseenter', 'a.space_time_button', function (e) {
                 $('#'+this.id+' span.endTime').show();
          });
          $(document).on('mouseleave', 'a.space_time_button', function (e) {
                 $('#'+this.id+' span.endTime').hide();
          });
          $(document).on('click', 'a.space_time_button', function (e) {                  
                  var data = $(this).data();
                  self.selectEventTime(this.id, data);            
          });
          $(document).on('click', 'a.book_meeting', function (e) {
                var data = $(this).data();
                self.bookMeetingEvent(this.id, data);                                 
          });                           

        }
      });
  }
  
  
  // Book meeting button
  bookMeetingEvent(id, data) {
    this.fixTimeData = data;  
    $('#addEventModal').modal('show');
  }

  // Time buttons
  selectEventTime(id, data) {
    this.fixTimeData = data;  
    $('#addEventModal').modal('show');    
  }
  
  // Show space by id
  showSpaceById(bookIdFinal){
    this.router.navigate([this.meetingParam.show_space+bookIdFinal]);
  }

  /**
   * @uses call service and get floor data when select building
   *
   * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
   *
   */
  getBuildingChangeStatus(evt){
    if(evt.value){
      this.spaceService.floorListData(evt.value)
      .then((res) => {
        if (res) {
          this.listResponseData = res;
          this.searchModel.floor_id = "";
          //this.searchModel.space_id = "";
          //this.spaceList = [];
          this.floorList = this.listResponseData.data;
        }
      });
    } else {
      this.searchModel.floor_id = "";
      //this.searchModel.space_id = "";
      this.getAllListData();
    }
  }


  // Clear search
  clearSearch() {
    this.searchModel.building_id = "";
    this.searchModel.floor_id = "";
    this.searchModel.space_type_id = "";
    this.searchModel.capacity = "";
    this.searchModel.hours = "";
    this.searchModel.minutes = "";

    this.searchModel.event_date = this.momentDateTime('', this.timezone, this.displayDateFormat); 
    this.currentDateTime = this.momentDateTime('', this.timezone, this.displayDateTimeFormat); 
    this.currentTimeRounded = this.roundTime(this.currentDateTime, this.minuteStepSlot, this.displayTimeFormat); 
    this.searchModel.start_time = this.currentTimeRounded;

    this.requestUrl = this.constant.baseUrl + this.moduleParam.get_list_param + '?&event_date='+this.searchModel.event_date+'&start_time='+this.searchModel.start_time+'&hours='+this.hourStepSlot+'&minutes='+this.minuteStepSlot+'&flag=0';
    this.getSpaceListing(this.requestUrl);
  }


  // get Search result 
  onSubmit(form) {

    // Selected Amenities array
    var myObj=form.amenitiesListGroup;
    var result = Object.keys(myObj).filter(function(x) { 
        if(myObj[x].amenity_selected !== undefined && myObj[x].amenity_selected == true){
          return myObj[x];
        } 
    }); 

    var selectedAmenitiesArray = [];
    if(result.length>0) {   
      result.forEach(element => {
        selectedAmenitiesArray.push(myObj[element].amenity_id);       
      });
    }    

    // Form data
    let event_date = (form.event_date)?form.event_date:'';
    let start_time = (form.start_time)?form.start_time:'';
    let hours = (form.hours)?form.hours:0;    
    let minuteAddTime = (hours==0) ? this.minuteStepSlot : 0; 
    let minutes = (form.minutes)?form.minutes:minuteAddTime;

    let building_id = (form.building_id)?form.building_id:'';
    let floor_id = (form.floor_id)?form.floor_id:'';
    let space_type_id = (form.space_type_id)?form.space_type_id:'';
    let capacity = (form.capacity)?form.capacity:'';
    let amenitiesListGroup = encodeURIComponent(JSON.stringify(selectedAmenitiesArray));

    // Request url
    this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param+'?&event_date='+event_date+'&start_time='+start_time+'&hours='+hours+'&minutes='+minutes+'&building_id='+building_id+'&floor_id='+floor_id+'&space_type_id='+space_type_id+'&capacity='+capacity+'&amenities='+amenitiesListGroup+'&flag=1';
              
    // Call function for get search data
    this.getSpaceListing(this.requestUrl);
  }

  
  // change date to formatted date
  momentDateTime(date='', timezone='', format='MM/DD/YYYY hh:mm A') {         
    var momentDate = '';
    if(timezone) {
        momentDate = (date) ? moment.tz(timezone).format(format) : moment.tz(timezone).format(format);
    } else {
        momentDate = (date) ? moment(date).format(format) : moment().format(format);
    }  
    return momentDate;
  }

  // Time with slot of specific minutes
  roundTime(datetime, interval, format='') {  
      var calculateTime = 1000 * 60 * interval;
      var date = (datetime) ? moment(datetime) : moment();  
      var rounded = moment(Math.ceil(moment(date).valueOf() / calculateTime) * calculateTime).format(format);
      return rounded;
  }  

  // On change methods
	eventDateChange(e) {
		this.searchModel.event_date = e;

    //this.renderData(this.timezone);
      
	}
	startTimeChange(e) {
		this.searchModel.start_time = e;	
	}
	
  // Datepicker Events  
	eventDateTrigger() {
		$('.eventDateClass').trigger("click");    
	}
	startTimeTrigger() {
		$('.eventTimeClass').trigger("click");		
  }  
	onKeypressEvent(e) {		
		return false;	
	}
	onKeydown(e){
		return false;	
	}

  
  /**
   * @uses (getFormToken) get csrf form token
   *
   * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
   *
   */
   getFormToken() {
     this.auth.getToken()
     .subscribe(
       response => {
         if(response){
           this.Formtoken = response;
         }
       },
       error =>  {
         this.errorMessage = <any>error
       });
   }
    
}