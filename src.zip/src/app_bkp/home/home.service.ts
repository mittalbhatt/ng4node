﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class HomeService {
    
    private requestUrl:String;
    moduleParam:any;
    responseData:any ={};


    constructor(
        private http: Http,
        private router: Router, 
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.meetings;
    }

    /**
     * @uses (getSchedule) Get Schedule for meetings
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getSchedule() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    getSpaceById(data) {
        let url = this.requestUrl+this.moduleParam.show_space;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (updateAmenities) send amenity update form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    // updateAmenities(data) {
    //     let url = this.requestUrl+this.moduleParam.update_param;
    //     return this.httpClient.post(url, data);
    // }


    // amenityStatusUpdate(data){
    //     let url = this.requestUrl+this.moduleParam.update_status_param;
    //     return this.httpClient.post(url, data);
    // }

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeMeetings(data){
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }
}