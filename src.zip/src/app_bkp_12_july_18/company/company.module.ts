import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyComponent } from './list/company.component';
import { CompanyUpdateComponent }     from './edit/update.component';
import { CompanyRoute } from './company.routing';
import { CompanyService } from './company.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { UiSwitchModule } from 'ng2-ui-switch';
import { DefaultRequestOptions } from '../common/services/default-request-options.service';
import { HttpModule,RequestOptions} from '@angular/http';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CompanyRoute,
    SharedModule,
    UiSwitchModule
  ],
  providers: [CompanyService, FormBuilder,
  { provide: RequestOptions, useClass: DefaultRequestOptions }
  ],
  declarations: [CompanyComponent,CompanyUpdateComponent]
})
export class CompanyModule { }
