import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HomeService } from './home.service';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { UserService } from './../user/user.service';

/** for socket to available room or not - Start - ashwin */
import { SpaceSocketService } from '../space.socket.service';
/** for socket to available room or not - End - ashwin */

import * as moment from 'moment';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  providers:[HomeService]
})
export class HomeComponent implements OnInit {
    private requestUrl:String;
    errorMessage:String;
    moduleParam:any;
    meetingParam:any;
    Formtoken:any;
    localVal:any;
    currentDate:any;
    user_id:any;
    user_type:any;
    timezone: any;

  constructor(
    private home:HomeService,
    private router: Router,
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService,
    private  userService: UserService,
    private spacesocket :SpaceSocketService,
    ) { }



  @ViewChild('layout') canvasRef;
  //image = 'http://smartoffice.softwebopensource.com/images/location/location_1484819832.png';
  image = 'http://priya.softwebsmartoffice.com/images/softwebFloorPlan.png';
  ngAfterViewInit() {
    let canvas = this.canvasRef.nativeElement;
    let context = canvas.getContext('2d');

    let source = new Image();
    source.crossOrigin = 'Anonymous';
    source.onload = () => {
        canvas.height = source.height;
        canvas.width = source.width;
        context.drawImage(source, 0, 0);


        //1.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(121,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Galaxy', 150, 60);

        //2.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(181,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Int.1', 210, 60);

        //3.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(241,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Int.2', 270, 60);

       /* //4.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(301,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('TEST', 330, 60);*/

        //5.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(441,14,60,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Uranus', 470, 60);

        //6.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(506,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('PriyaVyas', 533, 60);

        //7.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(566,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Saturn', 595, 60);

        //8.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(625,14,53,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('SunConf', 650, 60);

        //9.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(121,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Moon', 150, 570);

        //10.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(181,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Mars', 210, 570);

        //11.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(241,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Jupiter', 270, 570);

        //12.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(505,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Earth', 530, 570);

        //13.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(565,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('Mercury', 590, 570);

        //14.
        /*context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(625,530,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('ABCD', 650, 570);*/

        this.image = canvas.toDataURL();
    };
    source.src = this.image;


    this.spacesocket.getSocketSpaces().subscribe((data:any) => {
      if(data.type == 'available-or-not'){        

        var red_color = '#ff8080';
        var green_color = '#ccffcc';
        var orange_color = '#ffbf80';

        /*Galaxy => de57f244-6eda-2573-6918-6ea6da4495e8
        Interview Room 1 => 2cac3852-6d26-a84b-1a47-d71a38ba6257
        Interview Room 2 => b55e1328-2dbf-bc65-c28e-3dbc7ee1a1e5

        Earth Cabin => 09e99df1-ff21-e130-0432-65908e4bfee8
        Mercury => 7d6affc7-ee4f-79fa-86f6-69e785422b62

        Moon => 829c0d70-a41c-522b-75ea-d78d777c9d1e
        Mars => b161d034-1840-ea50-ff9b-0b5ecf87814e
        Jupiter => afbbea0d-d5cf-82b4-cebc-c62d89616de1

        Uranus => 984a226c-f074-730c-a2f1-aa5087ee043e
        Saturn => 6c739045-fe24-2219-6dac-8128a8295feb
        Sun Conference => 44f02670-35b8-c2c6-a32d-527c0f20c84a
        PriyaVyas => b3b8eeab-2182-99d4-6096-148abff0e83e*/


        let context = canvas.getContext('2d');
        context.beginPath();

        var color = green_color;
        if(data.available == 1 || data.available == 2){
          color = red_color;
        }else if(data.available == 3){
          color = orange_color;
        }



        if(data.space_id == 'de57f244-6eda-2573-6918-6ea6da4495e8'){
          context.clearRect(121,14,55,82);
          context.fillStyle=color;
          context.fillRect(121,14,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Galaxy', 150, 60);
        }


        if(data.space_id == '2cac3852-6d26-a84b-1a47-d71a38ba6257'){
          //2.
          context.clearRect(181,14,55,82);
          context.fillStyle=color;
          context.fillRect(181,14,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Int.1', 210, 60);
        }

        if(data.space_id == 'b55e1328-2dbf-bc65-c28e-3dbc7ee1a1e5'){
          //3.
          context.clearRect(241,14,55,82);
          context.fillStyle=color;
          context.fillRect(241,14,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Int.2', 270, 60);
         }

       /* //4.
        context.beginPath();
        context.fillStyle="#ccffcc";
        context.fillRect(301,14,55,82);
        context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
        context.fillText('TEST', 330, 60);*/

        if(data.space_id == '984a226c-f074-730c-a2f1-aa5087ee043e'){
          //5.
          context.clearRect(441,14,60,82);
          context.fillStyle=color;
          context.fillRect(441,14,60,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Uranus', 470, 60);
         }

        if(data.space_id == 'b3b8eeab-2182-99d4-6096-148abff0e83e'){
          //6.
          context.clearRect(506,14,55,82);
          context.fillStyle=color;
          context.fillRect(506,14,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('PriyaVyas', 533, 60);
         }

        if(data.space_id == '6c739045-fe24-2219-6dac-8128a8295feb'){
          //7.
          context.clearRect(566,14,55,82);
          context.fillStyle=color;
          context.fillRect(566,14,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Saturn', 595, 60);
         }

         if(data.space_id == '44f02670-35b8-c2c6-a32d-527c0f20c84a'){
          //8.
          context.clearRect(625,14,53,82);
          context.fillStyle=color;
          context.fillRect(625,14,53,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('SunConf', 650, 60);
         }

         if(data.space_id == '829c0d70-a41c-522b-75ea-d78d777c9d1e'){
          //9.
          context.clearRect(121,530,55,82);
          context.fillStyle=color;
          context.fillRect(121,530,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Moon', 150, 570);
         }
         if(data.space_id == 'b161d034-1840-ea50-ff9b-0b5ecf87814e'){
          //10.
          context.clearRect(181,530,55,82);
          context.fillStyle=color;
          context.fillRect(181,530,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Mars', 210, 570);
         }
         if(data.space_id == 'afbbea0d-d5cf-82b4-cebc-c62d89616de1'){
          //11.
          context.clearRect(241,530,55,82);
          context.fillStyle=color;
          context.fillRect(241,530,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Jupiter', 270, 570);
         }
         if(data.space_id == '09e99df1-ff21-e130-0432-65908e4bfee8'){
          //12.
          context.clearRect(565,530,55,82);
          context.fillStyle=color;
          context.fillRect(505,530,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Earth', 530, 570);
         }
         if(data.space_id == '7d6affc7-ee4f-79fa-86f6-69e785422b62'){
          //13.
          context.clearRect(565,530,55,82);
          context.fillStyle=color;
          context.fillRect(565,530,55,82);
          context.font = "14px impact";context.textAlign = 'center';context.fillStyle = '#003d99';
          context.fillText('Mercury', 590, 570);
         }


        /*if(data.space_id == '12b96ff6-0029-e8de-8aee-590efd726d32'){ // for Venus
          context.clearRect(167,262,73,80);
          context.fillStyle=color;
          context.fillRect(167,262,73,80);

          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('Venus', 205, 300);
        }

        if(data.space_id == '2a3537aa-a45e-193f-cf78-aa9665cc0ccd'){ // for Mercury Cabin
          context.clearRect(167,425,73,80);
          context.fillStyle=color;
          context.fillRect(167,425,73,80);
          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('Mercury', 205, 470);
        }

        if(data.space_id == 'b5c1ff41-a521-d6fd-21c0-ad3979461285'){ // for Earth
          context.clearRect(167,507,73,80);
          context.fillStyle=color;
          context.fillRect(167,507,73,80);
          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('Earth', 205, 550);
        }



        if(data.space_id == 'e515475e-9e63-eba7-c6ef-cf1b5466cac7'){ // for Interview Room 1
          context.clearRect(283,206,38,38);
          context.fillStyle=color;
          context.fillRect(283,206,38,38);

          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('In.1', 303, 230);
        }

        if(data.space_id == '9f8fe857-6e21-f716-7be7-50f12a48bc54'){ // for Interview Room 2
          context.clearRect(283,330,38,42);
          context.fillStyle=color;
          context.fillRect(283,330,38,42);

          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('In.2', 303, 352);
        }


        if(data.space_id == '2863db0e-fbec-55a6-021e-ac80be759a9a'){ // for Galaxy
          context.clearRect(283,459,38,42);
          context.fillStyle=color;
          context.fillRect(283,459,38,42);

          context.font = "14px impact";
          context.textAlign = 'center';
          context.fillStyle = '#003d99';
          context.fillText('GLX', 303, 480);
        }*/

        /*this.socketSpaceData.forEach(function(element){
          if(element.space_id == data.space_id){
            element.available = data.available;
          }
        });*/
      }
    })

  }


  ngOnInit() {
     this.currentDate = moment().format('YYYY-MM-DD HH:mm');
     this.moduleParam = this.constant.home;
     this.meetingParam = this.constant.meetings;

     this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param+'?dt='+this.currentDate;

     this.getFormToken();
     this.getUserInfo();
  }




    getUserInfo() {
      this.userService.getUserInfo()
          .subscribe((data) => {
            this.timezone = data.timezone;  

            this.user_id = data.user_id;
            this.userService.getCompanyUserInfo(this.user_id)
              .subscribe((data) => {
                  this.user_type = data.data.company.user_type;
                  if(this.user_type !== 'MasterAdmin'){

                    this.getMeetings(this.requestUrl);
                  }
              })
        })
    }

  /**
	 * @uses  (getBuldingInfo) amenities list using server side datatable
	 *
	 * @author RK < rakesh.rathava@softwebsolutions.com >
	 *
	*/

  getMeetings(serviceUrl) {    
    var userType = '';
  	var self = this;
    $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };
    var dataTable = $("#schedule-list")
      .on( 'processing.dt', function ( e, settings, processing ) {
          if(processing)
          {

            
              if(!($('#schedule-list').find('#loader-container').length))
              {
                  $("#schedule-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
              }

          }
          else {
              $('#loader-container').remove();
          }
      }).DataTable({
      "destroy": true,
      "serverSide": true,
      "lengthMenu": [5],
      "searching":true,
      "responsive": true,
      "bPaginate": false,
      "data": { "myRequest": new Date() },
      "order": [[3, 'desc']],
      "ajax": {
        url : serviceUrl,
        type: 'get',
        "beforeSend": function(xhr){
            xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
        },
        "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;
            userType = respData.userType;

            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
      },

      "columns": [
      {"data": "booking_title", "name": "booking_title","width": "25%",
       "render": function (data, type, full, meta) {
        
         var imageHtml = '';
            imageHtml += "<span><b><a id='info_"+full.space_id+"' class='meeting-details' style='border-bottom: none;' title='Click to detail view'>"+full.booking_title +  "</a></b></span>";
            return imageHtml;
       }
     },
      {"data": "start_time", "name": "start_time","width": "10%",
        "render": function (data, type, full, meta) {

            // Converted utc to user timezone
            var displayStartDate = self.constant.utcToTimezone(full.utc_start_time, self.timezone, 'MM/DD/YYYY');
            var displayStartTime = self.constant.utcToTimezone(full.utc_start_time, self.timezone, 'h:mm A'); 
            var displayEndTime = self.constant.utcToTimezone(full.utc_end_time, self.timezone, 'h:mm A'); 
            var start_time = moment(displayStartDate).format('D MMM, YYYY') + '<br> '+displayStartTime;;            
            var end_time = displayEndTime;

            // var start_time = full.display_start_date+'<br>'+" "+full.display_start_time;
            // var end_time = " "+full.display_end_time;

            var imageHtml = '';
            imageHtml += "<span style='color:grey;font-size:14px;'>"+start_time + " - " + end_time + "</span>";
            imageHtml += '<br><span class="subdomain">';
                imageHtml += '<div class="ipad_company_url" style="color:green">';
                    imageHtml += '<i class="fa fa-clock-o" aria-hidden="true"></i> '+full.booking_duration+' Minutes';
                imageHtml += '</div>';
            imageHtml += '</span>';


            return imageHtml;

        }
      },
      {"data": "building_name", "name": "building_name","width": "30%",
        "render": function (data, type, full, meta) {
          var actionLinks = "";
          var building_name = "";
          var space_name = "";
          var floor_name = "";

          if(full.building_name){
            building_name = full.building_name;
          }

          if(full.space_name){
            space_name = full.space_name;
          }

          if(full.floor_name){
            floor_name = full.floor_name;
          }


          var imageHtml ="";

         if(full.space_image_path != "" && full.space_name != "") {
            if(userType=='Member')
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
            else
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='iconsmall floorsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='iconsmall buildingsmicon'>&nbsp;</i><span style='color:grey;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }

          } else {
            if(userType=='Member')
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='font-icon font-icon-burger color-orange'>&nbsp;</i><span style='color:grey;font-size:14px;margin-left: 4px;'> " + floor_name+"</span><br/><i class='font-icon font-icon-build color-red'>&nbsp;</i><span style='color:grey;font-size:14px;'>" + building_name+"</span>";
            }
            else
            {
              imageHtml += "<span><b>"+space_name+"</b></span><br/><i class='font-icon font-icon-burger color-orange'>&nbsp;</i><span style='color:grey;font-size:14px;'> " + floor_name+"</span><br/><i class='font-icon font-icon-build color-red'>&nbsp;</i><span style='color:grey;font-size:14px;margin-left: 4px;'>" + building_name+"</span>";
            }
          }


          return imageHtml;
        }
      },
      // {"data": "space_name", "name": "space_name","width": "20%"},
      {"data": "organizer_full_name", "name": "organizer_full_name","width": "20%",
        "render": function (data, type, full, meta) {
          return "<span style='color:#4169e1;'>"+full.organizer_full_name+"</span>"
        }
      }
     
      // {"data": "end_time", "name": "end_time","width": "10%",

      //   "render": function (data, type, full, meta) {
      //       var end_time = full.display_end_date+" "+full.display_end_time;
      //       return end_time;
      //   }
      // },
      //  {"data": "booking_duration", "name": "booking_duration","width": "15%",

      //   "render": function (data, type, full, meta) {
      //       var booking_duration = "00 Minutes";
      //       if(full.booking_duration != "" && full.booking_duration != undefined){
      //         booking_duration = full.booking_duration+" Minutes ";
      //       }
      //       return booking_duration;
      //   }
      // }
    ],
  	fnRowCallback: function( nRow, aData, iDisplayIndex )
  	{
  		return nRow;
  	},
  	fnDrawCallback: function( oSettings )
  	{

        if(oSettings.aoData[0] == undefined) {
            $('#schedule-list_info').hide();
            $('#schedule-list_paginate').hide();
            // $('#cardSection').hide();
            // $('#no-data-available').show();
        }
        else {

            // $('#no-data-available').hide();

        }


      $(document).on('click', 'a.meeting-delete', function (e) {

        var deleteId = this.id;
        var delId = deleteId.split('_');
        var delIdFinal = delId[1];

        e.preventDefault();
        swal({
          title: "Are you sure?",
          text: "You want to remove this record?",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel"
        },
        function(isConfirm) {
          if (isConfirm) {
            self.deletemeetings(delIdFinal, dataTable);
          }

        });
      });

      $(document).on('click', 'a.meeting-details', function (e) {
        var bookingId = this.id;
        var bookid = bookingId.split('_');
        var bookIdFinal = bookid[1];
          self.showSpaceById(bookIdFinal);
      });

    }
  });
  }


    showSpaceById(bookIdFinal){
      this.router.navigate([this.meetingParam.show_space+bookIdFinal]);
    }


    changeDate(date, time_difference){
      return moment(date).utcOffset(time_difference).format('DD/MM/YYYY hh:mm A');
    }

    /**
     * @uses (deletemeetings) remove meeting from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */

    deletemeetings(id, dataTable){
        this.home.removeMeetings({'booking_id':id, "_csrf":this.Formtoken})
            .then(
            response => {
              if(response){
                 this.localVal = response;
                 if(this.localVal.success){
                    dataTable.ajax.reload(null, false);
                    this.router.navigate([this.moduleParam.meetings_link]);
                    this._notificationService.add(new Notification('success', this.localVal.message));
                 }else{
                    this._notificationService.add(new Notification('error', this.localVal.message));
                 }
              }
            },
            error =>  {
              this.errorMessage = <any>error;
                this._notificationService.add(new Notification('error', error));
            });
    }

     /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

      getFormToken() {
         this.auth.getToken()
         .subscribe( response => {
             if(response){
               this.Formtoken = response;

             }
           },error =>  {
             this.errorMessage = <any>error
           });
      }
}
