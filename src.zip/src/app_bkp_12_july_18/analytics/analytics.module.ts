import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnalyticsComponent } from './analytics.component';
import { AnalyticsRoute } from './analytics.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { DetailComponent }   from './detail/detail.component';

@NgModule({
  imports: [
    CommonModule,
    AnalyticsRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [
	  AnalyticsComponent,	  
	    DetailComponent
  ],
})
export class AnalyticsModule { }
