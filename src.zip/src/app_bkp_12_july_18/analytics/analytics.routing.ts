import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { AnalyticsComponent }     from './analytics.component';
import { DetailComponent }     from './detail/detail.component';

export const AnalyticRoutes: Routes = [
	{
		path: '',
		component: AnalyticsComponent
	},
	{ 
		path: 'detail/:id',		
		component: DetailComponent 
	}
];

export const AnalyticsRoute: ModuleWithProviders = RouterModule.forChild(AnalyticRoutes);