import { Injectable } from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ResponseData } from './../common/classes/response-data';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';


@Injectable()
export class EventService {

    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http, 
        private constant:Constants,
        private httpClient:HttpClient) {
        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.event;
     }


	/**
     * @uses get all space data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */    
    allListData() {
        let url = this.requestUrl+this.moduleParam.get_list_data;       
        return this.httpClient.get(url);
    }

    /**
     * @uses get all space data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */    
    getOMSUsersList() {
        let data = [];
        let url = "http://softwebsolutions.co.in/omsservice/Services.svc/login/GetUserList";
        data['authToken'] = `70121591-F60C-43DB-992D-13231024DB15`;
        return this.httpClient.getWithHeader(url, data);
    }

    
    /**
     * @uses call for get update data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    getEventUpdateData(bookingId) {
        let url = this.requestUrl+this.moduleParam.edit_param+bookingId;
        return this.httpClient.get(url);
    }
      
    

    /**
     * @uses call for insert new space
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    bookEvent(formData) {
        let url = this.requestUrl+this.moduleParam.book_event;
        return this.httpClient.post(url, formData);
    }



      /**
     * @uses call for insert new space
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    updateEvent(formData) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, formData);
    }

   
	/**
     * @uses Observable extractData
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    private extractData(res: Response) {
        let body = res.json();
        return body.data || {};
    }

	/**
     * @uses Observable handleError
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
        const body = error.json() || '';
        const err = body.error || JSON.stringify(body);
        errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
        errMsg = error.message ? error.message : error.toString();
    }
    return Observable.throw(errMsg);
}


}
