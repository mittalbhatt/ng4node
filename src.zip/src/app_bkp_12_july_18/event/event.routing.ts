import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { EventComponent }     from './list/event.component';
import { EventAddComponent }     from './add/add.component';
import { EventUpdateComponent } from './edit/edit.component';
import { EventViewComponent } from './view/view.component';

export const EventRoutes: Routes = [
	{ path: '', component: EventComponent },
	{ path: 'add', component: EventAddComponent },
	{ path: 'edit/:id', component: EventUpdateComponent },
	{ path: 'view/:id', component: EventViewComponent }
];

export const EventRoute: ModuleWithProviders = RouterModule.forChild(EventRoutes);