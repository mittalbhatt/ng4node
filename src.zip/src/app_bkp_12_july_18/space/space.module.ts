import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpaceComponent } from './list/space.component';
import { SpaceUpdateComponent } from './edit/update.component';
import { SpaceAddComponent } from './add/add.component';
import { SpaceRoute } from './space.routing';
import { SpaceService } from './space.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { PlanExpiredGuardService } from './../common/services/plan-expired-guard.service';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SpaceRoute,
    SharedModule
  ],
  providers: [SpaceService, FormBuilder,PlanExpiredGuardService],
  declarations: [SpaceComponent, SpaceAddComponent, SpaceUpdateComponent]
})
export class SpaceModule { }
