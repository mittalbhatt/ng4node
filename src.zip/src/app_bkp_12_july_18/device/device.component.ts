import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { UserService } from "../user/user.service";

import * as moment from 'moment';
import 'moment-timezone';
declare var $: any;

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
})

export class DeviceManageComponent implements OnInit {
  private requestUrl:String;
  errorMessage:String;
  moduleParam:any;
  Formtoken:any;
  localVal:any;
  timezone:any;
  displayDateFormat: any="D MMM, YYYY";
  displayTimeFormat: any="h:mm A";

  constructor(
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService,
    private _userService: UserService   
    ) { }

  ngOnInit() {
  
    this.moduleParam = this.constant.device_management;
    this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param;
    this.getFormToken();
    this.getUserInfo(); 
  }

  getUserInfo() {
    this._userService.getUserInfo().subscribe((res) => {
      if (res) {
        this.timezone = res.timezone; 
        this.getDeviceList(this.requestUrl);
      }
    });
  }

  /**
	 * @uses  (getDeviceList) Device list using server side datatable
	 *
	 * @author BG < bhumi.gothi@softwebsolutions.com >
	 *
   */   
   getDeviceList(serviceUrl) {
     var self = this;  
     $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };
     var dataTable = $("#device-list")
      .on( 'processing.dt', function ( e, settings, processing ) {
            if(processing)
            {
                if(!($('#device-list').find('#loader-container').length))
                {
                    $("#device-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
                }
            }
            else {
                $('#loader-container').remove();
            }
        })
      .DataTable({
       "destroy": true,
       "serverSide": true,
       "lengthMenu": self.constant.showRecords,
       "searching":true,
       "responsive": true,    
       "order": [[6, 'desc']],
       "ajax": {
         url : serviceUrl,
         type: 'get',
         "beforeSend": function(xhr){
              xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
          },
          "dataFilter": function(data){            
            var json = $.parseJSON(data);
            var respData = json;
            
            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
       },
       "columns": [
          {"data": "device_id", "name": "device_id","width": "5%","orderable": false},
          {"data": "user_name", "name": "user_name","width": "15%"},
          {"data": "device_name", "name": "device_name","width": "20%", "orderable": false,
              "render": function (data, type, full, meta) {               
              var attributes = '<p style="word-wrap: break-word; max-width:180px">'+ full.device_uniq_id +'</p>';
              //attributes += '<p> '+ full.device_type +'</p>';
              return attributes;
            } },
          {"data": "application_name", "name": "application_name","width": "20%", "orderable": false,
              "render": function (data, type, full, meta) {
              var attributes = '<p style="word-wrap: break-word; max-width:180px"> '+ full.application_name +'</p>';
                attributes += '<p> <span style="color:grey">'+ full.app_version +'</span></p>';
              return attributes;
            } },
          {"data": "os_version", "name": "os_version","width": "10%", 
            "render": function (data, type, full, meta) {
              var os = '<p> '+ full.device_type +'</p>';
              os += '<p> <span style="color:grey">'+ data +'</span></p>';
              return os;
            }},
          {
            "data": "utc_created", "name": "created_at","width": "15%", 
            "render": function (data, type, full, meta) {
                               
                var createdDate = self.constant.utcToTimezone(data, self.timezone, self.displayDateFormat+' '+self.displayTimeFormat);
                var date = moment(createdDate).format(self.displayDateFormat);
                var time = moment(createdDate).format(self.displayTimeFormat);
                var imageHtml = '';            
                imageHtml += "<span style='color:grey;font-size:14px;'>"+date+'<br />'+time+"</span>";
                return imageHtml;             
            }
          },
          {
            "data": "utc_sync_date", "name": "sync_date","width": "15%",
            "render": function (data, type, full, meta) {             
              var syncDate = self.constant.utcToTimezone(data, self.timezone, self.displayDateFormat+' '+self.displayTimeFormat);
              var date = moment(syncDate).format(self.displayDateFormat);
              var time = moment(syncDate).format(self.displayTimeFormat);
              var imageHtml = '';
              imageHtml += "<span style='color:grey;font-size:14px;'>"+date+'<br />'+time+"</span>";
              return imageHtml;                                             
              }
          },
       ]
       ,
       fnRowCallback: function( nRow, aData, iDisplayIndex )
       {
          var display_number = self.constant.dataTableNo(dataTable, iDisplayIndex);
          $('td:eq(0)', nRow).html(display_number);
          return nRow;
       }
     });
   }
   
    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

    getFormToken() {
     this.auth.getToken()
     .subscribe( response => {
       if(response){
         this.Formtoken = response;
       }
     },error =>  {
       this.errorMessage = <any>error
     });
}


   }
