import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule }   from './../common/components/shared.module';
import { FormsModule } from '@angular/forms';

import { DeviceManageComponent } from './device.component';
import { DeviceManageRoute } from './device.routing';


@NgModule({
  imports: [
    CommonModule,
    DeviceManageRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [
  DeviceManageComponent
  ]
})
export class DeviceManageModule { }
