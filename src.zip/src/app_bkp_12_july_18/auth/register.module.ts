import { NgModule } from '@angular/core';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { CommonModule } from '@angular/common';

import { RegisterComponent } from './register/register.component';
import { RegisterComponent2 } from './register/second/register.component';
import { RegisterSpaceComponent } from './register/space/space.component';
import { RegisterIntegrationComponent } from './register/integration/integration.component';
import { RegisterInviteComponent } from './register/invite/invite.component';
import { RegisterRoutingModule }      from './register/register.routing';
import { EqualValidator } from '../common/directives/equal-validator.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RegisterRoutingModule

  ],
  providers: [
    FormBuilder,
  ],
  declarations: [RegisterComponent,RegisterComponent2, RegisterSpaceComponent, RegisterIntegrationComponent, RegisterInviteComponent,EqualValidator]
})
export class RegisterModule { }