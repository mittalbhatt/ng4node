import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BillingComponent } from './billing.component';
import { BillingPaymentComponent }     from './payment/payment.component';
import { BillingRoute } from './billing.routing';
import { BillingService } from './billing.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { UiSwitchModule } from 'ng2-ui-switch';
import { DefaultRequestOptions } from '../common/services/default-request-options.service';
import { HttpModule,RequestOptions} from '@angular/http';
import { PackageService } from '../package/package.service';
import { ProfileService } from './../profile/profile.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    BillingRoute,
    SharedModule,
    UiSwitchModule
  ],
  providers: [BillingService, FormBuilder,PackageService, ProfileService,
  { provide: RequestOptions, useClass: DefaultRequestOptions }
  ],
  declarations: [BillingComponent,BillingPaymentComponent]
})
export class BillingModule { }
