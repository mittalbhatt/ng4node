import { Component, OnInit } from '@angular/core';
import { AmenitiesService } from './amenities.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-amenities',
  templateUrl: './amenities.component.html',
  providers:[AmenitiesService]
})
export class AmenitiesComponent implements OnInit {
    private requestUrl:String;
    errorMessage:String;
    moduleParam:any;
    Formtoken:any;
    localVal:any;
   

  constructor(
    private amenitiesService:AmenitiesService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
     this.moduleParam = this.constant.amenity;
     this.requestUrl = this.constant.baseUrl+this.moduleParam.get_list_param;
     this.getAmenitiesInfo(this.requestUrl);
     this.getFormToken();
  }

  /**
	 * @uses  (getBuldingInfo) amenities list using server side datatable
	 *
	 * @author RK < rakesh.rathava@softwebsolutions.com >
	 *
	*/   
  getAmenitiesInfo(serviceUrl) {
  	var self = this;
    $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log() } };  

    var dataTable = $("#aminities-list")
    .on( 'processing.dt', function ( e, settings, processing ) {
          if(processing)
          {
              if(!($('#aminities-list').find('#loader-container').length))
              {
                  $("#aminities-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
              }
          }
          else {
              $('#loader-container').remove();
          }
      })
    .DataTable({
      "destroy": true,
      "serverSide": true,
      "lengthMenu": self.constant.showRecords,
      "searching":true,
      "responsive": true, 
      "order": [[1, 'asc']],
      "ajax": {
        url : serviceUrl,
        type: 'get',
        "beforeSend": function(xhr){
            xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
        },
        "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;

            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            
            if(!$.isEmptyObject(respData.accessObj)){
              respData.data.forEach(function(obj){
                obj.access = true;
              });              
            } else {
              respData.data.forEach(function(obj){
                obj.access = false;
              });  
            }
            return JSON.stringify(json);
            
        }
      },

      "columns": [
      {"data": "amenity_id", "name": "amenity_id","width": "5%","orderable": false}, 
      {"data": "amenity_name", "name": "amenity_name","width": "45%",
        "render": function (data, type, full, meta) {
          var imageHtml ="";

          // if(full.image_path != "" && full.image_path != "") {
          //   imageHtml += "<img src='"+ full.image_path + "' title='" + full.amenity_name + "' [onError]='this.src="+"images/default/no_images/80X80.png"+"' width='15%' style='border:1px;border-style:solid;border-color:#021a40;' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span><i><b>"+full.amenity_name+"<b/></i></span>";
          // } else {
          //   imageHtml += "<img src='images/default/no_images/80X80.png' title='" + full.amenity_name  + "' width='15%' style='border:1px;border-style:solid;border-color:#021a40;' />&nbsp;&nbsp;&nbsp;&nbsp;<span><i><b>"+full.amenity_name+"</b></i></span>";
          // }

          imageHtml += '<div class="company_box">';
            imageHtml += '<span class="companyImage">';
              imageHtml += '<img src="'+full.image_path+'" onerror="this.onerror=null;this.src="/images/default/no_images/70X70.png";" style="max-width: 30px;" class="borderimg">';
            imageHtml += '</span>';
            imageHtml += '<span class="companyTextAmenity">';
              imageHtml += '<span class="companyname">'+full.amenity_name+'</span><br>';
            imageHtml += '</span>';
          imageHtml += '</div>';

          return imageHtml;
        }
      },
      {
          "data": "status",
          "name": "status",
          "width": "10%",
          "orderable": false,
          "render": function (data, type, full, meta) {
            
            var statusStr = '';

              if(full.access){
                statusStr = '<div title="Inactive"  class="checkbox-bird amenity-status-update" id="amenitySatusUpdate_' + full.amenity_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox"/><label></label></div>';
                
                if (full.status == 1) {
                  statusStr = '<div title="Active"  class="checkbox-bird green amenity-status-update" id="amenitySatusUpdate_' + full.amenity_id + '_' + full.status + '" style="margin: 0 auto; width: 25px;"><input type="checkbox" checked/><label></label></div>';
                }
              } else {
                statusStr = '<div title="Inactive"  class="checkbox-bird" style="margin: 0 auto; width: 25px; pointer-events: none; cursor: default;"><input type="checkbox"/><label></label></div>';
              }

            return statusStr;
          }
      },
      {
        "data": "action", 
        "name": "action", 
        "orderable": false,
        "searchable": false, 
        "width": "12%",
        "render": function (data, type, full, meta) {
         //  if(full.access){
      		 //  var actionLinks = '<a title="Edit" id="'+full.amenity_id+'" class="btn btn-primary-outline btn-sm amenities-edit"><i class="fa fa-edit"></i></a>';
      			// actionLinks += '&nbsp;<a title="Delete" class="btn btn-danger-outline btn-sm amenities-delete" id="delete_'+full.amenity_id+'"><i class="fa fa-trash-o"></i></a>';
         //  } else {

         //    var actionLinks = '<a title="Edit" class="btn btn-outline btn-sm " style="background-color: #dbe4ea; border-color: #dbe4ea; color: #6c7a86;  pointer-events: none; cursor: default;"><i class="fa fa-edit"></i></a>';
         //    actionLinks += '&nbsp;<a title="Delete" class="btn btn-outline btn-sm " style="background-color: #dbe4ea; border-color: #dbe4ea; color: #6c7a86;  pointer-events: none; cursor: default;"><i class="fa fa-trash-o"></i></a>';
         //  }
            var actionLinks = '<div  class="btn-group btn-group-sm" style="float: none;"><button type="button" id="'+full.amenity_id+'" title = "Edit" class="tabledit-edit-button btn btn-sm btn-default amenities-edit" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button><button type="button" title = "Delete" id="delete_'+full.amenity_id+'" class="tabledit-delete-button btn btn-sm btn-default amenities-delete" style="float: none;"><span class="glyphicon glyphicon-trash"></span></button></div>';
            return actionLinks;

    		}
    }],

  	fnRowCallback: function( nRow, aData, iDisplayIndex )
  	{  
      var display_number = self.constant.dataTableNo(dataTable, iDisplayIndex);
      $('td:eq(0)', nRow).html(display_number);
      $('td:eq(0)',nRow).addClass('aligncenter');
      $('td:eq(2)',nRow).addClass('aligncenter');
      $('td:eq(3)',nRow).addClass('aligncenter');
  		return nRow;
  	},
  	fnDrawCallback: function( oSettings )
  	{
      if(oSettings.aoData[0] == undefined) {
        $('#schedule-list_info').hide();
        $('#schedule-list_paginate').hide();
      }

  		$(document).on('click', 'button.amenities-edit', function (e) {
  			var amenityId = this.id;
  			self.editamenities(amenityId);
  			e.preventDefault();
  		});

      $(document).on('click', '.amenity-status-update', function (e) {
          var amenityStatusIdVal = this.id;

          e.preventDefault();
          swal({
            title: "Status",
            text: "Are you sure you want to update Status?",
            type: "info",
            showCancelButton: true,
            confirmButtonClass: "btn-confirm",
            confirmButtonText: "Update",
            cancelButtonText: "Cancel"
          },
            function (isConfirm) {
              if (isConfirm) {
                  var amenityIdSplitted = amenityStatusIdVal.split('_');
                  var amenityStatusId = amenityIdSplitted[1];
                  var amenityStatus = amenityIdSplitted[2];
                  self.amenityStatusUpdate(amenityStatusId, amenityStatus, dataTable);
              }
            });
        });

  		$(document).on('click', 'button.amenities-delete', function (e) {

  			var deleteId = this.id;
  			var delId = deleteId.split('_');
  			var delIdFinal = delId[1];

  			e.preventDefault();
  			swal({
  				title: "Delete",
  				text: "Are you sure you want to delete this Amenity?",
  				type: "warning",
  				showCancelButton: true,
  				confirmButtonClass: "btn-danger",
  				confirmButtonText: "Delete",
  				cancelButtonText: "Cancel"        
  			},
  			function(isConfirm) {
  				if (isConfirm) {          
  					self.deleteamenities(delIdFinal, dataTable);
  				}        

  			});
  		});

  	}
  });
  }

  	/**
  	 * @uses (editamenities) to edit selected amenities record
  	 *
  	 * @author RK < rakesh.rathava@softwebsolutions.com >
  	 *
  	*/
    editamenities(id){
      this.router.navigate([this.moduleParam.edit_amenity_link+id]);
    }

    amenityStatusUpdate(amenityId, status, dataTable){
      
        this.amenitiesService.amenityStatusUpdate({'amenity_id':amenityId,'status':status, "_csrf":this.Formtoken})
                .then(
                response => {
                  if(response){
                     this.localVal = response;
                     if(this.localVal.success){
                         dataTable.ajax.reload(null, false);
                         this.router.navigate([this.moduleParam.amenity_link]);
                        this._notificationService.add(new Notification('success', this.localVal.message));
                     }else{
                        this._notificationService.add(new Notification('error', this.localVal.message));   
                     }
                  }
                },
                error =>  {
                  this.errorMessage = <any>error;
                    this._notificationService.add(new Notification('error', error));
                });
    }

    
    /**
     * @uses (deleteamenities) remove amenities from list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
    */

    deleteamenities(id, dataTable){
        this.amenitiesService.removeAmenity({'amenity_id':id, "_csrf":this.Formtoken})
                  .then(
                  response => {
                    if(response){
                       this.localVal = response;
                       if(this.localVal.success){
                          dataTable.ajax.reload(null, false);
                          this.router.navigate([this.moduleParam.amenity_link]);
                          this._notificationService.add(new Notification('success', this.localVal.message));
                       }else{
                          this._notificationService.add(new Notification('error', this.localVal.message));   
                       }
                    }
                  },
                  error =>  {
                    this.errorMessage = <any>error;
                      this._notificationService.add(new Notification('error', error));
                  });
    }

     /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

      getFormToken() {
         this.auth.getToken()
         .subscribe( response => {
             if(response){
               this.Formtoken = response;
             }
           },error =>  {
             this.errorMessage = <any>error
           });
      }
}
