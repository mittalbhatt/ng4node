import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmenitiesComponent } from './amenities.component';
import { AddComponent }     from './addAmenities/add.component';
import { EditComponent }     from './editAmenities/edit.component';
import { AmenitiesRoute } from './amenities.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { PlanExpiredGuardService } from './../common/services/plan-expired-guard.service';


@NgModule({
  imports: [
    CommonModule,
    AmenitiesRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [AmenitiesComponent,AddComponent,EditComponent],
  providers:[PlanExpiredGuardService]
})
export class AmenitiesModule { }
