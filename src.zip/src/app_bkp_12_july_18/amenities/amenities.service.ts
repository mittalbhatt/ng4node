﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class AmenitiesService {
    
    private requestUrl:String;
    moduleParam:any;
    responseData:any ={};


    constructor(
        private http: Http,
        private router: Router, 
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.amenity;
    }

    /**
     * @uses (addBuilding) send building add form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    addAmenities(data) {
        let url = this.requestUrl+this.moduleParam.add_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    getEditAmenity(data) {
        let url = this.requestUrl+this.moduleParam.edit_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (updateAmenities) send amenity update form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    updateAmenities(data) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, data);
    }


    amenityStatusUpdate(data){
        let url = this.requestUrl+this.moduleParam.update_status_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeAmenity(data){
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }
}