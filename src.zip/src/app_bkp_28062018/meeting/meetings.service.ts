﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class MeetingsService {
    
    private requestUrl:String;
    moduleParam:any;
    responseData:any ={};


    constructor(
        private http: Http,
        private router: Router, 
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.meetings;
    }

    /**
     * @uses (getSchedule) Get Schedule for meetings
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getSchedule() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }

    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    getSpaceById(data) {
        let url = this.requestUrl+this.moduleParam.show_space_meetings;        
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (allDrowDownListData) send amenity update form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    allDrowDownListData() {
        let url = this.requestUrl+this.moduleParam.allBuildingFloorSpacelist;
        return this.httpClient.get(url);
    }


    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeMeetings(data){
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }

    //  getBookingDetailsById(data) {
    //     let url = this.requestUrl+this.moduleParam.get_booking_details_by_id;
    //     return this.httpClient.post(url, data);
    // }
    
     /**
     * @uses (getUpcomingMeetings) 
     *
     * @author FK < foram.kantaria@softwebsolutions.com >
     *
     * @return Json selected meeting data
    */
    getUpcomingMeetings(spaceId) {
        let url = this.requestUrl+'meetings/upcoming/' + spaceId;
        return this.httpClient.get(url);
    }


    /**
     * @uses (getUpcomingMeetings) 
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return Json selected meeting data
    */
    getCurrentMeetings(spaceId) {
        let url = this.requestUrl+'meetings/current/' + spaceId;
        return this.httpClient.get(url);
    }
}