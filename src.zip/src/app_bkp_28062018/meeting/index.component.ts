import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { SpaceService } from "../space/space.service";
import * as moment from 'moment';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-meeting-index',
  templateUrl: './index.component.html',  
})

export class IndexComponent implements OnInit {

  moduleParam:any;
  tableView : boolean = true;
  calendarView : boolean = false;


  constructor(    
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
    this.moduleParam = this.constant.meetings;    
  }

  changeFilter(event)
  {
    if(event=='table')
    {
      this.tableView = true;
      this.calendarView = false;
    }
    else if(event=='calendar')
    {
      this.tableView = false;
      this.calendarView = true;
    }
  }

}
