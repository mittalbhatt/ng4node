import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MeetingsComponent } from './meetings.component';
import { IndexComponent } from './index.component';
import { currentMeetingSpaceComponent }     from './currentMeetingSapce.component';
// import { EditComponent }     from './editAmenities/edit.component';
import { MeetingsRoute } from './meetings.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { PlanExpiredGuardService } from './../common/services/plan-expired-guard.service';
import { CalendarComponent } from "ap-angular2-fullcalendar/src/calendar/calendar";
import { TagInputModule } from 'ng2-tag-input';
import { meetingCalendar } from './calendar/meetingCalendar.component';

@NgModule({
  imports: [
    CommonModule,
    MeetingsRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [MeetingsComponent,IndexComponent,currentMeetingSpaceComponent,CalendarComponent,meetingCalendar],
  providers:[PlanExpiredGuardService]
})
export class MeetingsModule { }
