import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { AuthGuardService }          from './../auth/auth-guard.service';
// import { MeetingsComponent }     from './meetings.component';
import { IndexComponent }     from './index.component';
import { currentMeetingSpaceComponent }     from './currentMeetingSapce.component';
// import { AddComponent }     from './addAmenities/add.component';
// import { EditComponent }     from './editAmenities/edit.component';
import { PlanExpiredGuardService } from  './../common/services/plan-expired-guard.service';
// import { myMeetingsComponent }     from './myMeetingsComponent.component';



export const MeetingRoutes: Routes = [
	{ 
		path: '',
		component: IndexComponent 
	},
	{ 
		path: 'add', 
		// canActivate: [PlanExpiredGuardService],
		// component: AddComponent 
	},
	{ 
		path: 'space/:id', 
		canActivate: [PlanExpiredGuardService],
		component: currentMeetingSpaceComponent 
	},
	// { 
	// 	path: 'calendar', 
	// 	component: myMeetingsComponent 
	// },
];

export const MeetingsRoute: ModuleWithProviders = RouterModule.forChild(MeetingRoutes);