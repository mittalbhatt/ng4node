import { Injectable } from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ResponseData } from './../common/classes/response-data';
import { Constants } from '../common/services/constants';
import {  HttpClient } from '../common/services/http.service';


@Injectable()
export class PackageService {

    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http, 
        private constant:Constants,
        private httpClient:HttpClient) {
        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.package;
    }

	/**
     * @uses get all package data
     *
     * @author FJ < foram.kantaria@softwebsolutions.com >
     *
     * @return json
     */
    getPackageList() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }

    packageStatusUpdate(data) {
        let url = this.requestUrl + this.moduleParam.packageStatus;
          return this.httpClient.post(url, data);
    }

    packageAdd(formData) {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.post(url, formData);
    }

    packageUpdateData(planId) {
        let url = this.requestUrl + this.moduleParam.edit_package_link+planId;
        return this.httpClient.get(url); 
    }

    updatePackageData(data) {
        let url = this.requestUrl+this.moduleParam.update_package;
          return this.httpClient.post(url, data);
    }
    deletepackage(data) {
      let url = this.requestUrl+this.moduleParam.remove_param+data.plan_id;
        return this.httpClient.post(url,data);
    }
    
    getPackageFeatures() {
      let url = this.requestUrl + this.moduleParam.get_package_features;
        return this.httpClient.get(url);
    }
    getPackageDuration() {
      let url = this.requestUrl + this.moduleParam.get_package_duration;
        return this.httpClient.get(url);
    }


    private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;

    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }

    return Observable.throw(errMsg);
  }

}
