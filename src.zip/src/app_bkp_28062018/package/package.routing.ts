import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { PackageComponent }     from './list/package.component';
import { PackageAddComponent }     from './add/add.component';
import { PackageUpdateComponent }     from './edit/update.component';

export const PackageRoutes: Routes = [
	{ path: '', component: PackageComponent },
	{ path: 'add', component: PackageAddComponent },
	{ path: 'edit/:id', component: PackageUpdateComponent }
	
];

export const PackageRoute: ModuleWithProviders = RouterModule.forChild(PackageRoutes);