import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackageComponent } from './list/package.component';
import { PackageAddComponent } from './add/add.component';

import { PackageUpdateComponent }     from './edit/update.component';
import { PackageRoute } from './package.routing';
import { PackageService } from './package.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { UiSwitchModule } from 'ng2-ui-switch';
import { DefaultRequestOptions } from '../common/services/default-request-options.service';
import { HttpModule,RequestOptions} from '@angular/http';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    PackageRoute,
    SharedModule,
    UiSwitchModule
  ],
  providers: [PackageService, FormBuilder,
  { provide: RequestOptions, useClass: DefaultRequestOptions }
  ],
  declarations: [PackageComponent, PackageUpdateComponent,PackageAddComponent]
})
export class PackageModule { }
