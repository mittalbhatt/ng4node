import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { AuthGuardService }          from './../auth/auth-guard.service';
import { AmenitiesComponent }     from './amenities.component';
import { AddComponent }     from './addAmenities/add.component';
import { EditComponent }     from './editAmenities/edit.component';
import { PlanExpiredGuardService } from  './../common/services/plan-expired-guard.service';

export const AmenityRoutes: Routes = [
	{ 
		path: '',
		component: AmenitiesComponent 
	},
	{ 
		path: 'add', 
		canActivate: [PlanExpiredGuardService],
		component: AddComponent 
	},
	{ 
		path: 'edit/:id', 
		canActivate: [PlanExpiredGuardService],
		component: EditComponent 
	},
];

export const AmenitiesRoute: ModuleWithProviders = RouterModule.forChild(AmenityRoutes);