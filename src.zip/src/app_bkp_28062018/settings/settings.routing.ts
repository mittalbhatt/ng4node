import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { SettingsComponent }     from './settings.component';

export const SettingRoutes: Routes = [
	{ path: '', component: SettingsComponent }
];

export const SettingsRoute: ModuleWithProviders = RouterModule.forChild(SettingRoutes);