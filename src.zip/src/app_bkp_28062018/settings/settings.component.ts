import { Component, OnInit } from '@angular/core';
import { SettingsService } from './settings.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { EmailComponent } from './additional/email.component';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  providers:[SettingsService]
})
export class SettingsComponent implements OnInit {
    private requestUrl:String;
    errorMessage:String;
    build:Object = {};
    moduleParam:any;
    buildData:any;
    Formtoken:any;
    localVal:any;
    delId:any;

  constructor(
    private settingsService:SettingsService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
    this.getFormToken();
    this.moduleParam = this.constant.settings;
  }

    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */
     getFormToken() {
       this.auth.getToken()
       .subscribe(
         response => {
           if(response){
             this.Formtoken = response;
           }
         },
         error =>  {
           this.errorMessage = <any>error
         });
     }

}
