/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserComponent } from './user.component';

describe('Component: User', () => {
  it('should create an instance', () => {
    let component = new UserComponent();
    expect(component).toBeTruthy();
  });
});
