import {Component,OnInit} from "@angular/core";
import {FormGroup, FormControl, Validators} from "@angular/forms";
import { ActivatedRoute, Router } from '@angular/router';
import {UserService} from "./user.service";
import {User} from "./user";
import {companyUser} from "./companyUser";
import { NotificationService, Notification } from '../common/services/notifications.service';
import { AuthService } from '../auth/auth.service';
import { BuildingService } from '../building/building.service';
import { SpaceService } from '../space/space.service';
import { EqualValidator } from './../common/directives/equal-validator.directive';  // import validator
import { Constants } from '../common/services/constants';
import { UiSwitchModule } from 'ng2-ui-switch';


@Component({
  selector: 'app-signup',
  templateUrl: './add.html'
})
export class UserAddComponent implements OnInit {

  userModel = {
    'first_name':'',
    'last_name':''
  }; 


  public responseData: any;
  private submitFlag: any;

  private base64textString:String="";
  
  errorMessage: any = {};
  floorList: any;
  floorDisabled: any;
  filename:string='';
  companyUsers: any;
  binaryString:any;
  moduleParam:any;
  Formtoken:any;
  localVal: any;
  users: any;
  files:any;
  file:any;
  DomainUrl: any;
  dataLoadingStatus: boolean;
  fileSizeExceeded: any;
  flag: any;
  
  constructor(private userService: UserService, private _spaceService: SpaceService, private auth:AuthService, private constant: Constants,private _notificationService: NotificationService,public router: Router, ) { 
    this.users = {};
    this.companyUsers = {};
    this.submitFlag = false;
  }

  submitData() {

    this.users._csrf = this.Formtoken;
    this.companyUsers._csrf = this.Formtoken;
    this.users.profile_image = this.base64textString; // image base64 string to insert into form obj 
    this.users.image_name = this.filename; 
    var globalTime_difference = this.users.time_difference;
  
    for (let obj of this.constant.timezoneArray) {
    for (let key in obj) {
     
        if(this.users.time_difference === obj.key){
          var timezone = obj[key];
        }
    }
}

    this.users.timezone = timezone;
    this.users.time_difference = globalTime_difference;
    
    
    this.dataLoadingStatus = true;
    this.userService.userAdd(this.users,this.companyUsers) 
      .subscribe((data)=>{
        if(data){
        this.localVal = data;
        if(this.localVal.success == true){
            this.dataLoadingStatus = false;
            this.router.navigate(['/user']);
            this._notificationService.add(new Notification('success', this.localVal.message));
        }else{         
            this._notificationService.add(new Notification('error', this.localVal.message));
            this.dataLoadingStatus = false;
        }
      }
    },
     error =>  {
      this.errorMessage = <any>error
    });
  }

  ngOnInit() {
     
      var url = window.location.origin;
      this.DomainUrl = url.split('//')[1].split('.')[0];
      this.users.user_type = '';
      this.users.status = true;
      this.users.time_difference = this.constant.defaultTimezone;
      this.companyUsers.building_id = '';
      this.companyUsers.floor_id = '';
      this.getRole();
      this.getFormToken();
      this.moduleParam = this.constant.user;
      this.getBuilding();
      this.floorDisabled = true;
  }

  timezoneArray = this.constant.timezoneArray;


    /**
   * @uses (getFormToken) get csrf form token
   *
   *
   */
    getFormToken() {
     this.auth.getToken()
     .subscribe(
       response => {
         if(response){
           this.Formtoken = response;
         }
       },
       error =>  {
         this.errorMessage = <any>error
       });
    }


    getBuilding() {
      this.dataLoadingStatus = true;
       this.userService.getBuildingList()
        .subscribe((data)=>{ 
          if(data){
          this.localVal = data;
          if(this.localVal.success == true){
            this.users.building = data.data;
            this.dataLoadingStatus = false;
          } else{  
            this.dataLoadingStatus = false;
          }
        }
      },
       error =>  {
        this.errorMessage = <any>error
      });


    }


    onBuildingChange(id){
    if(id!=''){
      this.floorDisabled = false;
      this.getFloorFromBuilding(id);
    } else {
      this.floorDisabled = true;
    }    
  }


    getFloorFromBuilding(buildingId) {
      this.dataLoadingStatus = true;
       this._spaceService.floorListData(buildingId)
        .then((res) => {
          if (res) {
            this.floorList = res;
            this.floorList = this.floorList.data;
            this.dataLoadingStatus = false;
          }
          else {
            this.floorDisabled = true;
            this.dataLoadingStatus = false;
          }
        });

    }

    getRole() {
       this.userService.getRoleFromDomain() 
        .subscribe((data)=>{ 
          if(data){

          this.localVal = data;

          if(this.localVal.success == true){
            if(data.data == 1 ) {
              this.users.role = 'company';
            }
            else{
              this.users.role = 'product';
            }

          } else{         
          }
        }
      },
       error =>  {
        this.errorMessage = <any>error
      });

    }


   onChange(evt){
       this.files = evt.target.files;
       this.file = this.files[0];
       this.filename = this.file.name;

       if (this.files && this.file) {

          if(this.file.size > 2000000) {
            this.flag= false;
            this.fileSizeExceeded = 'Profile Picture size cannot be greater than 2 MB';
          }
          else {
            this.fileSizeExceeded = '';
          }
          var reader = new FileReader();
          reader.onload =this._handleReaderLoaded.bind(this);
          reader.readAsBinaryString(this.file);
       }

    }

    _handleReaderLoaded(readerEvt) {
       this.binaryString = readerEvt.target.result;
       this.base64textString= btoa(this.binaryString);
     }
 
}