import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { DeviceManageComponent }     from './device.component';


export const DeviceRoutes: Routes = [
	{ path: '', component: DeviceManageComponent },
];

export const DeviceManageRoute: ModuleWithProviders = RouterModule.forChild(DeviceRoutes);