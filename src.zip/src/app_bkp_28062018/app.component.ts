import { Component } from '@angular/core';
import { Title }     from '@angular/platform-browser';

import {
    Router,
    // import as RouterEvent to avoid confusion with the DOM Event
    Event as RouterEvent,
    NavigationStart,
    NavigationEnd,
    NavigationCancel,
    NavigationError
} from '@angular/router'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template: `<app-add-aminities (valueChange)='displayCounter($event)'></app-add-aminities>`,
  styleUrls: ['./app.component.css']
})




export class AppComponent {
    // Sets initial value to true to show loading spinner on first load
    loading: boolean = true;

    constructor(private router: Router, private titleService: Title) {

        router.events.subscribe((event: RouterEvent) => {
            this.navigationInterceptor(event);
            if(event instanceof NavigationEnd) {
                var title = this.getTitle(router.routerState, router.routerState.root);
                // console.log('title', title[0]);
                if(title[0]) {
                    titleService.setTitle('Smartoffice' + ' - ' +title[0]);
                }
                else {
                    titleService.setTitle('Smartoffice');
                }
            }
        });
    }


    getTitle(state, parent) {
        var data = [];
        if(parent && parent.snapshot.data && parent.snapshot.data.title) {
          data.push(parent.snapshot.data.title);
        }

        if(state && parent) {
          data.push(... this.getTitle(state, state.firstChild(parent)));
        }
        return data;
    }

    // Shows and hides the loading spinner during RouterEvent changes
    navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.loading = true;
        }
        if (event instanceof NavigationEnd) {
            this.loading = false;
        }

        // Set loading state to false in both of the below events to hide the spinner in case a request fails
        if (event instanceof NavigationCancel) {
            this.loading = false;
        }
        if (event instanceof NavigationError) {
            this.loading = false;
        }
    }
}