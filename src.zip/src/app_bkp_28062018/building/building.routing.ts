import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { BuildingComponent }     from './building.component';
import { AddComponent }     from './addBuilding/add.component';
import { EditComponent }     from './editBuilding/edit.component';

export const BuildingRoutes: Routes = [
	{ path: '', component: BuildingComponent },
	{ path: 'add', component: AddComponent },
	{ path: 'edit/:id', component: EditComponent },
];

export const BuildRoute: ModuleWithProviders = RouterModule.forChild(BuildingRoutes);