﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class BuildingService {
    
    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.building;
    }

    /**
     * @uses (addBuilding) send building add form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    addBuilding(data) {
        let url = this.requestUrl+this.moduleParam.add_param;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getEditBuilding) get selected building info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    getEditBuilding(data) {
        let url = this.requestUrl+this.moduleParam.edit_param;
        return this.httpClient.post(url, data);
    }


    /**
     * @uses (updateBuilding) send building updateed form post data
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    updateBuilding(data) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, data);
    }

    buildingStatusUpdate(data){     
        let url = this.requestUrl+this.moduleParam.update__status_param;
        return this.httpClient.post(url, data);   
    }
    /**
     * @uses (removeBuilding) remove selected building from building list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    removeBuilding(data) {
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }

    

    private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }
    
    private handleError (error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
          const body = error.json() || '';
          const err = body.error || JSON.stringify(body);
          errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
          errMsg = error.message ? error.message : error.toString();
        }
        // console.error(errMsg);
        return Observable.throw(errMsg);
    }
}