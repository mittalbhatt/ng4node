﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class AnalyticsService {
    
    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.analytics;
    }

    /**
     * @uses (get status of ESTIMOTE_BEACON)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    getSensors()
    {        
        let url = this.requestUrl+this.moduleParam.get_sensors;
        return this.httpClient.get(url);
    }

    /**
     * @uses (remove company logo image)
     *
     * @author KT < ketan@softwebsolutions.com >
     *
     * @return 
    */
    updateSensors(data)
    {
        let url = this.requestUrl+this.moduleParam.update_sensors;
        return this.httpClient.post(url, data);
    }       
}