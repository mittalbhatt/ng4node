import { Component, OnInit } from '@angular/core';
import { AnalyticsService } from './analytics.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  providers:[AnalyticsService]
})
export class AnalyticsComponent implements OnInit {
    
    private requestUrl:String;
    errorMessage:String;    
    moduleParam:any;    
    Formtoken:any;
    localVal:any;

  constructor(
    private analyticsService:AnalyticsService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
    this.getFormToken();
    this.moduleParam = this.constant.analytics;
  }

    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */
     getFormToken() {
       this.auth.getToken()
       .subscribe(
         response => {
           if(response){
             this.Formtoken = response;
           }
         },
         error =>  {
           this.errorMessage = <any>error
         });
     }

}
