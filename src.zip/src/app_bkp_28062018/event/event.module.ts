import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventComponent } from './list/event.component';
import { EventRoute } from './event.routing';
import { EventService } from './event.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { UserService } from '../user/user.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    EventRoute,
    SharedModule,
  ],
  providers: [EventService, FormBuilder, UserService],
  declarations: [EventComponent]
})
export class EventModule { }
