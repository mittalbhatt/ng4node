import { Component, OnInit } from '@angular/core';
import { ServiceRequestService } from './serviceRequest.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-service-request',
  templateUrl: './serviceRequest.component.html',
  providers:[ServiceRequestService]
})
export class ServiceRequestComponent implements OnInit {
    private requestUrl:String;
    errorMessage:String;
    moduleParam:any;
    Formtoken:any;
    localVal:any;
   

  constructor(
    private serviceRequestService:ServiceRequestService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService
    ) { }

  ngOnInit() {
     this.moduleParam = this.constant.service_request;
     this.requestUrl = this.constant.baseUrl+this.moduleParam.get_service_request_list;
     this.getServiceRequestList(this.requestUrl);
     this.getFormToken();
  }

  /**
	 * @uses  (getServiceRequestList) amenities list using server side datatable
	 *
	 * @author RK < rakesh.rathava@softwebsolutions.com >
	 *
	*/   
  getServiceRequestList(serviceUrl) {
  	var self = this;  
    $.fn.dataTableExt.sErrMode = function(settings, helpPage, message) { if (message) { console.log(message) } };
  	var dataTable = $("#request-list")
    .on( 'processing.dt', function ( e, settings, processing ) {
          if(processing)
          {
              if(!($('#request-list').find('#loader-container').length))
              {
                  $("#request-list").append('<tbody id="loader-container"><tr><td colspan="8" class="align-center"> <div class="middle-loader-container"><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></td></tr></tbody>');
              }
          }
          else {
              $('#loader-container').remove();
          }
      })
    .DataTable({
  		"destroy": true,
  		"serverSide": true,
  		"lengthMenu": self.constant.showRecords,
  		"searching":true,
  		"responsive": false, 
    	// "sScrollX": "110%",
    	// "sScrollXInner": "120%",
    	// "bScrollCollapse": true,
  		"order": [[0, 'desc']],
  		"ajax": {
  			url : serviceUrl,
  			type: 'get',
        "beforeSend": function(xhr){
            xhr.setRequestHeader("Authorization", "Bearer " +  localStorage.getItem('userAccessToken'));
        },
        "dataFilter": function(data){
            var json = $.parseJSON(data);
            var respData = json;
            
            if(respData.status === "fail"){
                self.auth.logout();
                self._notificationService.add(new Notification('error', self.constant.expired_message));
            }
            return JSON.stringify(json);
          }
  		},
  		"columns": [
      	
  		{"data": "service_ticket_number", "name": "service_ticket_number","width": "25%",
        "render": function (data, type, full, meta) {
            var current_status = '';

            if(full.current_status == 1 ){
              current_status = '<span class="color-red" title="Open"><i class="fa fa-circle"></i></span>';
            }else if( full.current_status == 2){
              current_status = '<span class="color-orange" title="Assigned"><i class="fa fa-circle"></i></span>';
            }else {
              current_status = '<span class="color-green" title="Close"><i class="fa fa-circle"></i></span>';
            }

              
            var ticket = '';
            var ticket = '<a title = "Edit" id="'+full.service_request_id+'" class="ticket-edit">'+full.service_ticket_number+'</a>';
            ticket += "<p style='font-size: 95%;'>"+current_status+"&nbsp;"+full.dispUpdatedAt+"</p>";
            return ticket;
          }
      },
      {"data": "service_title", "name": "service_title","width": "35%",

        "render": function (data, type, full, meta) {
            var full_title = '';
            var category_name = "";
            var space_name = "";
            var service_title = "";

            if(full.category_name){
              category_name = full.category_name;
            }

            if(full.space_name){
              space_name = full.space_name;
            }

            if(full.service_title){
              service_title = full.service_title;
              service_title = service_title.toUpperCase();
            }

            full_title = "<a id='"+full.service_request_id+"' title = 'Edit' class='ticket-edit'><span class='color-blue'>"+service_title+"</span></a><br /><b><span>Category: </span></b>"+category_name;
            if(space_name!='')
            {
              full_title += "<br /><b><span>Space: </span></b>"+space_name+"</p>";              
            }
            return full_title;
          }

      },
      // {"data": "category_name", "name": "category_name","width": "20%"},
      {"data": "assigned_user_id", "name": "created_by","width": "35%",

          "render": function (data, type, full, meta) { 
            var full_name = "";
            if(full.assigned_user != null){
              full_name = full.assigned_user
            }
            return "<span class='color-royal-blue'><b>"+full_name.substring(0,1).toUpperCase()+full_name.substring(1)+"</b></span>";
          }
      },
      // {"data": "space_name", "name": "space_name","width": "15%"},
      {"data": "severity", "name": "severity","width": "5%",
        "render": function (data, type, full, meta) {
          var severity = "";
          var icon ="";

          if(full.severity == 1){
            severity = "Moderate";
              icon = '<div class="color-orange" title="Moderate"><i class="fa fa-bell-o"></i></div>';
          }else if(full.severity == 2){
            severity = "High";
             icon = '<div class="color-red" title="High"><i class="fa fa-bell"></i></div>';
          }else{
            severity = "Low";
              icon = '<div class="color-green" title="Low"><i class="fa fa-bell-o"></i></div>';
          }  

          return severity;
        }
      }
  	]
  	,
  	fnRowCallback: function( nRow, aData, iDisplayIndex )
  	{  
      if ( aData.current_status == 0){
           $('td', nRow).css('background-color', self.constant.severity_low_color);
      }else if(aData.current_status == 1){
          $('td', nRow).css('background-color', self.constant.severity_High_color);
      }else if(aData.current_status == 2){
           $('td', nRow).css('background-color', self.constant.severity_moderate_color);
      };
  		return nRow;
  	},
  	fnDrawCallback: function( oSettings )
  	{
      if(oSettings.aoData[0] == undefined) {
          $('#schedule-list_info').hide();
          $('#schedule-list_paginate').hide();
      }
        
  		$('a.ticket-edit').on( 'click', function (e) {
  			var requestId = this.id;
  			self.editserviceRequest(requestId);
  			e.preventDefault();
  		});

      $('#open').unbind('click');
      $('#open').on('click', function (e) {
          if($('#open_val').text() === "Open"){
            var serachVal = $('#open_val').text();
            $("#request-list").DataTable().search(serachVal).draw();
          }
      });

      $('#assign').unbind('click');
      $('#assign').on('click', function (e) {
          if($('#assign_val').text() === "Assigned"){
            var serachVal = $('#assign_val').text();
            $("#request-list").DataTable().search(serachVal).draw();
          }

      });

      $('#close').unbind('click');
      $('#close').on('click', function (e) {
          if($('#close_val').text() === "Close"){
            var serachVal = $('#close_val').text();
            $("#request-list").DataTable().search(serachVal).draw();
          }
      });

      $('.request-status-update').on('click', function (e) {
          var serviceRequestStatusIdVal = this.id;

          e.preventDefault();
          swal({
            title: "Are you sure?",
            text: "This Service Request status will be update!",
            type: "info",
            showCancelButton: true,
            confirmButtonClass: "btn-confirm",
            confirmButtonText: "Update",
            cancelButtonText: "Cancel"
          },
            function (isConfirm) {
              if (isConfirm) {
                  var requestIdSplitted = serviceRequestStatusIdVal.split('_');
                  var requestStatusId = requestIdSplitted[1];
                  var requestStatus = requestIdSplitted[2];
                  //self.serviceRequestStatusUpdate(requestStatusId, requestStatus, dataTable);
              }
            });
        });

  		$('a.request-delete').on( 'click', function (e) {

  			var deleteId = this.id;
  			var delId = deleteId.split('_');
  			var delIdFinal = delId[1];

  			e.preventDefault();
  			swal({
  				title: "Are you sure?",
  				text: "You want to remove this record?",
  				type: "warning",
  				showCancelButton: true,
  				confirmButtonClass: "btn-danger",
  				confirmButtonText: "Delete",
  				cancelButtonText: "Cancel"        
  			},
  			function(isConfirm) {
  				if (isConfirm) {          
  					//self.deleterequest(delIdFinal, dataTable);
  				}        

  			});
  		});

  	}
  });
  }

  	/**
  	 * @uses (editamenities) to edit selected amenities record
  	 *
  	 * @author RK < rakesh.rathava@softwebsolutions.com >
  	 *
  	*/
    editserviceRequest(id){
      //console.log(this.moduleParam.service_edit_link+id);
      this.router.navigate([this.moduleParam.service_edit_link+id]);
    }

       
    /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */
    getFormToken() {
       this.auth.getToken()
       .subscribe( response => {
           if(response){
             this.Formtoken = response;
           }
         },error =>  {
           this.errorMessage = <any>error
         });
    }
}
