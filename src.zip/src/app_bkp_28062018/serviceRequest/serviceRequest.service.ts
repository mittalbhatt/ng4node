﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class ServiceRequestService {
    
    private requestUrl:String;
    moduleParam:any;


    constructor(
        private http: Http,
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.service_request;
    }

    /**
     * @uses (getServiceRequestInitList) get Admin User lists
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getServiceRequestInitList() {
        let url = this.requestUrl+this.moduleParam.get_SR_int_list;
        return this.httpClient.get(url);
    }

    /**
     * @uses (getSpaceList) get space list
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    addServiceRequest(data) {
        let url = this.requestUrl+this.moduleParam.add_service_request;
        return this.httpClient.post(url, data);
    }

    updateServiceRequest(data) {
        let url = this.requestUrl+this.moduleParam.update_service_request;
        return this.httpClient.post(url, data);
    }

    /**
     * @uses (getServiceRequestList) list of all service request generated on system
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */

    getServiceRequestList() {
        let url = this.requestUrl+this.moduleParam.get_service_request_list;
        return this.httpClient.get(url);
    }


    serviceRequestStatusUpdate(data){
        let url = this.requestUrl+this.moduleParam.update_status_param;
        return this.httpClient.post(url, data);
    }

    getEditServiceRequest(data){
        let url = this.requestUrl+this.moduleParam.get_edit_service_request;
        return this.httpClient.post(url, data);
    }
    /**
     * @uses (getEditAmenity) get selected amenities info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     * @return Json selected building data
    */

    removeServiceRequest(data){
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, data);
    }
    
}