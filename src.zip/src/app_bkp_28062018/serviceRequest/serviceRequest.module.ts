import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiceRequestComponent } from './serviceRequest.component';
import { AddComponent }     from './addServiceRequest/add.component';
import { EditComponent }     from './editServiceRequest/edit.component';
import { ServiceRequestsRoute } from './serviceRequest.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';


@NgModule({
  imports: [
    CommonModule,
    ServiceRequestsRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [ServiceRequestComponent, AddComponent, EditComponent]
})
export class ServiceRequestsModule { }
