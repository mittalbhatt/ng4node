import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { BillingComponent }     from './billing.component';
import { BillingPaymentComponent }     from './payment/payment.component';

export const BillingRoutes: Routes = [
	{ path: '', component: BillingComponent },
	{ path: 'payment', component: BillingPaymentComponent }
];

export const BillingRoute: ModuleWithProviders = RouterModule.forChild(BillingRoutes);