import { Component, OnInit } from '@angular/core';
import { BillingService } from './billing.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { LocalStorageModule } from 'angular-2-local-storage';
import { ProfileService } from './../profile/profile.service';
import { PackageService } from './../package/package.service';
import _ from "lodash";


declare var $: any;
declare var swal: any;
declare var billing: any;


@Component({
  selector: 'app-billing',
  templateUrl: './billing.html',
  styleUrls: ['./billing.css']
})

export class BillingComponent implements OnInit {

  errorMessage: any = {}
  newfeatureArray =[];
  featureArray = [];
  baseUrl: any;
  companyData: any;
  moduleParam:any;
  Formtoken:any;
  localVal:any;
  statusResponse:any;
  billing:any;
  billingData:any;
  _csrf: any;
  data: any;
  features: any;

  constructor(
    private _BillingService: BillingService,
    //private _companyService: CompanyService,
    public router: Router,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService,
    private _packageService : PackageService,

  ) { }


  ngOnInit() {
    this.moduleParam = this.constant.billing;
    this.baseUrl = this.constant.baseUrl+this.moduleParam.get_billing_list;
    this.getFormToken();
    this.getFeatures();
    this.getBilling();
     
  }

   /**
   * @uses (getFormToken) get csrf form token
   *
   * @author RK < rakesh.rathava@softwebsolutions.com >
   *
   */
   getFormToken() {
     this.auth.getToken()
     .subscribe(
       response => {
         if(response){
           this.Formtoken = response;
           
         }
       },
       error =>  {
         this.errorMessage = <any>error
       });
   }

  getBilling() {
    this._BillingService.getBillingData()
     .then(
         response => {
           this.localVal = response;
           if(this.localVal.success == true){
            this.billing = this.localVal.data;
            // this.getFeatures();  
             this.getFeaturesTitle(this.billing); 


           } else {

             // if(typeof this.localVal.message === 'object'){
             //   this.serverMessage = this.localVal.message;
             // } else {
             //   this._notificationService.add(new Notification('error', this.localVal.message));
             // }
           }
         },
         error =>  {
           this._notificationService.add(new Notification('error', <any>error));
         });
  }


  getFeatures() {
    this._packageService.getPackageFeatures()
        .then((data)=>{ 
        if(data){
            this.localVal = data;
            if(this.localVal.success == true){
                this.features = this.localVal.data;

                
            }else{         
            }
        }
        },
        error =>  {
          this.errorMessage = <any>error
        });
    }

  getFeaturesTitle(billing) {


    
    var features = this.features;

    for(var i = 0; i<billing.length; i++) {
      var featureId = billing[i].PlanDetail.feature_id;

      var abc = this.featureArray;


      _.forEach(features, function(feature) {





          if(featureId.indexOf(feature.feature_id) >= 0) {



            // if(feature.feature_id.indexOf(abc) >=0) {



              abc.push({

                feature_id : feature.feature_id,
                feature_title : feature.feature_title



              })    


            // }

          


          

           
          }
          
        });

      
      
      
    }
     var newArr = [];
     this.newfeatureArray = newArr; 

  _.forEach(this.featureArray, function(value, key) {
    var exists = false;
    _.forEach(newArr, function(val2, key) {
      if(_.isEqual(value.feature_id, val2.feature_id)){ exists = true }; 
    });
    if(exists == false && value.id != "") { newArr.push(value); }
  });




      console.log(this.newfeatureArray);

    

  }


  
  



  editCompanyData(companyId) {
    this.router.navigate(['/company/edit/', companyId]);
  }

   companyStatusUpdate(companyId, status, dataTable) {
      
        // this._companyService.companyStatusUpdate({
        //         'company_id': companyId,
        //         'status': status,
        //         "_csrf": this.Formtoken
        //     })
        //     .subscribe((response)=>{ 
        //         this.statusResponse = response;
        //         if (this.statusResponse.success) {
        //           dataTable.ajax.reload(null, false);

        //         this._notificationService.add(new Notification('success', this.statusResponse.message));

        //           this.router.navigate([this.moduleParam.space_link]);
        //         } else {
        //           this._notificationService.add(new Notification('error', this.statusResponse.message));
        //         }
        //       });
    }


 


   

}
