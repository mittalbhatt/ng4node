import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { PlanExpiredGuardService } from './../common/services/plan-expired-guard.service';
import { SearchRoute } from './search.routing';
import { SearchComponent }     from './search.component';

@NgModule({
  imports: [
    CommonModule,
    SearchRoute,
    FormsModule,
    SharedModule
  ],
  declarations: [SearchComponent],
  providers:[PlanExpiredGuardService]
})
export class SearchModule { }
