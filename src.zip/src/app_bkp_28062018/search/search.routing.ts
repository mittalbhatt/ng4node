import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlanExpiredGuardService } from  './../common/services/plan-expired-guard.service';
import { SearchComponent }     from './search.component';


export const SearchRoutes: Routes = [
	{ 
		path: '',
		component: SearchComponent 
	}
];

export const SearchRoute: ModuleWithProviders = RouterModule.forChild(SearchRoutes);