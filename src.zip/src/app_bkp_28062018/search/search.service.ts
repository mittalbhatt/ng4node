﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';

@Injectable()
export class SearchService {
    
    private requestUrl:String;
    moduleParam:any;
    responseData:any ={};


    constructor(
        private http: Http,
        private router: Router, 
        private constant:Constants,
        private httpClient:HttpClient) {

        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.search;
    }

    /**
     * @uses get space data by search parameter
     *
     * @author RB < ranjitsinh.bhalgriya@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */
    getSearchData() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }


    /**
     * @uses get all listing data for dropdown
     *
     * @author RB < ranjitsinh.bhalgriya@softwebsolutions.com >
     *
     * @return Json success respose true or flase
    */
    getAllListData(){
        let url = this.requestUrl+this.moduleParam.all_list_data;
        return this.httpClient.get(url);
    }

}