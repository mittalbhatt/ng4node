import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { SpaceComponent }     from './list/space.component';
import { SpaceAddComponent }     from './add/add.component';
import { SpaceUpdateComponent }     from './edit/update.component';
import { PlanExpiredGuardService } from './../common/services/plan-expired-guard.service';

export const SpaceRoutes: Routes = [
	{ 
		path: '',
		//canActivate: [SpaceGuardService],
		component: SpaceComponent 
	},
	{ 
		path: 'add',
		canActivate: [PlanExpiredGuardService],
		component: SpaceAddComponent 
	},
	{ 
		path: 'edit/:id',
		canActivate: [PlanExpiredGuardService],
		component: SpaceUpdateComponent 
	}
];

export const SpaceRoute: ModuleWithProviders = RouterModule.forChild(SpaceRoutes);