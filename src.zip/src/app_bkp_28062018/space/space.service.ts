import { Injectable } from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ResponseData } from './../common/classes/response-data';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';


@Injectable()
export class SpaceService {

    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http, 
        private constant:Constants,
        private httpClient:HttpClient) {
        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.space;
     }

	/**
     * @uses get all space data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */    
    getSpaceList() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }


    /**
     * @uses get all Listing data for dropdown
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    allListData() { 
        let url = this.requestUrl+this.moduleParam.get_all_listing_data;
        return this.httpClient.get(url);       
    }

    
    /**
     * @uses get selected building's Floor List by id
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    floorListData(buildingId) {
        let url = this.requestUrl+this.moduleParam.get_floor_param+buildingId;
        return this.httpClient.get(url);
    }

    spaceListData(floorId) {
        let url = this.requestUrl+this.moduleParam.get_space_param+floorId;
        return this.httpClient.get(url);
    }
    
    

    /**
     * @uses call for insert new space
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    spaceAdd(formData) {
        let url = this.requestUrl+this.moduleParam.add_param;
        return this.httpClient.post(url, formData);
    }


    /**
     * @uses call for get update space data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    getSpaceUpdateData(spaceId) {
        let url = this.requestUrl+this.moduleParam.edit_space_link+spaceId;
        return this.httpClient.get(url);
    }

    /**
     * @uses call for update space
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    spaceUpdate(formData) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, formData);
    }

    /**
     * @uses call for update space status
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    spaceStatusUpdate(formData) {
        let url = this.requestUrl+this.moduleParam.update_status;
        return this.httpClient.post(url, formData);
    }

    /**
     * @uses call for delete space
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */   
    spaceDelete(formData) {
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url, formData);
    }

	/**
     * @uses Observable extractData
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    private extractData(res: Response) {
        let body = res.json();
        return body.data || {};
    }

	/**
     * @uses Observable handleError
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
        const body = error.json() || '';
        const err = body.error || JSON.stringify(body);
        errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
        errMsg = error.message ? error.message : error.toString();
    }
    return Observable.throw(errMsg);
}


}
