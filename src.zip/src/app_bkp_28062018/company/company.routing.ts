import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { CompanyComponent }     from './list/company.component';
import { CompanyUpdateComponent }     from './edit/update.component';

export const CompanyRoutes: Routes = [
	{ path: '', component: CompanyComponent },
	{ path: 'edit/:id', component: CompanyUpdateComponent }
];

export const CompanyRoute: ModuleWithProviders = RouterModule.forChild(CompanyRoutes);