import { Injectable } from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ResponseData } from './../common/classes/response-data';
import { Constants } from '../common/services/constants';
import {  HttpClient } from '../common/services/http.service';


@Injectable()
export class CompanyService {

    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http, 
        private constant:Constants,
        private httpClient:HttpClient) {
        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.company;
    }

	/**
     * @uses get all company data
     *
     * @author FJ < foram.kantaria@softwebsolutions.com >
     *
     * @return json
     */
    getCompanyList() {
        let url = this.requestUrl+this.moduleParam.get_company_list;
        return this.httpClient.get(url);
    }

    companyStatusUpdate(data) {
        let url = this.requestUrl + this.moduleParam.companyStatus;
        

        return this.http.post(url, data)
      .map(res => res.json())
      .catch(this.handleError)
    }

    companyUpdateData(companyId) {
        let url = this.requestUrl + this.moduleParam.edit_company_link+companyId;
        return this.httpClient.get(url); 
    }

    updateCompanyData(data) {
        let url = this.requestUrl + this.moduleParam.update_company;
        var combineData = {user: data,_csrf: data._csrf}

        return this.http.put(url, data)
      .map(res => res.json())
      .catch(this.handleError)
    }


     private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;

    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }

    return Observable.throw(errMsg);
  }

}
