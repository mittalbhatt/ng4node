import { Component } from '@angular/core';

@Component({
  template: `<div class="page-center">
        <div class="page-center-in">
            <div class="container-fluid">
                <div class="page-error-box">
                    <div class="error-code">404</div>
                    <div class="error-title">Page not found</div>
                    <a routerLink="/" class="btn btn-rounded">Main page</a>
                </div>
            </div>
        </div>
    </div>`
})
export class PageNotFoundComponent {}
