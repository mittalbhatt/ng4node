import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FloorComponent } from './list/floor.component';
import { FloorAddComponent }     from './add/add.component';
import { FloorUpdateComponent }     from './edit/update.component';
import { FloorRoute } from './floor.routing';
import { FloorService } from './floor.service';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FloorRoute,
    SharedModule
  ],
  providers: [FloorService, FormBuilder],
  declarations: [FloorComponent, FloorAddComponent, FloorUpdateComponent]
})
export class FloorModule { }
