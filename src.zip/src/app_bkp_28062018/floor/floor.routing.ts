import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService }          from './../auth/auth-guard.service';
import { FloorComponent }     from './list/floor.component';
import { FloorAddComponent }     from './add/add.component';
import { FloorUpdateComponent }     from './edit/update.component';

export const FloorRoutes: Routes = [
	{ path: '', component: FloorComponent },
	{ path: 'add', component: FloorAddComponent },
	{ path: 'edit/:id', component: FloorUpdateComponent }
];

export const FloorRoute: ModuleWithProviders = RouterModule.forChild(FloorRoutes);