import { Injectable } from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ResponseData } from './../common/classes/response-data';
import { Constants } from '../common/services/constants';
import { HttpClient } from '../common/services/http.service';


@Injectable()
export class FloorService {

    private requestUrl:String;
    moduleParam:any;

    constructor(
        private http: Http, 
        private constant:Constants,
        private httpClient:HttpClient) {
        this.requestUrl = this.constant.baseUrl;
        this.moduleParam = this.constant.floor;
    }

	/**
     * @uses get all floor data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    getFloorList() {
        let url = this.requestUrl+this.moduleParam.get_list_param;
        return this.httpClient.get(url);
    }

    /**
     * @uses get all floor data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    getBuildingList() {
        let url = this.requestUrl+this.moduleParam.get_build_param;
        return this.httpClient.get(url);
    }

	/**
     * @uses call for insert new floor
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    floorAdd(formData) {
        let url = this.requestUrl+this.moduleParam.add_param;
        return this.httpClient.post(url, formData);
    }

	/**
     * @uses call for get update floor data
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    getFloorUpdateData(floorId) {
        let url = this.requestUrl+this.moduleParam.edit_param+floorId;
        return this.httpClient.get(url);
    }

    findNoFloor(formData){
        let url = this.requestUrl+this.moduleParam.no_of_floor_count;
        return this.httpClient.post(url, formData); 
    }

	/**
     * @uses call for update floor
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    floorUpdate(formData) {
        let url = this.requestUrl+this.moduleParam.update_param;
        return this.httpClient.post(url, formData);
    }

    /**
     * @uses call for update floor status
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    floorStatusUpdate(formData) {
        let url = this.requestUrl+this.moduleParam.update_status;
        return this.httpClient.post(url, formData);
    }

	/**
     * @uses call for delete floor
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     * @return json
     */
    floorDelete(formData) {
        let url = this.requestUrl+this.moduleParam.remove_param;
        return this.httpClient.post(url,formData);
    }

}
