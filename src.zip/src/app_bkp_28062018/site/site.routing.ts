import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SiteComponent }    from './site.component';

import { AuthGuardService } from './../auth/auth-guard.service';


const siteRoutes: Routes = [
  {
    path: '',
    canActivate: [AuthGuardService],
    component: SiteComponent,
    children: [
      {
        path: '',
        canActivate: [AuthGuardService],
        loadChildren: './../home/home.module#HomeModule',
        data: {title: 'Upcoming Meetings'}

      },
      {
        path: 'building',
        canActivate: [AuthGuardService],
        loadChildren: './../building/building.module#BuildingModule',
        data: {title: 'Buildings'}

      },
      {
        path: 'floor',
        canActivate: [AuthGuardService],
        loadChildren: './../floor/floor.module#FloorModule',
        data: {title: 'Floors'}

      },
      {
        path: 'user',
        canActivate: [AuthGuardService],
        loadChildren: './../user/user.module#UserModule',
        data: {title: 'Users'}

      },
      {
        path: 'amenities',
        canActivate: [AuthGuardService],
        loadChildren: './../amenities/amenities.module#AmenitiesModule',
        data: {title: 'Amenities'}
        
      },
      {
        path: 'space',
        canActivate: [AuthGuardService],
        loadChildren: './../space/space.module#SpaceModule',
        data: {title: 'Spaces'}

      },
      {
        path: 'analytics',
        canActivate: [AuthGuardService],
        loadChildren: './../analytics/analytics.module#AnalyticsModule',
        data: {title: 'Analytics'}

      },
      {
        path: 'settings',
        canActivate: [AuthGuardService],
        loadChildren: './../settings/settings.module#SettingsModule',
        data: {title: 'Settings'}

      },
      {

        path: 'get-user',
        canActivate:[AuthGuardService],
        loadChildren: './../profile/profile.module#ProfileModule',
        data: {title: 'Profile'}

      },
      {
        path: 'profile',
        canActivate: [AuthGuardService],
        loadChildren: './../profile/profile.module#ProfileModule',
        data: {title: 'Profile'}
        
      },
      {
        path: 'company',
        canActivate: [AuthGuardService],
        loadChildren: './../company/company.module#CompanyModule',
        data: {title: 'Company'}

      },
      {
        path: 'sensor',
        loadChildren: './../sensor/sensor.module#SensorManageModule',
        data: {title: 'Sensors'}

      },
      {
        path: 'device',
        loadChildren: './../device/device.module#DeviceManageModule',
        data: {title: 'Devices'}

      },
      {
        path: 'logout',
        canActivate: [AuthGuardService],
        loadChildren: './../auth/logout.module#LogoutModule',
        data: {title: 'Logout'}

      },
      {
        path: 'event',
        canActivate: [AuthGuardService],
        loadChildren: './../event/event.module#EventModule',
        data: {title: 'Event'}

      },
      {
        path: 'package',
        canActivate: [AuthGuardService],
        loadChildren: './../package/package.module#PackageModule',
        data: {title: 'Packages'}

      },
      {
        path: 'billing',
        canActivate: [AuthGuardService],
        loadChildren: './../billing/billing.module#BillingModule',
        data: {title: 'Billing'}

      },
      {
        path: 'service-request',
        canActivate: [AuthGuardService],
        loadChildren: './../serviceRequest/serviceRequest.module#ServiceRequestsModule',
        data: {title: 'Service Requests'}

      },
      {
        path:'schedule',
        canActivate:[AuthGuardService],
        loadChildren:'./../meeting/meetings.module#MeetingsModule',
        data: {title: 'Meetings'}

      },
      {
        path:'search',
        canActivate:[AuthGuardService],
        loadChildren:'./../search/search.module#SearchModule',
        data: {title: 'Search'}

      }

    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(siteRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SiteRoutingModule {}
