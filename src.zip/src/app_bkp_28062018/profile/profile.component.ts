import { Component, OnInit } from '@angular/core';
import { ProfileService } from './profile.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService, Notification } from '../common/services/notifications.service';
import { Constants } from '../common/services/constants';
import { AuthService } from '../auth/auth.service';
import { LocalStorageModule } from 'angular-2-local-storage';
import { SpaceService } from "../space/space.service";
// import { ChangeProfileService } from '../common/services/shared.service';
import { ProfileLogo } from '../common/services/shared.service';

declare var $: any;
declare var swal: any;

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',  
  providers:[ProfileService,SpaceService]
})
export class ProfileComponent implements OnInit {

  private requestUrl:String;
  current_password_err:any;
  serverMessage:String;
  removeImage: boolean =  false;


  profile={
  	"floor_id":"",
  	"building_id":"",
    "time_zone":"",
    "time_difference":""
  };

  passwd:Object={};
  errorMessage:String;
  objData:object;
  moduleParam:any;
  Formtoken:any;
  localVal:any;
  profile_picture:any;
  user_name:any;

  private base64textString:String="";
  floorDisabled = true;
  listResponseData: any = {};
  timezoneArr: any = {};
  buildingList: any = [];
  floorList: any = [];
  responseData: any = {};
  files:any;
  file:any;
  filename:string='';
  binaryString:any;
  


  constructor(
    private profileService:ProfileService,
    private router: Router, 
    private activeRoute:ActivatedRoute,
    private _notificationService: NotificationService,
    private constant: Constants,
    private auth:AuthService,
    private _spaceService: SpaceService,
    // private changeprofileService:ChangeProfileService,
    private shareProfileLogo:ProfileLogo,

    ) { }

  ngOnInit() {
    this.moduleParam = this.constant.profile;
    this.timezoneArr = this.constant.timezoneArray;
    this.getFormToken();
    this.getCurrentUser();
    this.getAllListData();
  }

  onUpdateProfile(form){
    form.profile_picture = this.base64textString; // image base64 string to insert into form obj 
    form.profile_picture_name = this.filename; // image original file name to recover image in server side
    form.removeImage = this.removeImage;
    form._csrf = this.Formtoken;

    let time_difference = form.time_zone;
    let time_zone = "";

    
    if(this.file != undefined && this.file.size > this.constant.fileUploadSize){
      this._notificationService.add(new Notification('error', this.constant.error_message_file));
      return;
    }
      
    this.timezoneArr.forEach(function(val){
      if(val.key == time_difference){
        form.time_zone = val.value;
        form.time_difference = val.key;
      }
    })

      if(this.file != undefined && this.file.size > this.constant.fileUploadSize){
        this._notificationService.add(new Notification('error', this.constant.error_message_file));
        return;
      } 

    // console.log("---- START : profile image ---");
    // console.log(form.profile_picture);    
    // console.log("---- STOP : profile image ---");

      this.profileService.updateProfile(form)
       .then(
         response => {
           this.localVal = response;
           if(this.localVal.success == true){
            this.profile['image'] = this.localVal.data.image;
            this.shareProfileLogo.updateProfileLogo(this.localVal.data.image);
            // Remove from front side upload
            this.base64textString = '';
            this.filename = '';

            // this.changeprofileService.change(this.localVal.data);
            this._notificationService.add(new Notification('success', this.localVal.message));
            this.router.navigate(['/profile']);
           } else {
             if(typeof this.localVal.message === 'object'){
               this.serverMessage = this.localVal.message;
             }else{
               this._notificationService.add(new Notification('error', this.localVal.message));
             }
           }
         },
         error =>  {
           this._notificationService.add(new Notification('error', <any>error));
         });
  }

     /**
     * @uses (onPasswordChangeSubmit) Change Password function
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

     onPasswordChangeSubmit(form){

       form._csrf = this.Formtoken;
       if(form.current_password != "" && form.confirm_password == form.password){

         this.profileService.changePassword(form)
         .then(
           response => {
             this.localVal = response;

             if(this.localVal.success == true){
               this.router.navigate(['/']);
               this._notificationService.add(new Notification('success', this.localVal.message));
             } else {

               if(typeof this.localVal.message === 'object'){
                 this.serverMessage = this.localVal.message;
               }else{
                 this._notificationService.add(new Notification('error', this.localVal.message));
               }
             }
           },
           error =>  {
             this._notificationService.add(new Notification('error', <any>error));
           });

       }
     }

    getAllListData() {
		this._spaceService.allListData()
			.then((res) => {
				this.listResponseData = res;          
        if (this.responseData) {          
					this.buildingList = this.listResponseData.data.buildings;
				}
			});
	}


	/**
	 * @uses get floor data for selected building
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     */
	getFloorData(building_id) {
		this._spaceService.floorListData(building_id)
			.then((res) => {
				if (res) {
					this.floorList = res;
					this.floorList = this.floorList.data;
				}
			});
	}

	/**
	 * @uses Get floor list onBuildingChange
     *
     * @author RB < ranjitsinh.bhalgariya@softwebsolutions.com >
     *
     */
	onBuildingChange(id){
		if(id!=''){
			this.floorDisabled = false;
			this.getFloorData(id);
		} else {
			this.floorDisabled = true;
		}		
	}

     /**
     * @uses (getFormToken) get csrf form token
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */
     getFormToken() {
       this.auth.getToken().subscribe(
         response => {
           if(response){
             this.Formtoken = response;
           }
         }, error =>  {
           this.errorMessage = <any>error
         });
     }

      /**
     * @uses (getCurrentUser) get current user info
     *
     * @author RK < rakesh.rathava@softwebsolutions.com >
     *
     */

     getCurrentUser(){
       this.profileService.getCurrentUser()
       .then(
         response => {
           this.localVal = response;

           if(this.localVal.success == true){
            
            console.log("---- all profile info ----");
            console.log(this.localVal);

             this.profile = this.localVal.data;
             this.profile.floor_id = (this.localVal.data.floor_id)? this.localVal.data.floor_id : "";
             this.profile.building_id =  (this.localVal.data.building_id)? this.localVal.data.building_id : "";
             this.profile.time_zone =  (this.localVal.data.timezone)? this.localVal.data.timezone : "";

             if(this.localVal.data.building_id){
               this.getFloorData(this.localVal.data.building_id);
               this.floorDisabled = false;
             }

           } else {

             if(typeof this.localVal.message === 'object'){
               this.serverMessage = this.localVal.message;
             } else {
               this._notificationService.add(new Notification('error', this.localVal.message));
             }
           }
         },
         error =>  {
           this._notificationService.add(new Notification('error', <any>error));
         });
     }

    /**
   * @uses (removeConfirmPlanImage) Close button click confirmation popup box
   *
   * @author RK < rakesh.rathava@softwebsolutions.com >
   *
  */
    removeConfirmProfileImage(e) {
      e.preventDefault();
        var self = this;    
        swal({
          title: "Are you sure?",
          text: "you want to remove this image.!",
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel"        
        },
        function(isConfirm) {
          if (isConfirm) {          
            self.removeFile();                                    
          }        
        });
    }
   
   /**
   * @uses (removeFile) function to set image remove flag
   *
   * @author KT < ketan@softwebsolutions.com >
   *
   */
   removeFile()
   {
      var submitData = {'_csrf':this.Formtoken};
      this.profileService.removeProfileLogo(submitData)
       .then(
         response => {
           if(response){
             this.localVal = response;
             if(this.localVal.success == true)
             {
                this.profile['image'] = this.localVal.profile_picture;
                this.shareProfileLogo.updateProfileLogo(this.localVal.profile_picture);
                // Remove from front side
                this.base64textString = '';
                this.filename = '';
                // this.removeImage = true;
               this.router.navigate(['/profile']);
               this._notificationService.add(new Notification('success', this.localVal.message));
             }else{
               if(typeof this.localVal.message === 'object'){
                 this.serverMessage = this.localVal.message;
               }else{
                 this._notificationService.add(new Notification('error', this.localVal.message));
               }
             }
           }
         },
         error =>  {
           this._notificationService.add(new Notification('error', <any>error));
         });      
   }

  /**
   * @uses  (fileChangeEvent) On file change function to encode image into the base64 string
   *
   * @author RK < rakesh.rathava@softwebsolutions.com >
   *
   */

   fileChangeEvent(evt){
     this.files = evt.target.files;
     this.file = this.files[0];
     this.filename = this.file.name;

     if (this.files && this.file) {
       var reader = new FileReader();

       reader.onload =this._handleReaderLoaded.bind(this);

       reader.readAsBinaryString(this.file);
     }

   }

   _handleReaderLoaded(readerEvt) {
     this.binaryString = readerEvt.target.result;
     this.base64textString= btoa(this.binaryString);
     //console.log(btoa(this.binaryString));
   }
 }
