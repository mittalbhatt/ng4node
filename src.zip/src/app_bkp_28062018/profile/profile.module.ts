import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileComponent } from './profile.component';
import { FormsModule } from '@angular/forms';
import { SharedModule }   from './../common/components/shared.module';
import { ProfilesRoutes} from './profile.routing';
// import { EqualValidator } from '../common/directives/equal-validator.directive';

@NgModule({
  imports: [
    CommonModule,
    ProfilesRoutes,
    FormsModule,
    SharedModule
  ],
  declarations: [ProfileComponent]
})
export class ProfileModule { }
