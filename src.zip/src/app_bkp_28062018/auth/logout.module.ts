import { NgModule } from '@angular/core';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { CommonModule } from '@angular/common';

import { LogoutComponent } from './logout/logout.component';
import { LogoutRoutingModule }      from './logout/logout.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LogoutRoutingModule
  ],
  providers: [
    FormBuilder,
  ],
  declarations: [LogoutComponent]
})
export class LogoutModule { }