// import { Injectable } from '@angular/core';

// @Injectable()
// export class AuthGuardService {

//   constructor() { }

// }

import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { LocalStorageModule } from 'angular-2-local-storage';

@Injectable()
export class AuthGuardService implements CanActivate {
    constructor(private router: Router) { }

    canActivate() {
        if (localStorage.getItem('userAccessToken')) {
            // logged in so return true
            return true;
        }
        // not logged in so redirect to login page
        this.router.navigate(['/login']);
        return false;
    }
}
