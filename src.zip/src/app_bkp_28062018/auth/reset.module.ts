import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResetComponent } from './reset/reset.component';
import { ResetTokenComponent } from './reset/reset-token.component';

import { ResetRoutingModule } from './reset/reset.routing';
import { FormsModule }   from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    ResetRoutingModule,
    FormsModule
  ],
  declarations: [ResetComponent,ResetTokenComponent]
})
export class ResetModule { }
