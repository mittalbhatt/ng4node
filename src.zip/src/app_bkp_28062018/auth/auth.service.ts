import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { LocalStorageModule } from 'angular-2-local-storage';
import { Http, Response,RequestOptions,Headers }          from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Constants } from '../common/services/constants';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { ResponseData } from './../common/classes/response-data';


@Injectable()
export class AuthService {
	private url = 'webapi/';

  // URL to web API

  constructor(private http: Http,private constants: Constants,private _router: Router) { }

  // login(loginModel) {
    // 	return this.http.post(this.url + "login", loginModel)
    // 	.map(this.extractData)
    // 	.catch(this.handleError);
    // }
    private requestUrl = this.constants.baseUrl+'/user/info';  // URL to web API

    login(loginModel): Observable<string> {
      
      let basicToken = "Basic "+localStorage.getItem('userBasicToken');
      let options = new RequestOptions({
        headers: new Headers({ 'Content-Type': 'application/json;charset=UTF-8', 'Authorization': basicToken }) 
      });
      

      let user = {username: loginModel.email, password: loginModel.password, grant_type: 'password', _csrf:loginModel._csrf};
      let url = this.url+'login';
      user._csrf = loginModel._csrf;

      return this.http.post(url,JSON.stringify(user),options)
      .map((response: Response) => {
        let res = response.json();


        console.log(res.error_description);
        // login successful if there's a jwt token in the response
        let token = res && res.access_token;
        if (token) {
          // set token property
          
          localStorage.setItem('userAccessToken', res.access_token);
          localStorage.setItem('UserSession', res);
          
          return res;
        } else {
          return res;
        }

      }).catch(this.handleError);
    }


    getProfile(): Observable<string> {
      return this.http.get(this.requestUrl)
      .map(this.extractData)
      .catch(this.handleError);
    }

    getBasicToken(): Observable<boolean>{
      let url = this.url+'getToken';
      return this.http.get(url)
      .map((response: Response) => {
        // login successful if there's a jwt token in the response
        let token = response.json() && response.json().data;
        if (token) {

          // store jwt token in local storage to keep user logged in between page refreshes
          
          localStorage.setItem('userBasicToken', token);

          // return true to  successful token receive
          return true;
        } else {
          // return false to indicate failed to receive token
          return false;
        }
      }).catch(this.handleError);
    }



    getToken(): Observable<string> {
      return this.http.get(this.constants.tokenUrl + "token/form-token")
      .map((response: Response) => {
        let res = response.json();
        if(res.success){
          return res.token;
        }
      })
      .catch(this.handleError);
    }

    private extractData(res: Response) {
      let body = res.json();
      localStorage.setItem('userSession',JSON.stringify(body.data));
      return body.data || { };
    }

    userRegister(formDataUser) {
      return this.http.post(this.constants.registerUrl + "register",formDataUser)
      .map(res=>res.json())
      .catch(this.handleError)
    }

    userAccessRights() {
      return this.http.get(this.constants.baseUrl+this.constants.accessRightsUrl)
      .map(res=>res.json())
      .catch(this.handleError)
    }


    logout(): void {
      // localStorage.removeItem('userSession');
      // localStorage.removeItem('userId');

      localStorage.clear();
      this._router.navigate(['/login']);        
    }



  getDomain() {
    let url = this.constants.registerUrl + 'getDomain';
    return this.http.get(url)
      .map(res => res.json())
      .catch(this.handleError)
  }

  getCompanyDetailsFromDomain(data) {


    let url = this.constants.registerUrl + 'getCompanyFromDomain/' + data;
    return this.http.get(url)
      .map(res => res.json())
      .catch(this.handleError)

  }

  getConfiguration() {


    let url = this.constants.registerUrl + 'getCompanyConfiguration/';
    return this.http.get(url)
      .map(res => res.json())
      .catch(this.handleError)

  }


    private handleError (error: Response | any) {
      // In a real world app, you might use a remote logging infrastructure
      let errMsg: string;
      if (error instanceof Response) {
        const body = error.json() || '';
        const err = body.error || JSON.stringify(body);
        errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
      } else {
        errMsg = error.message ? error.message : error.toString();
      }
      return Observable.throw(errMsg);
    }

  }
