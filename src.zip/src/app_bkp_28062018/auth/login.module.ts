import { NgModule } from '@angular/core';
import { FormsModule, FormBuilder }    from '@angular/forms';
import { CommonModule } from '@angular/common';

import { LoginComponent } from './login/login.component';
import { LoginRoutingModule }      from './login/login.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LoginRoutingModule
  ],
  providers: [
    FormBuilder,
  ],
  declarations: [LoginComponent]
})
export class LoginModule { }