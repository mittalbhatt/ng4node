import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { LocalStorageModule } from 'angular-2-local-storage';


@Injectable()
export class PreventLoggedInAccess implements CanActivate {

  constructor(private router: Router) {}

  canActivate() {

  	if(localStorage.getItem('userAccessToken') == null) {
        return true;
  	}
  	else {
  		this.router.navigate(['/']);
  		return false;
  	}
  }
} 