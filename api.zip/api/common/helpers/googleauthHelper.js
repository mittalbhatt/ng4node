var http = require('http');
var express = require('express');
var Session = require('express-session');
//var google = require('googleapis');
const {google} = require('googleapis');
var plus = google.plus('v1');
var OAuth2 = google.auth.OAuth2;
const ClientId = "57025079773-qj7a0ru0qikhv9raqe9h9vgn0a8see8f.apps.googleusercontent.com";
const ClientSecret = "XExuheUbcRaT4fBlqJ_8LdLe";

var database = require('../../../server/config/database');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;
var momenttime = require('moment-timezone');
var dateFormat = require('dateformat');
var tmplDateTimeFormat = 'D MMM, YYYY h:mm A';

//const RedirectionUrl = "http://localhost:1234/oauthCallback";
const RedirectionUrl = "http://texas.smartoffice.com:3005/settings";
//var settingsController = require('../controllers/settingsController');

var app = express();
app.use(Session({
    secret: 'raysources-secret-19890913007',
    resave: true,
    saveUninitialized: true
}));

// function getOAuthClient () {
//     return new OAuth2(ClientId ,  ClientSecret, RedirectionUrl);
// }
module.exports = {
  getOAuthClient: function() {
    return new OAuth2(ClientId ,  ClientSecret, RedirectionUrl);
  },
 getAuthUrl: function() {
    var oauth2Client = this.getOAuthClient();
    // generate a url that asks permissions for Google+ and Google Calendar scopes
    var scopes = [
      //'https://www.googleapis.com/auth/plus.me'
    'https://www.googleapis.com/auth/plus.login', 'https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/calendar'
    ];
   

    var url = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });

    return url;
},
 getTokenFromCode: function(auth_code, callback, request, response) {
  
  var oauth2Client = this.getOAuthClient();
    var session = request.session;
    var code = auth_code;
//   oauth2Client.on('tokens', (tokens) => {
//   if (tokens.refresh_token) {
//     console.log('refreshtokens===========================');
//     // store the refresh_token in my database!
//     console.log(tokens.refresh_token);
//   }
//   console.log(tokens.access_token);
// });
    oauth2Client.getToken(code, function(err, tokens) {
      // Now tokens contains an access_token and an optional refresh_token. Save them.
      if(!err) {
        var setcread=oauth2Client.setCredentials(tokens);
 if (tokens.refresh_token) {
    console.log('refreshtokens===========================');
    // store the refresh_token in my database!
    console.log(tokens.refresh_token);
  }
        var tokan=tokens;
        session["tokens"]=tokens;
         console.log('tokens===========================');
        console.log(tokan);
        this.upsertConfigurationUser(request, response, tokan);
       // console.log( session["tokens"]);
        // settingsController.upsertConfigurationUserforgoogle(request, response, tokan);  
         callback(request, response, null, tokan);
       // res.send('<h3>Login successful!!</h3><a href="/details">Go to details page</a>;');
      }
      else{
        console.log('Access token error: ', error.message);
          console.log(error);
          callback(request ,response, error, null);
      }
    });
   
   },
 upsertConfigurationUser: function(req, res, token)
{
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        if(company_databasename != null)
        {
                    //console.log('Token created: ', token.token);
                    var GUID = generalConfig.generateGUID();
                    var userid = tokenData.UserData.user_id;
                    var o365_access_token = token.token.access_token;
                    var o365_refresh_token = token.token.refresh_token;
                    var o365_token_expire_at = generalConfig.getDateTimeUTC(token.token.expires_at);
                    var created_at = generalConfig.getDateTimeUTC();
                    var updated_at = generalConfig.getDateTimeUTC();
                    
                    console.log('----------------------------------------------------------------');
                    console.log('-----------------        Testing (start)   2  ---------------------');
                    console.log('');
                    console.log(userid);
                    console.log(token);
                    console.log(tokenData);
                    console.log('');
                    console.log('-----------------        Testing (end)      2   ---------------------');
                    console.log('----------------------------------------------------------------');
                    
                    var selectQuery = "SELECT `configUser`.*  FROM " + company_databasename+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
                    connection.query(selectQuery, function (error, results, fields) {
                        if (error) {
                          console.log(message.ERROR);
                        } else {
                            if (results.length == 0) {
                              var configUser = " INSERT INTO "+company_databasename+".`so_configuration_user` (`configuration_user_id` , `user_id` , `office_365`, `o365_access_token` , `o365_refresh_token` , `o365_token_expire_at`, `created_at`, `updated_at`) VALUES ( '"+GUID+"','"+userid+"' , 'true', '"+o365_access_token+"', '"+o365_refresh_token+"', '"+o365_token_expire_at+"' , '"+created_at+"', '"+updated_at+"')";
                              connection.query(configUser, function (error, configUser, fields)
                              {
                                if(error){
                                 console.log(message.ERROR);
                                }
                              });
                            } else {
                              var updateConfigUser = "UPDATE "+company_databasename+".`so_configuration_user` SET `o365_access_token` =  '"+o365_access_token+"', `o365_refresh_token` =  '"+o365_refresh_token+"', `o365_token_expire_at` =  '"+o365_token_expire_at+"',`office_365` = 'true', `updated_at` =  '"+updated_at+"' WHERE  `so_configuration_user`.`user_id` = '"+userid+"'";
                              connection.query(updateConfigUser, function (error, updateConfigUser, fields)
                              {
                                if(error){
                                  console.log(message.ERROR);
                                }
                              });
                            }
                        }
                    });
        }

    });
},
   createEvent: function( results, attendiesForgoogle, newEvent) {
 var oauth2Client = this.getOAuthClient();
     console.log('oauth2Client==========');
  console.log(newEvent.start.dateTime);
  console.log(newEvent.start.dateTime.toISOString().replace('Z', ''));
  var startdate=newEvent.start.dateTime.toISOString().replace('Z', '');

  var enddate=newEvent.end.dateTime.toISOString().replace('Z', '');
    oauth2Client.setCredentials({ access_token: results[0].google_access_token,
  token_type: 'Bearer',
  refresh_token:results[0].google_refresh_token,
  id_token: results[0].google_id_token,
  expiry_date: results[0].google_token_expire_at });

     var resource = {
        summary: newEvent.summary,
        location: newEvent.location,
        description: newEvent.description,
        start: {
            'dateTime': startdate,
            'timeZone': newEvent.start.timeZone
          },
        end: {
            'dateTime': enddate,
            'timeZone': newEvent.end.timeZone,
        },

       
        
    }; 
    console.log(resource);

    var calendar = google.calendar('v3');
    calendar.events.insert({
    auth: oauth2Client,
    calendarId: 'primary',
    sendNotifications: true,
    resource: resource

    },function(err,resp) {
      console.log('eventcreated=========')
        if (err) {
           // resp.send('There was an error : ' + err);
           // return;
        }
           // resp.send(resp,'Event created:', resp.htmlLink);
        }
    )

  }
 


};










