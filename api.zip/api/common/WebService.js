/* Customization Start ASHWIN */

var generalConfig = require('../../server/config/generalConfig');
var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var moment = require('moment');
var jwt = require('jwt-simple');
var mysql = require('mysql');
var config    = require('../../server/config/database');
var conn = require('../../server/config/mysql-connection');
var connection = conn.connection;

module.exports = {


  CheckJWTToken: function(req, res, callback) {
    var token = req.headers['authorization'];
    if (token) {
      try {
        var AccessToken = token.split(" ")[1];
        var decoded = jwt.decode(AccessToken, secretKey);
        var currentDate = Date.now();
        if (decoded.exp <= currentDate) {
            var expireDate = moment().add(1, 'hours').valueOf();
            var token = jwt.encode({
                          UserData: decoded.UserData,
                          CompanyData : decoded.CompanyData,
                          ConfigData : decoded.ConfigData,
                          exp: expireDate
                        }, secretKey);
            //var newToken = { "newToken" : token};
            //WS.Output(req, res, false, 400,"Token has expired and can no longer be refreshed",newToken);
            WS.Output(req, res, false, 401,"Token has expired and can no longer be refreshed","","",token);
        }else{
          if(req.body.logout && req.body.logout == 1)
          {
              callback(decoded);
          }
          else {
              //Check API AND APP VERSION -- START
              all_form_fields = req.body;
              app_version_query = "SELECT app_version, api_version, update_link FROM `so_app_versions` WHERE is_production=1 AND application_name = '"+all_form_fields.application_name+"' AND device_type = '"+all_form_fields.device_type+"'";

              connection.query(app_version_query, function (error, results, fields) {
                if(error){
                  WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,[error.message]);
                  return true;
                }
                if(results && results[0] != undefined){
                  var api_version = results[0]['api_version'];
                  var app_version = results[0]['app_version'];
                  var update_link = results[0]['update_link'];
                  if(app_version != all_form_fields.app_version){
                      var msg = "App version not match. Please download latest app version.";
                      var data = {
                        "app_status" : {
                          "current_version": all_form_fields.app_version,
                          "latest_version": app_version,
                          "update_link": update_link
                        }
                      };
                      WS.Output(req, res, false, 400,msg,data);
                  }else if(api_version != req.url.substring(11, 13)){
                      var msg = "API version not match. Please download latest app version.";
                      var data = {
                        "app_status" : {
                          "current_version": req.url.substring(11, 13),
                          "latest_version": api_version,
                          "update_link": update_link
                        }
                      };
                      WS.Output(req, res, false, 400,msg,data);
                  }else{

                      //Check DEVICE ENTRY -- START
                      var company_databasename = decoded.CompanyData.mycompany;
                      device_entry_query = "SELECT device_id,device_uniq_id FROM "+company_databasename+".so_device_master WHERE device_uniq_id='"+all_form_fields.device_uniq_id+"' AND application_name = '"+all_form_fields.application_name+"'";
                      connection.query(device_entry_query, function (error, results, fields) {
                          if(error){
                            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,[error.message]);
                            return true;
                          }
                          
                          // var now = new Date();
                          // var current_date = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
                          var current_date = moment.utc().format('YYYY-MM-DD HH:mm:ss');

                          if(results.length > 0){
                            var update_device_query = "UPDATE "+company_databasename+".so_device_master ";
                              update_device_query += " SET app_version='"+all_form_fields.app_version+"',";
                              update_device_query += " api_version = '"+req.url.substring(11, 13)+"',";
                              update_device_query += " device_type = '"+all_form_fields.device_type+"',";
                              update_device_query += " os_version = '"+all_form_fields.os_version+"',";
                              update_device_query += " user_id = '"+decoded.UserData.user_id+"',";
                              update_device_query += " device_token = '"+all_form_fields.device_token+"',";
                              update_device_query += " application_name = '"+all_form_fields.application_name+"',";
                              update_device_query += " status = '1',";
                              update_device_query += " sync_date = '"+current_date+"',";
                              update_device_query += " updated_at = '"+current_date+"'";
                              update_device_query += " WHERE device_id = '"+results[0]['device_id']+"'";
                              connection.query(update_device_query);
                          }else{
                              var insert_device_query = "INSERT INTO "+company_databasename+".so_device_master ";
                              insert_device_query += "(device_id, device_uniq_id, device_name, app_version, api_version, device_type, os_version, user_id, device_token, application_name, status, sync_date, created_at, updated_at) ";
                              insert_device_query += "VALUES (UUID(), '"+all_form_fields.device_uniq_id+"', NULL, '"+all_form_fields.app_version+"', '"+req.url.substring(11, 13)+"', '"+all_form_fields.device_type+"', '"+all_form_fields.os_version+"', '"+decoded.UserData.user_id+"','"+all_form_fields.device_token+"','"+all_form_fields.application_name+"',1,'"+current_date+"','"+current_date+"','"+current_date+"')";
                              connection.query(insert_device_query);
                          }
                      });
                      //Check DEVICE ENTRY -- END
                      callback(decoded);
                  }
                }else{
                  WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
                }
              });
              //Check API AND APP VERSION -- END
            }
        }
      } catch (err) {
        WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
      }
    } else {
      WS.Output(req, res, false, 401, "Token absent");
    }

  },

  /* Declare rules of webservice by ASHWIN  */
  RequiredParameter : function (req, res, next, callback){

    var para = new Array();

    /*
    $para['custom']['aa'] = 'required';
    $para['custom']['a'] = 'required|boolean';
    $para['custom']['b'] = 'required|integer';
    $para['custom']['c'] = 'required|numeric';
    $para['custom']['d'] = 'required|alpha_num';
    $para['custom']['e'] = 'required|date_format:Y-m-d';
    $para['custom']['f'] = 'required|exists:locations,id';
    $para['custom']['g'] = 'required|exists:users,id,usertype,guide';

    //email => email address
    //boolean => only allow 0 or 1
    //integer => allow + or - in integer
    //numeric => allow + or - in numeric
    //alpha => only a to z allow
    //alpha_num => alpha numeric
    //date_format:format -> date_format:Y-m-d
    //exists:table,column
    //exists:table,column,add where condition
    */

    para['login'] = new Array();
    para['login'] = [{
                        'key' : 'email',
                        'validation' : 'required|email',
                      },{
                        'key' : 'password',
                        'validation' : 'required',
                      }];
    para['logout'] = new Array();
    para['logout'] = [
                      {
                        'key' : 'logout',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      }
                      ];
    para['forgotpassword'] = new Array();
    para['forgotpassword'] = [
                      {
                        'key': 'email',
                        'validation' : 'required|email',
                      }
                    ];
    para['test'] = new Array();
    para['test'] = [{
                        'key' : 'email',
                        'validation' : 'required',
                      }
                    ];


    para['get-spaces-list'] = new Array();
    para['get-spaces-list'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      }
                    ];

    para['get-search-spaces-list'] = new Array();
    para['get-search-spaces-list'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_start_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_end_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'space_capacity',
                        'validation' : 'integer',
                      }
                    ];


    para['sosetup-get-search-spaces-list'] = new Array();
    para['sosetup-get-search-spaces-list'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'space_capacity',
                        'validation' : 'integer',
                      }
                    ];



    para['space-booking'] = new Array();
    para['space-booking'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_title',
                        'validation' : 'required',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      },{
                        'key' : 'booking_start_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_end_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_duration',
                        'validation' : 'required|integer',
                      }
                    ];





    para['filter-data'] = new Array();
    para['filter-data'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      }
                    ];

    para['my-meetings'] = new Array();
    para['my-meetings'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      }
                    ];

    para['dashboard-meetings'] = new Array();
    para['dashboard-meetings'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      }
                    ];                


    para['space-meetings'] = new Array();
    para['space-meetings'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      },{
                        'key' : 'start_date',
                        'validation' : 'required|date_format:Y-m-d',
                      },{
                        'key' : 'end_date',
                        'validation' : 'required|date_format:Y-m-d',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      }
                    ];

    para['user-attend-meeting'] = new Array();
    para['user-attend-meeting'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_id',
                        'validation' : 'required',
                      }
                    ];
                    
    para['cancel-meeting'] = new Array();
    para['cancel-meeting'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_id',
                        'validation' : 'required',
                      }
                    ];

    para['hold-extend-meeting'] = new Array();
    para['hold-extend-meeting'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'booking_id',
                        'validation' : 'required',
                      },{
                        'key' : 'action_type',
                        'validation' : 'required|enum:HOLD,EXTEND,RELEASE',
                      },{
                        'key' : 'booking_duration',
                        'validation' : 'required|integer',
                      }
                    ];

    para['space-availibility'] = new Array();
    para['space-availibility'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      }
                    ];

    para['spaces-availibility-entire-day'] = new Array();
    para['spaces-availibility-entire-day'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'available_date',
                        'validation' : 'required',
                      }
                    ];

    para['most-active'] = new Array();
    para['most-active'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      }
                    ];


    para['sensor-check-in-out'] = new Array();
    para['sensor-check-in-out'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      }
                    ];

    para['get-users-list'] = new Array();
    para['get-users-list'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      }
                    ];

    para['get-space-list'] = new Array();
    para['get-space-list'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      }
                    ];

    para['service-request'] = new Array();
    para['service-request'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'page',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'limit',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'severity',
                        'validation' : 'integer',
                      },{
                        'key' : 'current_status',
                        'validation' : 'integer',
                      },{
                        'key' : 'service_ticket_number',
                        'validation' : 'alpha_num',
                      }


                    ];

    para['service-request-add'] = new Array();
    para['service-request-add'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'service_title',
                        'validation' : 'required',
                      },{
                        'key' : 'severity',
                        'validation' : 'required|integer|enum:0,1,2',
                      },{
                        'key' : 'category_name',
                        'validation' : 'required',
                      },{
                        'key' : 'service_due_date',
                        'validation' : 'date_format:Y-m-d',
                      }
                    ];

    para['service-request-edit'] = new Array();
    para['service-request-edit'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'service_request_id',
                        'validation' : 'required',
                      }
                    ];

    para['service-request-update'] = new Array();
    para['service-request-update'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'service_request_id',
                        'validation' : 'required',
                      },{
                        'key' : 'severity',
                        'validation' : 'required|integer|enum:0,1,2',
                      },{
                        'key' : 'service_due_date',
                        'validation' : 'date_format:Y-m-d',
                      },{
                        'key' : 'current_status',
                        'validation' : 'required|integer|enum:0,1,2',
                      }
                    ];

    para['service-request-add-image'] = new Array();
    para['service-request-add-image'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'service_request_id',
                        'validation' : 'required',
                      },{
                        'key' : 'service_request_image',
                        'validation' : 'required',
                      }
                    ];

    para['service-request-get-images'] = new Array();
    para['service-request-get-images'] = [{
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'service_request_id',
                        'validation' : 'required',
                      }
                    ];

    para['add-sensor'] = new Array();
    para['add-sensor'] = [
                      {
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },
                      {
                        'key' : 'sensor_uuid',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_name',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_type',
                        'validation' : 'required|enum:EstimoteBeacon',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_major',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'sensor_minor',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      }];
    para['update-sensor'] = new Array();
    para['update-sensor'] = [
                      {
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'sensor_uuid',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_name',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_type',
                        'validation' : 'required|enum:EstimoteBeacon',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_major',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'sensor_minor',
                        'validation' : 'required|integer',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      },{
                        'key' : 'sensor_id',
                        'validation' : 'required',
                      }];

    para['delete-sensor'] = new Array();
    para['delete-sensor'] = [
                      {
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'sensor_id',
                        'validation' : 'required',
                      }];
    para['sensor-list'] = new Array();
    para['sensor-list'] = [
                      {
                        'key' : 'application_name',
                        'validation' : 'required|enum:SOSETUP,SMARTOFFICE_MOBILE,SMARTOFFICE_TABLET',
                      },{
                        'key' : 'device_type',
                        'validation' : 'required|enum:IOS,ANDROID',
                      },{
                        'key' : 'device_uniq_id',
                        'validation' : 'required',
                      },{
                        'key' : 'device_token',
                        'validation' : 'required',
                      },{
                        'key' : 'os_version',
                        'validation' : 'required',
                      },{
                        'key' : 'app_version',
                        'validation' : 'required',
                      },{
                        'key' : 'request_date',
                        'validation' : 'required|date_format:Y-m-d H:i:s',
                      },{
                        'key' : 'space_id',
                        'validation' : 'required',
                      }];
    callback(para);
  },


  Output: function(req, res, status, statusCode=200, msg, data=Array(), errorMsgList = Array(), newToken="") {

    // console.log('=====================************START***********======================');
    // console.log(status);
    // console.log(msg);
    // console.log(errorMsgList);
    // console.log(data);
    // console.log(newToken);
    // console.log('=====================*************END************======================');


    var returnResponse = {};
    returnResponse.status = status;
    returnResponse.statusCode = statusCode;
    returnResponse.message = msg;
    if(!_.isEmpty(data)){
      returnResponse.data = data;
    }
    if(!_.isEmpty(errorMsgList)){
      returnResponse.error_list = errorMsgList;
    }

    if(!_.isEmpty(newToken)){
      returnResponse.newToken = newToken;
    }
    res.json(returnResponse);

    /*res.json({
        "status": status,
        "statusCode" : statusCode,
        "message": msg,
        "data" : data
    });*/

    return true;
  },

  CheckValidation: function(req, res, next) {

    WS.RequiredParameter(req, res, next, function(para){
          
        var current_request = req.route.path;
        var last_request_para = current_request.substr(current_request.lastIndexOf('/') + 1);

        if(_.has(para, last_request_para)){

            var ErrorMsgList = new Array();

            all_form_fields = req.body;
            var all_validation_rules = para[last_request_para];

            all_validation_rules.forEach(function(value) {

                var field_key = value.key;
                var field_validation = value.validation;

                if(_.has(all_form_fields, field_key)){

                  field_validation_rules = field_validation.split("|");
                  field_validation_rules.forEach(function(rules) {
                  var input_value = all_form_fields[field_key].trim();

                    if(rules == "required"){
                        if(_.isNaN(input_value) ||
                           _.isNull(input_value) ||
                           _.isUndefined(input_value) ||
                           _.isEmpty(input_value)
                          ){
                          ErrorMsgList.push("The "+field_key+" field is required.");
                        }
                    }

                    if(rules == "email"){
                      var email_regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                      if (input_value.search(email_regex) == -1){
                        ErrorMsgList.push("The "+field_key+" must be an email address.");
                      }
                    }

                    if(rules.substr(0, 4) == "enum"){
                        var enum_text = rules.substr(5);
                        var enumArray = enum_text.split(",");
                        if(enumArray.indexOf(input_value) == -1){
                          ErrorMsgList.push("The "+field_key+" field must be given string.");
                        }
                    }

                    if(rules == "integer"){
                      if(input_value != parseInt(input_value)){
                        ErrorMsgList.push("The "+field_key+" must be an integer.");
                      }
                    }

                    if(rules == "float"){
                      if(input_value != parseFloat(input_value)){
                        ErrorMsgList.push("The "+field_key+" must be an float.");
                      }
                    }

                    if(rules == "boolean"){
                      if(parseInt(input_value)==1 || parseInt(input_value)==0){
                      }else{
                        ErrorMsgList.push("The "+field_key+" field must be 1 or 0.");
                      }
                    }

                    if(rules.substr(0, 11) == "date_format"){
                      //var dateformat_regex = /^[0-9]+$/;
                      var dateformat_regex = /^[0-9-: ]+$/;
                      var dateformat_number_regex = /^[0-9]+$/;
                      var dateformat_rules = rules.substr(12);
                      var dateformat_rules_length = dateformat_rules.length;
                      var input_value_length = input_value.length;

                      if (input_value.search(dateformat_regex) == -1){
                        ErrorMsgList.push("The "+field_key+" does not match the format "+dateformat_rules+".");
                      }else{

                        var dateformat_error = 0;

                        if((dateformat_rules_length == 5 && input_value_length == 10) || (dateformat_rules_length == 11 && input_value_length == 19)){
                            var number = 0;
                            dateformat_rules.split('').map(letter => {
                              if(letter == 'Y'){
                                var date_year = input_value.substr(number, 4);
                                if (date_year.search(dateformat_number_regex) == -1){
                                    dateformat_error = 1;
                                }
                                number += 4;
                              }
                              if(letter == 'm'){
                                var date_month = input_value.substr(number, 2);
                                if (date_month.search(dateformat_number_regex) == -1){
                                      dateformat_error = 1;
                                }else{
                                  if(parseInt(date_month) > 12 || parseInt(date_month) <= 0){
                                    dateformat_error = 1;
                                  }
                                }
                                number += 2;
                              }
                              if(letter == 'd'){
                                var date_day = input_value.substr(number, 2);
                                if (date_day.search(dateformat_number_regex) == -1){
                                      dateformat_error = 1;
                                }else{
                                  if(parseInt(date_day) > 31 || parseInt(date_day) <= 0){
                                    dateformat_error = 1;
                                  }
                                }
                                number += 2;
                              }

                              if(letter == 'H'){
                                var date_hour = input_value.substr(number, 2);
                                if (date_hour.search(dateformat_number_regex) == -1){
                                      dateformat_error = 1;
                                }else{
                                  if(parseInt(date_hour) > 23 || parseInt(date_hour) < 0){
                                    dateformat_error = 1;
                                  }
                                }
                                number += 2;
                              }

                              if(letter == 'i'){
                                var date_minute = input_value.substr(number, 2);
                                if (date_minute.search(dateformat_number_regex) == -1){
                                      dateformat_error = 1;
                                }else{
                                  if(parseInt(date_minute) > 59 || parseInt(date_minute) < 0){
                                    dateformat_error = 1;
                                  }
                                }
                                number += 2;
                              }

                              if(letter == 's'){
                                var date_second = input_value.substr(number, 2);
                                if (date_second.search(dateformat_number_regex) == -1){
                                      dateformat_error = 1;
                                }else{
                                  if(parseInt(date_second) > 59 || parseInt(date_second) < 0){
                                    dateformat_error = 1;
                                  }
                                }
                                number += 2;
                              }

                              if(letter == '-'){
                                var date_dash = input_value.substr(number, 1);
                                if (date_dash != '-'){
                                    dateformat_error = 1;
                                }
                                number += 1;
                              }

                              if(letter == ' '){
                                var date_space = input_value.substr(number, 1);
                                if (date_space != ' '){
                                    dateformat_error = 1;
                                }
                                number += 1;
                              }
                              if(letter == ':'){
                                var date_colon = input_value.substr(number, 1);
                                if (date_colon != ':'){
                                    dateformat_error = 1;
                                }
                                number += 1;
                              }
                            });

                            if(dateformat_error == 1){
                              ErrorMsgList.push("The "+field_key+" does not match the format "+dateformat_rules+".");
                            }
                        }else{
                          ErrorMsgList.push("The "+field_key+" does not match the format "+dateformat_rules+".");
                        }

                      }

                    }

                    if(rules == "numeric"){
                      if(input_value != parseFloat(input_value)){
                        ErrorMsgList.push("The "+field_key+" field must be a number.");
                      }
                    }

                    if(rules == "alpha_num"){
                      //var regexp = /^[a-zA-Z0-9-_]+$/;
                      var alpha_num_regex = /^[a-zA-Z0-9]+$/;
                      if (input_value.search(alpha_num_regex) == -1){
                       ErrorMsgList.push("The "+field_key+" may only contain letters and numbers.");
                      }
                    }


                  });
                }else{
                  field_validation_rules = field_validation.split("|");
                  field_validation_rules.forEach(function(rules) {
                    if(rules == "required"){
                      ErrorMsgList.push("The "+field_key+" field is required.");
                    }
                  });
                }
            });
            if(!_.isEmpty(ErrorMsgList)){
              WS.Output(req, res, false, 200, "Woops, Something Went Wrong.",'',ErrorMsgList);
            }else{
              next();
            }

        }else{
          WS.Output(req, res, false, 200, "Validation Error");
        }

       
 
    });

  },


  GetBuildingData: function(req, res, tokenData, AllReturnData,  callback) {
    var company_db_name = tokenData.CompanyData.mycompany;
    var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
    var all_form_fields = req.body;
    var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

    var BuildingQuery  = "";
    BuildingQuery += "SELECT building_id, building_name, no_of_floor, state,city,country,  ";
    BuildingQuery += " CONCAT('"+base_image_url+"building_image/',building_image) as full_building_image, ";
    BuildingQuery += " CONCAT('"+base_image_url+"building_image/80x80/',building_image) as thumb_building_image ";
    BuildingQuery += " FROM "+company_db_name+".so_buildings ";
    BuildingQuery += " WHERE deleted_at IS NULL ";
    BuildingQuery += " ORDER BY building_name";

    connection.query(BuildingQuery, function (error, building_data, fields) {
        if(error){
            //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            AllReturnData['building_data'] = {};
            callback(AllReturnData);
        }
        if(building_data){
            AllReturnData['building_data'] = building_data;
            callback(AllReturnData);
            //WS.Output(req, res, false, 200, "Success.",ReturnData);
        }
    });
  },


  GetFloorData: function(req, res, tokenData, AllReturnData, callback) {
    var company_db_name = tokenData.CompanyData.mycompany;
    var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
    var all_form_fields = req.body;
    var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

    var FloorQuery  = "";
    FloorQuery += "SELECT floor_id, floor_name, floor_no, building_id  ";
    FloorQuery += " FROM "+company_db_name+".so_floors ";
    FloorQuery += " WHERE deleted_at IS NULL ";
    FloorQuery += " ORDER BY floor_name";

    connection.query(FloorQuery, function (error, floor_data, fields) {
        if(error){
            //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            AllReturnData['floor_data'] = {};
            callback(AllReturnData);
        }
        if(floor_data){
            AllReturnData['floor_data'] = floor_data;
            callback(AllReturnData);
            //WS.Output(req, res, false, 200, "Success.",ReturnData);
        }
    });
  },


  GetAmenitiesData: function(req, res, tokenData, AllReturnData, callback) {
    var company_db_name = tokenData.CompanyData.mycompany;
    var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
    var all_form_fields = req.body;
    var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

    var AmenityQuery  = "";
    AmenityQuery += "SELECT amenity_id, amenity_name, ";
    AmenityQuery += " CONCAT('"+base_image_url+"amenities_images/',amenity_image) as full_amenity_image, ";
    AmenityQuery += " CONCAT('"+base_image_url+"amenities_images/80x80/',amenity_image) as thumb_amenity_image ";
    AmenityQuery += " FROM "+company_db_name+".so_amenities ";
    AmenityQuery += " WHERE deleted_at IS NULL ";
    AmenityQuery += " ORDER BY amenity_name";

    connection.query(AmenityQuery, function (error, amenities_data, fields) {
        if(error){
            //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            AllReturnData['amenities_data'] = {};
            callback(AllReturnData);
        }
        if(amenities_data){
            AllReturnData['amenities_data'] = amenities_data;
            callback(AllReturnData);
            //WS.Output(req, res, false, 200, "Success.",ReturnData);
        }
    });
  },

  GetSpaceTypeData: function(req, res, tokenData, AllReturnData, callback) {
    var company_db_name = tokenData.CompanyData.mycompany;
    var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
    var all_form_fields = req.body;
    var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

    var SpaceTypeQuery  = "";
    SpaceTypeQuery += "SELECT space_type_id, space_type_name ";
    SpaceTypeQuery += " FROM "+company_db_name+".so_space_type ";
    SpaceTypeQuery += " WHERE deleted_at IS NULL ";
    SpaceTypeQuery += " ORDER BY space_type_name";


    connection.query(SpaceTypeQuery, function (error, space_type_data, fields) {
        if(error){
            //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            AllReturnData['space_type_data'] = {};
            callback(AllReturnData);
        }
        if(space_type_data){
            AllReturnData['space_type_data'] = space_type_data;
            callback(AllReturnData);
            //WS.Output(req, res, false, 200, "Success.",ReturnData);
        }
    });
  },


};
/* Customization END ASHWIN */

