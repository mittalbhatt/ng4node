global.LANGMSG = {
	"ROUTENOTFOUND" : "Route Not Found",
	"SUCCESS" : "Records fetch successfully.",
	"FAILURE" : "Record found successfully",
	"NOTPERMITTED" : "You are not permitted to perform this action.",
};

/*module.exports = {
    message:message
};*/
