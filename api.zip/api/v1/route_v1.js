var controllers_v1 = {}
var controllers_path_v1 = process.cwd() + '/api/v1/controllers'
fs.readdirSync(controllers_path_v1).forEach(function (file) {
  if (file.indexOf('.js') != -1) {
      controllers_v1[file.split('.')[0]] = require(controllers_path_v1 + '/' + file)
  }
})



var oauthserver = require('oauth2-server');
var oAuthModel = require('../../server/config/oAuthModel');

/* Oauth server setup */
app.oauth = oauthserver({
    model: oAuthModel,
    grants: ['password', 'refresh_token','client_credentials', 'authorization_code'],
    debug: false,
    accessTokenLifetime: oAuthModel.accessTokenLifetime,
    refreshTokenLifetime: oAuthModel.refreshTokenLifetime
});


app.post("/mobileapi/v1/login", multipartMiddleware, WS.CheckValidation, controllers_v1.Login.Login);
app.post("/mobileapi/v1/logout", multipartMiddleware, WS.CheckValidation, controllers_v1.Logout.Logout);
app.post("/mobileapi/v1/forgotpassword", multipartMiddleware, WS.CheckValidation, controllers_v1.ForgotPassword.ForgotPassword);
/*app.post("/mobileapi/v1/get-spaces-list", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.GetSpaceList);*/
app.post("/mobileapi/v1/get-search-spaces-list", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.GetAdvanceSpaceList);
app.post("/mobileapi/v1/space-booking", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.SaveSpaceBooking);

app.post("/mobileapi/v1/filter-data", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.GetFilterData);
app.post("/mobileapi/v1/my-meetings", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.MyMeetings);
app.post("/mobileapi/v1/space-meetings", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.SpaceMeetings);

app.post("/mobileapi/v1/user-attend-meeting", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.UserAttendMeeting);
app.post("/mobileapi/v1/cancel-meeting", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.CancelMeeting);
app.post("/mobileapi/v1/hold-extend-meeting", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.HoldExtendMeeting);
app.post("/mobileapi/v1/space-availibility", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.GetSpaceCheckAvailibility);

app.post("/mobileapi/v1/sensor-check-in-out", multipartMiddleware, WS.CheckValidation, controllers_v1.Sensor.CheckInOut);

// Service-Request
app.post("/mobileapi/v1/service-request", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.ListServiceRequest);
app.post("/mobileapi/v1/service-request-add", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.AddServiceRequest);
app.post("/mobileapi/v1/service-request-edit", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.EditServiceRequest);
app.post("/mobileapi/v1/service-request-update", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.UpdateServiceRequest);
app.post("/mobileapi/v1/service-request-add-image", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.AddServiceRequestImage);
app.post("/mobileapi/v1/service-request-get-images", multipartMiddleware, WS.CheckValidation, controllers_v1.ServiceRequest.GetServiceRequestImage);

// get-users-list
app.post("/mobileapi/v1/get-users-list", multipartMiddleware, WS.CheckValidation, controllers_v1.Users.getUsersList);

// get-users-list
app.post("/mobileapi/v1/get-space-list", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.getSpaceList);

//for dashboard dashlet webservice - start
app.post("/mobileapi/v1/most-active", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.MostActive);
//for dashboard dashlet webservice - end


//SOSetup routes

app.post("/mobileapi/v1/sosetup/login", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.Login);
app.post("/mobileapi/v1/sosetup/sosetup-get-search-spaces-list", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.GetAdvanceSpaceList);
app.post("/mobileapi/v1/sosetup/add-sensor", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.addSensor);
app.post("/mobileapi/v1/sosetup/update-sensor", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.updateSensor);
app.post("/mobileapi/v1/sosetup/delete-sensor", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.deleteSensor);
app.post("/mobileapi/v1/sosetup/sensor-list", multipartMiddleware, WS.CheckValidation, controllers_v1.SOSetup.sensorList);

//END SOSetup routes


// Start - Api for New UI screens
app.post("/mobileapi/v1/dashboard-meetings", multipartMiddleware, WS.CheckValidation, controllers_v1.Meetings.DashboardMeetings);
// End - Api for New UI screens

app.post("/mobileapi/v1/spaces-availibility-entire-day", multipartMiddleware, WS.CheckValidation, controllers_v1.Spaces.GetSpacesAvailibilityEntireDay);