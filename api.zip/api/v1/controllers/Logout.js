var generalConfig = require('../../../server/config/generalConfig');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;


/**
 * @uses (Logout) Logout from device
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/

exports.Logout = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_db_name = tokenData.CompanyData.mycompany;

        var device_uniq_id = req.body.device_uniq_id;
        var user_id = tokenData.UserData.user_id;

            if(company_db_name != null){
                var updateDate = generalConfig.getDateTimeUTC();

                var query = "";
                var query = "UPDATE "+company_db_name+".`so_device_master` AS `Device`"; 
                query += " SET `Device`.`user_id`= NULL, ";
                query += " `Device`.`device_token`= NULL, ";
                query += " `Device`.`updated_at`='"+updateDate+"'";
                query += " WHERE `Device`.`device_uniq_id` = '"+device_uniq_id+"'";
                query += " AND `Device`.`user_id` = '"+user_id+"'";
                
                connection.query(query, function (error, results, fields) {
                    if(error){
                        WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null, [error]);
                    } else if(results){
                        WS.Output(req, res, true, 200, "Logout Success");
                    }
                });
            } else {
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
            }
    });
};
