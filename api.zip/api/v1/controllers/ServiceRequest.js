var generalConfig = require('../../../server/config/generalConfig');
var database = require('../../../server/config/database');
var LANG = require('../../../server/common/language');
var message = LANG.msg;
var getObjectDiff = require('object-diff');
var upload = require('../../../server/config/upload');

var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;

var dateFormat = require('dateformat');


exports.ListServiceRequest = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var domain = generalConfig.getDomain(req);
        var imagePathObj = generalConfig.getFilePath(domain, "serviceRequest", "main", "sub");
        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;
        var time_difference = tokenData.UserData.time_difference;
        if(time_difference == "" || time_difference == null){
            time_difference = '+00:00';
        }

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;
        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }        

        var query = "SELECT sr.service_request_id, sr.service_title,sr.special_instruction, ";
        query += " sr.service_ticket_number,  DATE_FORMAT(sr.service_due_date, '%m/%d/%Y') AS service_due_date, ";
        query += " sr.space_id, sr.space_name, sr.category_name, sr.severity, sr.current_status, ";
        query += " sr.created_by, ";
        query += " CONCAT(createdBy.first_name,' ',createdBy.last_name) as created_user_name, ";
        query += " sr.assigned_user_id, ";
        query += " CONCAT(assignedBy.first_name,' ',assignedBy.last_name) as assigned_user_name, ";
        query += " DATE_FORMAT(CONVERT_TZ(sr.created_at,'+00:00','"+time_difference+"'),'%d %b, %Y | %k:%i %p') as display_created_at, ";
        query += " DATE_FORMAT(CONVERT_TZ(sr.updated_at,'+00:00','"+time_difference+"'),'%d %b, %Y | %k:%i %p') as display_updated_at ";

        query += " FROM "+company_db_name+".so_service_requests AS sr ";
        query += " LEFT JOIN smartoffice_master.so_users AS createdBy ON createdBy.user_id = sr.created_by ";
        query += " LEFT JOIN smartoffice_master.so_users AS assignedBy ON assignedBy.user_id = sr.assigned_user_id ";
        query += " WHERE sr.status=1 and sr.deleted_at IS NULL";

        if(all_form_fields.category_name && all_form_fields.category_name != ""){
            query += " AND sr.category_name LIKE '%"+all_form_fields.category_name+"%'";
        }
        if(all_form_fields.space_name && all_form_fields.space_name != ""){
            query += " AND sr.space_name LIKE '%"+all_form_fields.space_name+"%'";
        }
        if(all_form_fields.service_title && all_form_fields.service_title != ""){
            query += " AND sr.service_title LIKE '%"+all_form_fields.service_title+"%'";
        }
        if(all_form_fields.service_ticket_number && all_form_fields.service_ticket_number != ""){
            query += " AND sr.service_ticket_number LIKE '%"+all_form_fields.service_ticket_number+"%'";
        }
        if(all_form_fields.severity && all_form_fields.severity != ""){
            query += " AND sr.severity = "+all_form_fields.severity+"";
        }
        if(all_form_fields.current_status && all_form_fields.current_status != ""){
            query += " AND sr.current_status = "+all_form_fields.current_status+"";
        }
        if(all_form_fields.created_by && all_form_fields.created_by != ""){
            query += " AND sr.created_by = "+all_form_fields.created_by+"";
        }
        if(all_form_fields.assigned_user_id && all_form_fields.assigned_user_id != ""){
            query += " AND sr.assigned_user_id = "+all_form_fields.assigned_user_id+"";
        }

        query += " ORDER BY sr.created_at DESC limit "+start+","+limit;



        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){                    
                    var counter = 0;                    
                    results.forEach(function(rValue)
                    {                        
                        var getImages = "SELECT image_name FROM `"+company_db_name+"`.`so_service_request_images` WHERE `service_request_id` = '"+rValue.service_request_id+"'";
                        connection.query(getImages, function (error, getImageResult, fields)
                        {
                            if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }
                            if(getImageResult)
                            {                     
                                getImageResult.forEach(function(val){
                                    if(val.image_name != ""){
                                        var path = imagePathObj.mainLink+'/'+val.image_name;
                                        if(!generalConfig.checkFilePath(path)){
                                           val.image_name = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+"/"+generalConfig.no_image_200;
                                        }else{
                                           val.image_name = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+"/"+generalConfig.imageUrl(path);
                                        }
                                    } else {
                                        val.image_name = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+"/"+generalConfig.no_image_200;
                                    }
                                });

                                counter++;
                                rValue.images = getImageResult;                               
                                if(counter == results.length)
                                {
                                    return WS.Output(req, res, true, 200, "Success", results);
                                }
                            }                               
                        });
                    })
                }
                else
                {
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });
    });
}

exports.AddServiceRequest = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {
        
        // var time_difference = tokenData.UserData.time_difference;
        // if(time_difference == "" || time_difference == null)
        // {
        //     time_difference = '+00:00';
        // }

        var company_databasename = tokenData.CompanyData.mycompany;
        var user_id = tokenData.UserData.user_id;
        var now = new Date();
        var createDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
        var GUID = generalConfig.generateGUID();

        var service_title = (req.body.service_title)?req.body.service_title:'';
        var service_due_date = (req.body.service_due_date) ? moment(req.body.service_due_date, "YYYY-MM-DD").format('YYYY-MM-DD') : createDate;
        var assigned_user_id = (req.body.assigned_user_id)?req.body.assigned_user_id:'';
        var space_id = (req.body.space_id)?req.body.space_id:'';
        var space_name = (req.body.space_name)?req.body.space_name:'';
        var current_status = (req.body.current_status)?req.body.current_status:1;
        var severity = (req.body.severity)?req.body.severity:'';
        var category_name = (req.body.category_name)?req.body.category_name:'';
        var special_instruction = (req.body.special_instruction)?req.body.special_instruction:'';
        var status = (req.body.status)?req.body.status:1;

        // specified category
        if(!['Administration','Housekeeping','Access Controls','Network & Communication','Others'].includes(category_name))
        {
            return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,['Invalid Category']);
        }

        var query = "SELECT `SR`.`service_ticket_number` FROM "+company_databasename+".`so_service_requests` AS `SR` ORDER BY `SR`.`created_at`  DESC LIMIT 1";
        connection.query(query, function (error, results, fields)
        {
            if(error){ WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]); }

            if(results.length > 0){
                var lastTicketNum = results[0].service_ticket_number;;
                if(lastTicketNum){
                   var  split_number = lastTicketNum.replace(/[a-zA-Z]+/, '');
                   var newTicketNum = (parseInt(split_number) + 1);
                   newTicketNum = generalConfig.ticketTag+newTicketNum;
                }
            } else {
                var newTicketNum = generalConfig.ticketTag+10000;
            }

            var service_ticket_number = (newTicketNum)?newTicketNum:'';                    
            var created_by            = (user_id)?user_id:'';
            var created_at            = createDate;                    

                var insert = "INSERT INTO "+company_databasename+".`so_service_requests` (`service_request_id`, `service_title`, `special_instruction`, `service_ticket_number`, `service_due_date`, `space_id`, `space_name`, `created_by`, `assigned_user_id`, `category_name`, `severity`, `current_status`, `status`, `created_at`, `updated_at` ) VALUES ('"+GUID+"', '"+service_title+"', '"+special_instruction+"', '"+service_ticket_number+"', '"+service_due_date+"', '"+space_id+"', '"+space_name+"','"+created_by+"', '"+assigned_user_id+"', '"+category_name+"', '"+severity+"', "+current_status+", "+status+", '"+created_at+"', '"+created_at+"')";

                connection.query(insert, function (error, results, fields) {
                    if(error){ WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]); }
                
                    if(results){
                        
                        var GUID2 = generalConfig.generateGUID();
                        var query = "INSERT INTO "+company_databasename+".`so_service_request_status` (`service_request_status_id`,`service_request_id`,`current_status`,`service_due_date`,`severity`,`special_instruction`,`created_by`,`assigned_user_id`,`created_at`, `updated_at` ) VALUES ('"+GUID2+"', '"+GUID+"', '"+current_status+"', '"+service_due_date+"', '"+severity+"', '"+special_instruction+"','"+created_by+"', '"+assigned_user_id+"', '"+created_at+"', '"+created_at+"')";
                        connection.query(query, function (error, results, fields) {
                            if(error){ WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]); }
                            else
                            {
                                WS.Output(req, res, true, 200, "Success",{'service_request_id':GUID});
                            }
                        });
                    }
                });
        });

        

    });
}

exports.EditServiceRequest = function(req, res, next){

    WS.CheckJWTToken(req, res, function(tokenData) {
        
        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var domain = generalConfig.getDomain(req);
        var user_id = tokenData.UserData.user_id;
        var service_request_id = req.body.service_request_id;
        
        var imagePathObj = generalConfig.getFilePath(domain, "space", "main", "sub");
        var imgProfileImage = generalConfig.getFilePath(domain, "user", "main", "sub");                

        if(company_databasename != null)
        {
            var query = "SELECT `S`.space_name, `S`.space_image, DATE_FORMAT(`SR`.`created_at`, '%d %b, %Y | %k:%i %p') AS createdAt, CONCAT(`SU`.first_name,' ',`SU`.last_name) as userName ,DATE_FORMAT(`SR`.`service_due_date`,  '%c/%d/%Y') AS service_due_date, DATE_FORMAT(`SR`.`service_due_date`, '%d %b, %Y') AS displayDueDate, `SR`.service_request_id,`SR`.service_title,`SR`.special_instruction,`SR`.service_ticket_number,`SR`.space_id,`SR`.space_name,`SR`.created_by,`SR`.assigned_user_id,`SR`.category_name,`SR`.severity,`SR`.current_status,`SR`.status,`SR`.created_at,`SR`.updated_at,`SR`.deleted_at  FROM "+company_databasename+".`so_service_requests` AS `SR` LEFT JOIN "+company_databasename+".`so_spaces` AS `S` ON `SR`.space_id = `S`.space_id LEFT JOIN `"+master_database+"`.`so_users` AS `SU` ON ``.`SR`.created_by = `SU`.user_id WHERE `SR`.service_request_id = '"+service_request_id+"'";
            connection.query(query, function (error, results, fields) {
                
                if(error)
                {
                    return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]);
                }
                else if(results && results!='')
                {
                    results.forEach(function(val){
                        if(val.space_image != ""){
                            var path = imagePathObj.mainLink+'/'+val.space_image;
                            if(!generalConfig.checkFilePath(path)){
                               val.space_image = generalConfig.no_image_200;
                            }else{
                               val.space_image = generalConfig.imageUrl(path);
                            }
                        } else {
                            val.space_image = generalConfig.no_image_200;
                        }
                    });

                    if(results[0].userName){
                        userName = results[0].userName;
                        results[0].userName = userName.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()});
                    }
                    return WS.Output(req, res, true, 200, "Success",results[0]);                        
                }
                else
                {
                    return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.NOT_FOUND]);
                }
            });                
        }
        else
        {           
            return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]);
        }        
    });

}

exports.UpdateServiceRequest = function(req, res, next){
    
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var domain = generalConfig.getDomain(req);
        var user_id = tokenData.UserData.user_id;    
        var service_request_id = req.body.service_request_id;
        var now = new Date();
        var createDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
            
        var postData = {};
        postData.service_due_date = (req.body.service_due_date) ? moment(req.body.service_due_date, "YYYY-MM-DD").format('MM/DD/YYYY') : createDate;
        postData.assigned_user_id = (req.body.assigned_user_id)?req.body.assigned_user_id:'';
        postData.current_status = parseInt(req.body.current_status);
        postData.severity = parseInt(req.body.severity);
        postData.special_instruction = (req.body.special_instruction)?req.body.special_instruction:'';

        var service_due_date = (req.body.service_due_date) ? moment(req.body.service_due_date, "YYYY-MM-DD").format('YYYY-MM-DD') : createDate;
        var assigned_user_id = (req.body.assigned_user_id)?req.body.assigned_user_id:'';
        var current_status = req.body.current_status;
        var severity = (req.body.severity)?req.body.severity:'';    
        var special_instruction = (req.body.special_instruction)?req.body.special_instruction:'';
        
        var updatedDate = generalConfig.getDateTimeUTC();
        var created_by = (user_id)?user_id:'';

        // Local Validation
        // if current status is Assigne then there should be select Assigned User
        if(current_status==2 && assigned_user_id=='')
        {
            return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,['Please select assignee']);
        }

        if(company_databasename != null)
        {
            var selectRow = "SELECT DATE_FORMAT(`service_due_date`, '%c/%d/%Y') AS service_due_date, assigned_user_id, current_status, special_instruction, severity FROM "+company_databasename+".`so_service_requests` WHERE `service_request_id` = '"+service_request_id+"'";
            connection.query(selectRow, function (error, results, fields) {
                if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }
                if(results && results!='')
                {
                    var postDiff = getObjectDiff(results[0], postData);
                    
                    if(Object.keys(postDiff).length)
                    {
                        var query = "UPDATE "+company_databasename+".`so_service_requests` SET `service_due_date`='"+service_due_date+"',`assigned_user_id`='"+assigned_user_id+"',`current_status`='"+current_status+"', `severity`='"+severity+"', `special_instruction`='"+special_instruction+"', `updated_at`='"+updatedDate+"' WHERE `service_request_id` = '"+service_request_id+"'";
                        connection.query(query, function (error, results, fields) {                    
                            if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }
                            if(results){
                                if(results.affectedRows > 0){
                                    var GUID = generalConfig.generateGUID();
                                    var serviceStatus = "INSERT INTO "+company_databasename+".`so_service_request_status` ( `service_request_status_id`, `service_request_id`, `current_status`, `service_due_date`, `severity`, `special_instruction`, `created_by`, `assigned_user_id`, `created_at`, `updated_at` ) VALUES ( '"+GUID+"', '"+service_request_id+"', "+current_status+", '"+service_due_date+"', '"+severity+"', '"+special_instruction+"','"+created_by+"', '"+assigned_user_id+"', '"+updatedDate+"', '"+updatedDate+"')";
                                    
                                    connection.query(serviceStatus, function (error, results, fields) {
                                        if(error){
                                            return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]);
                                        }
                                        if(results){
                                            return WS.Output(req, res, true, 200, "Success",[message.SERVICE_UPDATE]);
                                        }
                                    });
                                }
                            }
                        });
                    }
                    else
                    {                            
                        return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.NO_UPDATES_SUBMITTED]);
                    }
                }
                else
                {
                    return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.NOT_FOUND]);
                }
            });
            // ----- STOP : update operation only any updates submitted
        }
        else
        {
            return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); 
        }      
        
    });
}

exports.AddServiceRequestImage = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_databasename = tokenData.CompanyData.mycompany;
        var user_id = tokenData.UserData.user_id;
        var now = new Date();
        var createDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
        var GUID = generalConfig.generateGUID();        

        var service_request_id = req.body.service_request_id;
        var service_request_image = req.body.service_request_image;

        // validate service request id
        var findServiceRequestId = "SELECT * FROM `"+company_databasename+"`.`so_service_requests` WHERE `service_request_id` = '"+service_request_id+"'";
        connection.query(findServiceRequestId, function (error, results, fields)
        {            
            if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }

            if(results && results!="")
            {
                var new_file_name = "";
                var created_at = generalConfig.getDateTimeUTC();
                var doamin = generalConfig.getDomain(req);
                var base64Image = req.body.service_request_image;
                var filename = "test.jpg";
                var resObj = upload.uploadImage(doamin, "serviceRequest", base64Image, filename, "", "", "");
                if(resObj.success == true)
                {                    
                    new_file_name = resObj.file_name;                    
                    var saveImage = "INSERT INTO  "+company_databasename+".`so_service_request_images` (`image_id` ,`service_request_id` , `image_name` ,`status` ,`created_at` ,`updated_at` , `deleted_at`) VALUES ( '"+GUID+"', '"+service_request_id+"', '"+new_file_name+"', '1',  '"+created_at+"',  '"+created_at+"', NULL )";
                    connection.query(saveImage, function (error, saveImageResult, fields)
                    {
                        if(saveImageResult)
                        {
                            WS.Output(req, res, true, 200, "Success","image upload success");                            
                        }                               
                    });

                } else {
                    
                    return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,["Not Upload"]);
                }
            }
            else
            {
                return WS.Output(req, res, false, 404, message.NOT_FOUND,null,[]);
            }
        });
    });
}

exports.GetServiceRequestImage = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_databasename = tokenData.CompanyData.mycompany;
        var service_request_id = req.body.service_request_id;
        var domain = generalConfig.getDomain(req);
        var imagePathObj = generalConfig.getFilePath(domain, "serviceRequest", "main", "sub");

        // validate service request id
        var findServiceRequestId = "SELECT * FROM `"+company_databasename+"`.`so_service_requests` WHERE `service_request_id` = '"+service_request_id+"'";
        connection.query(findServiceRequestId, function (error, results, fields)
        {            
            if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }

            if(results && results!="")
            {
                var getImages = "SELECT image_name FROM `"+company_databasename+"`.`so_service_request_images` WHERE `service_request_id` = '"+service_request_id+"'";
                connection.query(getImages, function (error, getImageResult, fields)
                {
                    if(error){ return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]); }
                    if(getImageResult)
                    {                     
                        getImageResult.forEach(function(val){
                            if(val.image_name != ""){
                                var path = imagePathObj.mainLink+'/'+val.image_name;
                                if(!generalConfig.checkFilePath(path)){
                                   val.image_name = generalConfig.no_image_200;
                                }else{
                                   val.image_name = generalConfig.imageUrl(path);
                                }
                            } else {
                                val.image_name = generalConfig.no_image_200;
                            }
                        });       
                        return WS.Output(req, res, true, 200, "Success",[getImageResult]);
                    }                               
                });                                
            }
            else
            {
                return WS.Output(req, res, false, 404, message.NOT_FOUND,null,[]);
            }
        });
    });
}