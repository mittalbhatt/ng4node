var passport = require('passport');
var moment = require('moment');
var jwt = require('jwt-simple');
var generalConfig = require('../../../server/config/generalConfig');

var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;


/**
 * @uses login for sosetup app
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
 */
exports.Login = function(req, res, next) {

    passport.authenticate('local', function(err, user, info) {
        if (err) {
            WS.Output(req, res, false, 401, err.message, null,[err.message]);
            return true;
        }
        if (!user) {
            WS.Output(req, res, false, 401, info.message);
            return true;
        }else{
            var query = "SELECT c.company_id, company_name, company_logo, timezone, time_difference, company_domain_prefix, company_db_name, um.user_type FROM `so_company_users_map` um LEFT JOIN so_company_master AS c ON c.company_id = um.`company_id` WHERE um.user_id = '"+user.dataValues.user_id+"' AND (um.user_type = 'SubAdmin' OR um.user_type = 'CompanyAdmin' )";
          
            connection.query(query, function (error, results, fields) {

                if(error){
                    WS.Output(req, res, false, 401, err.message, null,[error.message]);
                    return true;
                }

                var tokenUser = {};
                tokenUser.user_id = user.dataValues.user_id;
                tokenUser.first_name = user.dataValues.first_name;
                tokenUser.last_name = user.dataValues.last_name;
                tokenUser.email = user.dataValues.email;
                tokenUser.phone_number = user.dataValues.phone_number;
                tokenUser.timezone = user.dataValues.timezone;
                tokenUser.time_difference = user.dataValues.time_difference;
                tokenUser.profile_picture = user.dataValues.profile_picture;

                if(results.length > 0){
                    if(results[0]['company_db_name']){

                        var base_image_url = process.env.HTTP_PATH+results[0]['company_domain_prefix']+'.'+process.env.BASE_URL+'/images/uploads/'+results[0]['company_domain_prefix'];
                        tokenUser.profile_picture = base_image_url+'/user_image/80x80/'+user.dataValues.profile_picture;

                        var tokenCompanyData = {};
                        tokenCompanyData.company_id = results[0]['company_id'];
                        tokenCompanyData.company_name = results[0]['company_name'];
                        tokenCompanyData.timezone = results[0]['timezone'];
                        tokenCompanyData.time_difference = results[0]['time_difference'];
                        tokenCompanyData.company_domain_prefix = results[0]['company_domain_prefix'];
                        tokenCompanyData.mycompany = results[0]['company_db_name'];
                        tokenCompanyData.company_logo = base_image_url+'/company_logo/80x80/'+results[0]['company_logo'];

                        if(results[0]['company_db_name'] != ""){
                        var config_query = "SELECT config_title,config_value ";
                        config_query += " FROM "+results[0]['company_db_name']+".so_configuration ";
                        config_query += " WHERE config_type = 'SOSETUP' OR config_type = 'SENSOR'";

                        connection.query(config_query, function (error, configData, fields) {
                            if(error){
                            WS.Output(req, res, false, 401, error.message, null,[error.message]);
                            return true;
                            }

                            if(configData.length > 0){
                            var configDataArray = {};
                            configData.forEach(function(value) {
                                configDataArray[value.config_title] = value.config_value;
                            });

                            var expireDate = moment().add(1, 'hours').valueOf();
                            var token = jwt.encode({
                                UserData: tokenUser,
                                CompanyData : tokenCompanyData,
                                ConfigData : configDataArray,
                                exp: expireDate
                            }, secretKey);
                            var tokenArray = { 'token' : token, UserData: tokenUser, CompanyData : tokenCompanyData, ConfigData : configDataArray};
                            WS.Output(req, res, true, 200, 'Login success',tokenArray);

                            }else{
                            WS.Output(req, res, false, 401, "No Data found...", null,["No Data found..."]);
                            }
                        });

                        }else{
                        WS.Output(req, res, false, 401, "No Data found...", null,["No Data found..."]);
                        }


                    }else{
                        WS.Output(req, res, false, 401, "No Data found...", null,["No Data found..."]);
                    }
                }else{
                    WS.Output(req, res, false, 401, "No access for this portal...", null,["No access for this portal..."]);
                }
            });
        }
    })(req, res);

    return false;

}

/**
 * @uses get space listing data
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
 */
exports.GetAdvanceSpaceList = function (req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';
        var all_form_fields = req.body;

        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var query  = "";
        query += "SELECT flr.floor_id, flr.floor_name, flr.floor_no, b.building_name, b.building_id, ";
        query += " s.space_id, space_name, space_capacity, space_notes, ss.space_type_id, ss.space_type_name, ";
        query += " space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/',space_image) as full_space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/80x80/',space_image) as thumb_space_image, ";

        query += " ( ";
        query += " SELECT ";
        //query += " GROUP_CONCAT(sub_a.amenity_name) AS amenity_names, ";
        query += " GROUP_CONCAT(CONCAT('"+base_image_url+"amenities_images/',sub_a.amenity_image)) as amenity_images ";
        query += " FROM "+company_db_name+".so_space_amenities AS sub_sa ";
        query += " LEFT JOIN "+company_db_name+".so_amenities AS sub_a ON sub_a.amenity_id = sub_sa.amenity_id";
        query += " WHERE sub_sa.space_id = s.space_id";
        query += " ) AS amenity_images ";

        query += " FROM "+company_db_name+".so_spaces AS s ";
        query += " LEFT JOIN "+company_db_name+".so_floors AS flr ON flr.floor_id = s.floor_id ";
        query += " LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = flr.building_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_amenities AS sa ON sa.space_id = s.space_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_type AS ss ON ss.space_type_id = s.space_type_id ";

        query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";

        if(all_form_fields.building_id && all_form_fields.building_id != ""){
            query += " AND b.building_id = '"+all_form_fields.building_id+"'";
        }
        if(all_form_fields.floor_id && all_form_fields.floor_id != ""){
            query += " AND flr.floor_id = '"+all_form_fields.floor_id+"'";
        }
        if(all_form_fields.space_type_id && all_form_fields.space_type_id != ""){
            query += " AND ss.space_type_id = '"+all_form_fields.space_type_id+"'";
        }
        if(all_form_fields.amenity_id && all_form_fields.amenity_id != ""){
            var amenity_idString = all_form_fields.amenity_id.toString();
            var amenity_id = amenity_idString.replace(/,/g, "','");
            query += " AND sa.amenity_id IN ('"+amenity_id+"')";
        }
        if(all_form_fields.space_capacity && all_form_fields.space_capacity != ""){
            query += " AND s.space_capacity >= '"+all_form_fields.space_capacity+"'";
        }

        query += "GROUP BY s.space_id ORDER BY s.space_name limit "+start+","+limit;

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, error,null,[error]);
            }
            if(results){
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });
    });
};


/**
 * @uses (addSensor) insert new sensor data
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/
exports.addSensor = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_db_name = tokenData.CompanyData.mycompany;
        var sensor_company = req.body.sensor_company;
        var sensor_name = req.body.sensor_name;
        var sensor_type = req.body.sensor_type;
        var sensor_uuid = req.body.sensor_uuid;
        var sensor_major = req.body.sensor_major;
        var sensor_minor = req.body.sensor_minor;
        var space_id = req.body.space_id;
        var status = 1;

        var createDate = generalConfig.getDateTimeUTC();
            if(company_db_name != null){
                var sensor_check_query = "SELECT `sensor_major`, `sensor_minor` from "+company_db_name+".`so_sensor_master` AS Sensor";
                sensor_check_query += " WHERE `Sensor`.`sensor_major` = '"+sensor_major+"' ";
                sensor_check_query += " AND `Sensor`.`sensor_minor` = '"+sensor_minor+"'";
                sensor_check_query += " AND `Sensor`.`deleted_at` IS NULL";
                
                connection.query(sensor_check_query, function (error, sensor, fields) {
                    if(sensor.length > 0){
                        WS.Output(req, res, false, 200, "Sensor already in use with another space.", null, ['Sensor already in use with another space']);
                    }
                    else {
                        var space_query = "SELECT `space_id` from "+company_db_name+".`so_spaces` AS Space WHERE `Space`.`space_id` = '"+space_id+"'";
              
                        connection.query(space_query, function (error, space, fields) {
                            if(space.length > 0){
                                var createDate = generalConfig.getDateTimeUTC();
                                var GUID = generalConfig.generateGUID();

                                sensor_company  = sensor_company ? sensor_company : '';
                                sensor_name     = sensor_name ? sensor_name : '';
                                sensor_type     = sensor_type ? sensor_type : '';
                                sensor_uuid     = sensor_uuid ? sensor_uuid : '';
                                sensor_major    = sensor_major ? sensor_major : '';
                                sensor_minor    = sensor_minor ? sensor_minor : '';
                                space_id        = space_id ? space_id : '';

                                var query = "";
                                query += " INSERT INTO "+company_db_name+".`so_sensor_master`";
                                query += " (`sensor_id`,`sensor_company`, `sensor_name`, `sensor_type`, `sensor_uuid`, `sensor_major`, `sensor_minor`, `space_id`, `status`, `created_at`, `updated_at`) VALUES";
                                query += " ('"+GUID+"', '"+sensor_company+"', '"+sensor_name+"', '"+sensor_type+"', '"+sensor_uuid+"', '"+sensor_major+"', '"+sensor_minor+"', '"+space_id+"', '"+status+"', '"+createDate+"', '"+createDate+"')";

                                connection.query(query, function (error, results, fields) {
                                    if(error){
                                        WS.Output(req, res, false, 401, error, error);
                                    } else if(results){
                                        WS.Output(req, res, true, 200, "Sensor added successfully");
                                    }
                                });
                            }
                            else {
                                WS.Output(req, res, false, 200, "Please give valid space.", null, ['Please give valid space']);
                            }
                        });
                    }
                });
            } else {
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
            }
    });
};

/**
 * @uses (updateSensor) update sensor data
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/
exports.updateSensor = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_db_name = tokenData.CompanyData.mycompany;

        var sensor_id = req.body.sensor_id;
        var sensor_company = req.body.sensor_company;
        var sensor_name = req.body.sensor_name;
        var sensor_type = req.body.sensor_type;
        var sensor_uuid = req.body.sensor_uuid;
        var sensor_major = req.body.sensor_major;
        var sensor_minor = req.body.sensor_minor;
        var space_id = req.body.space_id;
        var status = 1;

            if(company_db_name != null){
                var sensor_check_query = "SELECT `sensor_major`, `sensor_minor` from "+company_db_name+".`so_sensor_master` AS Sensor";
                sensor_check_query += " WHERE `Sensor`.`sensor_major` = '"+sensor_major+"' ";
                sensor_check_query += " AND `Sensor`.`sensor_minor` = '"+sensor_minor+"'";
                sensor_check_query += " AND `Sensor`.`sensor_id` != '"+sensor_id+"'";
                sensor_check_query += " AND `Sensor`.`deleted_at` IS NULL";
                
                connection.query(sensor_check_query, function (error, sensor, fields) {
                    if(sensor.length > 0){
                        WS.Output(req, res, false, 200, "Sensor already in use with another space.", null, ['Sensor already in use with another space']);
                    }
                    else {
                        var space_query = "SELECT `space_id` from "+company_db_name+".`so_spaces` AS Space WHERE `Space`.`space_id` = '"+space_id+"'";
                    
                        connection.query(space_query, function (error, space, fields) {
                            if(space.length > 0){
                                var updateDate = generalConfig.getDateTimeUTC();

                                sensor_company  = sensor_company ? sensor_company : '';
                                sensor_name     = sensor_name ? sensor_name : '';
                                sensor_type     = sensor_type ? sensor_type : '';
                                sensor_uuid     = sensor_uuid ? sensor_uuid : '';
                                sensor_major    = sensor_major ? sensor_major : '';
                                sensor_minor    = sensor_minor ? sensor_minor : '';
                                space_id        = space_id ? space_id : '';

                                var query = "";
                                var query = "UPDATE "+company_db_name+".`so_sensor_master` AS `Sensor`"; 
                                query += " SET `Sensor`.`sensor_name`='"+sensor_name+"', ";
                                query += " `Sensor`.`sensor_company`='"+sensor_company+"', ";
                                query += " `Sensor`.`sensor_type`='"+sensor_type+"', ";
                                query += " `Sensor`.`sensor_uuid`='"+sensor_uuid+"', ";
                                query += " `Sensor`.`sensor_major`='"+sensor_major+"', ";
                                query += " `Sensor`.`sensor_minor`='"+sensor_minor+"', ";
                                query += " `Sensor`.`space_id`='"+space_id+"', ";
                                query += " `Sensor`.`status`='"+status+"', ";
                                query += " `Sensor`.`updated_at`='"+updateDate+"' WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";


                                connection.query(query, function (error, results, fields) {
                                    if(error){
                                        WS.Output(req, res, false, 401, error, null,[error]);
                                    } else if(results){
                                        WS.Output(req, res, true, 200, "Sensor updated successfully");
                                    }
                                });
                            } else {
                                WS.Output(req, res, false, 200, "Please give valid space.", null, ['Please give valid space']);
                            }
                        });
                    }
                });
            } else {
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
            }
    });
};

/**
 * @uses (deleteSensor) delete sensor data
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/
exports.deleteSensor = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_db_name = tokenData.CompanyData.mycompany;

        var sensor_id = req.body.sensor_id;
        var deleteDate = generalConfig.getDateTimeUTC();

            if(company_db_name != null){

                var query = "UPDATE "+company_db_name+".`so_sensor_master` AS `Sensor` SET `Sensor`.`deleted_at`='"+deleteDate+"' WHERE `Sensor`.`sensor_id` = '"+sensor_id+"'";


                connection.query(query, function (error, results, fields) {
                    if(error){
                        WS.Output(req, res, false, 401, error, null,[error]);
                    } else if(results){
                        WS.Output(req, res, true, 200, "Sensor deleted successfully");
                    }
                });
            } else {
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
            }
    });
};

/**
 * @uses (deviceList) Get Device List of selected space 
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/

exports.sensorList = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_db_name = tokenData.CompanyData.mycompany;

        var space_id = req.body.space_id;

            if(company_db_name != null){

                var query = "";
                query += " SELECT `Sensor`.`sensor_id`, `Sensor`.`sensor_name`, `Sensor`.`sensor_type`, `Sensor`.`sensor_uuid`, ";
                query += " `Sensor`.`sensor_major`, `Sensor`.`sensor_minor`, `Sensor`.`status`, `Sensor`.`sensor_company`, "
                query += " `Sensor`.`created_at` AS `createdAt`, `Sensor`.`updated_at` AS `updatedAt`, `Sensor`.`deleted_at`, ";
                query += " `Space`.`space_id` AS `space_id`, `Space`.`space_name` AS `space_name`,";
                query += " `Floor`.`floor_name` AS `floor_name`, `Building`.`building_name` AS `building_name`";
                query += " FROM "+company_db_name+".`so_sensor_master` AS `Sensor` LEFT OUTER JOIN "+company_db_name+" .`so_spaces` AS `Space`";
                query += " ON `Sensor`.`space_id` = `Space`.`space_id`";
                query += " LEFT OUTER JOIN "+company_db_name+" .`so_floors` AS `Floor`";
                query += " ON `Space`.`floor_id` = `Floor`.`floor_id`";
                query += " LEFT OUTER JOIN "+company_db_name+" .`so_buildings` AS `Building`";
                query += " ON `Floor`.`building_id` = `Building`.`building_id`";
                query += " WHERE `Sensor`.`deleted_at` IS NULL";
               
                query += " AND `Sensor`.`space_id` = '"+ space_id +"'";
               
                connection.query(query, function (error, results, fields) {
                    if(error){
                        WS.Output(req, res, false, 401, error, null, [error]);
                    } else if(results){
                        WS.Output(req, res, true, 200, "Success", results);
                    }
                });
            } else {
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
            }
    });
};

