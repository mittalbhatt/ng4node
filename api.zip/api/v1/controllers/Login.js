var passport = require('passport');
var moment = require('moment');
var jwt = require('jwt-simple');
var generalConfig = require('../../../server/config/generalConfig');

var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;

exports.Login = function(req, res, next) {
    passport.authenticate('local', function(err, user, info) {
      if (err) {
        WS.Output(req, res, false, 200, /*"Woops, Something Went Wrong."*/ err.message, null,[err.message]);
        return true;
      }
      if (!user) {
        WS.Output(req, res, false, 401, info.message);
        return true;
      }else{    

        var query = "SELECT c.company_id, company_name, company_logo, timezone, time_difference, company_domain_prefix, company_db_name FROM `so_company_users_map` um LEFT JOIN so_company_master AS c ON c.company_id = um.`company_id` WHERE um.user_id = '"+user.dataValues.user_id+"'";
        connection.query(query, function (error, results, fields) {
          if(error){
            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,[error.message]);
            return true;
          }
          
          var tokenUser = {};
          tokenUser.user_id = user.dataValues.user_id;
          tokenUser.first_name = user.dataValues.first_name;
          tokenUser.last_name = user.dataValues.last_name;
          tokenUser.email = user.dataValues.email;
          tokenUser.phone_number = user.dataValues.phone_number;
          tokenUser.timezone = user.dataValues.timezone;
          tokenUser.time_difference = user.dataValues.time_difference;
          tokenUser.profile_picture = user.dataValues.profile_picture;

          if(results.length > 0){
            if(results[0]['company_db_name']){

                var base_image_url = process.env.HTTP_PATH+results[0]['company_domain_prefix']+'.'+process.env.BASE_URL+'/images/uploads/'+results[0]['company_domain_prefix'];
                tokenUser.profile_picture = base_image_url+'/user_image/80x80/'+user.dataValues.profile_picture;

                var tokenCompanyData = {};
                tokenCompanyData.company_id = results[0]['company_id'];
                tokenCompanyData.company_name = results[0]['company_name'];
                tokenCompanyData.timezone = results[0]['timezone'];
                tokenCompanyData.time_difference = results[0]['time_difference'];
                tokenCompanyData.company_domain_prefix = results[0]['company_domain_prefix'];
                tokenCompanyData.mycompany = results[0]['company_db_name'];
                tokenCompanyData.company_logo = base_image_url+'/company_logo/80x80/'+results[0]['company_logo'];

                if(results[0]['company_db_name'] != ""){
                  var config_query = "SELECT config_title,config_value ";
                  config_query += " FROM "+results[0]['company_db_name']+".so_configuration ";
                  config_query += " WHERE config_type = 'SOSETUP' OR config_type = 'SENSOR'";

                  connection.query(config_query, function (error, configData, fields) {
                    if(error){
                      WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,[error.message]);
                      return true;
                    }

                    if(configData.length > 0){
                      var configDataArray = {};
                      configData.forEach(function(value) {
                          configDataArray[value.config_title] = value.config_value;
                      });

                      var expireDate = moment().add(1, 'hours').valueOf();
                      var token = jwt.encode({
                          UserData: tokenUser,
                          CompanyData : tokenCompanyData,
                          ConfigData : configDataArray,
                          exp: expireDate
                      }, secretKey);
                      var tokenArray = { 'token' : token, UserData: tokenUser, CompanyData : tokenCompanyData, ConfigData : configDataArray};
                      WS.Output(req, res, true, 200, 'Login success',tokenArray);

                    }else{
                      WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,["No Data found..."]);
                    }
                  });

                }else{
                  WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,["No Data found..."]);
                }


            }else{
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,["No Data found..."]);
            }
          }else{
            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null,["No Data found..."]);
          }
        });

      }
    })(req, res);

    return false;


    /*//socket.on('space-not-available', (data) => {
        io.emit('getNewSpaces', {
            type: 'available-or-not',
            space_id: '0010d952-48b8-4088-8615-eaab88c2b957',
            //space_name: data.space_name,
            available : 0
        });
    //});*/

}