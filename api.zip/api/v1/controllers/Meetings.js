var generalConfig = require('../../../server/config/generalConfig');
var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;

var dateFormat = require('dateformat');


exports.MyMeetings = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;
        var time_difference = tokenData.UserData.time_difference;
        if(time_difference == "" || time_difference == null){
            time_difference = '+00:00';
        }

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;
        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var query  = "";
        query += "SELECT sb.space_id, s.space_name,  s.floor_id, s.space_capacity,  s.space_size, ";
        query += " CONCAT('"+base_image_url+"space_image/',s.space_image) as full_space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/80x80/',s.space_image) as thumb_space_image, ";
        query += " s.floor_id, f.floor_name, f.building_id, b.building_name, s.space_type_id, st.space_type_name, ";
        query += " sb.booking_id, sb.user_id,  sb.booking_title, sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
        query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
        query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,  ";
        query += " sb.booking_duration, ";

        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_time, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_end_date, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_time, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%W, %M %d, %Y') as display_date, ";

        query += " ( ";
        query += " SELECT ";
        query += " GROUP_CONCAT(DISTINCT CONCAT('"+base_image_url+"amenities_images/',sub_a.amenity_image)) as amenity_images ";
        query += " FROM "+company_db_name+".so_space_amenities AS sub_sa ";
        query += " LEFT JOIN "+company_db_name+".so_amenities AS sub_a ON sub_a.amenity_id = sub_sa.amenity_id";
        query += " WHERE sub_sa.space_id = sb.space_id";
	query += " AND sub_sa.deleted_at IS NULL";
        query += " ) AS amenity_images, ";

        query += " ( ";
        query += " SELECT ";
        query += " GROUP_CONCAT(email_address) as email_address ";
        query += " FROM "+company_db_name+".so_email_master AS emailmaster ";
        query += " LEFT JOIN "+company_db_name+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id";
        query += " WHERE spaceattendies.booking_id = sb.booking_id";
        query += " GROUP BY sb.booking_id";
        query += " ) AS attendies, ";
        //query += " sa.email_id, sa.attendies_type,e.email_address ";
        query += " CONCAT(u.first_name,' ',u.last_name) as organizer_full_name, ";
        query += " LCASE(u.email) as organizer_email, ";
        query += " u.phone_number as organizer_phone_number, ";
        query += " CONCAT('"+base_image_url+"user_image/80x80/',u.profile_picture) as organizer_thumb_picture, ";
        query += " CONCAT('"+base_image_url+"user_image/',u.profile_picture) as organizer_full_picture ";

        query += "FROM "+company_db_name+".so_space_attendies AS sa ";
        query += " LEFT JOIN "+company_db_name+".so_email_master AS e ON e.email_id = sa.email_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_booking AS sb ON sb.booking_id = sa.booking_id ";
        query += " LEFT JOIN "+company_db_name+".so_spaces AS s ON s.space_id = sb.space_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_type AS st ON st.space_type_id = s.space_type_id ";
        query += " LEFT JOIN "+company_db_name+".so_floors AS f ON f.floor_id = s.floor_id ";
        query += " LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = f.building_id ";
        query += " LEFT JOIN smartoffice_master.so_users AS u ON u.user_id = sb.user_id ";

        query += " WHERE (LCASE(e.email_address) = LCASE('"+email+"') OR sb.user_id = '"+user_id+"') ";
        query += " AND  sb.deleted_at IS NULL AND sb.end_time >= '"+currentDate+"' ";
        query += " GROUP BY sb.booking_id ORDER BY sb.start_time limit "+start+","+limit;

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });

    });
},


exports.SpaceMeetings = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/uploads/'+company_domain_prefix+'/';

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;
        var time_difference = tokenData.UserData.time_difference;
        if(time_difference == "" || time_difference == null){
            time_difference = '+00:00';
        }

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd");

        var all_form_fields = req.body;
        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var start_date = currentDate;
        var end_date = currentDate;
        if(all_form_fields.start_date){
            start_date = all_form_fields.start_date;
        }
        if(all_form_fields.end_date){
            end_date = all_form_fields.end_date;
        }

        var query  = "";
        query += "SELECT ";
        query += " sb.booking_id, sb.space_id, sb.user_id,  sb.booking_title, sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
        //query += " sb.start_time , sb.end_time, sb.booking_duration, ";
        query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
        query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,  ";
        query += " sb.booking_duration, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%Y-%m-%d %H:%i:%s') as display_start_date, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%Y-%m-%d %H:%i:%s') as display_end_date ";
        query += " FROM "+company_db_name+".so_space_booking AS sb ";
        query += " WHERE sb.deleted_at IS NULL ";
        query += " AND DATE_FORMAT(sb.start_time,'%Y-%m-%d') >= '"+start_date+"' ";
        query += " AND DATE_FORMAT(sb.end_time,'%Y-%m-%d') <= '"+end_date+"' ";
        if(all_form_fields.space_id && all_form_fields.space_id != ""){
            query += " AND sb.space_id = '"+all_form_fields.space_id+"'";
        }
        query += " ORDER BY sb.start_time limit "+start+","+limit;

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });

    });

},

exports.UserAttendMeeting = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;
        var booking_id = "";
        if(all_form_fields.booking_id){
            booking_id = all_form_fields.booking_id;
        }

        var is_meetingStarted = 0;
        if(all_form_fields.is_meetingStarted){
            is_meetingStarted = all_form_fields.is_meetingStarted;
        }

        var request_date = all_form_fields.request_date;
        request_date = dateFormat(request_date, "UTC:yyyy-mm-dd HH:MM:ss");
        
        var query  = "";
        query += "SELECT ";
        query += " sb.booking_id, sb.space_id, sb.user_id, ";
        query += " DATE_FORMAT(sb.created_at,'%Y-%m-%d %H:%i:%s') as booking_date, DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as booking_start_time, DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as booking_end_time";
        query += " FROM "+company_db_name+".so_space_booking AS sb ";
        query += " WHERE sb.deleted_at IS NULL ";
        query += " AND sb.booking_id = '"+booking_id+"' ";

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    if(user_id == results[0].user_id){
                        
                        var space_id = results[0].space_id;
                        var status = 3;
                        var booking_date = results[0].booking_date;
                        var booking_start_time = results[0].booking_start_time;
                        var booking_end_time = results[0].booking_end_time;
                        var meeting_started_time = request_date;
                        var meeting_ended_time = "";
                        var spaceName = "";
                        var userName = "";
                        var query = "";
                        query = "SELECT `space_name` FROM "+company_db_name+".`so_spaces`  WHERE `space_id` = '"+space_id+"'";
                        connection.query(query, function (error, space_results, fields) {
                                if(error){
                                        console.log(error);
                                }
                                if(space_results.length > 0){
                                    spaceName = space_results[0].space_name;
                                }
                        });
                        var querynew = "SELECT CONCAT(u.first_name,' ',u.last_name) as userName FROM smartoffice_master.so_users as u WHERE u.user_id = '"+user_id+"'";
                        connection.query(querynew, function (error, user_results, fields) {
                                if(error){
                                        console.log(error);
                                }
                                if(user_results.length > 0){
                                    userName = user_results[0].userName;
                                    console.log(userName);
                                    //INSERT USER LEFT MEETING LOG - START
                                    var insertUserLeftMeetingLogQuery = "INSERT INTO "+company_db_name+".so_space_booking_capturelogs ";
                                    insertUserLeftMeetingLogQuery += "(capture_log_id, booking_id, space_id, user_id, space_name, username, status, created_at, booking_date, booking_start_time, booking_end_time, meeting_started_time, is_meetingStarted) ";
                                    insertUserLeftMeetingLogQuery += "VALUES (UUID(), '"+booking_id+"', '"+space_id+"', '"+user_id+"','"+spaceName+"','"+userName+"', '"+status+"','"+currentDate+"','"+booking_date+"','"+booking_start_time+"','"+booking_end_time+"','"+meeting_started_time+"', '"+is_meetingStarted+"')";

                                    if(is_meetingStarted==1){
                                        connection.query(insertUserLeftMeetingLogQuery, function (error, results, fields) {
                                            if(error){
                                                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                                            }
                                            if(results){
                                                if(results.affectedRows > 0){
                                                    WS.Output(req, res, true, 200, "User Attend Meeting logs inserted successfully.",results);
                                                } else {
                                                    results = {};
                                                    WS.Output(req, res, true, 401, "No data found..",results);
                                                }
                                            }
                                        });
                                    } else {
                                        results = {};
                                        WS.Output(req, res, true, 200, "No data found..",results);
                                    }
                                    //INSERT USER LEFT MEETING LOG - END
                                }
                        });                        
                    }else{
                        results = {};
                        WS.Output(req, res, true, 200, "You are not authorize to attend this meeting.",results);
                    }
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });

    });
}

exports.CancelMeeting = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");


        var all_form_fields = req.body;
        var booking_id = "";
        if(all_form_fields.booking_id){
            booking_id = all_form_fields.booking_id;
        }

        var early_left = 0;
        if(all_form_fields.early_left!=undefined){
            early_left = all_form_fields.early_left;
        }

        var request_date = all_form_fields.request_date;
        //request_date = dateFormat(request_date, "UTC:yyyy-mm-dd HH:MM:ss");

        var query  = "";
        query += "SELECT ";
        query += " sb.booking_id, sb.space_id, sb.user_id, ";
        query += " DATE_FORMAT(sb.created_at,'%Y-%m-%d %H:%i:%s') as booking_date, DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as booking_start_time, DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as booking_end_time";
        query += " FROM "+company_db_name+".so_space_booking AS sb ";
        query += " WHERE sb.deleted_at IS NULL ";
        query += " AND sb.booking_id = '"+booking_id+"' ";

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    if(user_id == results[0].user_id){
                        var delete_meeting_query = "UPDATE "+company_db_name+".so_space_booking ";
                          delete_meeting_query += " SET ";
                          delete_meeting_query += " updated_at = '"+currentDate+"', ";
                          delete_meeting_query += " deleted_at = '"+currentDate+"', ";
                          delete_meeting_query += " booking_status = 'CANCELLED'";
                          delete_meeting_query += " WHERE booking_id = '"+booking_id+"'";
                          connection.query(delete_meeting_query, function(error, cancelresults, fields) {
                            if(cancelresults) {
                                io.sockets.emit('getNewSpaces', {
                                            type: 'available-or-not',
                                            space_id: results[0].space_id,
                                            available : 0
                                });
                            }
                        });

                        // Start : Insert logs for User early left
                        if(early_left==1) {
                            var query  = "";
                            query += "SELECT ";
                            query += " sbc.is_meetingStarted, sbc.user_id, DATE_FORMAT(sbc.booking_date,'%Y-%m-%d %H:%i:%s') as booking_date, DATE_FORMAT(sbc.booking_start_time,'%Y-%m-%d %H:%i:%s') as booking_start_time, DATE_FORMAT(sbc.booking_end_time,'%Y-%m-%d %H:%i:%s') as booking_end_time, DATE_FORMAT(sbc.meeting_started_time,'%Y-%m-%d %H:%i:%s') as meeting_started_time";
                            query += " FROM "+company_db_name+".so_space_booking_capturelogs AS sbc ";
                            query += " WHERE sbc.booking_id = '"+booking_id+"' ORDER BY sbc.created_at DESC LIMIT 1";
                            connection.query(query, function (error, log_results, fields) {
                                if(error){
                                    //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                                    console.log(error);
                                }

                                var space_id = results[0].space_id;
                                var status = 1;
                                var booking_date = results[0].booking_date;
                                var booking_start_time = results[0].booking_start_time;
                                var booking_end_time = results[0].booking_end_time;
                                var is_meetingStarted = 0;
                                var meeting_started_time = booking_start_time;
                                var meeting_ended_time = request_date;

                                if(log_results.length > 0){
                                    if(log_results[0].is_meetingStarted==1){
                                        meeting_started_time = log_results[0].meeting_started_time;
                                    }
                                }
                                var spaceName = "";
                                var userName = "";
                                var query = "";
                                query = "SELECT `space_name` FROM "+company_db_name+".`so_spaces`  WHERE `space_id` = '"+space_id+"'";
                                connection.query(query, function (error, space_results, fields) {
                                        if(error){
                                                console.log(error);
                                        }
                                        if(space_results.length > 0){
                                             spaceName = space_results[0].space_name;
                                        }
                                });
                                var querynew = "SELECT CONCAT(u.first_name,' ',u.last_name) as userName FROM smartoffice_master.so_users as u WHERE u.user_id = '"+user_id+"'";
                                connection.query(querynew, function (error, user_results, fields) {
                                        if(error){
                                                console.log(error);
                                        }
                                        if(user_results.length > 0){
                                            userName = user_results[0].userName;
                                            //INSERT USER LEFT MEETING LOG - START
                                            var insertUserLeftMeetingLogQuery = "INSERT INTO "+company_db_name+".so_space_booking_capturelogs ";
                                            insertUserLeftMeetingLogQuery += "(capture_log_id, booking_id, space_id, user_id, space_name, username, status, created_at, booking_date, booking_start_time, booking_end_time, meeting_started_time, meeting_ended_time, is_meetingStarted) ";
                                            insertUserLeftMeetingLogQuery += "VALUES (UUID(), '"+booking_id+"', '"+space_id+"', '"+user_id+"','"+spaceName+"','"+userName+"','"+status+"','"+currentDate+"','"+booking_date+"','"+booking_start_time+"','"+booking_end_time+"','"+meeting_started_time+"','"+meeting_ended_time+"', '"+is_meetingStarted+"')";

                                            connection.query(insertUserLeftMeetingLogQuery, function (error, results, fields) {
                                                if(error){
                                                    //WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                                                    console.log(error);
                                                }
                                                if(results){
                                                    if(results.affectedRows > 0){
                                                        //WS.Output(req, res, true, 200, "User left meeting logs inserted successfully.",results);
                                                    } else {
                                                        results = {};
                                                        //WS.Output(req, res, true, 401, "No data found..",results);
                                                    }
                                                }
                                            });
                                            //INSERT USER LEFT MEETING LOG - END    
                                        }
                                });
                            });
                        }
                        // End : Insert logs for User early left
                        
                        WS.Output(req, res, true, 200, "Meeting cancelled successfully.",results);
                    }else{
                        results = {};
                        WS.Output(req, res, true, 200, "You are not authorize to cancel this meeting.",results);
                    }
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });

    });
}


exports.HoldExtendMeeting = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");


        var all_form_fields = req.body;
        var booking_id = "";
        if(all_form_fields.booking_id){
            booking_id = all_form_fields.booking_id;
        }

        var query  = "";
        query += "SELECT ";
        query += " sb.booking_id, sb.space_id, sb.user_id, ";
        query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
        query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
        query += " sb.booking_duration ";
        query += " FROM "+company_db_name+".so_space_booking AS sb ";
        query += " WHERE sb.deleted_at IS NULL ";
        query += " AND sb.booking_id = '"+booking_id+"' ";

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){
                    if(user_id == results[0].user_id){

                        var space_id = results[0].space_id;
                        var utc_start_time = results[0].utc_start_time;
                        var utc_end_time = results[0].utc_end_time;
                        var booking_start_date = results[0].utc_end_time;
                        var booking_duration = results[0].booking_duration;
                        var new_end_date = moment(utc_end_time).add(parseInt(all_form_fields.booking_duration), 'minutes').format("YYYY-MM-DD HH:mm:ss");
                        var booking_end_date = new_end_date;
                        var new_booking_duration = parseInt(booking_duration) + parseInt(all_form_fields.booking_duration);

                        var query  = "";
                        query += "SELECT ";
                        query += " sb.booking_id, sb.space_id, sb.user_id, ";
                        query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
                        query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time, ";
                        query += " sb.booking_duration, ";
                        query += "IF( ";
                        query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = '"+space_id+"' ";
                        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
                        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
                        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
                        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
                        query += "  IS NULL, ";

                            query += "IF( ";
                            query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = '"+space_id+"' ";
                            query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
                            query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
                            query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
                            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
                            query += "  IS NULL, ";
                            query += "  '0', "; //query += "  'Room Available', ";
                            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
                            query += "  ), ";

                        query += "  '1' "; //query += "  'Room not available' ";
                        query += "  ) AS is_available ";
                        query += " FROM "+company_db_name+".so_space_booking AS sb ";
                        query += " WHERE sb.deleted_at IS NULL ";
                        query += " AND sb.booking_id = '"+booking_id+"' ";

                        connection.query(query, function (error, AvailableResult, fields) {
                            if(error){
                                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                            }
                            if(AvailableResult){
                                if(AvailableResult.length > 0){
                                    var available = AvailableResult[0].is_available;
                                    if(available == 0){

                                        //INSERT BOOKING LOG - START
                                        var insertBookingLogQuery = "INSERT INTO "+company_db_name+".so_space_booking_log ";
                                        insertBookingLogQuery += "(booking_log_id, booking_id, booking_status, created_at, updated_at) ";
                                        insertBookingLogQuery += "VALUES (UUID(), '"+all_form_fields.booking_id+"', '"+all_form_fields.action_type+"', '"+currentDate+"','"+currentDate+"')";
                                        connection.query(insertBookingLogQuery);
                                        //INSERT BOOKING LOG - END

                                        //INSERT BOOKING EXTEND LOG - START
                                        var insertExtendLogQuery = "INSERT INTO "+company_db_name+".so_space_booking_extend_detail ";
                                        insertExtendLogQuery += "(extend_id, booking_id, start_time, end_time, booking_duration, booking_status, created_at, updated_at) ";
                                        insertExtendLogQuery += "VALUES (UUID(), '"+all_form_fields.booking_id+"','"+utc_end_time+"','"+new_end_date+"', '"+all_form_fields.booking_duration+"', '"+all_form_fields.action_type+"', '"+currentDate+"','"+currentDate+"')";
                                        connection.query(insertExtendLogQuery);
                                        //INSERT BOOKING EXTEND LOG - END

                                        //UPDATE BOOKING TABLE  - START
                                        var update_meeting_query = "UPDATE "+company_db_name+".so_space_booking ";
                                        update_meeting_query += " SET ";
                                        update_meeting_query += " end_time = '"+new_end_date+"', ";
                                        update_meeting_query += " booking_duration = '"+new_booking_duration+"', ";
                                        update_meeting_query += " updated_at = '"+currentDate+"' ";
                                        update_meeting_query += " WHERE booking_id = '"+booking_id+"'";
                                        connection.query(update_meeting_query);
                                        //UPDATE BOOKING TABLE  - END

                                        WS.Output(req, res, true, 200, "Meeting Extended successfully.",results);

                                    }else{
                                        results = {};
                                        WS.Output(req, res, true, 401, "This meeting room no longer available. Please search another room.",results);
                                    }
                                }
                            }
                        });

                    }else{
                        results = {};
                        WS.Output(req, res, true, 401, "You are not authorize to cancel this meeting.",results);
                    }
                }else{
                    results = {};
                    WS.Output(req, res, true, 401, "No data found..",results);
                }
            }
        });

    });
},


exports.DashboardMeetings = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;
        var time_difference = tokenData.UserData.time_difference;
        if(time_difference == "" || time_difference == null){
            time_difference = '+00:00';
        }

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;
        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var query  = "";
        query += "SELECT sb.space_id, s.space_name,  s.floor_id, s.space_capacity,  s.space_size, ";
        query += " CONCAT('"+base_image_url+"space_image/',s.space_image) as full_space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/80x80/',s.space_image) as thumb_space_image, ";
        query += " s.floor_id, f.floor_name, f.building_id, b.building_name, s.space_type_id, st.space_type_name, ";
        query += " sb.booking_id, sb.user_id,  sb.booking_title, sb.booking_details, sb.amenities_notes, sb.catering_notes, ";
        query += " DATE_FORMAT(sb.start_time,'%Y-%m-%d %H:%i:%s') as utc_start_time, ";
        query += " DATE_FORMAT(sb.end_time,'%Y-%m-%d %H:%i:%s') as utc_end_time,  ";
        query += " sb.booking_duration, ";

        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_start_date, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_start_time, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%m/%d/%Y') as display_end_date, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.end_time,'+00:00','"+time_difference+"'),'%l:%i %p') as display_end_time, ";
        query += " DATE_FORMAT(CONVERT_TZ(sb.start_time,'+00:00','"+time_difference+"'),'%W, %M %d, %Y') as display_date, ";

        query += " ( ";
        query += " SELECT ";
        query += " GROUP_CONCAT(DISTINCT CONCAT('"+base_image_url+"amenities_images/',sub_a.amenity_image)) as amenity_images ";
        query += " FROM "+company_db_name+".so_space_amenities AS sub_sa ";
        query += " LEFT JOIN "+company_db_name+".so_amenities AS sub_a ON sub_a.amenity_id = sub_sa.amenity_id";
        query += " WHERE sub_sa.space_id = sb.space_id";
        query += " AND sub_sa.deleted_at IS NULL";
        query += " ) AS amenity_images, ";

        query += " ( ";
        query += " SELECT ";
        // Added for get attendies array   
        query += " CONCAT('[', JSON_QUOTE(GROUP_CONCAT( JSON_OBJECT('email', emailmaster.email_address,'name',  CONCAT(su.first_name,' ',su.last_name), 'image', CONCAT('"+base_image_url+"user_image/', IF(LENGTH(su.profile_picture), su.profile_picture ,NULL) ), 'isOrganizer', 'false'))) ,']') AS email_address";
        
        query += " FROM "+company_db_name+".so_email_master AS emailmaster ";
        query += " LEFT JOIN "+company_db_name+".so_space_attendies AS spaceattendies ON spaceattendies.email_id = emailmaster.email_id";
        query += " LEFT JOIN smartoffice_master.so_users AS su ON emailmaster.email_address = su.email";
        query += " WHERE spaceattendies.booking_id = sb.booking_id";
        query += " GROUP BY sb.booking_id";
        query += " ) AS attendies, ";
        //query += " sa.email_id, sa.attendies_type,e.email_address ";
        query += " CONCAT(u.first_name,' ',u.last_name) as organizer_full_name, ";
        query += " LCASE(u.email) as organizer_email, ";
        query += " u.phone_number as organizer_phone_number, ";
        query += " CONCAT('"+base_image_url+"user_image/80x80/',u.profile_picture) as organizer_thumb_picture, ";
        query += " CONCAT('"+base_image_url+"user_image/',u.profile_picture) as organizer_full_picture ";

        query += "FROM "+company_db_name+".so_space_attendies AS sa ";
        query += " LEFT JOIN "+company_db_name+".so_email_master AS e ON e.email_id = sa.email_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_booking AS sb ON sb.booking_id = sa.booking_id ";
        query += " LEFT JOIN "+company_db_name+".so_spaces AS s ON s.space_id = sb.space_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_type AS st ON st.space_type_id = s.space_type_id ";
        query += " LEFT JOIN "+company_db_name+".so_floors AS f ON f.floor_id = s.floor_id ";
        query += " LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = f.building_id ";
        query += " LEFT JOIN smartoffice_master.so_users AS u ON u.user_id = sb.user_id ";

        query += " WHERE (LCASE(e.email_address) = LCASE('"+email+"') OR sb.user_id = '"+user_id+"') ";
        query += " AND  sb.deleted_at IS NULL AND sb.end_time >= '"+currentDate+"' ";
        query += " GROUP BY sb.booking_id ORDER BY sb.start_time limit "+start+","+limit;

        //query += " CONCAT('[', GROUP_CONCAT(JSON_OBJECT('email', emailmaster.email_address,'name',  CONCAT(su.first_name,' ',su.last_name), 'image', CONCAT('"+base_image_url+"user_image/',su.profile_picture), 'isOrganizer', 'false')),']') AS email_address";
        
        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                if(results.length > 0){

                    var finalResult = results.reduce(function(result, item){
                        var displayStartDate = dateFormat(item.utc_start_time, "UTC:yyyy-mm-dd");
                        
                        // convert a JSON string to a JavaScript object 
                        var attendies = item['attendies'];
                        var attendies3  = '[ {'+attendies.slice(3, -3)+'} ]';
                        attendies3 = attendies3.replace(/\\"/g, '"');
                        //attendies = JSON.stringify(attendies3);
                        var finalAttendiesArr = JSON.parse(attendies3);

                        
                        // For set isOrganizer value
                        finalAttendiesArr.forEach(function(value, index) {
                            //console.log('email--------------------', value.email);
                            if(value.email == item.organizer_email) {
                                finalAttendiesArr[index]['isOrganizer'] = "true";
                            }
                        });

                        item['attendies'] = finalAttendiesArr;

                        result[displayStartDate] = (result[displayStartDate] || []).concat(item);
                        return result;
                    }, {});
                    

                    WS.Output(req, res, true, 200, "Success",finalResult);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });

    });
}
