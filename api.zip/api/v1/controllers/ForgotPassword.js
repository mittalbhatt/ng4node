var generalConfig = require('../../../server/config/generalConfig');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;
var master_db = require('../../../server/config/sequelize').master_db;
var crypto      = require('crypto');

/**
 * @uses (forgotpassword) Forgot password, send reset password link to user email
 *
 * @author BG < bhumi.gothi@softwebsolutions.com >
 *
 * @return json
*/

exports.ForgotPassword = function(req, res, next) {

        master_db.models.User.findOne({
            attribute: ['first_name', 'last_name', 'email'],
            where : { 
                    email : req.body.email,
                    deleted_at : { $eq: null }
                }
            })
            .then(function(user) {
                if (!user) {
                    WS.Output(req, res, true, 401, 'Please enter valid email address.')
                }
                else {
                    var randomString = new Date().getTime()+ user.email;
                    var forgotToken = crypto.createHash('md5').update(randomString).digest('hex');
                    user.update({
                        forgotToken: forgotToken
                    }).then(function(updatedUser) {
                        if(updatedUser)
                        {
                            var domain = generalConfig.getDomain(req);
                            var fromDomainName = req.protocol + "://" + req.headers.host;
                            var imagePathObj = generalConfig.getFilePath(domain, "company", "main", "sub");
                            generalConfig.getCompanyFromDomain(domain, function (companyInfo) {
                                var companyName = companyInfo.company_name;
                                var companyLogoPath = "";
                                if(companyInfo.company_logo)
                                {
                                    var path = imagePathObj.mainLink+'/'+companyInfo.company_logo;
                                    if(generalConfig.checkFilePath(path))
                                    {                                       
                                       companyLogoPath = fromDomainName + '/' + generalConfig.imageUrl(path);
                                    }                                                                        
                                }                                
                                var replacements = {
                                    companyName : companyName,
                                    companyLogo : companyLogoPath,
                                    username : user.dataValues.first_name + ' ' + user.dataValues.last_name,
                                    link : fromDomainName+'/reset/password/'+forgotToken,
                                };                                
                                var to = user.email;
                                var subject = "Reset Password Link"                                                                
                                generalConfig.sendMail('resetPasswordTemplate.html',replacements,to,subject);

                                WS.Output(req, res, true, 200, "Password reset link has been successfully sent to this email address");
                            });
                        } else {
                            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.");
                        }
                    }).catch(function(error){
                        WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null, [error]);
                    });;
                }
        }).catch(function(error){
            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.", null, [error]);
        });
};
