var generalConfig = require('../../../server/config/generalConfig');
var database = require('../../../server/config/database');
var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;

var dateFormat = require('dateformat');


exports.getUsersList = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {
        
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';
        var user_id = tokenData.UserData.user_id;        
        var find_company_id = "SELECT company_id, user_type, building_id, floor_id  FROM "+master_database+".`so_company_users_map` WHERE `user_id` = '"+user_id+"' AND status = 1";

        connection.query(find_company_id, function (error, company, fields) {
            if(company && company.length >0){
                var company_id = company[0].company_id;
                var query = "SELECT `U`.user_id, `U`.email, concat(`U`.`first_name`,' ', `U`.`last_name`) as name  FROM "+master_database+".`so_company_users_map` AS `CUM` LEFT JOIN "+master_database+".`so_users` AS `U` ON `U`.user_id = `CUM`.user_id  WHERE `CUM`.`company_id` = '"+company_id+"' AND `U`.user_id != 1 AND `U`.user_id != '' AND `U`.deleted_at IS NULL";
                connection.query(query, function (error, results, fields) {
                    if(error){
                        return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]);
                    }                        
                    if(results){
                        if(results.length > 0){
                            WS.Output(req, res, true, 200, "Success",results);
                        }else{
                            results = {};
                            WS.Output(req, res, true, 200, "No data found..",results);
                        }
                    }
                });
            }
        });
    });
}