var generalConfig = require('../../../server/config/generalConfig');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;

var dateFormat = require('dateformat');


exports.CheckInOut = function(req, res, next) {


    WS.CheckJWTToken(req, res, function(tokenData) {


        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var user_id = tokenData.UserData.user_id;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
        var booking_start_date = currentDate;
        var booking_end_date = currentDate;

        var all_form_fields = req.body;

        if(all_form_fields.inout){

            var ErrorMsgList = new Array();
            all_form_fields.inout.forEach(function(value) {
                var inoutvalue = value['inout'];
                if(parseInt(inoutvalue)==1 || parseInt(inoutvalue)==0){
                }else{
                    ErrorMsgList.push("The inout field must be 1 or 0.");
                }
            });

            if(!_.isEmpty(ErrorMsgList)){
              WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",'',ErrorMsgList);
            }else{

                var WhereQuery = '';
                var CHECKOUTWhereQuery = '';
                var totalinoutlength = all_form_fields.inout.length;
                var inc_index = 0;
                all_form_fields.inout.forEach(function(value) {
                    inc_index++;
                    var inoutvalue = value['inout'];
                    var major = value['major'];
                    var minor = value['minor'];
                    if(totalinoutlength == inc_index){
                        WhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") ';
                    }else{
                        WhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") OR ';
                    }

                    if(value['inout'] == 0){
                        if(totalinoutlength == inc_index){
                            CHECKOUTWhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") ';
                        }else{
                            CHECKOUTWhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") OR ';
                        }
                    }
                });

                    var sensorFindQuery = "SELECT sensor_id,sensor_uuid,sensor_major,sensor_minor,sensormaster.space_id, ";
                    sensorFindQuery += "IF( ";
                    sensorFindQuery += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = sensormaster.space_id ";
                    sensorFindQuery += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
                    sensorFindQuery += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
                    sensorFindQuery += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
                    sensorFindQuery += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
                    sensorFindQuery += "  IS NULL, ";

                        sensorFindQuery += "IF( ";
                        sensorFindQuery += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = sensormaster.space_id ";
                        sensorFindQuery += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
                        sensorFindQuery += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
                        sensorFindQuery += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
                        sensorFindQuery += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
                        sensorFindQuery += "  IS NULL, ";
                        sensorFindQuery += "  '0', "; //sensorFindQuery += "  'Room Available', ";

                        sensorFindQuery += "  '2' "; //sensorFindQuery += "  'Maintainance ma chhe Room NOT Available' ";
                        sensorFindQuery += "  ), ";

                    sensorFindQuery += "  '1' "; //sensorFindQuery += "  'Room not available' ";
                    sensorFindQuery += "  ) AS is_available ";


                    sensorFindQuery += " FROM "+company_db_name+".so_sensor_master as sensormaster ";
                    sensorFindQuery += " WHERE sensormaster.status=1 AND sensormaster.deleted_at IS NULL ";
                    sensorFindQuery += " AND ("+WhereQuery+") ";

                /*console.log(sensorFindQuery);*/

                connection.query(sensorFindQuery, function (error, sensorData, fields) {

                    // console.log('****************');
                    // console.log(error);

                    if(error){
                        WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                    }
                    if(sensorData){
                        all_form_fields.inout.forEach(function(value) {
                            sensorData.forEach(function(sensorInfo) {
                                if(sensorInfo.sensor_major == value['major'] && sensorInfo.sensor_minor == value['minor']){
                                    var now = new Date();
                                    var current_date = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
                                    var guid = generalConfig.generateGUID();
                                    var insert_sensor_inout = "INSERT INTO "+company_db_name+".so_sensor_inout ";
                                    insert_sensor_inout += "(id, `inout`, user_id, sensor_id, created_at, updated_at) ";
                                    insert_sensor_inout += "VALUES ('"+guid+"', '"+value['inout']+"', '"+user_id+"', '"+sensorInfo.sensor_id+"', '"+current_date+"', '"+current_date+"')";
                                    connection.query(insert_sensor_inout);
                                }

                                //SOCKET TO OCCUPIED STATUS ASHWIN - START
                                // 1 => in, 0 => out
                                if(value['inout'] == 1 && sensorInfo.is_available == 0){
                                    io.emit('getNewSpaces', {
                                        type: 'available-or-not',
                                        space_id: sensorInfo.space_id,
                                        available : 3
                                    });
                                }
                                //SOCKET TO OCCUPIED STATUS ASHWIN - END

                            });
                        });
                    }
                });


                if(CHECKOUTWhereQuery != ""){
                    //1. out thay to socket thi notify thay
                    var sensorFindOUTQuery = "SELECT sensor_id,sensor_uuid,sensor_major,sensor_minor,space_id FROM "+company_db_name+".so_sensor_master ";
                        sensorFindOUTQuery += " WHERE status=1 AND deleted_at IS NULL ";
                        sensorFindOUTQuery += " AND ("+CHECKOUTWhereQuery+") ";


                    connection.query(sensorFindOUTQuery, function (error, sensorOutData, fields) {
                        if(error){
                            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                        }
                        if(sensorOutData){

                            var CheckoutWhereQuery = '';
                            var totaloutlength = sensorOutData.length;
                            var out_index = 0;
                            sensorOutData.forEach(function(value) {
                                out_index++;
                                if(out_index==totaloutlength){
                                    CheckoutWhereQuery += '"'+value.space_id+'"';
                                }else{
                                    CheckoutWhereQuery += '"'+value.space_id+'",';
                                }
                            });
                            var now = new Date();
                            var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
                            //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
                            var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");

                            var CheckoutQuery = " SELECT tbl.created_at,tbl.space_id, tbl.soutout FROM ( ";
                            CheckoutQuery += " SELECT sinin.created_at , sm.space_id, ";

                            CheckoutQuery += " (SELECT  soutout.created_at";
                            CheckoutQuery += " FROM "+company_db_name+".so_sensor_inout AS soutout";
                            CheckoutQuery += " LEFT JOIN "+company_db_name+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
                            CheckoutQuery += " WHERE soutout.inout = 0";
                            CheckoutQuery += " AND sinin.`user_id` = soutout.user_id";
                            CheckoutQuery += " AND sinin.`created_at`<= soutout.created_at";
                            CheckoutQuery += " AND sm.space_id  = soutout_sm.space_id";
                            CheckoutQuery += " ORDER BY soutout.created_at  LIMIT 1";
                            CheckoutQuery += " ) AS soutout";
                            CheckoutQuery += " FROM "+company_db_name+".so_sensor_inout AS sinin";
                            CheckoutQuery += " LEFT JOIN "+company_db_name+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
                            CheckoutQuery += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
                            CheckoutQuery += " WHERE sinin.inout = 1";
                            CheckoutQuery += " AND sinin.created_at > '"+previous_4hourtime+"'";
                            CheckoutQuery += " ORDER BY sinin.created_at DESC";

                            CheckoutQuery += "  ) AS tbl WHERE tbl.soutout IS NULL ";
                            if(CheckoutWhereQuery != ""){
                                CheckoutQuery += " AND tbl.space_id IN ("+CheckoutWhereQuery+")";
                            }
                            CheckoutQuery += " GROUP BY tbl.space_id ";

                            connection.query(CheckoutQuery, function (error, OutData, fields) {
                                if(error){
                                    WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                                }
                                if(OutData){
                                    var OutArray = new Array();

                                    /*console.log(sensorOutData);*/

                                    sensorOutData.forEach(function(value) {
                                        var space_exist = 0;
                                        OutData.forEach(function(spacedata) {
                                            if(value.space_id == spacedata.space_id){
                                                space_exist = 1;
                                            }
                                        });

                                        if(space_exist == 0){
                                            io.emit('getNewSpaces', {
                                                type: 'available-or-not',
                                                space_id: value.space_id,
                                                available : 0
                                            });
                                        }
                                    });
                                }
                            });

                        }
                    });
                }
                //WS.Output(req, res, false, 200, "Success.");
            }
        }
        /*else{
            WS.Output(req, res, false, 401, "The inout record missing.",null,["The inout record missing."]);
        }*/

        //2. get information for spaces to display near body
        if(all_form_fields.info){
                var InfoWhereQuery = '';
                var InfoOrderByQuery = ' ORDER BY FIELD(sensor_major, ';
                var inc_index = 0;
                if(all_form_fields.info){
                    var totalinfolength = all_form_fields.info.length;
                    if(totalinfolength > 0){
                        all_form_fields.info.forEach(function(value) {
                            inc_index++;
                            var major = value['major'];
                            var minor = value['minor'];
                            if(totalinfolength == inc_index){
                                InfoWhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") ';
                            }else{
                                InfoWhereQuery += ' (sensor_major = "'+major+'" AND sensor_minor = "'+minor+'") OR ';
                            }

                            if(totalinfolength == inc_index){
                                InfoOrderByQuery += ' '+major+' ) ';
                            }else{
                                InfoOrderByQuery += ' '+major+', ';
                            }
                        });
                    }
                }

                if(InfoWhereQuery != ""){
                    var sensorInfoQuery = "SELECT sensor_id,sensor_uuid,sensor_major,sensor_minor,space_id FROM "+company_db_name+".so_sensor_master ";
                    sensorInfoQuery += " WHERE status=1 AND deleted_at IS NULL ";
                    sensorInfoQuery += " AND ("+InfoWhereQuery+") ";
                    sensorInfoQuery += InfoOrderByQuery;
                    connection.query(sensorInfoQuery, function (error, sensorInfoData, fields) {
                        if(error){
                            WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                        }

                        if(sensorInfoData.length > 0){
                            var SpaceInfoSpaceId = '';
                            var Spaceinc_index = 0;
                            var totalspaceinfolength = sensorInfoData.length;
                            sensorInfoData.forEach(function(spaces) {
                                Spaceinc_index++;
                                 if(totalspaceinfolength == Spaceinc_index){
                                    SpaceInfoSpaceId += ' "'+spaces.space_id+'" ';
                                }else{
                                    SpaceInfoSpaceId += ' "'+spaces.space_id+'", ';
                                }
                            });
                            if(SpaceInfoSpaceId != ""){

                                var now = new Date();
                                var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
                                var booking_start_date = currentDate;
                                var booking_end_date = currentDate;
                                //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
                                var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");

                                var query  = "";
                                query += "SELECT flr.floor_id, flr.floor_name, flr.floor_no, b.building_name, b.building_id, ";
                                query += " s.space_id, space_name, space_capacity, space_notes, ss.space_type_id, ss.space_type_name, ";
                                query += " space_image, ";
                                query += " CONCAT('"+base_image_url+"space_image/',space_image) as full_space_image, ";
                                query += " CONCAT('"+base_image_url+"space_image/80x80/',space_image) as thumb_space_image, ";

                                query += " ( ";
                                query += " SELECT ";
                                query += " GROUP_CONCAT(DISTINCT CONCAT('"+base_image_url+"amenities_images/',sub_a.amenity_image)) as amenity_images ";
                                query += " FROM "+company_db_name+".so_space_amenities AS sub_sa ";
                                query += " LEFT JOIN "+company_db_name+".so_amenities AS sub_a ON sub_a.amenity_id = sub_sa.amenity_id";
                                query += " WHERE sub_sa.space_id = s.space_id";
								query += " AND sub_a.deleted_at IS NULL";
                                query += " ) AS amenity_images, ";

                                query += "IF( ";
                                query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
                                query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
                                query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
                                query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
                                query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
                                query += "  IS NULL, ";

                                    query += "IF( ";
                                    query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
                                    query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
                                    query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
                                    query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
                                    query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
                                    query += "  IS NULL, ";

                                        //query += "  '0', "; //query += "  'Room Available', ";
                                        query += "IF( ";
                                        query += " (SELECT tbl.created_at FROM ( ";
                                        query += " SELECT sinin.created_at , sm.space_id, ";

                                        query += " (SELECT  soutout.created_at";
                                        query += " FROM "+company_db_name+".so_sensor_inout AS soutout";
                                        query += " LEFT JOIN "+company_db_name+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
                                        query += " WHERE soutout.inout = 0";
                                        query += " AND sinin.`user_id` = soutout.user_id";
                                        query += " AND sinin.`created_at`<= soutout.created_at";
                                        query += " AND sm.space_id  = soutout_sm.space_id";
                                        query += " ORDER BY soutout.created_at  LIMIT 1";
                                        query += " ) AS soutout";
                                        query += " FROM "+company_db_name+".so_sensor_inout AS sinin";
                                        query += " LEFT JOIN "+company_db_name+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
                                        query += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
                                        query += " WHERE sinin.inout = 1";
                                        query += " AND sinin.created_at > '"+previous_4hourtime+"'";
                                        query += " ORDER BY sinin.created_at DESC LIMIT 1";

                                        query += "  ) AS tbl WHERE tbl.soutout IS NULL AND tbl.space_id = s.space_id ";
                                        query += " GROUP BY tbl.space_id, tbl.created_at ";
                                        query += " ) IS NULL, '0' , '3'), ";

                                    query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
                                    query += "  ), ";

                                query += "  '1' "; //query += "  'Room not available' ";
                                query += "  ) AS is_available ";

                                query += " FROM "+company_db_name+".so_spaces AS s ";
                                query += " LEFT JOIN "+company_db_name+".so_floors AS flr ON flr.floor_id = s.floor_id ";
                                query += " LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = flr.building_id ";
                                query += " LEFT JOIN "+company_db_name+".so_space_amenities AS sa ON sa.space_id = s.space_id ";
                                query += " LEFT JOIN "+company_db_name+".so_space_type AS ss ON ss.space_type_id = s.space_type_id ";
                                query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";


                                query += " AND s.space_id IN ("+SpaceInfoSpaceId+") ";
                                query += " GROUP BY s.space_id ";
                                query += " ORDER BY FIELD(s.space_id, "+SpaceInfoSpaceId+") ";


                                connection.query(query, function (error, NearBySpaceInfo, fields) {

                                    // console.log('==========**query start**============');
                                    // console.log(query);
                                    // console.log(error);
                                    // console.log('==========**query end**============');

                                    if(error){
                                        WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
                                    }

                                    if(NearBySpaceInfo){
                                        if(NearBySpaceInfo.length > 0){
                                            WS.Output(req, res, true, 200, "Success",NearBySpaceInfo);
                                        }else{
                                            data = {};
                                            WS.Output(req, res, true, 200, "No data found..",data);
                                        }
                                    }

                                });
                            }
                        }else{
                            WS.Output(req, res, true, 200, "Success");
                        }
                    });
                }
                /*else{
                    WS.Output(req, res, true, 200, "Success");
                }*/
        }else{
            WS.Output(req, res, true, 200, "Success");
        }

    });
}