var generalConfig = require('../../../server/config/generalConfig');
var secretKey = generalConfig.secretKey;
var clientKey = generalConfig.clientKey;
var database = require('../../../server/config/database');

var moment = require('moment');
var mysql = require('mysql');
var config    = require('../../../server/config/database');
var conn = require('../../../server/config/mysql-connection');
var connection = conn.connection;
var momenttime = require('moment-timezone');
var dateFormat = require('dateformat');
var tmplDateTimeFormat = 'D MMM, YYYY h:mm A';

var authHelper = require('../../common/helpers/authHelper');
var googleauthHelper = require('../../common/helpers/googleauthHelper');
var Request = require("request");

/*exports.GetSpaceList = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;
        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var query  = "";
        query += "SELECT flr.floor_name, flr.floor_no, b.building_name, ";
        query += "s.space_id, space_name,space_capacity, space_notes, space_image, ";
        //query += "GROUP_CONCAT(a.amenity_name) AS amenity_names, ";
        query += "GROUP_CONCAT(a.amenity_image) AS amenity_images, ";
        query += "IF( (SELECT booking_id FROM "+company_db_name+".so_space_booking AS sb WHERE sb.space_id = s.space_id ";
        query += "AND sb.start_time <= '"+currentDate+"' AND sb.end_time >= '"+currentDate+"' ";
        query += "GROUP BY sb.space_id)  IS NULL, 0, 1) AS is_available ";
        query += "FROM "+company_db_name+".so_spaces AS s ";
        query += "LEFT JOIN "+company_db_name+".so_floors AS flr ON flr.floor_id = s.floor_id ";
        query += "LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = flr.building_id ";
        query += "LEFT JOIN "+company_db_name+".so_space_amenities AS sa ON sa.space_id = s.space_id ";
        query += "LEFT JOIN "+company_db_name+".so_amenities AS a ON a.amenity_id = sa.amenity_id ";
        query += "WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";
        query += "GROUP BY s.space_id ORDER BY s.space_name limit "+start+","+limit;

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[error]);
            }
            if(results){
                WS.Output(req, res, true, 200, "Success",results);
            }
        });

    });

},*/



exports.GetFilterData = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var all_form_fields = req.body;

        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/uploads/'+company_domain_prefix+'/';

        var AllReturnData = {};
        WS.GetBuildingData(req, res, tokenData, AllReturnData, function(AllReturnData) {
            WS.GetFloorData(req, res, tokenData, AllReturnData, function(AllReturnData) {
                WS.GetAmenitiesData(req, res, tokenData, AllReturnData, function(AllReturnData) {
                    WS.GetSpaceTypeData(req, res, tokenData, AllReturnData, function(AllReturnData) {

                        WS.Output(req, res, true, 200, "Success.",AllReturnData);
                    });
                });
            });
        });
    });

},



exports.GetAdvanceSpaceList = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;


        var booking_start_date = all_form_fields.booking_start_date;
        var booking_end_date = all_form_fields.booking_end_date;
        var orderBy = (all_form_fields.order_by)?all_form_fields.order_by:'ASC';
        //var booking_start_date_addseconds = moment(booking_start_date).add(1, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        //var booking_end_date_minusseconds = moment(booking_end_date).subtract(1, 'seconds').format("YYYY-MM-DD HH:mm:ss");

        var next_current_time = moment(currentDate).add(300, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");


        var page = 1;
        var start = 0;
        var limit = generalConfig.WS_LIMIT;
        if(all_form_fields.page && all_form_fields.page > 0){
            page = all_form_fields.page;
        }
        if(all_form_fields.limit){
            limit = all_form_fields.limit;
        }
        if(page != 1){
            start = ((limit * page) - limit);
        }

        var query  = "";
        query += "SELECT flr.floor_id, flr.floor_name, flr.floor_no, b.building_name, b.building_id, ";
        query += " s.space_id, space_name, space_capacity, space_notes, ss.space_type_id, ss.space_type_name, ";
        query += " space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/512x512/',space_image) as full_space_image, ";
        query += " CONCAT('"+base_image_url+"space_image/80x80/',space_image) as thumb_space_image, ";

        query += " ( ";
        query += " SELECT ";
        //query += " GROUP_CONCAT(sub_a.amenity_name) AS amenity_names, ";
        query += " GROUP_CONCAT(DISTINCT CONCAT('"+base_image_url+"amenities_images/',sub_a.amenity_image)) as amenity_images ";
        query += " FROM "+company_db_name+".so_space_amenities AS sub_sa ";
        query += " LEFT JOIN "+company_db_name+".so_amenities AS sub_a ON sub_a.amenity_id = sub_sa.amenity_id";
        query += " WHERE sub_sa.space_id = s.space_id";
        query += " AND sub_sa.deleted_at IS NULL";
        query += " ) AS amenity_images, ";

        query += "IF( ";
        query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
        query += "  IS NULL, ";

            query += "IF( ";
            query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
            query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
            query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
            query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
            query += "  IS NULL, ";

            if(next_current_time < booking_start_date){
                query += "  '0', "; //query += "  'Room Available', ";
            }else{
                //query += "  '0', "; //query += "  'Room Available', ";

                query += "IF( ";
                query += " (SELECT tbl.created_at FROM ( ";
                query += " SELECT sinin.created_at , sm.space_id, ";

                query += " (SELECT  soutout.created_at";
                query += " FROM "+company_db_name+".so_sensor_inout AS soutout";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
                query += " WHERE soutout.inout = 0";
                query += " AND sinin.`user_id` = soutout.user_id";
                query += " AND sinin.`created_at`<= soutout.created_at";
                query += " AND sm.space_id  = soutout_sm.space_id";
                query += " ORDER BY soutout.created_at  LIMIT 1";
                query += " ) AS soutout";
                query += " FROM "+company_db_name+".so_sensor_inout AS sinin";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
                query += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
                query += " WHERE sinin.inout = 1";
                query += " AND sinin.created_at > '"+previous_4hourtime+"'";
                query += " ORDER BY sinin.created_at DESC";

                query += "  ) AS tbl WHERE tbl.soutout IS NULL AND tbl.space_id = s.space_id ";
                query += " GROUP BY tbl.space_id";
                query += " ) IS NULL, '0' , '3'), ";

            }
            //query += "  '0', "; //query += "  'Room Available', ";

            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
            query += "  ), ";

        query += "  '1' "; //query += "  'Room not available' ";
        query += "  ) AS is_available ";

        query += " FROM "+company_db_name+".so_spaces AS s ";
        query += " LEFT JOIN "+company_db_name+".so_floors AS flr ON flr.floor_id = s.floor_id ";
        query += " LEFT JOIN "+company_db_name+".so_buildings AS b ON b.building_id = flr.building_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_amenities AS sa ON sa.space_id = s.space_id ";
        //query += " LEFT JOIN "+company_db_name+".so_amenities AS a ON a.amenity_id = sa.amenity_id ";
        query += " LEFT JOIN "+company_db_name+".so_space_type AS ss ON ss.space_type_id = s.space_type_id ";

        query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";

        if(all_form_fields.building_id && all_form_fields.building_id != ""){
            query += " AND b.building_id = '"+all_form_fields.building_id+"'";
        }
        if(all_form_fields.floor_id && all_form_fields.floor_id != ""){
            query += " AND flr.floor_id = '"+all_form_fields.floor_id+"'";
        }
        if(all_form_fields.space_type_id && all_form_fields.space_type_id != ""){
            query += " AND ss.space_type_id = '"+all_form_fields.space_type_id+"'";
        }
        if(all_form_fields.amenity_id && all_form_fields.amenity_id != ""){
            var amenity_idString = all_form_fields.amenity_id.toString();
            var amenity_id = amenity_idString.replace(/,/g, "','");
            query += " AND sa.amenity_id IN ('"+amenity_id+"')";
        }
        if(all_form_fields.space_capacity && all_form_fields.space_capacity != ""){
            query += " AND s.space_capacity >= '"+all_form_fields.space_capacity+"'";
            //query += " AND s.space_capacity = '"+all_form_fields.space_capacity+"'";
        }

        query += "GROUP BY s.space_id ORDER BY s.space_capacity "+orderBy+" limit "+start+","+limit;
        
        
        connection.query(query, function (error, results, fields) {


            if(error){
                WS.Output(req, res, false, 401, error,null,[error]);
            }
            if(results){
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });
    });
},




exports.GetSpaceCheckAvailibility = function(req, res, next) {
	console.log('---------------------------***-------------------------------');
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;

        var booking_start_date = currentDate;
        var booking_end_date = currentDate;
        //var previous_4hourtime = moment(currentDate).subtract(14400, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        var space_id = all_form_fields.space_id;

        var query  = "";
        query += "SELECT s.space_id,";
        query += " space_name, space_capacity, space_notes, ";

        query += "IF( ";
        query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
        query += "  IS NULL, ";

            query += "IF( ";
            query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
            query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
            query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
            query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
            query += "  IS NULL, ";

                //query += "  '0', "; //query += "  'Room Available', ";
                query += "IF( ";
                query += " (SELECT tbl.created_at FROM ( ";
                query += " SELECT sinin.created_at , sm.space_id, ";

                query += " (SELECT  soutout.created_at";
                query += " FROM "+company_db_name+".so_sensor_inout AS soutout";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
                query += " WHERE soutout.inout = 0";
                query += " AND sinin.`user_id` = soutout.user_id";
                query += " AND sinin.`created_at`<= soutout.created_at";
                query += " AND sm.space_id  = soutout_sm.space_id";
                query += " ORDER BY soutout.created_at  LIMIT 1";
                query += " ) AS soutout";
                query += " FROM "+company_db_name+".so_sensor_inout AS sinin";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
                query += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
                query += " WHERE sinin.inout = 1";
                query += " AND sinin.created_at > '"+previous_4hourtime+"'";
                query += " ORDER BY sinin.created_at DESC LIMIT 1";

                query += "  ) AS tbl WHERE tbl.soutout IS NULL AND tbl.space_id = s.space_id ";
                query += " GROUP BY tbl.space_id";
                query += " ) IS NULL, '0' , '3'), ";

            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
            query += "  ), ";

        query += "  '1' "; //query += "  'Room not available' ";
        query += "  ) AS is_available, ";


        query += "(SELECT DATE_FORMAT(start_time,'%Y-%m-%d %H:%i:%s') as start_time FROM "+company_db_name+".so_space_booking WHERE space_id = '"+all_form_fields.space_id+"' AND start_time > '"+booking_start_date+"' AND deleted_at IS NULL ORDER BY start_time LIMIT 1) AS nextbooking_time, ";
        query += "(SELECT TIMESTAMPDIFF(MINUTE,'"+booking_start_date+"',DATE_FORMAT(start_time,'%Y-%m-%d %H:%i:%s')) as start_time FROM "+company_db_name+".so_space_booking WHERE space_id = '"+all_form_fields.space_id+"' AND start_time > '"+booking_start_date+"' AND deleted_at IS NULL ORDER BY start_time LIMIT 1) AS nextbooking_time_in_minute ";

        query += " FROM "+company_db_name+".so_spaces AS s ";
        query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";

        if(all_form_fields.space_id && all_form_fields.space_id != ""){
            query += " AND s.space_id = '"+all_form_fields.space_id+"'";
        }
        query += " GROUP BY s.space_id ORDER BY s.space_name";

        connection.query(query, function (error, results, fields) {

   	        console.log('error');
   	        console.log(error);

            if(error){
                WS.Output(req, res, false, 401, error,null,[error]);
            }
            var data = {};
            if(results){

                if(results.length > 0){
                    if(results[0].nextbooking_time == null){
                        results[0].nextbooking_time = '';
                    }
                    if(results[0].nextbooking_time_in_minute == null){
                        results[0].nextbooking_time_in_minute = 480;
                    }
                    data = results[0];
                    WS.Output(req, res, true, 200, "Success",data);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",data);
                }
            }
        });
    });
},



exports.SaveSpaceBooking = function(req, res, next) {
   
    WS.CheckJWTToken(req, res, function(tokenData) {

 var time_difference = tokenData.UserData.time_difference;
  if(time_difference == "" || time_difference == null){
            time_difference = '+00:00';
        }

let timeDiffOffset = '';
let timezone = '';
timeDiffOffset = time_difference;
timezone = tokenData.UserData.timezone;

  var all_form_fields = req.body;
  var company_db_name = tokenData.CompanyData.mycompany;
  var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
  var user_id = tokenData.UserData.user_id;
  //new parameter add
  var meetingTitle = req.body.booking_title;
  var meetingData = req.body.booking_date;        
  
 // var startTime = momenttime(req.body.booking_start_date).format(tmplDateTimeFormat);
//  var endTime =  momenttime(req.body.booking_end_date).format(tmplDateTimeFormat);

  if(req.body.catering_notes!="") {
          var cateringCheck = "along with snacks";
  }
  if(req.body.amenities_notes!="") {
          var amenities =  "The meeting room includes some extra amenities like "+ req.body.amenities_notes + '.';
  }
  else {
          var cateringCheck = "";
  }
  if(all_form_fields.attendies)
  {

    var ErrorMsgList = new Array();
    var attendiesArray = new Array();
    var email_regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    all_form_fields.attendies.forEach(function(value) {
            var email = value.toLowerCase();
            if (email.search(email_regex) == -1){
                    ErrorMsgList.push("The "+value+" must be an email address.");
            }
            attendiesArray.push(email);
    });

    if(!_.isEmpty(ErrorMsgList)) {
      WS.Output(req, res, false, 401, ErrorMsgList[0],'',ErrorMsgList);
    } else {

    generalConfig.CheckSpaceAvailability(req, res, tokenData, function(data){

      var space_capacity = data[0].space_capacity;
      var is_available = data[0].is_available;

      if(is_available == 0){
              if(space_capacity >= all_form_fields.attendies.length){

              var now = new Date();
              var upcoming_datetime = new Date(now.getTime() + 60000);
              var current_date = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
              var current_cmp_date = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:00");
              var upcoming_cmp_date = dateFormat(upcoming_datetime, "UTC:yyyy-mm-dd HH:MM:00");

              var booking_id = generalConfig.generateGUID();
              var booking_details = "";
              if(all_form_fields.booking_details){
                      booking_details = all_form_fields.booking_details;
              }
              var amenities_notes = "";
              if(all_form_fields.amenities_notes){
                      amenities_notes = all_form_fields.amenities_notes;
              }
              var catering_notes = "";
              if(all_form_fields.catering_notes){
                      catering_notes = all_form_fields.catering_notes;
              }
              var booking_duration = "";
              if(all_form_fields.booking_duration){
                      booking_duration = all_form_fields.booking_duration;
              }

              var insert_booking_query = "INSERT INTO "+company_db_name+".so_space_booking ";
              insert_booking_query += "(booking_id, space_id, user_id, booking_title, booking_details, booking_status, amenities_notes, catering_notes, start_time, end_time, booking_duration, device_id, status, created_at, updated_at) ";
              insert_booking_query += "VALUES ('"+booking_id+"', '"+all_form_fields.space_id+"', '"+user_id+"', '"+all_form_fields.booking_title+"', ";
              insert_booking_query += " '"+booking_details+"', '', '"+amenities_notes+"', '"+catering_notes+"', ";
              insert_booking_query += " '"+all_form_fields.booking_start_date+"', '"+all_form_fields.booking_end_date+"', ";
              insert_booking_query += " '"+booking_duration+"', '"+all_form_fields.device_uniq_id+"', 1, '"+current_date+"', '"+current_date+"')";

              connection.query(insert_booking_query, function (error, results, fields) {
                      if(error){
                          WS.Output(req, res, false, 401, error.message, null,[error.message]);
                          return true;
                      }
                      /* Start : Insert logs for most Book now */
                      if(results){
                        if(results.affectedRows > 0){
                            // Start - Added for o365
                            var userid = user_id;
                            var attendiesEmails = attendiesArray;
                            var attendiesForo365 = [];

                            for (var i = 0; i < attendiesEmails.length; i++) {
                                attendiesForo365.push({
                                    EmailAddress: {
                                        "Address": attendiesEmails[i],
                                        "Name": ""
                                    },
                                    Type: "Required"
                                });
                            }
                                                      
                          var newEvent = {
                              "Subject": all_form_fields.booking_title,
                              "Body": {
                                  "ContentType": "HTML",
                                  "Content": booking_details
                              },
                              "Start": {
                                  "DateTime": all_form_fields.booking_start_date,
                                  "TimeZone": "UTC"
                              },
                              "End": {
                                  "DateTime": all_form_fields.booking_end_date,
                                  "TimeZone": "UTC"
                              },
                              "Attendees": attendiesForo365,
                              "Location": {
                                  "DisplayName": all_form_fields.space_name,
                                  "LocationType": "Default"
                              },
                          };
                          
                          var selectQuery = "SELECT  `configUser`.*  FROM " + company_db_name+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
                          connection.query(selectQuery, function (error, results, fields) {
                              if(error) { console.log(message.ERROR) }
                              else if(results)
                              {                           
                                  if(typeof results[0] != 'undefined')
                                  {
                                      if(results[0].office_365=="true" && results[0].o365_access_token!=undefined && results[0].o365_access_token!='') {
                                          
                                          accessTokenCheck(req, res, next, tokenData).then( function(result) {
                                              if(result==true){

                                                  createOffice365Event(results, attendiesForo365, newEvent);      
                                              } else {
                                                  console.log('Something went Wrong !!!');
                                              }
                                          });
                                      } else {
                                          console.log("Disconnected from Office-365 Calendar");
                                      }
                                  }
                              }
                          });

                        // End - Added for o365

                        // Start - Added for google
                       
                        var attendiesForgoogle= [];

                        for (var i = 0; i < attendiesEmails.length; i++) {
                            attendiesForgoogle.push({
                                EmailAddress: {
                                    "Address": attendiesEmails[i],
                                    "Name": ""
                                },
                                Type: "Required"
                            });
                        }
                                      

                        var date=new Date(all_form_fields.booking_start_date);
                         date.setMinutes(date.getMinutes() + 30);
                          var dateend=new Date(all_form_fields.booking_end_date);
                         dateend.setMinutes(dateend.getMinutes() + 30);
                          var startTimenew = utcToTimezone(all_form_fields.booking_start_date,timezone, 'D MMMM, YYYY hh:mm A');
                           
                        var endTimenew = utcToTimezone(all_form_fields.booking_end_date, timezone, 'D MMMM, YYYY hh:mm A');  
                           
                        var newEvent= {
                        summary: all_form_fields.booking_title,
                        location: all_form_fields.space_name,
                       
                        start: {
                            'dateTime': new Date(startTimenew),
                            'timeZone': timezone,
                          },
                        end: {
                            'dateTime': new Date(endTimenew),
                            'timeZone': timezone,
                        },

                        attendees: attendiesForgoogle
                        
                    }
                                                      
                    var selectQuery = "SELECT  `configUser`.*  FROM " + company_db_name+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
                    connection.query(selectQuery, function (error, results, fields) {
                        if(error) { console.log(message.ERROR) }
                        else if(results)
                        {                           
                            if(typeof results[0] != 'undefined')
                            {
                                if(results[0].google=="true" && results[0].google_access_token!=undefined && results[0].google_access_token!='') {
                                    
                                     googleauthHelper.createEvent(results, attendiesForgoogle, newEvent);   
                                           
                                       
                                  
                                } else {
                                    console.log("Disconnected from Office-365 Calendar");
                                }
                            }
                        }
                    
                });

                var bookingTitle = all_form_fields.booking_title;
                bookingTitle = bookingTitle.toLowerCase();
                if (bookingTitle.indexOf("meeting in") !=-1) {
                    var status = 2;
                } else {
                    var status = 4;
                }
                var booking_start_time = all_form_fields.booking_start_date;
                var booking_end_time = all_form_fields.booking_end_date;
                var meeting_started_time = "";
                var meeting_ended_time = "";
                var is_meetingStarted = 0;
                
                var spaceName = "";
                var userName = "";
                var query = "";
                query = "SELECT `space_name` FROM "+company_db_name+".`so_spaces`  WHERE `space_id` = '"+req.body.space_id+"'";
                connection.query(query, function (error, space_results, fields) {
                        if(error){
                                console.log(error);
                        }
                        if(space_results.length > 0){
                             spaceName = space_results[0].space_name;
                             
                        }
                });
                
                var querynew = "SELECT CONCAT(u.first_name,' ',u.last_name) as userName FROM smartoffice_master.so_users as u WHERE u.user_id = '"+user_id+"'";
                    connection.query(querynew, function (error, user_results, fields) {
                          if(error){
                                  console.log(error);
                          }
                                if(user_results.length > 0){

                                    connection.query("SELECT google,office_365 FROM "+company_db_name+".`so_configuration_user` WHERE user_id = '"+user_id+"'", function(err, result)
                                    {
                                      if (err)
                                      {
                                          console.log(err);
                                      } 
                                      else
                                      {
                                          if(typeof result[0] != 'undefined')
                                          {
                                              if(req.body.book_from != "" && req.body.book_from != undefined)
                                              {
                                                  if(result[0].google == 'true' && result[0].office_365 == 'true')
                                                  {
                                                      var meeting_from = "Google,O365,"+req.body.book_from;
                                                  }
                                                  else if(result[0].google == 'true' && result[0].office_365 == 'false')
                                                  {
                                                      var meeting_from = "Google,"+req.body.book_from;
                                                  }
                                                  else if(result[0].google == 'false' && result[0].office_365 == 'true')
                                                  {
                                                      var meeting_from = "O365,"+req.body.book_from;
                                                  }
                                                  else
                                                  {                
                                                      var meeting_from = req.body.book_from;
                                                  }
                                              }
                                              else
                                              {
                                                  if(result[0].google == 'true' && result[0].office_365 == 'true')
                                                  {
                                                      var meeting_from = "Google,O365,"+req.body.device_type;
                                                  }
                                                  else if(result[0].google == 'true' && result[0].office_365 == 'false')
                                                  {
                                                      var meeting_from = "Google,"+req.body.device_type;
                                                  }
                                                  else if(result[0].google == 'false' && result[0].office_365 == 'true')
                                                  {
                                                      var meeting_from = "O365,"+req.body.device_type;
                                                  }
                                                  else
                                                  {
                                                      var meeting_from = req.body.device_type;              
                                                  }
                                              }
                                          }
                                          else
                                          {
                                              if(req.body.book_from != undefined && req.body.book_from != "")
                                              {
                                                  var meeting_from = req.body.book_from;
                                              }
                                              else
                                              {
                                                  var meeting_from = req.body.device_type;
                                              }
                                          }

                                          userName = user_results[0].userName;
                                          //INSERT BOOK NOW MEETING LOG - START
                                          var insertUserMostBookNowLogQuery = "INSERT INTO "+company_db_name+".so_space_booking_capturelogs ";
                                          insertUserMostBookNowLogQuery += "(capture_log_id, booking_id, space_id, user_id, space_name, username, status,meeting_from, created_at, booking_date, booking_start_time, booking_end_time, is_meetingStarted) ";
                                          insertUserMostBookNowLogQuery += "VALUES (UUID(), '"+booking_id+"', '"+all_form_fields.space_id+"', '"+user_id+"','"+spaceName+"','"+userName+"','"+status+"','"+meeting_from+"','"+current_date+"','"+current_date+"','"+booking_start_time+"','"+booking_end_time+"', '"+is_meetingStarted+"')";
                                          connection.query(insertUserMostBookNowLogQuery, function (error, results, fields) {
                                              if(error){
                                                  console.log(error);
                                              }
                                              if(results){
                                                  if(results.affectedRows > 0){
                                                      console.log("success");       
                                                  } else {
                                                      console.log("Something went wrong!!!");
                                                  }
                                              }
                                          });
                                      }
                                    });
                                        
                                //INSERT BOOK NOW MEETING LOG - END
                                }
                    });     
                }
            }
            /* End : Insert logs for most Book now */

            /* ATTENDIES CHECK AND ADD - START - ASHWIN */
            var attendiesString = attendiesArray.toString();
            var attendies = attendiesString.replace(/,/g, "','");
            var emailQuery = "SELECT tbl.email_id, tbl.email_address,IF(u.user_id IS NULL, 0, 1) AS is_user FROM ( ";
            emailQuery += " SELECT email_id, email_address FROM "+company_db_name+".so_email_master WHERE email_address IN ('"+attendies+"')";
            emailQuery += ") AS tbl LEFT JOIN smartoffice_master.so_users AS u ON LCASE(u.email) = LCASE(tbl.email_address)";
            connection.query(emailQuery, function (error, results, fields) {
                    if(error){
                            WS.Output(req, res, false, 401, error,null,[error]);
                    }
                    if(results)
                    {
                            var BeforeInsertAttendies = new Array();
                            attendiesArray.forEach(function(email) {
                                    var email_id = "";
                                    var findingEmailAddress = _.findWhere(results, {email_address: email});
                                    if(findingEmailAddress){
                                            var addEmail = new Array();
                                            addEmail['email_id'] = findingEmailAddress.email_id;
                                            addEmail['email_address'] = findingEmailAddress.email_address;
                                            addEmail['is_user'] = findingEmailAddress.is_user;
                                    }else{
                                            email_id = generalConfig.generateGUID();
                                            var insert_email_query = "INSERT INTO "+company_db_name+".so_email_master ";
                                            insert_email_query += "(email_id, email_address, status, created_at, updated_at) ";
                                            insert_email_query += "VALUES ('"+email_id+"', '"+email+"', 1, '"+current_date+"', '"+current_date+"')";
                                            connection.query(insert_email_query);

                                            var addEmail = new Array();
                                            addEmail['email_id'] = email_id;
                                            addEmail['email_address'] = email;
                                            addEmail['is_user'] = 0;

                                            var CheckUserQuery = "SELECT u.user_id ";
                                            CheckUserQuery += " FROM smartoffice_master.so_users AS u WHERE LCASE(u.email) = ('"+email+"') AND u.deleted_at IS NULL";
                                            connection.query(emailQuery, function (error, userDetail, fields) {
                                                if(error){
                                                    WS.Output(req, res, false, 401, error,null,[error]);
                                            }
                                            if(userDetail > 0){
                                                    addEmail['is_user'] = 1;
                                            }
                                    });
                                    }

                                    BeforeInsertAttendies.push(addEmail);
                            });

                            BeforeInsertAttendies.forEach(function(attendies_values) {
                                var insert_space_attendies_query = "INSERT INTO "+company_db_name+".so_space_attendies ";
                                insert_space_attendies_query += "(attendies_id,booking_id,email_id,attendies_type, status, created_at, updated_at) ";
                                insert_space_attendies_query += "VALUES (UUID(),'"+booking_id+"', '"+attendies_values['email_id']+"','GUEST', 1, '"+current_date+"', '"+current_date+"')";
                                connection.query(insert_space_attendies_query);
                            });
                    }
            });
      
                                  /* ATTENDIES CHECK AND ADD - END - ASHWIN */
                                  var data = {}
                                  data.booking_id = booking_id;

                                  /* FOR SOCKET NOT AVAILABLE SPACE - START */
                                  if(all_form_fields.booking_start_date >= current_cmp_date && all_form_fields.booking_start_date < upcoming_cmp_date){
                                      io.sockets.emit('getNewSpaces', {
                                          type: 'available-or-not',
                                          space_id: all_form_fields.space_id,
                                          available : 1
                                  });
                                  }
                              
                              var domain = req.protocol + "://" + req.headers.host;
                              generalConfig.getCompanyFromDomain(domain, function (companyInfo) {

                                      var companyLogoPath = "";
                                      if(companyInfo.company_logo)
                                      {
                                          var path = imagePathObj.mainLink+'/'+companyInfo.company_logo;
                                          if(generalConfig.checkFilePath(path))
                                          {                                       
                                               companyLogoPath = fromDomainName + '/' + generalConfig.imageUrl(path);
                                          }
                                      }

                                      var querynew = "SELECT  `space_name` FROM "+company_db_name+".`so_spaces`  WHERE `space_id` = '"+req.body.space_id+"'";
                                      connection.query(querynew, function (error, results, fields) {
                                            var startTimedate = momenttime(req.body.booking_start_date).format('D MMMM, YYYY');
                                            var endTimedate =  momenttime(req.body.booking_end_date).format('D MMMM, YYYY');
                                      var startTime = utcToTimezone(req.body.booking_start_date,timezone, 'hh:mm A');
                                      var endTime = utcToTimezone(req.body.booking_end_date, timezone, 'hh:mm A');                                
                                      var getendstartTime = moment(req.body.booking_start_date).format('dddd - D MMM, YYYY');
                                      if(results){

                                           var replacements = {
                                                  bookingDate: meetingData,
                                                  mainheader: 'You Are Invited To Join This Meeting',
                                                  companyLogo : companyLogoPath,
                                                  meetingTitle: meetingTitle,
                                                  startTime: startTime +' to '+endTime+" CST, "+getendstartTime,
                                                  endTime: endTimedate+' '+endTime,
                                                  description: (req.body.booking_details)? req.body.booking_details:null,
                                                  spaceName: results[0].space_name,
                                                  meetingtitle: (req.body.booking_details)? 'meeting Comments:': null,
                                                  confirmavbility: 'Please confirm your availability.'
                                          };

                                          if(results.length > 0){
                                              var emailArrayExisting = [];
                                              req.body.attendies.forEach(function (emailArrayss) {
                                              
                                              var to = emailArrayss;
                                                        var subject = "You are invited to join this meeting.";
                                                                                                              // var endTimedate =  momenttime(req.body.booking_start_date).format('D MMMM, YYYY');
                                                          var maindate=req.body.booking_start_date.split(' ');
   
                                                        var startTimenew = utcToTimezone(req.body.booking_start_date,timezone, 'D MMMM, YYYY hh:mm A');
                                                       
                                                        var endTimenew = utcToTimezone(req.body.booking_end_date, timezone, 'D MMMM, YYYY hh:mm A');  
                                                       
                                                        var date=new Date(startTimedate+' '+startTimenew);
                                                        //  console.log('date');
                                                        // console.log(date);
                                                         date.setMinutes(date.getMinutes() - 30);
                                                          //console.log(date);
                                                         var dateend=new Date(endTimedate+' '+endTimenew);
                                                          dateend.setMinutes(dateend.getMinutes() - 30);
                                                               
                                                          var testDateUtc = momenttime.utc(startTimenew);
                                                          var localDate = momenttime(testDateUtc).local();
                                                          var s = localDate.format("YYYY-MM-DD HH:mm:ss");
                                                          var startdate = localDate.toDate();

                                                          var testDateUtcnew = momenttime.utc(endTimenew);
                                                          var localDatenew = momenttime(testDateUtcnew).local();
                                                          var s = localDatenew.format("YYYY-MM-DD HH:mm:ss");
                                                          var enddate = localDatenew.toDate();
                                                             const event = {
                                                                            start: new Date(startdate),
                                                                            end: new Date(enddate),
                                                                            timezone: timezone,
                                                                            summary: replacements.meetingTitle,
                                                                             alarms:[
                                                                                {type: 'display', trigger: 900},
                                                                                {type: 'audio', trigger: 300}

                                                                                ],
                                                                            location: replacements.spaceName
                                                                           
                        
                                                                            }
                                              // please remove comment after upload to live
                                              generalConfig.sendMailWithics('createEventTemplate.html',replacements,to,subject,event);   
                                          });
                                          
                                              WS.Output(req, res, true, 200, "Meeting booked successfully.",data );
                                          } else {
                                              results = {};
                                              WS.Output(req, res, true, 200, "No data found..",results);
                                          }
                                          }
                                      });

                              });


                          });


                      }else{
                          WS.Output(req, res, false, 200, "Space has not enough capacity for attendies.",null,["Space has not enough capacity for attendies."]);
                      }
                  }else{
                      if(is_available == 3){
                          WS.Output(req, res, false, 200, "Space Occupied.",null,["Space Occupied."]);
                      }else{
                          WS.Output(req, res, false, 200, "Whoops, Another meeting is already scheduled on this time.",null,["Whoops, Another meeting is already scheduled on this time."]);
                      }
                  }
              });
          }
      }else{
          WS.Output(req, res, false, 200, "The attendies is required.",null,["The attendies is required."]);
      }

  });

},



exports.MostActive = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");

        var all_form_fields = req.body;

        var start_date = all_form_fields.start_date;
        var end_date = all_form_fields.end_date;

        var query  = "";
        query += "SELECT s.space_id, s.space_name,";
        query += " COUNT(sb.space_id) AS noof_meetings, ";
        query += " SUM(booking_duration) AS total_noofminute_meetings ";
        query += " FROM  "+company_db_name+".so_spaces AS s ";
        query += " LEFT JOIN "+company_db_name+".so_space_booking AS sb ON sb.space_id = s.space_id ";
        query += " WHERE s.deleted_at IS NULL AND s.status = 1 ";
        query += " AND DATE_FORMAT(sb.start_time,'%Y-%m-%d') >= '"+start_date+"' ";
        query += " AND DATE_FORMAT(sb.start_time,'%Y-%m-%d') <= '"+end_date+"' ";
        query += " GROUP BY s.space_id ";
        query += " ORDER BY total_noofminute_meetings DESC ";

        console.log(query);

        connection.query(query, function (error, results, fields) {
            if(error){
                WS.Output(req, res, false, 401, error,null,[error]);
            }
            if(results){
                var data = {};
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });
    });
},

exports.getSpaceList = function(req, res, next) {

    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;
        var base_image_url = process.env.HTTP_PATH+company_domain_prefix+'.'+process.env.BASE_URL+'/images/uploads/'+company_domain_prefix+'/';

        var email = tokenData.UserData.email;
        var user_id = tokenData.UserData.user_id;
        
        var query = "SELECT `space_id`, `space_name` FROM "+company_databasename+".`so_spaces` AS `Space` WHERE `Space`.`deleted_at` IS NULL AND `Space`.`status` = 1";
        connection.query(query, function (error, results, fields) {
            if(error){
                return WS.Output(req, res, false, 401, "Woops, Something Went Wrong.",null,[message.ERROR]);                        
            }                        
            if(results){
                if(results.length > 0){
                    WS.Output(req, res, true, 200, "Success",results);
                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",results);
                }
            }
        });
    });
}
function utcToTimezone(date, timezone='', format=''){
            if(date){
                  if(timezone){
                    console.log(timezone);
                     return momenttime.utc(date).tz(timezone).format(format);
                  } else {
                     return momenttime.utc(date).format(format);   
                  }
            } else {

                  return moment().format(format);
            }
      } 


/**
 * @uses to check access token expire and generate new
 *
 * @author JD < jignesh.vagh@softwebsolutions.com >
 *
 * @return json
*/
function accessTokenCheck(req, res, next, tokenData) {
    return new Promise((resolve, reject) => {
        console.log('++++++++++++++++++++++++++++++++++++++++++++++++');
        var userid = tokenData.UserData.user_id;

        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        if(company_databasename != null)
        {
            var selectQuery = "SELECT  `configUser`.*, DATE_FORMAT(`configUser`.o365_token_expire_at,'%Y-%m-%d %H:%i:%s') as utc_o365_token_expire_at  FROM " + company_databasename+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
            connection.query(selectQuery, function (error, results, fields) {
                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                else if(results)
                {                           
                    if(typeof results[0] != 'undefined')
                    {
                        var currentTime = generalConfig.getDateTimeUTC();
                        var o365TokenExpireTime = results[0].utc_o365_token_expire_at;
                        var currentTimestamp = new Date(currentTime).getTime()/1000.0; 
                        var o365TokenExpireTimestamp = new Date(o365TokenExpireTime).getTime()/1000.0;
                        var refresh_token = results[0].o365_refresh_token;
                        
                        if (currentTimestamp > o365TokenExpireTimestamp) {
                            authHelper.getTokenFromRefreshToken(refresh_token, tokenReceived, req, res, resolve);
                        }else {
                            resolve(true);  
                        }   
                    }
                }
            });
        }
    });
}

/**
 * @uses to check access token expire and generate new
 *
 * @author MB < mittal.bhatt@softwebsolutions.com >
 *
 * @return json
*/
function accessTokenCheckforgoogle(req, res, next, tokenData) {
    return new Promise((resolve, reject) => {
        console.log('++++++++++++++++++++++++++++++++++++++++++++++++');
        var userid = tokenData.UserData.user_id;

        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        if(company_databasename != null)
        {
            var selectQuery = "SELECT  `configUser`.*, DATE_FORMAT(`configUser`.google_token_expire_at,'%Y-%m-%d %H:%i:%s') as utc_google_token_expire_at  FROM " + company_databasename+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
            connection.query(selectQuery, function (error, results, fields) {
                if(error) { res.json({ 'success': false, 'message': message.ERROR, 'error': error }); }
                else if(results)
                {                           
                    if(typeof results[0] != 'undefined')
                    {
                        var currentTime = generalConfig.getDateTimeUTC();
                        var googleTokenExpireTime = results[0].utc_google_token_expire_at;
                        var currentTimestamp = new Date(currentTime).getTime()/1000.0; 
                        var googleTokenExpireTimestamp = new Date(googleTokenExpireTime).getTime()/1000.0;
                        var refresh_token = results[0].google_refresh_token;
                        
                        if (currentTimestamp > googleTokenExpireTimestamp) {
                            console.log('if-----------------------------------------------');
                            resolve(true);  
                           // googleauthHelper.getTokenFromRefreshToken(refresh_token, tokenReceived, req, res, resolve);
                        }else {
                            console.log('else----------------------------------------------');
                            resolve(true);  
                        }   
                    }
                }
            });
        }
    });
}

/**
 * @uses create Event for o365
 *
 * @author JD < jignesh.vagh@softwebsolutions.com >
 *
 * @return json
*/
function createOffice365Event(results, attendiesForo365, newEvent) {
    console.log('start creating Event on o365...............................');
    Request.post({
        "headers": { 
            "Content-Type": "application/json",
            "Authorization": "Bearer "+results[0].o365_access_token
        },
        "url": "https://outlook.office.com/api/v2.0/me/events",
        "body": JSON.stringify(newEvent)
    }, (error, response, body) => {
        if(error) {
            return console.log(error);
        } else {
            console.log('successfully created Event on o365...............................');
        }

    });
}



/**
 * @uses set access token for o365
 *
 * @author JD < jignesh.vagh@softwebsolutions.com >
 *
 * @return json
*/
function tokenReceived(req, res, error, token) {
  if (error) {
    console.log('ERROR getting token:'  + error);
    res.send('ERROR getting token: ' + error);
  }
  else {
    //req.session.access_token = token.token.access_token;
    //req.session.refresh_token = token.token.refresh_token;
    req.session.email = authHelper.getEmailFromIdToken(token.token.id_token);
    upsertConfigurationUser(req,res,token);
    
    /*res.json({
        'success' : true,                               
        'email' : req.session.email
    });*/
  }
}

function upsertConfigurationUser(req, res, token)
{
    WS.CheckJWTToken(req, res, function(tokenData) {
        var company_databasename = tokenData.CompanyData.mycompany;
        var master_database = database.master_database.name;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        if(company_databasename != null)
        {
                    //console.log('Token created: ', token.token);
                    var GUID = generalConfig.generateGUID();
                    var userid = tokenData.UserData.user_id;
                    var o365_access_token = token.token.access_token;
                    var o365_refresh_token = token.token.refresh_token;
                    var o365_token_expire_at = generalConfig.getDateTimeUTC(token.token.expires_at);
                    var created_at = generalConfig.getDateTimeUTC();
                    var updated_at = generalConfig.getDateTimeUTC();
                    
                    console.log('----------------------------------------------------------------');
                    console.log('-----------------        Testing (start)   2  ---------------------');
                    console.log('');
                    console.log(userid);
                    console.log(token);
                    console.log(tokenData);
                    console.log('');
                    console.log('-----------------        Testing (end)      2   ---------------------');
                    console.log('----------------------------------------------------------------');
                    
                    var selectQuery = "SELECT `configUser`.*  FROM " + company_databasename+".`so_configuration_user` as `configUser` where `configUser`.user_id =  '" + userid + "'";
                    connection.query(selectQuery, function (error, results, fields) {
                        if (error) {
                          console.log(message.ERROR);
                        } else {
                            if (results.length == 0) {
                              var configUser = " INSERT INTO "+company_databasename+".`so_configuration_user` (`configuration_user_id` , `user_id` , `office_365`, `o365_access_token` , `o365_refresh_token` , `o365_token_expire_at`, `created_at`, `updated_at`) VALUES ( '"+GUID+"','"+userid+"' , 'true', '"+o365_access_token+"', '"+o365_refresh_token+"', '"+o365_token_expire_at+"' , '"+created_at+"', '"+updated_at+"')";
                              connection.query(configUser, function (error, configUser, fields)
                              {
                                if(error){
                                 console.log(message.ERROR);
                                }
                              });
                            } else {
                              var updateConfigUser = "UPDATE "+company_databasename+".`so_configuration_user` SET `o365_access_token` =  '"+o365_access_token+"', `o365_refresh_token` =  '"+o365_refresh_token+"', `o365_token_expire_at` =  '"+o365_token_expire_at+"',`office_365` = 'true', `updated_at` =  '"+updated_at+"' WHERE  `so_configuration_user`.`user_id` = '"+userid+"'";
                              connection.query(updateConfigUser, function (error, updateConfigUser, fields)
                              {
                                if(error){
                                  console.log(message.ERROR);
                                }
                              });
                            }
                        }
                    });
        }

    });
}

exports.GetSpacesAvailibilityEntireDay = function(req, res, next) {
    WS.CheckJWTToken(req, res, function(tokenData) {

        var company_db_name = tokenData.CompanyData.mycompany;
        var company_domain_prefix = tokenData.CompanyData.company_domain_prefix;

        var all_form_fields = req.body;

        var available_date = all_form_fields.available_date;
        
        var now = new Date();
        var currentDate = dateFormat(now, "UTC:yyyy-mm-dd HH:MM:ss");
        var previous_4hourtime = moment(currentDate).subtract(900, 'seconds').format("YYYY-MM-DD HH:mm:ss");
        
        var booking_start_date = moment(available_date).format("YYYY-MM-DD 00:00:00")
        var booking_start_date_event = moment(available_date).format("YYYY-MM-DD HH:mm:ss");
        var booking_end_date = moment(booking_start_date_event).format("YYYY-MM-DD 23:59:00")
        var booking_end_date_event = booking_end_date;
        var booking_start_time = moment(available_date).format("HH:mm:ss");
        //var space_id = all_form_fields.space_id;

        var query  = "";
        query += " SELECT space_id,";
        query += " space_name, space_capacity, space_notes, ";

        query += "IF( ";
        query += " (SELECT booking_id FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
        query += "  IS NULL, ";

            query += "IF( ";
            query += " (SELECT maintainance_id FROM "+company_db_name+".so_space_maintainance as sm WHERE sm.space_id = s.space_id ";
            query += " AND ((sm.start_time < '"+booking_start_date+"' AND sm.end_time > '"+booking_start_date+"') ";
            query += " OR (sm.start_time < '"+booking_end_date+"' AND sm.end_time > '"+booking_end_date+"') ";
            query += " OR (sm.start_time >= '"+booking_start_date+"' AND sm.end_time <= '"+booking_end_date+"')) ";
            query += " AND sm.status=1 and sm.deleted_at IS NULL GROUP BY sm.space_id) ";
            query += "  IS NULL, ";

                //query += "  '0', "; //query += "  'Room Available', ";
                query += "IF( ";
                query += " (SELECT tbl.created_at FROM ( ";
                query += " SELECT sinin.created_at , sm.space_id, ";

                query += " (SELECT  soutout.created_at";
                query += " FROM "+company_db_name+".so_sensor_inout AS soutout";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS soutout_sm ON soutout_sm.`sensor_id` = soutout.`sensor_id`";
                query += " WHERE soutout.inout = 0";
                query += " AND sinin.`user_id` = soutout.user_id";
                query += " AND sinin.`created_at`<= soutout.created_at";
                query += " AND sm.space_id  = soutout_sm.space_id";
                query += " ORDER BY soutout.created_at  LIMIT 1";
                query += " ) AS soutout";
                query += " FROM "+company_db_name+".so_sensor_inout AS sinin";
                query += " LEFT JOIN "+company_db_name+".so_sensor_master AS sm ON sm.`sensor_id` = sinin.`sensor_id`";
                query += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.`space_id` = sm.`space_id`";
                query += " WHERE sinin.inout = 1";
                query += " AND sinin.created_at > '"+previous_4hourtime+"'";
                query += " ORDER BY sinin.created_at DESC LIMIT 1";

                query += "  ) AS tbl WHERE tbl.soutout IS NULL AND tbl.space_id = s.space_id ";
                query += " GROUP BY tbl.space_id";
                query += " ) IS NULL, '0' , '3'), ";

            query += "  '2' "; //query += "  'Maintainance ma chhe Room NOT Available' ";
            query += "  ), ";

        query += "  '1' "; //query += "  'Room not available' ";
        query += "  ) AS is_available, ";

        // Start - Get Availble (Every Day), (10:00AM - 1:00PM, 3:00PM - 5:00PM)
        query += "IF( ";
        query += " (SELECT sb.start_time FROM "+company_db_name+".so_space_booking as sb WHERE sb.space_id = s.space_id ";
        query += " AND ((sb.start_time < '"+booking_start_date+"' AND sb.end_time > '"+booking_start_date+"') ";
        query += " OR (sb.start_time < '"+booking_end_date+"' AND sb.end_time > '"+booking_end_date+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date+"' AND sb.end_time <= '"+booking_end_date+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id) ";
        query += "  IS NULL, ";
        query += "  'Entire Day', "; //query += "  '', ";
        
        query += "  '2' "; // Add extra query for (10:00AM - 1:00PM, 3:00PM - 5:00PM)

        query += "  ) AS available_time, ";

        query += " ( ";
        query += " SELECT ";
        query += " CONCAT('[', JSON_QUOTE(GROUP_CONCAT( JSON_OBJECT('meeting', booking_title, 'start_time', DATE_FORMAT(sb.start_time,'%H:%i:%s'), 'end_time', DATE_FORMAT(sb.end_time,'%H:%i:%s') ))) ,']') AS details ";
        
        query += " FROM "+company_db_name+".so_space_booking as sb";
        query += " LEFT JOIN "+company_db_name+".so_spaces AS spa ON spa.space_id = sb.space_id ";
        query += " WHERE sb.space_id = s.space_id AND ((sb.start_time < '"+booking_start_date_event+"' AND sb.end_time > '"+booking_start_date_event+"') ";
        query += " OR (sb.start_time < '"+booking_end_date_event+"' AND sb.end_time > '"+booking_end_date_event+"') ";
        query += " OR (sb.start_time >= '"+booking_start_date_event+"' AND sb.end_time <= '"+booking_end_date_event+"')) ";
        query += " AND sb.status=1 and sb.deleted_at IS NULL GROUP BY sb.space_id ";
        query += " ) AS events ";
        // End - Get Availble (Every Day), (10:00AM - 1:00PM, 3:00PM - 5:00PM)

        query += " FROM "+company_db_name+".so_spaces AS s ";
        query += " WHERE space_bookable = 1 AND is_maintenance = 0 AND s.`status`=1 AND s.deleted_at IS NULL ";

        if(all_form_fields.space_id && all_form_fields.space_id != ""){
            query += " AND s.space_id = '"+all_form_fields.space_id+"'";
        }
        
        query += " GROUP BY s.space_id ORDER BY s.space_name";

        connection.query(query, function (error, results, fields) {

            console.log('error');
            console.log(error);

            if(error){
                WS.Output(req, res, false, 401, error,null,[error]);
            }
            var data = {};
            if(results){

                if(results.length > 0){

                    results.forEach( function(item, index) {
                        if(item.available_time != 'Entire Day'){
                            
                            if(item.events!=null){
                                var meetingsArr = item.events;
                            
                                meetingsArr  = '[ {'+meetingsArr.slice(3, -3)+'} ]';
                                meetingsArr = meetingsArr.replace(/\\"/g, '"');
                                var meetings = JSON.parse(meetingsArr);

                                //If meetings is already sorted by time
                                //you can skip this next bit of code
                                meetings.sort(function(a, b){
                                    return a.start_time > b.start_time? 1: -1;
                                });

                                var schedule = [];
                                var start_time = booking_start_time;
                                var end_time = '23:59:00';
                                for(var i=0, l=meetings.length; i<l; i++){
                                    end_time = subtractMinute(meetings[i].start_time);
                                    
                                    if(i)
                                        start_time = addMinute(meetings[i-1].end_time);   
                                    
                                    if((end_time && !i) || (end_time && i && meetings[i-1].end_time < meetings[i].start_time)) {

                                        if (start_time.toString() > end_time.toString())
                                            console.log("start_time is greater than end_time", start_time);
                                        else
                                            schedule.push({meeting: 'available slot', start_time: start_time, end_time: end_time});
                                    }
                                            
                                    schedule.push(meetings[i]);
                                    
                                    if(i+1 === l){
                                        start_time = addMinute(meetings[i].end_time);
                                        
                                        if(start_time)
                                            schedule.push({meeting: 'available slot', start_time: start_time, end_time: '23:59:00'});
                                    }
                                }

                                var available_slots =  schedule.filter(function(item) {
                                    return item.meeting == "available slot";
                                });

                                available_slots.sort(function(a, b){
                                    return a.start_time > b.start_time? 1: -1;
                                });
                                
                                if(available_slots.length > 0){
                                    results[index]['available_time'] = available_slots;
                                    delete results[index].events;
                                }
                            } else {

                                var schedule_no_events = [];
                                if(booking_start_time)
                                    schedule_no_events.push({meeting: 'available slot', start_time: booking_start_time, end_time: '23:59:00'});
                                results[index]['available_time'] = schedule_no_events
                            }
                        } else {

                            var schedule_entire_day = [];
                                if(booking_start_time)
                                    schedule_entire_day.push({meeting: 'Entire Day', start_time: '00:00:00', end_time: '23:59:00'});
                                results[index]['available_time'] = schedule_entire_day
                        }
                    });
                    
                    data = results;
                    WS.Output(req, res, true, 200, "Success",data);

                }else{
                    results = {};
                    WS.Output(req, res, true, 200, "No data found..",data);
                }
            }
        });
    });
}

function subtractMinute(time){
  var h = +time.substr(0, 2);
  var m = +time.substr(3, 2);

  if(m > 0){
    m -= 1;
  }else{
    if(h > 0){
      h -= 1;
    }else{
      return false;
    }
    m = 59;
  }

  if(h < 10)
    h = '0'+h;

  if(m < 10)
    m = '0'+m;

  return h+':'+m+':00';
}

function addMinute(time){
  var h = +time.substr(0, 2);
  var m = +time.substr(3, 2);

  if(m < 59){
    m += 1;
  }else{
    if(h < 22){
      h += 1;
    }else{
      return false;
    }
    m = 0;
  }

  if(h < 10)
    h = '0'+h;

  if(m < 10)
    m = '0'+m;

  return h+':'+m+':00';
}